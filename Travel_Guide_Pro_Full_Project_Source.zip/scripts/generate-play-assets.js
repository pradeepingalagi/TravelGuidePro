import fs from 'node:fs';
import path from 'node:path';
import sharp from 'sharp';

const outputDir = path.resolve('public');
if (!fs.existsSync(outputDir)) {
  fs.mkdirSync(outputDir, { recursive: true });
}

// Read the real 512x512 App Icon as base64 for embedding directly inside screenshots
const iconPath = path.join(outputDir, 'play-icon-512.png');
const iconBase64 = fs.existsSync(iconPath)
  ? `data:image/png;base64,${fs.readFileSync(iconPath).toString('base64')}`
  : '';

// ============================================================================
// 1. Phone Frame Template: 1080 x 1920 (Exact 9:16 Portrait)
// ============================================================================
function makePhoneScreenshotSvg({
  badgeText,
  headline,
  subtitle,
  themeColor = '#38bdf8',
  activeNavIndex = 0, // 0: Home, 1: Translate, 2: SOS, 3: Intelligence, 4: AI Agent
  renderContent,
}) {
  return `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1080 1920" width="1080" height="1920">
  <defs>
    <!-- Background Gradient -->
    <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#020617" />
      <stop offset="40%" stop-color="#0b1329" />
      <stop offset="100%" stop-color="#020617" />
    </linearGradient>

    <!-- Top Ambient Radial Glow -->
    <radialGradient id="topGlow" cx="50%" cy="10%" r="45%">
      <stop offset="0%" stop-color="${themeColor}" stop-opacity="0.28" />
      <stop offset="60%" stop-color="${themeColor}" stop-opacity="0.06" />
      <stop offset="100%" stop-color="#020617" stop-opacity="0" />
    </radialGradient>

    <!-- Smartphone Titanium Bezel Gradient -->
    <linearGradient id="deviceBorder" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#475569" />
      <stop offset="50%" stop-color="#1e293b" />
      <stop offset="100%" stop-color="#334155" />
    </linearGradient>

    <!-- Shadow for device -->
    <filter id="phoneShadow" x="-15%" y="-15%" width="130%" height="130%">
      <feDropShadow dx="0" dy="28" stdDeviation="35" flood-color="#000000" flood-opacity="0.85" />
    </filter>
  </defs>

  <!-- Background Canvas -->
  <rect width="1080" height="1920" fill="url(#bgGrad)" />
  <rect width="1080" height="1920" fill="url(#topGlow)" />

  <!-- Top Marketing Typography Banner -->
  <g transform="translate(60, 75)">
    <!-- Pill Badge with App Name -->
    <rect x="0" y="0" width="310" height="38" rx="19" fill="#0f172a" stroke="${themeColor}" stroke-width="1.5" />
    <text x="155" y="24" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" font-size="12" font-weight="800" fill="${themeColor}" text-anchor="middle" letter-spacing="2">${badgeText}</text>

    <!-- Headline -->
    <text x="0" y="85" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" font-size="46" font-weight="900" fill="#ffffff" letter-spacing="-1">${headline}</text>

    <!-- Subtitle -->
    <text x="0" y="128" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" font-size="20" font-weight="500" fill="#94a3b8">${subtitle}</text>
  </g>

  <!-- High-Fidelity Smartphone Shell (840 x 1560) -->
  <g transform="translate(120, 255)" filter="url(#phoneShadow)">
    <!-- Outer Titanium Bezel -->
    <rect x="0" y="0" width="840" height="1560" rx="54" fill="#020617" stroke="url(#deviceBorder)" stroke-width="7" />
    
    <!-- Screen Viewport Inner Area -->
    <rect x="14" y="14" width="812" height="1532" rx="44" fill="#020617" />

    <!-- Dynamic Island / Top Camera Punch-hole -->
    <rect x="330" y="24" width="180" height="30" rx="15" fill="#000000" />
    <circle cx="475" cy="39" r="4.5" fill="#1e293b" />

    <!-- In-App Status Bar -->
    <text x="60" y="46" font-family="sans-serif" font-size="14" font-weight="600" fill="#94a3b8">9:41</text>
    <g transform="translate(730, 35)" fill="#94a3b8">
      <rect x="0" y="0" width="24" height="12" rx="3" fill="none" stroke="#94a3b8" stroke-width="1.5" />
      <rect x="2" y="2" width="16" height="8" rx="1" fill="#94a3b8" />
      <rect x="25" y="3" width="2" height="6" fill="#94a3b8" />
    </g>

    <!-- EXACT TravelPro AI Header (Row 1: Logo &amp; Name | Row 2: Tagline on Next Line) -->
    <g transform="translate(32, 68)">
      <!-- Row 1 Left: Logo &amp; Title -->
      <g transform="translate(0, 0)">
        ${iconBase64 ? `<image href="${iconBase64}" x="0" y="0" width="46" height="46" rx="12" />` : `<rect x="0" y="0" width="46" height="46" rx="12" fill="#0369a1" />`}
        <text x="56" y="31" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" font-size="24" font-weight="900" fill="#ffffff" letter-spacing="-0.5">TravelPro AI</text>
      </g>

      <!-- Row 1 Right: Online Badge + User Profile + Settings Gear (Matching Header.tsx) -->
      <g transform="translate(480, 8)">
        <!-- Online Pill -->
        <rect x="0" y="0" width="100" height="30" rx="15" fill="#0f172a" stroke="#334155" stroke-width="1" />
        <circle cx="16" cy="15" r="4" fill="#10b981" />
        <text x="56" y="20" font-family="sans-serif" font-size="11" font-weight="bold" fill="#38bdf8" text-anchor="middle">ONLINE</text>

        <!-- User Profile Pill -->
        <rect x="110" y="0" width="90" height="30" rx="15" fill="#1e293b" stroke="#334155" stroke-width="1" />
        <circle cx="126" cy="15" r="9" fill="#4338ca" />
        <text x="126" y="19" font-family="sans-serif" font-size="10" fill="#ffffff" text-anchor="middle">👤</text>
        <text x="160" y="20" font-family="sans-serif" font-size="11" font-weight="bold" fill="#cbd5e1" text-anchor="middle">User</text>

        <!-- Settings Gear -->
        <circle cx="230" cy="15" r="15" fill="#0f172a" stroke="#334155" stroke-width="1" />
        <text x="230" y="20" font-family="sans-serif" font-size="14" fill="#94a3b8" text-anchor="middle">⚙️</text>
      </g>

      <!-- Row 2: Dedicated Tagline Row (Pulled to next line with top border, exactly matches Header.tsx) -->
      <line x1="0" y1="56" x2="748" y2="56" stroke="#1e293b" stroke-width="1" />
      <text x="0" y="74" font-family="-apple-system, BlinkMacSystemFont, sans-serif" font-size="13" font-weight="600" fill="#2dd4bf" letter-spacing="0.2">Translate. Explore. Navigate. Travel with confidence.</text>
    </g>

    <!-- Screen Feature Content -->
    <g transform="translate(0, 160)">
      ${renderContent}
    </g>

    <!-- EXACT App Bottom Navigation Bar (5 Items: Home, Translate, SOS, Intelligence, AI Agent) -->
    <g transform="translate(14, 1420)">
      <rect x="0" y="0" width="812" height="112" fill="#020617" opacity="0.98" />
      <line x1="0" y1="0" x2="812" y2="0" stroke="#1e293b" stroke-width="1" />

      <!-- Tab 1: Home -->
      <g transform="translate(85, 34)">
        <text x="0" y="0" font-family="sans-serif" font-size="22" text-anchor="middle">🏠</text>
        <text x="0" y="24" font-family="sans-serif" font-size="11" font-weight="${activeNavIndex === 0 ? 'bold' : '600'}" fill="${activeNavIndex === 0 ? '#38bdf8' : '#64748b'}" text-anchor="middle">Home</text>
      </g>

      <!-- Tab 2: Translate -->
      <g transform="translate(235, 34)">
        <text x="0" y="0" font-family="sans-serif" font-size="22" text-anchor="middle">💬</text>
        <text x="0" y="24" font-family="sans-serif" font-size="11" font-weight="${activeNavIndex === 1 ? 'bold' : '600'}" fill="${activeNavIndex === 1 ? '#38bdf8' : '#64748b'}" text-anchor="middle">Translate</text>
      </g>

      <!-- Tab 3: SOS Center Button (Raised Red Circle) -->
      <g transform="translate(406, 12)">
        <circle cx="0" cy="0" r="28" fill="#ef4444" filter="drop-shadow(0 6px 12px rgba(239,68,68,0.5))" />
        <text x="0" y="8" font-family="sans-serif" font-size="22" fill="#ffffff" text-anchor="middle">🚨</text>
        <text x="0" y="46" font-family="sans-serif" font-size="11" font-weight="bold" fill="#f87171" text-anchor="middle">SOS</text>
      </g>

      <!-- Tab 4: Intelligence -->
      <g transform="translate(577, 34)">
        <text x="0" y="0" font-family="sans-serif" font-size="22" text-anchor="middle">🧭</text>
        <text x="0" y="24" font-family="sans-serif" font-size="11" font-weight="${activeNavIndex === 3 ? 'bold' : '600'}" fill="${activeNavIndex === 3 ? '#38bdf8' : '#64748b'}" text-anchor="middle">Intelligence</text>
      </g>

      <!-- Tab 5: AI Agent -->
      <g transform="translate(727, 34)">
        <text x="0" y="0" font-family="sans-serif" font-size="22" text-anchor="middle">🤖</text>
        <text x="0" y="24" font-family="sans-serif" font-size="11" font-weight="${activeNavIndex === 4 ? 'bold' : '600'}" fill="${activeNavIndex === 4 ? '#38bdf8' : '#64748b'}" text-anchor="middle">AI Agent</text>
      </g>

      <!-- Home bar indicator -->
      <rect x="296" y="96" width="220" height="4.5" rx="2.2" fill="#64748b" />
    </g>
  </g>
</svg>
`;
}

// ============================================================================
// 2. Phone Screenshot 1: Home Dashboard Screen (HomeScreen.tsx)
// ============================================================================
const screenshot1Svg = makePhoneScreenshotSvg({
  badgeText: 'TRAVELPRO AI DASHBOARD',
  headline: 'TravelPro AI — Travel Dashboard',
  subtitle: 'Translate. Explore. Navigate. Travel with confidence.',
  themeColor: '#2dd4bf',
  activeNavIndex: 0,
  renderContent: `
    <!-- Top Destination &amp; Location Hero Hub Card (Matches HomeScreen.tsx) -->
    <g transform="translate(32, 0)">
      <rect x="0" y="0" width="748" height="210" rx="24" fill="#022c22" stroke="#059669" stroke-width="2" />
      
      <!-- Top Subhead &amp; Live Ping -->
      <g transform="translate(24, 26)">
        <circle cx="8" cy="8" r="6" fill="#34d399" />
        <circle cx="8" cy="8" r="10" fill="none" stroke="#34d399" stroke-width="1.5" opacity="0.6" />
        <text x="24" y="12" font-family="sans-serif" font-size="12" font-weight="bold" fill="#34d399" letter-spacing="1">CURRENT DESTINATION &amp; TRAVEL INTEL</text>
      </g>

      <!-- City, Country, and Location Badge -->
      <g transform="translate(24, 60)">
        <text x="0" y="32" font-family="sans-serif" font-size="34">🇯🇵</text>
        <text x="48" y="32" font-family="-apple-system, BlinkMacSystemFont, sans-serif" font-size="28" font-weight="900" fill="#ffffff">Tokyo</text>
        
        <!-- Country Pill -->
        <rect x="145" y="10" width="72" height="26" rx="13" fill="#064e3b" stroke="#059669" stroke-width="1" />
        <text x="181" y="27" font-family="sans-serif" font-size="12" font-weight="bold" fill="#a7f3d0" text-anchor="middle">Japan</text>

        <!-- Location Badge Pill -->
        <rect x="230" y="10" width="270" height="26" rx="13" fill="#065f46" stroke="#10b981" stroke-width="1" />
        <text x="245" y="27" font-family="sans-serif" font-size="11" font-weight="bold" fill="#34d399">📍 Destination based on your location</text>
      </g>

      <!-- Weather &amp; Emergency -->
      <g transform="translate(24, 120)">
        <text x="0" y="20" font-family="sans-serif" font-size="14" fill="#d1fae5">⛅ 19°C (Partly Cloudy) • Emergency: <tspan fill="#f87171" font-weight="bold">110 / 119</tspan></text>
      </g>

      <line x1="24" y1="155" x2="724" y2="155" stroke="#065f46" stroke-width="1" />

      <!-- Default Language &amp; Route -->
      <g transform="translate(24, 184)">
        <text x="0" y="0" font-family="sans-serif" font-size="13" font-weight="bold" fill="#6ee7b7">You Speak: 🇬🇧 English (EN)  ⇄  Destination: 🇯🇵 Japanese (JA)</text>
      </g>
    </g>

    <!-- Section 1: Translation Hub Feature (3 Cards) -->
    <g transform="translate(32, 230)">
      <text x="0" y="20" font-family="sans-serif" font-size="13" font-weight="bold" fill="#94a3b8" letter-spacing="1">FEATURE 1: TRANSLATION HUB</text>

      <g transform="translate(0, 32)">
        <!-- Card 1: Voice Hub -->
        <rect x="0" y="0" width="236" height="170" rx="20" fill="#0f172a" stroke="#4f46e5" stroke-width="2" />
        <rect x="20" y="20" width="44" height="44" rx="12" fill="#312e81" />
        <text x="42" y="48" font-family="sans-serif" font-size="22" text-anchor="middle">🎙️</text>
        <text x="20" y="94" font-family="sans-serif" font-size="15" font-weight="bold" fill="#ffffff">Live Voice</text>
        <text x="20" y="116" font-family="sans-serif" font-size="15" font-weight="bold" fill="#ffffff">Conversation</text>
        <text x="20" y="142" font-family="sans-serif" font-size="11" fill="#94a3b8">Bilingual 2-Way Speech</text>

        <!-- Card 2: Camera OCR -->
        <rect x="256" y="0" width="236" height="170" rx="20" fill="#0f172a" stroke="#0891b2" stroke-width="2" />
        <rect x="276" y="20" width="44" height="44" rx="12" fill="#155e75" />
        <text x="298" y="48" font-family="sans-serif" font-size="22" text-anchor="middle">📸</text>
        <text x="276" y="94" font-family="sans-serif" font-size="15" font-weight="bold" fill="#ffffff">Camera &amp; Sign</text>
        <text x="276" y="116" font-family="sans-serif" font-size="15" font-weight="bold" fill="#ffffff">Translate OCR</text>
        <text x="276" y="142" font-family="sans-serif" font-size="11" fill="#94a3b8">Menus &amp; Transit Boards</text>

        <!-- Card 3: Smart Text -->
        <rect x="512" y="0" width="236" height="170" rx="20" fill="#0f172a" stroke="#2563eb" stroke-width="2" />
        <rect x="532" y="20" width="44" height="44" rx="12" fill="#1e3a8a" />
        <text x="554" y="48" font-family="sans-serif" font-size="22" text-anchor="middle">✍️</text>
        <text x="532" y="94" font-family="sans-serif" font-size="15" font-weight="bold" fill="#ffffff">Text &amp; Paste</text>
        <text x="532" y="116" font-family="sans-serif" font-size="15" font-weight="bold" fill="#ffffff">Translation</text>
        <text x="532" y="142" font-family="sans-serif" font-size="11" fill="#94a3b8">Smart Typist &amp; Audio</text>
      </g>
    </g>

    <!-- Section 2: Feature 2 Travel Intelligence Preview -->
    <g transform="translate(32, 455)">
      <text x="0" y="20" font-family="sans-serif" font-size="13" font-weight="bold" fill="#94a3b8" letter-spacing="1">FEATURE 2: TRAVEL INTELLIGENCE</text>

      <g transform="translate(0, 32)">
        <!-- Hospital Card -->
        <rect x="0" y="0" width="362" height="175" rx="20" fill="#0f172a" stroke="#ef4444" stroke-width="1.5" />
        <g transform="translate(20, 22)">
          <text x="0" y="24" font-family="sans-serif" font-size="22">🏥</text>
          <text x="36" y="20" font-family="sans-serif" font-size="14" font-weight="bold" fill="#ffffff">Nearest Emergency Care</text>
          <text x="0" y="60" font-family="sans-serif" font-size="15" font-weight="900" fill="#f8fafc">St. Luke's Hospital</text>
          <text x="0" y="85" font-family="sans-serif" font-size="12" fill="#94a3b8">📍 0.4 km away • 5 min walk</text>
          <rect x="0" y="102" width="135" height="26" rx="13" fill="#065f46" />
          <text x="67" y="119" font-family="sans-serif" font-size="11" font-weight="bold" fill="#34d399" text-anchor="middle">🟢 Open 24/7 ER</text>
        </g>

        <!-- Document Vault Card -->
        <rect x="386" y="0" width="362" height="175" rx="20" fill="#0f172a" stroke="#3b82f6" stroke-width="1.5" />
        <g transform="translate(20, 22)">
          <text x="0" y="24" font-family="sans-serif" font-size="22">📁</text>
          <text x="36" y="20" font-family="sans-serif" font-size="14" font-weight="bold" fill="#ffffff">Travel Documents Vault</text>
          <text x="0" y="60" font-family="sans-serif" font-size="15" font-weight="900" fill="#f8fafc">Passports &amp; Visas</text>
          <text x="0" y="85" font-family="sans-serif" font-size="12" fill="#94a3b8">Encrypted Offline Storage</text>
          <rect x="0" y="102" width="155" height="26" rx="13" fill="#1e3a8a" />
          <text x="77" y="119" font-family="sans-serif" font-size="11" font-weight="bold" fill="#93c5fd" text-anchor="middle">🔒 100% Offline Access</text>
        </g>
      </g>
    </g>

    <!-- Section 3: Feature 3 AI Travel Agent Action Chips -->
    <g transform="translate(32, 685)">
      <text x="0" y="20" font-family="sans-serif" font-size="13" font-weight="bold" fill="#94a3b8" letter-spacing="1">FEATURE 3: AI TRAVEL COPILOT</text>
      
      <g transform="translate(0, 32)">
        <rect x="0" y="0" width="236" height="80" rx="18" fill="#1e1b4b" stroke="#6366f1" stroke-width="1.5" />
        <text x="18" y="32" font-family="sans-serif" font-size="20">✈️</text>
        <text x="50" y="30" font-family="sans-serif" font-size="13" font-weight="bold" fill="#ffffff">Flight Copilot</text>
        <text x="50" y="52" font-family="sans-serif" font-size="11" fill="#c7d2fe">Delay &amp; EU261 Rights</text>

        <rect x="256" y="0" width="236" height="80" rx="18" fill="#042f2e" stroke="#14b8a6" stroke-width="1.5" />
        <text x="18" y="32" font-family="sans-serif" font-size="20">🚖</text>
        <text x="50" y="30" font-family="sans-serif" font-size="13" font-weight="bold" fill="#ffffff">Hotel Taxi Card</text>
        <text x="50" y="52" font-family="sans-serif" font-size="11" fill="#99f6e4">Native Driver Kanji</text>

        <rect x="512" y="0" width="236" height="80" rx="18" fill="#451a03" stroke="#f59e0b" stroke-width="1.5" />
        <text x="18" y="32" font-family="sans-serif" font-size="20">🛡️</text>
        <text x="50" y="30" font-family="sans-serif" font-size="13" font-weight="bold" fill="#ffffff">Scam Guard</text>
        <text x="50" y="52" font-family="sans-serif" font-size="11" fill="#fde68a">Verify Tourist Fares</text>
      </g>
    </g>
  `,
});

// ============================================================================
// 3. Phone Screenshot 2: Real-Time 2-Way Voice Hub (TranslateHubScreen.tsx)
// ============================================================================
const screenshot2Svg = makePhoneScreenshotSvg({
  badgeText: 'REAL-TIME 2-WAY SPEECH',
  headline: 'TravelPro AI — Voice Hub',
  subtitle: 'Speak naturally in 100+ languages with automatic accent detection',
  themeColor: '#6366f1',
  activeNavIndex: 1,
  renderContent: `
    <!-- Sub-Mode Ribbon (Exact match to TranslateHubScreen.tsx) -->
    <g transform="translate(32, 0)">
      <rect x="0" y="0" width="180" height="42" rx="21" fill="#4f46e5" />
      <text x="90" y="26" font-family="sans-serif" font-size="13" font-weight="bold" fill="#ffffff" text-anchor="middle">💬 Live Voice</text>

      <rect x="190" y="0" width="170" height="42" rx="21" fill="#1e293b" stroke="#334155" stroke-width="1" />
      <text x="275" y="26" font-family="sans-serif" font-size="13" font-weight="600" fill="#94a3b8" text-anchor="middle">📸 Camera OCR</text>

      <rect x="370" y="0" width="165" height="42" rx="21" fill="#1e293b" stroke="#334155" stroke-width="1" />
      <text x="452" y="26" font-family="sans-serif" font-size="13" font-weight="600" fill="#94a3b8" text-anchor="middle">✍️ Text &amp; Paste</text>

      <rect x="545" y="0" width="95" height="42" rx="21" fill="#1e293b" stroke="#ef4444" stroke-width="1" />
      <text x="592" y="26" font-family="sans-serif" font-size="13" font-weight="bold" fill="#f87171" text-anchor="middle">🚨 SOS</text>

      <!-- Auxiliary Tools -->
      <text x="665" y="26" font-family="sans-serif" font-size="18">🧭</text>
      <text x="705" y="26" font-family="sans-serif" font-size="18">⬇️</text>
    </g>

    <!-- Language Selector Header Bar -->
    <g transform="translate(32, 60)">
      <rect x="0" y="0" width="748" height="68" rx="20" fill="#0f172a" stroke="#334155" stroke-width="1.5" />
      
      <!-- Source Lang: English -->
      <g transform="translate(24, 18)">
        <text x="0" y="24" font-family="sans-serif" font-size="22">🇬🇧</text>
        <text x="36" y="24" font-family="sans-serif" font-size="17" font-weight="bold" fill="#ffffff">English (You Speak)</text>
      </g>

      <!-- Center Swap Icon -->
      <g transform="translate(374, 34)">
        <circle cx="0" cy="0" r="20" fill="#1e293b" stroke="#475569" stroke-width="1" />
        <text x="0" y="6" font-family="sans-serif" font-size="16" fill="#38bdf8" text-anchor="middle">⇄</text>
      </g>

      <!-- Target Lang: Japanese -->
      <g transform="translate(530, 18)">
        <text x="0" y="24" font-family="sans-serif" font-size="22">🇯🇵</text>
        <text x="36" y="24" font-family="sans-serif" font-size="17" font-weight="bold" fill="#2dd4bf">Japanese</text>
      </g>
    </g>

    <!-- Chat Exchange: Bubble 1 (User Speaking English) -->
    <g transform="translate(32, 150)">
      <rect x="0" y="0" width="748" height="240" rx="26" fill="#1e1b4b" stroke="#6366f1" stroke-width="2" />
      
      <g transform="translate(24, 28)">
        <rect x="0" y="0" width="110" height="28" rx="14" fill="#312e81" />
        <text x="55" y="19" font-family="sans-serif" font-size="12" font-weight="bold" fill="#c7d2fe" text-anchor="middle">You (English)</text>
        <text x="0" y="68" font-family="sans-serif" font-size="22" font-weight="700" fill="#ffffff">"Excuse me, where is the nearest metro station?"</text>
      </g>

      <line x1="24" y1="126" x2="724" y2="126" stroke="#312e81" stroke-width="1" />

      <g transform="translate(24, 150)">
        <text x="0" y="22" font-family="sans-serif" font-size="14" font-weight="bold" fill="#2dd4bf">🇯🇵 Japanese Translation:</text>
        <text x="0" y="52" font-family="'Noto Sans JP', sans-serif" font-size="20" font-weight="bold" fill="#f8fafc">すみません、最寄りの地下鉄の駅はどこですか？</text>
        <text x="0" y="78" font-family="sans-serif" font-size="13" font-style="italic" fill="#94a3b8">Sumimasen, moyori no chikatetsu no eki wa doko desu ka?</text>
      </g>
    </g>

    <!-- Chat Exchange: Bubble 2 (Local Partner Replying in Japanese) -->
    <g transform="translate(32, 415)">
      <rect x="0" y="0" width="748" height="250" rx="26" fill="#042f2e" stroke="#14b8a6" stroke-width="2" />
      
      <g transform="translate(24, 28)">
        <rect x="0" y="0" width="130" height="28" rx="14" fill="#134e4a" />
        <text x="65" y="19" font-family="sans-serif" font-size="12" font-weight="bold" fill="#99f6e4" text-anchor="middle">Local Partner (🇯🇵)</text>
        <text x="0" y="68" font-family="'Noto Sans JP', sans-serif" font-size="21" font-weight="700" fill="#ffffff">「3番出口を出て、まっすぐ2分歩いたところです。」</text>
      </g>

      <line x1="24" y1="126" x2="724" y2="126" stroke="#115e59" stroke-width="1" />

      <g transform="translate(24, 150)">
        <text x="0" y="22" font-family="sans-serif" font-size="14" font-weight="bold" fill="#67e8f9">🇬🇧 English Translation:</text>
        <text x="0" y="54" font-family="sans-serif" font-size="21" font-weight="bold" fill="#f0fdfa">"Take exit 3 and walk straight ahead for 2 minutes."</text>
        <text x="0" y="80" font-family="sans-serif" font-size="13" fill="#5eead4">🔊 Auto-spoken with native pronunciation</text>
      </g>
    </g>

    <!-- Live Audio Waveform &amp; Big Glowing Mic Button -->
    <g transform="translate(32, 695)">
      <!-- Audio Waveform Visualization -->
      <g transform="translate(140, 45)" stroke="#38bdf8" stroke-width="5" stroke-linecap="round">
        <line x1="0" y1="0" x2="0" y2="30" />
        <line x1="18" y1="-15" x2="18" y2="45" />
        <line x1="36" y1="-30" x2="36" y2="60" />
        <line x1="54" y1="-45" x2="54" y2="75" stroke="#2dd4bf" />
        <line x1="72" y1="-20" x2="72" y2="50" />
        <line x1="90" y1="-5" x2="90" y2="35" />
        <line x1="378" y1="-5" x2="378" y2="35" />
        <line x1="396" y1="-20" x2="396" y2="50" />
        <line x1="414" y1="-45" x2="414" y2="75" stroke="#2dd4bf" />
        <line x1="432" y1="-30" x2="432" y2="60" />
        <line x1="450" y1="-15" x2="450" y2="45" />
        <line x1="468" y1="0" x2="468" y2="30" />
      </g>

      <!-- Center Big Microphone Button -->
      <g transform="translate(374, 50)">
        <circle cx="0" cy="0" r="64" fill="#6366f1" opacity="0.25" />
        <circle cx="0" cy="0" r="54" fill="url(#bgGrad)" stroke="#6366f1" stroke-width="3" />
        <circle cx="0" cy="0" r="44" fill="#4f46e5" />
        <text x="0" y="14" font-family="sans-serif" font-size="36" text-anchor="middle">🎙️</text>
      </g>
      <text x="374" y="140" font-family="sans-serif" font-size="16" font-weight="bold" fill="#38bdf8" text-anchor="middle">Tap to Speak (Hands-Free Loop)</text>
    </g>
  `,
});

// ============================================================================
// 4. Phone Screenshot 3: Instant Camera OCR &amp; Sign Scanner (CameraTranslateScreen.tsx)
// ============================================================================
const screenshot3Svg = makePhoneScreenshotSvg({
  badgeText: 'INSTANT CAMERA OCR',
  headline: 'TravelPro AI — Camera &amp; Sign OCR',
  subtitle: 'Point camera at street signs, subway maps &amp; foreign restaurant menus',
  themeColor: '#06b6d4',
  activeNavIndex: 1,
  renderContent: `
    <!-- Sub-Mode Ribbon (Camera Active) -->
    <g transform="translate(32, 0)">
      <rect x="0" y="0" width="165" height="42" rx="21" fill="#1e293b" stroke="#334155" stroke-width="1" />
      <text x="82" y="26" font-family="sans-serif" font-size="13" font-weight="600" fill="#94a3b8" text-anchor="middle">💬 Live Voice</text>

      <rect x="175" y="0" width="195" height="42" rx="21" fill="#0891b2" />
      <text x="272" y="26" font-family="sans-serif" font-size="13" font-weight="bold" fill="#ffffff" text-anchor="middle">📸 Camera OCR</text>

      <rect x="380" y="0" width="180" height="42" rx="21" fill="#1e293b" stroke="#334155" stroke-width="1" />
      <text x="470" y="26" font-family="sans-serif" font-size="13" font-weight="600" fill="#94a3b8" text-anchor="middle">✍️ Text &amp; Paste</text>

      <rect x="570" y="0" width="100" height="42" rx="21" fill="#1e293b" stroke="#ef4444" stroke-width="1" />
      <text x="620" y="26" font-family="sans-serif" font-size="13" font-weight="bold" fill="#f87171" text-anchor="middle">🚨 SOS</text>
    </g>

    <!-- Simulated Live Camera Viewfinder (Authentic Real-Time OCR Scan) -->
    <g transform="translate(32, 60)">
      <rect x="0" y="0" width="748" height="660" rx="26" fill="#030712" stroke="#0891b2" stroke-width="2.5" />
      
      <!-- Realistic Tokyo Subway &amp; Street Sign Scene Background -->
      <g opacity="0.25">
        <rect x="60" y="60" width="628" height="180" rx="16" fill="#1e293b" />
        <rect x="60" y="270" width="628" height="260" rx="16" fill="#1e293b" />
      </g>

      <!-- Viewfinder 4 Corner Brackets -->
      <path d="M 30,70 L 30,30 L 70,30" fill="none" stroke="#22d3ee" stroke-width="4.5" stroke-linecap="round" />
      <path d="M 718,70 L 718,30 L 678,30" fill="none" stroke="#22d3ee" stroke-width="4.5" stroke-linecap="round" />
      <path d="M 30,590 L 30,630 L 70,630" fill="none" stroke="#22d3ee" stroke-width="4.5" stroke-linecap="round" />
      <path d="M 718,590 L 718,630 L 678,630" fill="none" stroke="#22d3ee" stroke-width="4.5" stroke-linecap="round" />

      <!-- OCR Bounding Box 1: Tokyo Subway Sign -->
      <g transform="translate(60, 60)">
        <rect x="0" y="0" width="628" height="150" rx="16" fill="#083344" stroke="#22d3ee" stroke-width="2" opacity="0.9" />
        <text x="24" y="44" font-family="'Noto Sans JP', sans-serif" font-size="28" font-weight="bold" fill="#67e8f9">地下鉄・銀座線 渋谷方面</text>
        <line x1="24" y1="62" x2="604" y2="62" stroke="#155e75" stroke-width="1" />
        <text x="24" y="98" font-family="sans-serif" font-size="14" font-weight="bold" fill="#38bdf8">TRANSLATED TO ENGLISH:</text>
        <text x="24" y="128" font-family="sans-serif" font-size="22" font-weight="900" fill="#ffffff">Subway: Ginza Line (To Shibuya)</text>
      </g>

      <!-- OCR Bounding Box 2: Japanese Restaurant Menu Item -->
      <g transform="translate(60, 240)">
        <rect x="0" y="0" width="628" height="150" rx="16" fill="#042f2e" stroke="#2dd4bf" stroke-width="2" opacity="0.9" />
        <text x="24" y="44" font-family="'Noto Sans JP', sans-serif" font-size="28" font-weight="bold" fill="#5eead4">特製 濃厚 豚骨ラーメン ¥980</text>
        <line x1="24" y1="62" x2="604" y2="62" stroke="#115e59" stroke-width="1" />
        <text x="24" y="98" font-family="sans-serif" font-size="14" font-weight="bold" fill="#2dd4bf">TRANSLATED TO ENGLISH:</text>
        <text x="24" y="128" font-family="sans-serif" font-size="22" font-weight="900" fill="#ffffff">Signature Rich Pork Ramen ($6.45)</text>
      </g>

      <!-- OCR Bounding Box 3: Emergency Exit Notice -->
      <g transform="translate(60, 420)">
        <rect x="0" y="0" width="628" height="140" rx="16" fill="#1e1b4b" stroke="#818cf8" stroke-width="2" opacity="0.9" />
        <text x="24" y="44" font-family="'Noto Sans JP', sans-serif" font-size="26" font-weight="bold" fill="#c7d2fe">非常口・避難経路案内</text>
        <line x1="24" y1="60" x2="604" y2="60" stroke="#312e81" stroke-width="1" />
        <text x="24" y="92" font-family="sans-serif" font-size="14" font-weight="bold" fill="#a5b4fc">TRANSLATED TO ENGLISH:</text>
        <text x="24" y="122" font-family="sans-serif" font-size="20" font-weight="900" fill="#ffffff">Emergency Exit &amp; Evacuation Route</text>
      </g>

      <!-- Shutter Action Bar at Bottom of Camera Screen -->
      <g transform="translate(0, 580)">
        <rect x="0" y="0" width="748" height="80" rx="0" fill="#020617" opacity="0.85" />
        <!-- Flash icon -->
        <text x="120" y="48" font-family="sans-serif" font-size="24" text-anchor="middle">⚡</text>
        <!-- Center Shutter circle -->
        <circle cx="374" cy="40" r="30" fill="#ffffff" stroke="#0891b2" stroke-width="4" />
        <!-- Zoom pill -->
        <rect x="580" y="24" width="80" height="32" rx="16" fill="#1e293b" />
        <text x="620" y="45" font-family="sans-serif" font-size="14" font-weight="bold" fill="#ffffff" text-anchor="middle">1x</text>
      </g>
    </g>

    <!-- Real-Time OCR Status Banner -->
    <g transform="translate(32, 740)">
      <rect x="0" y="0" width="748" height="85" rx="20" fill="#0f172a" stroke="#1e293b" stroke-width="1.5" />
      <g transform="translate(24, 26)">
        <text x="0" y="24" font-family="sans-serif" font-size="22">✨</text>
        <text x="36" y="18" font-family="sans-serif" font-size="16" font-weight="bold" fill="#ffffff">Live Multimodal OCR Active</text>
        <text x="36" y="42" font-family="sans-serif" font-size="13" fill="#94a3b8">Signs, menus, and receipts auto-detected instantly</text>
      </g>
    </g>
  `,
});

// ============================================================================
// 5. Phone Screenshot 4: Travel Intelligence &amp; Safety Radar (TravelIntelligenceScreen.tsx)
// ============================================================================
const screenshot4Svg = makePhoneScreenshotSvg({
  badgeText: 'LOCAL DESTINATION RADAR',
  headline: 'TravelPro AI — Safety &amp; Intel',
  subtitle: 'Auto-detected city radar, emergency hotlines, currency conversion &amp; hospitals',
  themeColor: '#10b981',
  activeNavIndex: 3,
  renderContent: `
    <!-- Destination City &amp; Weather Card -->
    <g transform="translate(32, 0)">
      <rect x="0" y="0" width="748" height="150" rx="24" fill="#022c22" stroke="#059669" stroke-width="2" />
      
      <g transform="translate(26, 32)">
        <text x="0" y="32" font-family="sans-serif" font-size="34">🇯🇵</text>
        <text x="50" y="25" font-family="-apple-system, BlinkMacSystemFont, sans-serif" font-size="26" font-weight="900" fill="#ffffff">Tokyo, Japan</text>
        <text x="50" y="52" font-family="sans-serif" font-size="14" font-weight="600" fill="#6ee7b7">Primary Language: Japanese (日本語)</text>
      </g>

      <!-- Weather &amp; Local Time Widget on Right -->
      <g transform="translate(560, 32)">
        <text x="0" y="25" font-family="sans-serif" font-size="22" font-weight="900" fill="#ffffff">19°C ⛅</text>
        <text x="0" y="52" font-family="sans-serif" font-size="14" fill="#a7f3d0">14:32 (GMT+9)</text>
      </g>

      <line x1="26" y1="102" x2="722" y2="102" stroke="#065f46" stroke-width="1" />
      <text x="26" y="130" font-family="sans-serif" font-size="13" font-weight="600" fill="#34d399">📍 Auto-detected via GPS: Shinjuku City, Tokyo</text>
    </g>

    <!-- Emergency Services Quick-Dial Strip (3 Emergency Cards) -->
    <g transform="translate(32, 165)">
      <text x="0" y="20" font-family="sans-serif" font-size="13" font-weight="bold" fill="#94a3b8" letter-spacing="1.5">EMERGENCY HOTLINES (JAPAN)</text>

      <g transform="translate(0, 32)">
        <!-- 1. Police -->
        <rect x="0" y="0" width="236" height="85" rx="18" fill="#1e1b4b" stroke="#6366f1" stroke-width="1.5" />
        <text x="18" y="35" font-family="sans-serif" font-size="20">🚔</text>
        <text x="52" y="32" font-family="sans-serif" font-size="14" font-weight="bold" fill="#ffffff">Police</text>
        <text x="18" y="65" font-family="sans-serif" font-size="22" font-weight="900" fill="#818cf8">110</text>

        <!-- 2. Ambulance / Fire -->
        <rect x="256" y="0" width="236" height="85" rx="18" fill="#450a0a" stroke="#ef4444" stroke-width="1.5" />
        <text x="18" y="35" font-family="sans-serif" font-size="20">🚑</text>
        <text x="52" y="32" font-family="sans-serif" font-size="14" font-weight="bold" fill="#ffffff">Ambulance</text>
        <text x="18" y="65" font-family="sans-serif" font-size="22" font-weight="900" fill="#f87171">119</text>

        <!-- 3. Tourist Helpline -->
        <rect x="512" y="0" width="236" height="85" rx="18" fill="#042f2e" stroke="#14b8a6" stroke-width="1.5" />
        <text x="18" y="35" font-family="sans-serif" font-size="20">ℹ️</text>
        <text x="52" y="32" font-family="sans-serif" font-size="14" font-weight="bold" fill="#ffffff">Tourist Line</text>
        <text x="18" y="65" font-family="sans-serif" font-size="16" font-weight="900" fill="#2dd4bf">050-3816</text>
      </g>
    </g>

    <!-- Nearest Hospital &amp; Care Radar Card -->
    <g transform="translate(32, 305)">
      <rect x="0" y="0" width="748" height="150" rx="24" fill="#0f172a" stroke="#334155" stroke-width="1.5" />
      <g transform="translate(24, 28)">
        <text x="0" y="24" font-family="sans-serif" font-size="26">🏥</text>
        <text x="40" y="20" font-family="sans-serif" font-size="18" font-weight="bold" fill="#ffffff">St. Luke's International Hospital</text>
        <text x="40" y="45" font-family="sans-serif" font-size="13" fill="#94a3b8">9-1 Akashi-cho, Chuo-ku, Tokyo • English Speaking</text>
        <line x1="40" y1="62" x2="690" y2="62" stroke="#1e293b" stroke-width="1" />
        <text x="40" y="94" font-family="sans-serif" font-size="14" font-weight="bold" fill="#10b981">🟢 Open 24/7 • 0.4 km away (5 min walk)</text>
      </g>
    </g>

    <!-- Live Currency Radar &amp; Cheat Sheet Card -->
    <g transform="translate(32, 480)">
      <rect x="0" y="0" width="748" height="230" rx="24" fill="#172554" stroke="#3b82f6" stroke-width="1.5" />
      <g transform="translate(24, 28)">
        <text x="0" y="24" font-family="sans-serif" font-size="24">💱</text>
        <text x="36" y="22" font-family="sans-serif" font-size="18" font-weight="bold" fill="#ffffff">Live Currency Converter (ECB Rates)</text>
        <text x="36" y="58" font-family="sans-serif" font-size="26" font-weight="900" fill="#60a5fa">1 USD = 152.40 JPY</text>
      </g>

      <!-- Quick Street Shopping Cheat Sheet -->
      <g transform="translate(24, 110)">
        <rect x="0" y="0" width="220" height="60" rx="14" fill="#1e3a8a" />
        <text x="110" y="26" font-family="sans-serif" font-size="13" fill="#bfdbfe" text-anchor="middle">¥1,000 Yen</text>
        <text x="110" y="48" font-family="sans-serif" font-size="16" font-weight="bold" fill="#ffffff" text-anchor="middle">≈ $6.56 USD</text>

        <rect x="240" y="0" width="220" height="60" rx="14" fill="#1e3a8a" />
        <text x="350" y="26" font-family="sans-serif" font-size="13" fill="#bfdbfe" text-anchor="middle">¥5,000 Yen</text>
        <text x="350" y="48" font-family="sans-serif" font-size="16" font-weight="bold" fill="#ffffff" text-anchor="middle">≈ $32.80 USD</text>

        <rect x="480" y="0" width="220" height="60" rx="14" fill="#1e3a8a" />
        <text x="590" y="26" font-family="sans-serif" font-size="13" fill="#bfdbfe" text-anchor="middle">¥10,000 Yen</text>
        <text x="590" y="48" font-family="sans-serif" font-size="16" font-weight="bold" fill="#ffffff" text-anchor="middle">≈ $65.60 USD</text>
      </g>
    </g>
  `,
});

// ============================================================================
// 6. Tablet Template: 1920 x 1080 (Exact 16:9 Landscape)
// ============================================================================
function makeTabletScreenshotSvg({ badgeText, headline, subtitle, themeColor = '#2dd4bf', renderContent }) {
  return `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 1080" width="1920" height="1080">
  <defs>
    <linearGradient id="tBg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#020617" />
      <stop offset="50%" stop-color="#0b1329" />
      <stop offset="100%" stop-color="#020617" />
    </linearGradient>
    <filter id="tShadow" x="-10%" y="-10%" width="120%" height="120%">
      <feDropShadow dx="0" dy="24" stdDeviation="30" flood-color="#000000" flood-opacity="0.8" />
    </filter>
  </defs>

  <rect width="1920" height="1080" fill="url(#tBg)" />

  <!-- Top Marketing Banner -->
  <g transform="translate(100, 48)">
    <rect x="0" y="0" width="300" height="34" rx="17" fill="#0f172a" stroke="${themeColor}" stroke-width="1.5" />
    <text x="150" y="22" font-family="sans-serif" font-size="12" font-weight="bold" fill="${themeColor}" text-anchor="middle" letter-spacing="2">${badgeText}</text>
    <text x="0" y="80" font-family="-apple-system, BlinkMacSystemFont, sans-serif" font-size="38" font-weight="900" fill="#ffffff">${headline}</text>
    <text x="0" y="112" font-family="-apple-system, BlinkMacSystemFont, sans-serif" font-size="18" font-weight="500" fill="#94a3b8">${subtitle}</text>
  </g>

  <!-- Tablet Frame (1720 x 855) -->
  <g transform="translate(100, 185)" filter="url(#tShadow)">
    <rect x="0" y="0" width="1720" height="855" rx="32" fill="#020617" stroke="#334155" stroke-width="4" />

    <!-- EXACT App Top Navigation Bar (TravelPro AI 2-Row Header) -->
    <rect x="0" y="0" width="1720" height="86" rx="32" fill="#0f172a" />
    <rect x="0" y="44" width="1720" height="42" fill="#0f172a" />
    <line x1="0" y1="86" x2="1720" y2="86" stroke="#1e293b" stroke-width="1.5" />

    <!-- Header Row 1: Logo &amp; App Name -->
    <g transform="translate(36, 12)">
      ${iconBase64 ? `<image href="${iconBase64}" x="0" y="0" width="40" height="40" rx="10" />` : `<rect x="0" y="0" width="40" height="40" rx="10" fill="#0369a1" />`}
      <text x="50" y="27" font-family="-apple-system, BlinkMacSystemFont, sans-serif" font-size="22" font-weight="900" fill="#ffffff">TravelPro AI</text>
    </g>

    <!-- Header Row 1 Right: Status, User, Settings -->
    <g transform="translate(1420, 14)">
      <rect x="0" y="0" width="100" height="32" rx="16" fill="#1e293b" stroke="#334155" stroke-width="1" />
      <circle cx="16" cy="16" r="4.5" fill="#10b981" />
      <text x="56" y="21" font-family="sans-serif" font-size="12" font-weight="bold" fill="#38bdf8" text-anchor="middle">ONLINE</text>

      <rect x="110" y="0" width="100" height="32" rx="16" fill="#1e293b" stroke="#334155" stroke-width="1" />
      <circle cx="126" cy="16" r="8" fill="#4338ca" />
      <text x="126" y="19" font-family="sans-serif" font-size="9" fill="#ffffff" text-anchor="middle">👤</text>
      <text x="160" y="21" font-family="sans-serif" font-size="11" font-weight="bold" fill="#cbd5e1" text-anchor="middle">User</text>

      <circle cx="230" cy="16" r="16" fill="#1e293b" stroke="#334155" stroke-width="1" />
      <text x="230" y="21" font-family="sans-serif" font-size="14" fill="#94a3b8" text-anchor="middle">⚙️</text>
    </g>

    <!-- Header Row 2: Tagline pulled to next line with top border (Matches Header.tsx) -->
    <line x1="36" y1="58" x2="1684" y2="58" stroke="#1e293b" stroke-width="1" />
    <text x="36" y="74" font-family="-apple-system, BlinkMacSystemFont, sans-serif" font-size="13" font-weight="600" fill="#2dd4bf">Translate. Explore. Navigate. Travel with confidence.</text>
    <text x="1684" y="74" font-family="sans-serif" font-size="11" fill="#64748b" text-anchor="end">AI Multimodal Companion</text>

    <!-- Main Tablet Content -->
    ${renderContent}
  </g>
</svg>
`;
}

// ============================================================================
// Tablet 1: Home Dashboard on Large Screen (HomeScreen.tsx)
// ============================================================================
const tabletScreenshot1Svg = makeTabletScreenshotSvg({
  badgeText: 'TRAVELPRO AI TABLET',
  headline: 'TravelPro AI — All-in-One Travel Dashboard',
  subtitle: 'Live destination radar, emergency safety hotlines, and instant language translation',
  themeColor: '#2dd4bf',
  renderContent: `
    <g transform="translate(36, 105)">
      <!-- Left Column: Destination &amp; Location Intel Card (Width 780) -->
      <g transform="translate(0, 0)">
        <rect x="0" y="0" width="790" height="680" rx="24" fill="#022c22" stroke="#059669" stroke-width="2" />
        <g transform="translate(32, 32)">
          <!-- Top Subhead &amp; Live Ping -->
          <circle cx="8" cy="8" r="6" fill="#34d399" />
          <circle cx="8" cy="8" r="10" fill="none" stroke="#34d399" stroke-width="1.5" opacity="0.6" />
          <text x="24" y="12" font-family="sans-serif" font-size="13" font-weight="bold" fill="#34d399" letter-spacing="1">CURRENT DESTINATION &amp; TRAVEL INTEL</text>

          <!-- City &amp; Country -->
          <text x="0" y="60" font-family="sans-serif" font-size="44">🇯🇵</text>
          <text x="60" y="55" font-family="-apple-system, BlinkMacSystemFont, sans-serif" font-size="34" font-weight="900" fill="#ffffff">Tokyo, Japan</text>
          
          <rect x="0" y="85" width="310" height="30" rx="15" fill="#065f46" stroke="#10b981" stroke-width="1" />
          <text x="15" y="105" font-family="sans-serif" font-size="12" font-weight="bold" fill="#34d399">📍 Destination based on your location</text>

          <text x="0" y="150" font-family="sans-serif" font-size="16" fill="#d1fae5">⛅ 19°C (Partly Cloudy) • Local Time: 14:32 (GMT+9)</text>

          <line x1="0" y1="180" x2="726" y2="180" stroke="#065f46" stroke-width="1.5" />

          <!-- Language Route -->
          <text x="0" y="215" font-family="sans-serif" font-size="16" font-weight="bold" fill="#6ee7b7">Bilingual Route: 🇬🇧 English (You Speak) ⇄ 🇯🇵 Japanese (Local)</text>

          <!-- Local Emergency Hotlines -->
          <text x="0" y="270" font-family="sans-serif" font-size="14" font-weight="bold" fill="#94a3b8" letter-spacing="1">EMERGENCY FIRST RESPONDERS (JAPAN):</text>
          
          <g transform="translate(0, 290)">
            <rect x="0" y="0" width="225" height="85" rx="18" fill="#1e1b4b" stroke="#6366f1" stroke-width="1.5" />
            <text x="16" y="34" font-family="sans-serif" font-size="20">🚔</text>
            <text x="50" y="32" font-family="sans-serif" font-size="14" font-weight="bold" fill="#ffffff">Police</text>
            <text x="16" y="65" font-family="sans-serif" font-size="22" font-weight="900" fill="#818cf8">110</text>

            <rect x="250" y="0" width="225" height="85" rx="18" fill="#450a0a" stroke="#ef4444" stroke-width="1.5" />
            <text x="16" y="34" font-family="sans-serif" font-size="20">🚑</text>
            <text x="50" y="32" font-family="sans-serif" font-size="14" font-weight="bold" fill="#ffffff">Ambulance</text>
            <text x="16" y="65" font-family="sans-serif" font-size="22" font-weight="900" fill="#f87171">119</text>

            <rect x="500" y="0" width="225" height="85" rx="18" fill="#042f2e" stroke="#14b8a6" stroke-width="1.5" />
            <text x="16" y="34" font-family="sans-serif" font-size="20">ℹ️</text>
            <text x="50" y="32" font-family="sans-serif" font-size="14" font-weight="bold" fill="#ffffff">Tourist Line</text>
            <text x="16" y="65" font-family="sans-serif" font-size="17" font-weight="900" fill="#2dd4bf">050-3816</text>
          </g>

          <!-- Hospital Card -->
          <g transform="translate(0, 400)">
            <rect x="0" y="0" width="726" height="110" rx="18" fill="#064e3b" stroke="#10b981" stroke-width="1.5" />
            <text x="24" y="35" font-family="sans-serif" font-size="24">🏥</text>
            <text x="60" y="32" font-family="sans-serif" font-size="17" font-weight="bold" fill="#ffffff">St. Luke's International Hospital</text>
            <text x="60" y="58" font-family="sans-serif" font-size="13" fill="#a7f3d0">English Speaking Staff • 0.4 km away (5 min walk)</text>
            <text x="60" y="85" font-family="sans-serif" font-size="13" font-weight="bold" fill="#34d399">🟢 Open 24/7 ER • Direct Call: +81-3-3541-5151</text>
          </g>

          <!-- 3-Day Forecast -->
          <g transform="translate(0, 530)">
            <text x="0" y="20" font-family="sans-serif" font-size="13" font-weight="bold" fill="#94a3b8">3-DAY LOCAL FORECAST:</text>
            <g transform="translate(0, 32)">
              <rect x="0" y="0" width="225" height="50" rx="12" fill="#065f46" />
              <text x="112" y="32" font-family="sans-serif" font-size="14" font-weight="bold" fill="#ffffff" text-anchor="middle">Today: 19°C ⛅</text>

              <rect x="250" y="0" width="225" height="50" rx="12" fill="#065f46" />
              <text x="362" y="32" font-family="sans-serif" font-size="14" font-weight="bold" fill="#ffffff" text-anchor="middle">Tomorrow: 21°C ☀️</text>

              <rect x="500" y="0" width="225" height="50" rx="12" fill="#065f46" />
              <text x="612" y="32" font-family="sans-serif" font-size="14" font-weight="bold" fill="#ffffff" text-anchor="middle">Friday: 18°C 🌧️</text>
            </g>
          </g>
        </g>
      </g>

      <!-- Right Column: Features Hub &amp; Copilot (Width 825) -->
      <g transform="translate(820, 0)">
        <rect x="0" y="0" width="825" height="680" rx="24" fill="#0f172a" stroke="#1e293b" stroke-width="2" />
        <g transform="translate(32, 32)">
          <!-- Feature 1 Title -->
          <text x="0" y="15" font-family="sans-serif" font-size="13" font-weight="bold" fill="#38bdf8" letter-spacing="1">FEATURE 1: MULTIMODAL TRANSLATION HUB</text>

          <!-- 3 Translation Action Cards -->
          <g transform="translate(0, 30)">
            <rect x="0" y="0" width="240" height="150" rx="18" fill="#1e1b4b" stroke="#6366f1" stroke-width="1.5" />
            <text x="20" y="38" font-family="sans-serif" font-size="24">🎙️</text>
            <text x="20" y="75" font-family="sans-serif" font-size="16" font-weight="bold" fill="#ffffff">Live Voice</text>
            <text x="20" y="98" font-family="sans-serif" font-size="16" font-weight="bold" fill="#ffffff">Conversation</text>
            <text x="20" y="126" font-family="sans-serif" font-size="12" fill="#c7d2fe">Bilingual 2-Way Speech</text>

            <rect x="260" y="0" width="240" height="150" rx="18" fill="#083344" stroke="#0891b2" stroke-width="1.5" />
            <text x="20" y="38" font-family="sans-serif" font-size="24">📸</text>
            <text x="280" y="75" font-family="sans-serif" font-size="16" font-weight="bold" fill="#ffffff">Camera OCR</text>
            <text x="280" y="98" font-family="sans-serif" font-size="16" font-weight="bold" fill="#ffffff">Sign Scanner</text>
            <text x="280" y="126" font-family="sans-serif" font-size="12" fill="#67e8f9">Instant AR Overlays</text>

            <rect x="520" y="0" width="240" height="150" rx="18" fill="#172554" stroke="#2563eb" stroke-width="1.5" />
            <text x="20" y="38" font-family="sans-serif" font-size="24">✍️</text>
            <text x="540" y="75" font-family="sans-serif" font-size="16" font-weight="bold" fill="#ffffff">Text &amp; Paste</text>
            <text x="540" y="98" font-family="sans-serif" font-size="16" font-weight="bold" fill="#ffffff">Translation</text>
            <text x="540" y="126" font-family="sans-serif" font-size="12" fill="#bfdbfe">Smart Keyboard &amp; Audio</text>
          </g>

          <line x1="0" y1="210" x2="760" y2="210" stroke="#1e293b" stroke-width="1.5" />

          <!-- Feature 2 &amp; 3 Title -->
          <text x="0" y="240" font-family="sans-serif" font-size="13" font-weight="bold" fill="#f59e0b" letter-spacing="1">FEATURE 2 &amp; 3: DOCUMENTS VAULT &amp; AI COPILOT</text>

          <g transform="translate(0, 255)">
            <!-- Document Vault Banner -->
            <rect x="0" y="0" width="760" height="100" rx="18" fill="#1e293b" stroke="#334155" stroke-width="1.5" />
            <text x="24" y="38" font-family="sans-serif" font-size="24">📁</text>
            <text x="60" y="35" font-family="sans-serif" font-size="16" font-weight="bold" fill="#ffffff">Encrypted Travel Documents Vault</text>
            <text x="60" y="60" font-family="sans-serif" font-size="13" fill="#94a3b8">Passports, visas, flight vouchers, and insurance offline in 1 click.</text>
            <rect x="620" y="20" width="120" height="30" rx="15" fill="#10b981" />
            <text x="680" y="40" font-family="sans-serif" font-size="11" font-weight="bold" fill="#ffffff" text-anchor="middle">🔒 OFFLINE</text>
          </g>

          <!-- 3 AI Copilot Action Cards -->
          <g transform="translate(0, 380)">
            <rect x="0" y="0" width="240" height="150" rx="18" fill="#1e1b4b" stroke="#818cf8" stroke-width="1.5" />
            <text x="20" y="36" font-family="sans-serif" font-size="22">✈️</text>
            <text x="20" y="70" font-family="sans-serif" font-size="15" font-weight="bold" fill="#ffffff">Flight Copilot</text>
            <text x="20" y="94" font-family="sans-serif" font-size="12" fill="#c7d2fe">EU261 delay claims up to €600 cash.</text>

            <rect x="260" y="0" width="240" height="150" rx="18" fill="#042f2e" stroke="#2dd4bf" stroke-width="1.5" />
            <text x="280" y="36" font-family="sans-serif" font-size="22">🚖</text>
            <text x="280" y="70" font-family="sans-serif" font-size="15" font-weight="bold" fill="#ffffff">Hotel Taxi Card</text>
            <text x="280" y="94" font-family="sans-serif" font-size="12" fill="#99f6e4">Bilingual card for driver in native script.</text>

            <rect x="520" y="0" width="240" height="150" rx="18" fill="#451a03" stroke="#f59e0b" stroke-width="1.5" />
            <text x="540" y="36" font-family="sans-serif" font-size="22">🛡️</text>
            <text x="540" y="70" font-family="sans-serif" font-size="15" font-weight="bold" fill="#ffffff">Scam Guard</text>
            <text x="540" y="94" font-family="sans-serif" font-size="12" fill="#fde68a">Verify street taxi &amp; tour fare quotes.</text>
          </g>
        </g>
      </g>
    </g>
  `,
});

// ============================================================================
// Tablet 2: Split-Screen Tabletop Interpreter (FaceToFaceScreen.tsx)
// ============================================================================
const tabletScreenshot2Svg = makeTabletScreenshotSvg({
  badgeText: 'TABLETOP 2-WAY INTERPRETER',
  headline: 'TravelPro AI — Split-Screen Tabletop Mode',
  subtitle: 'Place tablet on table for natural face-to-face conversations across cultures',
  themeColor: '#6366f1',
  renderContent: `
    <g transform="translate(36, 105)">
      <!-- Left Pane: User 1 English 🇬🇧 (Width 805) -->
      <g transform="translate(0, 0)">
        <rect x="0" y="0" width="805" height="680" rx="24" fill="#0f172a" stroke="#4f46e5" stroke-width="2" />
        <g transform="translate(32, 32)">
          <rect x="0" y="0" width="150" height="34" rx="17" fill="#312e81" />
          <text x="75" y="22" font-family="sans-serif" font-size="13" font-weight="bold" fill="#c7d2fe" text-anchor="middle">You (English 🇬🇧)</text>
          
          <text x="0" y="80" font-family="sans-serif" font-size="24" font-weight="bold" fill="#ffffff">"Excuse me, how do I get to Shibuya station?"</text>
          <line x1="0" y1="110" x2="740" y2="110" stroke="#1e293b" stroke-width="1.5" />

          <text x="0" y="150" font-family="sans-serif" font-size="15" font-weight="bold" fill="#2dd4bf">🇯🇵 Japanese Translation (Auto-spoken):</text>
          <text x="0" y="195" font-family="'Noto Sans JP', sans-serif" font-size="26" font-weight="900" fill="#f8fafc">すみません、渋谷駅にはどう行けばいいですか？</text>
          <text x="0" y="235" font-family="sans-serif" font-size="16" font-style="italic" fill="#94a3b8">Sumimasen, Shibuya-eki ni wa dō ikeba ii desu ka?</text>

          <!-- Audio Waveform -->
          <g transform="translate(0, 320)" stroke="#38bdf8" stroke-width="4" stroke-linecap="round">
            <line x1="0" y1="0" x2="0" y2="25" />
            <line x1="16" y1="-10" x2="16" y2="35" />
            <line x1="32" y1="-25" x2="32" y2="50" />
            <line x1="48" y1="-40" x2="48" y2="65" stroke="#2dd4bf" />
            <line x1="64" y1="-15" x2="64" y2="40" />
            <line x1="80" y1="0" x2="80" y2="25" />
          </g>

          <g transform="translate(0, 480)">
            <rect x="0" y="0" width="220" height="54" rx="27" fill="#4f46e5" />
            <text x="110" y="34" font-family="sans-serif" font-size="16" font-weight="bold" fill="#ffffff" text-anchor="middle">🎙️ Tap to Speak</text>
          </g>
        </g>
      </g>

      <!-- Right Pane: Partner Japanese 🇯🇵 (Inverted for Tabletop, Width 805) -->
      <g transform="translate(840, 0)">
        <rect x="0" y="0" width="805" height="680" rx="24" fill="#042f2e" stroke="#14b8a6" stroke-width="2" />
        <g transform="translate(32, 32)">
          <rect x="0" y="0" width="180" height="34" rx="17" fill="#134e4a" />
          <text x="90" y="22" font-family="sans-serif" font-size="13" font-weight="bold" fill="#99f6e4" text-anchor="middle">Partner (Japanese 🇯🇵)</text>
          
          <text x="0" y="80" font-family="'Noto Sans JP', sans-serif" font-size="24" font-weight="bold" fill="#ffffff">「山手線に乗って、2つ目の駅です。」</text>
          <line x1="0" y1="110" x2="740" y2="110" stroke="#115e59" stroke-width="1.5" />

          <text x="0" y="150" font-family="sans-serif" font-size="15" font-weight="bold" fill="#67e8f9">🇬🇧 English Translation (Auto-spoken):</text>
          <text x="0" y="195" font-family="sans-serif" font-size="26" font-weight="900" fill="#f0fdfa">"Take the Yamanote Line, it's the second stop."</text>
          <text x="0" y="235" font-family="sans-serif" font-size="16" fill="#5eead4">🔊 Auto-spoken with native accent</text>

          <!-- Audio Waveform -->
          <g transform="translate(0, 320)" stroke="#2dd4bf" stroke-width="4" stroke-linecap="round">
            <line x1="0" y1="0" x2="0" y2="25" />
            <line x1="16" y1="-10" x2="16" y2="35" />
            <line x1="32" y1="-25" x2="32" y2="50" />
            <line x1="48" y1="-40" x2="48" y2="65" stroke="#38bdf8" />
            <line x1="64" y1="-15" x2="64" y2="40" />
            <line x1="80" y1="0" x2="80" y2="25" />
          </g>

          <g transform="translate(0, 480)">
            <rect x="0" y="0" width="220" height="54" rx="27" fill="#0d9488" />
            <text x="110" y="34" font-family="sans-serif" font-size="16" font-weight="bold" fill="#ffffff" text-anchor="middle">🎙️ 話す (Speak)</text>
          </g>
        </g>
      </g>
    </g>
  `,
});

// ============================================================================
// Tablet 3: Wide-Screen Camera OCR &amp; Sign Analyzer (CameraTranslateScreen.tsx)
// ============================================================================
const tabletScreenshot3Svg = makeTabletScreenshotSvg({
  badgeText: 'VISUAL OCR ON LARGE DISPLAY',
  headline: 'TravelPro AI — Camera &amp; Sign OCR Scanner',
  subtitle: 'Side-by-side scanning of transit boards, restaurant menus, and legal travel docs',
  themeColor: '#06b6d4',
  renderContent: `
    <g transform="translate(36, 105)">
      <!-- Left: Viewfinder Simulator (Width 805) -->
      <g transform="translate(0, 0)">
        <rect x="0" y="0" width="805" height="680" rx="24" fill="#030712" stroke="#0891b2" stroke-width="2" />
        <g transform="translate(40, 50)">
          <!-- Corners -->
          <path d="M 0,40 L 0,0 L 40,0" fill="none" stroke="#22d3ee" stroke-width="4" />
          <path d="M 725,40 L 725,0 L 685,0" fill="none" stroke="#22d3ee" stroke-width="4" />
          <path d="M 0,550 L 0,590 L 40,590" fill="none" stroke="#22d3ee" stroke-width="4" />
          <path d="M 725,550 L 725,590 L 685,590" fill="none" stroke="#22d3ee" stroke-width="4" />

          <!-- Bounding Boxes -->
          <rect x="50" y="60" width="620" height="130" rx="16" fill="#083344" stroke="#22d3ee" stroke-width="2" opacity="0.9" />
          <text x="75" y="110" font-family="'Noto Sans JP', sans-serif" font-size="28" font-weight="bold" fill="#67e8f9">地下鉄・銀座線 渋谷方面</text>
          <text x="75" y="150" font-family="sans-serif" font-size="20" font-weight="bold" fill="#ffffff">Subway: Ginza Line (To Shibuya)</text>

          <rect x="50" y="230" width="620" height="130" rx="16" fill="#042f2e" stroke="#2dd4bf" stroke-width="2" opacity="0.9" />
          <text x="75" y="280" font-family="'Noto Sans JP', sans-serif" font-size="28" font-weight="bold" fill="#5eead4">特製 濃厚 豚骨ラーメン ¥980</text>
          <text x="75" y="320" font-family="sans-serif" font-size="20" font-weight="bold" fill="#ffffff">Special Tonkotsu Ramen ($6.45)</text>
        </g>
      </g>

      <!-- Right: Document Analysis &amp; Translation Breakdown (Width 805) -->
      <g transform="translate(840, 0)">
        <rect x="0" y="0" width="805" height="680" rx="24" fill="#0f172a" stroke="#334155" stroke-width="2" />
        <g transform="translate(40, 40)">
          <text x="0" y="28" font-family="sans-serif" font-size="22" font-weight="bold" fill="#ffffff">📄 Extracted Text Breakdown</text>
          <text x="0" y="58" font-family="sans-serif" font-size="14" fill="#94a3b8">Multimodal OCR recognized 3 signs in camera frame</text>

          <rect x="0" y="85" width="725" height="150" rx="18" fill="#1e293b" />
          <text x="24" y="125" font-family="sans-serif" font-size="15" font-weight="bold" fill="#38bdf8">1. Transit Direction Sign</text>
          <text x="24" y="155" font-family="sans-serif" font-size="17" fill="#ffffff">Japanese: 地下鉄・銀座線</text>
          <text x="24" y="185" font-family="sans-serif" font-size="19" font-weight="bold" fill="#2dd4bf">English: Subway: Ginza Line</text>

          <rect x="0" y="260" width="725" height="150" rx="18" fill="#1e293b" />
          <text x="24" y="300" font-family="sans-serif" font-size="15" font-weight="bold" fill="#38bdf8">2. Menu Item &amp; Price</text>
          <text x="24" y="330" font-family="sans-serif" font-size="17" fill="#ffffff">Japanese: 特製 濃厚 豚骨ラーメン ¥980</text>
          <text x="24" y="360" font-family="sans-serif" font-size="19" font-weight="bold" fill="#2dd4bf">English: Signature Rich Pork Ramen ($6.45)</text>

          <rect x="0" y="440" width="725" height="110" rx="18" fill="#1e1b4b" stroke="#6366f1" stroke-width="1" />
          <text x="24" y="480" font-family="sans-serif" font-size="15" font-weight="bold" fill="#c7d2fe">💡 AI Food &amp; Ingredient Advice:</text>
          <text x="24" y="510" font-family="sans-serif" font-size="14" fill="#e0e7ff">Contains wheat, pork broth, egg, and green scallions.</text>
        </g>
      </g>
    </g>
  `,
});

// ============================================================================
// Tablet 4: Travel Intelligence &amp; AI Copilot Suite (TravelIntelligenceScreen.tsx)
// ============================================================================
const tabletScreenshot4Svg = makeTabletScreenshotSvg({
  badgeText: 'INTELLIGENCE &amp; COPILOT',
  headline: 'TravelPro AI — Safety Radar &amp; AI Copilot',
  subtitle: 'Emergency hospital directory, real-time currency rates, and flight rights copilot',
  themeColor: '#10b981',
  renderContent: `
    <g transform="translate(36, 105)">
      <!-- Left 1: Destination Card (Width 805) -->
      <g transform="translate(0, 0)">
        <rect x="0" y="0" width="805" height="325" rx="24" fill="#022c22" stroke="#059669" stroke-width="2" />
        <g transform="translate(30, 40)">
          <text x="0" y="36" font-family="sans-serif" font-size="42">🇯🇵</text>
          <text x="65" y="32" font-family="-apple-system, BlinkMacSystemFont, sans-serif" font-size="32" font-weight="900" fill="#ffffff">Tokyo, Japan</text>
          <text x="65" y="65" font-family="sans-serif" font-size="16" font-weight="600" fill="#6ee7b7">Primary Language: Japanese (日本語)</text>
          <text x="65" y="95" font-family="sans-serif" font-size="15" fill="#a7f3d0">📍 Shinjuku City • 14:32 (GMT+9) • 19°C ⛅</text>

          <line x1="0" y1="130" x2="745" y2="130" stroke="#065f46" stroke-width="1.5" />
          <text x="0" y="170" font-family="sans-serif" font-size="15" font-weight="bold" fill="#ffffff">Local Emergency Numbers:</text>
          <text x="0" y="210" font-family="sans-serif" font-size="22" font-weight="900" fill="#34d399">🚔 Police: 110  •  🚑 Ambulance: 119  •  ℹ️ Tourist: 050-3816-2787</text>
        </g>
      </g>

      <!-- Right 1: Nearest Medical Care (Width 805) -->
      <g transform="translate(840, 0)">
        <rect x="0" y="0" width="805" height="325" rx="24" fill="#0f172a" stroke="#334155" stroke-width="2" />
        <g transform="translate(30, 40)">
          <text x="0" y="32" font-family="sans-serif" font-size="34">🏥</text>
          <text x="50" y="30" font-family="sans-serif" font-size="24" font-weight="bold" fill="#ffffff">St. Luke's International Hospital</text>
          <text x="50" y="65" font-family="sans-serif" font-size="15" fill="#94a3b8">9-1 Akashi-cho, Chuo-ku, Tokyo (English Staff on Duty)</text>
          <rect x="0" y="100" width="220" height="38" rx="19" fill="#065f46" />
          <text x="110" y="125" font-family="sans-serif" font-size="14" font-weight="bold" fill="#34d399" text-anchor="middle">🟢 Open 24/7 (0.4 km away)</text>

          <line x1="0" y1="165" x2="745" y2="165" stroke="#1e293b" stroke-width="1.5" />
          <text x="0" y="200" font-family="sans-serif" font-size="15" font-weight="bold" fill="#ffffff">Emergency Dial Action:</text>
          <text x="0" y="235" font-family="sans-serif" font-size="18" font-weight="bold" fill="#38bdf8">📞 Direct Call: +81-3-3541-5151 (Emergency ER)</text>
        </g>
      </g>

      <!-- Bottom: Live Currency Cheat Sheet (Spans Full Width 1645) -->
      <g transform="translate(0, 355)">
        <rect x="0" y="0" width="1645" height="325" rx="24" fill="#172554" stroke="#3b82f6" stroke-width="2" />
        <g transform="translate(40, 40)">
          <text x="0" y="32" font-family="sans-serif" font-size="34">💱</text>
          <text x="50" y="30" font-family="sans-serif" font-size="24" font-weight="bold" fill="#ffffff">Live Currency Converter &amp; Street Shopping Cheat Sheet</text>
          <text x="50" y="68" font-family="sans-serif" font-size="32" font-weight="900" fill="#60a5fa">1 USD = 152.40 JPY  (Japanese Yen)</text>

          <g transform="translate(0, 100)">
            <rect x="0" y="0" width="365" height="85" rx="18" fill="#1e3a8a" />
            <text x="182" y="35" font-family="sans-serif" font-size="16" fill="#bfdbfe" text-anchor="middle">¥1,000 Yen</text>
            <text x="182" y="65" font-family="sans-serif" font-size="22" font-weight="bold" fill="#ffffff" text-anchor="middle">≈ $6.56 USD</text>

            <rect x="400" y="0" width="365" height="85" rx="18" fill="#1e3a8a" />
            <text x="582" y="35" font-family="sans-serif" font-size="16" fill="#bfdbfe" text-anchor="middle">¥5,000 Yen</text>
            <text x="582" y="65" font-family="sans-serif" font-size="22" font-weight="bold" fill="#ffffff" text-anchor="middle">≈ $32.80 USD</text>

            <rect x="800" y="0" width="365" height="85" rx="18" fill="#1e3a8a" />
            <text x="982" y="35" font-family="sans-serif" font-size="16" fill="#bfdbfe" text-anchor="middle">¥10,000 Yen</text>
            <text x="982" y="65" font-family="sans-serif" font-size="22" font-weight="bold" fill="#ffffff" text-anchor="middle">≈ $65.60 USD</text>

            <rect x="1200" y="0" width="365" height="85" rx="18" fill="#1e3a8a" />
            <text x="1382" y="35" font-family="sans-serif" font-size="16" fill="#bfdbfe" text-anchor="middle">¥50,000 Yen</text>
            <text x="1382" y="65" font-family="sans-serif" font-size="22" font-weight="bold" fill="#ffffff" text-anchor="middle">≈ $328.00 USD</text>
          </g>
        </g>
      </g>
    </g>
  `,
});

// ============================================================================
// Main Execution: Render All 8 Screenshots via Sharp
// ============================================================================
async function run() {
  console.log('🚀 Generating Google Play Store screenshots for TravelPro AI...');

  // 1. Phone Screenshots (1080 x 1920)
  await sharp(Buffer.from(screenshot1Svg))
    .png({ quality: 95 })
    .toFile(path.join(outputDir, 'play-screenshot-1.png'));
  console.log('✓ Created play-screenshot-1.png (TravelPro AI Home Dashboard)');

  await sharp(Buffer.from(screenshot2Svg))
    .png({ quality: 95 })
    .toFile(path.join(outputDir, 'play-screenshot-2.png'));
  console.log('✓ Created play-screenshot-2.png (Voice Hub &amp; Speech)');

  await sharp(Buffer.from(screenshot3Svg))
    .png({ quality: 95 })
    .toFile(path.join(outputDir, 'play-screenshot-3.png'));
  console.log('✓ Created play-screenshot-3.png (Camera OCR &amp; Sign Scanner)');

  await sharp(Buffer.from(screenshot4Svg))
    .png({ quality: 95 })
    .toFile(path.join(outputDir, 'play-screenshot-4.png'));
  console.log('✓ Created play-screenshot-4.png (Travel Intelligence &amp; Safety Radar)');

  // 2. Tablet Screenshots (1920 x 1080)
  await sharp(Buffer.from(tabletScreenshot1Svg))
    .png({ quality: 95 })
    .toFile(path.join(outputDir, 'play-tablet-screenshot-1.png'));
  console.log('✓ Created play-tablet-screenshot-1.png (Tablet Home Dashboard)');

  await sharp(Buffer.from(tabletScreenshot2Svg))
    .png({ quality: 95 })
    .toFile(path.join(outputDir, 'play-tablet-screenshot-2.png'));
  console.log('✓ Created play-tablet-screenshot-2.png (Tabletop Face-to-Face)');

  await sharp(Buffer.from(tabletScreenshot3Svg))
    .png({ quality: 95 })
    .toFile(path.join(outputDir, 'play-tablet-screenshot-3.png'));
  console.log('✓ Created play-tablet-screenshot-3.png (Wide-Screen Camera OCR)');

  await sharp(Buffer.from(tabletScreenshot4Svg))
    .png({ quality: 95 })
    .toFile(path.join(outputDir, 'play-tablet-screenshot-4.png'));
  console.log('✓ Created play-tablet-screenshot-4.png (Travel Intelligence &amp; Copilot)');

  // Also sync PWA manifest screenshots
  await sharp(path.join(outputDir, 'play-screenshot-1.png'))
    .resize(390, 844)
    .toFile(path.join(outputDir, 'screenshot-mobile.png'));

  await sharp(path.join(outputDir, 'play-tablet-screenshot-1.png'))
    .resize(1280, 720)
    .toFile(path.join(outputDir, 'screenshot-desktop.png'));

  console.log('🎉 All TravelPro AI screenshots successfully generated!');
}

run().catch((err) => {
  console.error('Error generating assets:', err);
  process.exit(1);
});
