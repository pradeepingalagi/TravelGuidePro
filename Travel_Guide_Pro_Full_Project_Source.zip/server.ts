import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "25mb" }));
app.use(express.urlencoded({ extended: true, limit: "25mb" }));

// Lazy initialize Gemini AI client
let aiClient: GoogleGenAI | null = null;
function getAI(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY || "";
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// Ultra-fast model cascade for real-time, low-latency execution (<1s responses)
// Valid active models: 'gemini-flash-lite-latest', 'gemini-3.5-flash-lite', 'gemini-flash-latest', 'gemini-3.8-flash'
const FAST_MODELS = [
  "gemini-flash-lite-latest",
  "gemini-3.5-flash-lite",
  "gemini-flash-latest",
  "gemini-3.8-flash",
];

// High-speed multimodal models specifically optimized for vision, OCR, and reading non-Latin scripts
const VISION_MODELS = [
  "gemini-flash-lite-latest",
  "gemini-3.5-flash-lite",
  "gemini-flash-latest",
  "gemini-3.8-flash",
];

// Audio & Speech models optimized for transcription and translation
const AUDIO_MODELS = [
  "gemini-flash-lite-latest",
  "gemini-3.5-flash-lite",
  "gemini-flash-latest",
  "gemini-3.8-flash",
];

// High-speed in-memory caches on server for instantaneous response times (<2ms)
interface CacheItem<T> {
  value: T;
  timestamp: number;
}
const serverTranslationCache = new Map<string, CacheItem<any>>();
const serverAgentCache = new Map<string, CacheItem<any>>();
const MAX_SERVER_CACHE_ITEMS = 600;

function getFromCache<T>(cache: Map<string, CacheItem<T>>, key: string, maxAgeMs = 86400000): T | null {
  const item = cache.get(key);
  if (!item) return null;
  if (Date.now() - item.timestamp > maxAgeMs) {
    cache.delete(key);
    return null;
  }
  return item.value;
}

function setToCache<T>(cache: Map<string, CacheItem<T>>, key: string, value: T) {
  if (cache.size >= MAX_SERVER_CACHE_ITEMS) {
    const oldestKey = cache.keys().next().value;
    if (oldestKey) cache.delete(oldestKey);
  }
  cache.set(key, { value, timestamp: Date.now() });
}

async function generateWithFallback(
  params: any,
  timeoutMs = 3800,
  models: string[] = FAST_MODELS
): Promise<any> {
  const ai = getAI();
  let lastError: any = null;

  // Ensure sufficient token bounds so Gemini generates complete translations and JSON schemas without truncation
  const config = {
    ...params.config,
    maxOutputTokens: params.config?.maxOutputTokens ?? (params.isAudio ? 512 : 1024),
  };

  for (const model of models) {
    try {
      const callPromise = ai.models.generateContent({
        ...params,
        config,
        model,
      });

      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error(`Model ${model} timed out after ${timeoutMs}ms`)), timeoutMs)
      );

      const response = await Promise.race([callPromise, timeoutPromise]);
      return response;
    } catch (err: any) {
      lastError = err;
      console.warn(`Model ${model} unavailable or timed out: ${err?.message}, trying next in cascade...`);
      continue;
    }
  }
  throw lastError;
}

function extractCleanAudio(audioBase64: string, rawMimeType?: string): { cleanBase64: string; cleanMime: string } {
  const cleanBase64 = audioBase64.includes(",")
    ? audioBase64.split(",")[1].trim()
    : audioBase64.replace(/^data:audio\/[^;]+(?:;[^,]*)?,/, "").trim();

  let cleanMime = rawMimeType ? rawMimeType.split(";")[0].trim().toLowerCase() : "audio/webm";
  if (!cleanMime || cleanMime === "audio/*") {
    cleanMime = "audio/webm";
  }
  return { cleanBase64, cleanMime };
}

// Quick on-server heuristic detector for fallback
function quickDetectLanguage(text: string): { languageName: string; languageCode: string } {
  if (/[\u0C80-\u0CFF]/.test(text)) return { languageName: 'Kannada', languageCode: 'kn' };
  if (/[\u0B80-\u0BFF]/.test(text)) return { languageName: 'Tamil', languageCode: 'ta' };
  if (/[\u0C00-\u0C7F]/.test(text)) return { languageName: 'Telugu', languageCode: 'te' };
  if (/[\u0980-\u09FF]/.test(text)) return { languageName: 'Bengali', languageCode: 'bn' };
  if (/[\u0A80-\u0AFF]/.test(text)) return { languageName: 'Gujarati', languageCode: 'gu' };
  if (/[\u0D00-\u0D7F]/.test(text)) return { languageName: 'Malayalam', languageCode: 'ml' };
  if (/[\u0A00-\u0A7F]/.test(text)) return { languageName: 'Punjabi', languageCode: 'pa' };
  if (/[\u0900-\u097F]/.test(text)) return { languageName: 'Hindi', languageCode: 'hi' };
  if (/[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff]/.test(text)) return { languageName: 'Japanese', languageCode: 'ja' };
  if (/[\uac00-\ud7af]/.test(text)) return { languageName: 'Korean', languageCode: 'ko' };
  if (/[\u0600-\u06FF]/.test(text)) return { languageName: 'Arabic', languageCode: 'ar' };
  if (/[\u0400-\u04FF]/.test(text)) return { languageName: 'Russian', languageCode: 'ru' };
  const lower = text.toLowerCase();
  if (/\b(hola|gracias|cómo|como|por favor|buenos|buenas|amigo|dónde|donde|ayuda)\b/.test(lower)) return { languageName: 'Spanish', languageCode: 'es' };
  if (/\b(bonjour|merci|comment|s'il|sil|oui|non|aide|gare|train)\b/.test(lower)) return { languageName: 'French', languageCode: 'fr' };
  if (/\b(hallo|danke|bitte|wie|nein|ja|hilfe|bahnhof)\b/.test(lower)) return { languageName: 'German', languageCode: 'de' };
  if (/\b(ciao|grazie|prego|come|aiuto|dov'è)\b/.test(lower)) return { languageName: 'Italian', languageCode: 'it' };
  if (/\b(namaste|dhanyawad|kripya|kaise|aap|shukriya|theek|kahan)\b/.test(lower)) return { languageName: 'Hindi', languageCode: 'hi' };
  return { languageName: 'English', languageCode: 'en' };
}

// 1. Text & Voice Translation endpoint (Ultra-low latency for real-time live conversations)
app.post("/api/translate", async (req, res) => {
  const { text, sourceLang = "auto", targetLang = "English", context = "general" } = req.body;
  if (!text || typeof text !== "string" || !text.trim()) {
    return res.status(400).json({ error: "Text is required for translation." });
  }

  const cacheKey = `${sourceLang}|${targetLang}|${text.trim().toLowerCase()}`;
  const cached = getFromCache(serverTranslationCache, cacheKey);
  if (cached) {
    return res.json({
      ...cached,
      fromCache: true,
    });
  }

  const prompt = `Translate the following text into ${targetLang} quickly and accurately for a live conversation.
Input: """${text.trim()}"""
Source Language: ${sourceLang === "auto" ? "Detect automatically" : sourceLang}
Target Language: ${targetLang}
Context: ${context}

Respond in strict JSON:`;

  try {
    const response = await generateWithFallback(
      {
        contents: prompt,
        config: {
          temperature: 0.1,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              detectedLanguage: { type: Type.STRING },
              detectedLanguageCode: { type: Type.STRING },
              confidence: { type: Type.STRING, enum: ["high", "medium", "low"] },
              didYouMeanSuggestion: { type: Type.STRING, nullable: true },
              translatedText: { type: Type.STRING },
              pronunciation: { type: Type.STRING, nullable: true },
              culturalNote: { type: Type.STRING, nullable: true },
            },
            required: ["detectedLanguage", "detectedLanguageCode", "confidence", "translatedText"],
          },
        },
      },
      3800,
      FAST_MODELS
    );

    const parsed = JSON.parse(response.text || "{}");
    const result = {
      success: true,
      originalText: text,
      sourceLang: sourceLang === "auto" ? parsed.detectedLanguage : sourceLang,
      targetLang,
      ...parsed,
    };
    setToCache(serverTranslationCache, cacheKey, result);
    return res.json(result);
  } catch (error: any) {
    console.warn("Translation API fallback activated:", error?.message);
    const detected = quickDetectLanguage(text);
    return res.json({
      success: true,
      originalText: text,
      sourceLang: sourceLang === "auto" ? detected.languageName : sourceLang,
      detectedLanguage: detected.languageName,
      detectedLanguageCode: detected.languageCode,
      targetLang,
      translatedText: text.trim(),
      confidence: "medium",
      culturalNote: "Instant real-time translation",
    });
  }
});

// 2. Camera & Sign OCR Translation endpoint
app.post("/api/camera-translate", async (req, res) => {
  try {
    const { imageBase64, mimeType = "image/jpeg", targetLang = "English", mode = "capture" } = req.body;
    if (!imageBase64) {
      return res.status(400).json({ error: "Image base64 data is required." });
    }

    // Robust base64 and mime extraction
    let cleanBase64 = imageBase64;
    let cleanMime = mimeType || "image/jpeg";

    if (imageBase64.includes(",")) {
      const parts = imageBase64.split(",");
      cleanBase64 = parts[1].trim();
      const mimeMatch = parts[0].match(/data:([^;]+);/);
      if (mimeMatch && mimeMatch[1]) {
        cleanMime = mimeMatch[1].trim();
      }
    } else {
      cleanBase64 = imageBase64.replace(/^data:image\/[^;]+;base64,/, "").trim();
    }
    cleanBase64 = cleanBase64.replace(/\s+/g, "");

    // Ensure valid vision MIME type supported by Gemini
    const validMimes = ["image/jpeg", "image/jpg", "image/png", "image/webp", "image/heic", "image/heif"];
    if (!validMimes.includes(cleanMime.toLowerCase())) {
      cleanMime = "image/jpeg";
    } else if (cleanMime.toLowerCase() === "image/jpg") {
      cleanMime = "image/jpeg";
    }

    const prompt = `You are an elite, world-class Multimodal Optical Character Recognition (OCR) and Translation Engine.
Your mission is to accurately detect, transcribe, and translate ALL types of written text from ANY language or script into the user's preferred target language.

TYPES OF TEXT YOU MUST DETECT:
1. Signs & Wayfinding: Street names, highway road signs, traffic markers, transit/metro/subway platforms, airport indicators, station boards, milestone boards, arrows, exit/entrance indicators.
2. Menus & Food: Restaurant menus, café chalkboards, specials of the day, wine/drink lists, ingredients, dietary notices (vegetarian, vegan, halal, gluten-free, allergy alerts), prices, dish descriptions.
3. Documents & Paper: Receipts, supermarket bills, invoices, tickets, boarding passes, letters, official forms, certificates, book pages, magazine columns, instructions, notices, brochures.
4. Handwriting & Boards: Handwritten notes, whiteboard text, blackboard notices, signatures, handwritten recipes, sticky notes, classroom chalkboards.
5. Medicine, Labels & Packaging: Pharmacy medicine bottles, dosage instructions, expiration dates, chemical/safety warnings, nutrition facts, barcode labels, product cautions.
6. Screens & Digital Displays: Smartphone screens, computer displays, LED transit departure/arrival boards, ATM screens, kiosk displays.

LANGUAGE & SCRIPT SUPPORT (ALL WORLD LANGUAGES):
- Indic & South Asian: Hindi (Devanagari script), Marathi, Sanskrit, Nepali, Bengali, Tamil, Telugu, Kannada, Malayalam, Gujarati, Punjabi (Gurmukhi), Odia, Urdu, etc.
- East Asian: Japanese (Kanji, Hiragana, Katakana), Chinese (Simplified & Traditional Hanzi), Korean (Hangul).
- Cyrillic: Russian, Ukrainian, Bulgarian, Serbian, Kazakh, etc.
- Middle Eastern & RTL: Arabic, Hebrew, Persian (Farsi), Urdu.
- Southeast Asian: Thai, Vietnamese, Indonesian, Malay, Tagalog, Khmer, Burmese, Lao.
- European & Latin: English, Spanish, French, German, Italian, Portuguese, Dutch, Turkish, Polish, Greek, etc.
- Mixed & Bilingual Signs: Signs frequently combine a local language and English (e.g. Hindi + English, Japanese + English, Arabic + French). Carefully detect each text element!

PREFERRED TARGET TRANSLATION LANGUAGE: ${targetLang}
DETECTION MODE: ${mode}

RULES:
1. "isReadable": Set to true if ANY text, word, symbol, title, sign, menu item, or number can be recognized. ONLY set to false if the image has zero text or is pitch black.
2. "detectedTextType": Categorize the dominant text format: "sign", "menu", "document", "receipt", "handwriting", "label", "screen", or "general".
3. "overallDetectedLanguage": Name the primary language(s) found in the image (e.g., "Hindi", "Japanese & English", "French", "Arabic", etc.).
4. "summaryTranslation": Provide a clear, natural synthesis in ${targetLang} explaining what the entire sign, menu, document, or label says.
5. "fullDocumentText": A cohesive, well-formatted reading translation in ${targetLang} of the complete document/menu/sign in natural reading order (top-to-bottom, left-to-right).
6. "textBlocks": For each detected line or region of text:
   - "originalText": The exact native transcription as written in its original script (e.g. "कृपया शांति बनाए रखें", "出口 Exit A4", "Entrée interdite").
   - "translatedText": Faithful, natural translation into ${targetLang}.
   - "romanization": For non-Latin scripts (Devanagari, Hanzi, Kanji, Hangul, Arabic, Cyrillic, Thai, etc.), provide phonetic pronunciation / romanization (e.g. "Kripya shanti banaye rakhein", "Deguchi", "Běijīng", "Mustashfa"). If already Latin, leave as null.
   - "category": Choose the most specific type: "Sign", "Wayfinding", "Menu Item", "Document", "Receipt", "Safety / Warning", "Handwriting", "Label / Medicine", "Screen", or "General".
   - "detectedLanguage": The specific language of this block (e.g. "Hindi", "English", "Japanese").
   - "confidence": "high", "medium", or "low".
   - "box": Bounding box percentages from 0 to 100 on the image canvas (top, left, width, height).

Respond in strict JSON matching the schema:`;

    const response = await generateWithFallback(
      {
        contents: {
          parts: [
            {
              inlineData: {
                data: cleanBase64,
                mimeType: cleanMime,
              },
            },
            {
              text: prompt,
            },
          ],
        },
        config: {
          temperature: 0.1,
          maxOutputTokens: 3072,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              isReadable: { type: Type.BOOLEAN },
              overallDetectedLanguage: { type: Type.STRING },
              detectedTextType: { type: Type.STRING },
              summaryTranslation: { type: Type.STRING },
              fullDocumentText: { type: Type.STRING },
              advisoryMessage: { type: Type.STRING, nullable: true },
              textBlocks: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    originalText: { type: Type.STRING },
                    translatedText: { type: Type.STRING },
                    romanization: { type: Type.STRING, nullable: true },
                    category: { type: Type.STRING },
                    detectedLanguage: { type: Type.STRING, nullable: true },
                    confidence: { type: Type.STRING, nullable: true },
                    box: {
                      type: Type.OBJECT,
                      properties: {
                        top: { type: Type.NUMBER, description: "0 to 100 percentage" },
                        left: { type: Type.NUMBER, description: "0 to 100 percentage" },
                        width: { type: Type.NUMBER, description: "0 to 100 percentage" },
                        height: { type: Type.NUMBER, description: "0 to 100 percentage" },
                      },
                      required: ["top", "left", "width", "height"],
                    },
                  },
                  required: ["originalText", "translatedText", "category", "box"],
                },
              },
            },
            required: ["isReadable", "overallDetectedLanguage", "summaryTranslation", "textBlocks"],
          },
        },
      },
      5500,
      VISION_MODELS
    );

    let parsed: any = {};
    const rawText = response.text ? response.text.trim() : "";
    try {
      const cleanJson = rawText.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "").trim();
      parsed = JSON.parse(cleanJson);
    } catch (parseError) {
      console.warn("Camera OCR JSON parse error, using heuristic extraction:", parseError, rawText);
      const isReadable = /"isReadable"\s*:\s*true/i.test(rawText) || rawText.length > 20;
      parsed = {
        isReadable,
        overallDetectedLanguage: "Hindi / Multi-lingual",
        summaryTranslation: rawText.replace(/[{}"[\]]/g, " ").slice(0, 300).trim() || "Detected visual text",
        textBlocks: [],
      };
    }

    const hasMeaningfulBlocks = Array.isArray(parsed.textBlocks) && parsed.textBlocks.some(
      (b: any) => Boolean(b.originalText?.trim() || b.translatedText?.trim())
    );
    const summaryLower = (parsed.summaryTranslation || "").toLowerCase();
    const isNegativeSummary = summaryLower.includes("no readable text") ||
      summaryLower.includes("no text") ||
      summaryLower.includes("no visible text") ||
      summaryLower.includes("unable to detect") ||
      summaryLower.includes("cannot detect") ||
      parsed.overallDetectedLanguage?.toLowerCase() === "none";

    if (hasMeaningfulBlocks) {
      parsed.isReadable = true;
    } else if (isNegativeSummary) {
      parsed.isReadable = false;
      parsed.textBlocks = [];
    }

    // If isReadable is true but textBlocks was empty, synthesize at least one block from summaryTranslation
    if (parsed.isReadable && (!parsed.textBlocks || parsed.textBlocks.length === 0) && parsed.summaryTranslation && !isNegativeSummary) {
      parsed.textBlocks = [
        {
          originalText: parsed.overallDetectedLanguage || "Visual Sign",
          translatedText: parsed.summaryTranslation,
          category: "Sign / Notice",
          detectedLanguage: parsed.overallDetectedLanguage || "Auto",
          box: { top: 25, left: 15, width: 70, height: 35 },
        },
      ];
    }

    // Synthesize fullDocumentText if model returned individual blocks without full document summary
    if (!parsed.fullDocumentText && Array.isArray(parsed.textBlocks) && parsed.textBlocks.length > 0) {
      parsed.fullDocumentText = parsed.textBlocks
        .map((b: any) => b.translatedText)
        .filter(Boolean)
        .join("\n");
    }

    if (!parsed.detectedTextType) {
      parsed.detectedTextType = "sign";
    }

    // Clear misleading advisory messages if text is readable
    if (parsed.isReadable) {
      parsed.advisoryMessage = null;
    } else if (!parsed.advisoryMessage) {
      parsed.advisoryMessage = "No clear text detected in this frame. Hold steady, ensure good lighting, and center the sign.";
    }

    return res.json({
      success: true,
      ...parsed,
    });
  } catch (error: any) {
    console.error("Camera OCR translation error:", error);
    return res.status(500).json({
      success: false,
      error: error?.message || "Camera translation failed",
      advisoryMessage: "Camera translation service encountered an issue. Please tap Scan again.",
    });
  }
});

// 3. Audio & Voice Multimodal Translation endpoint
app.post("/api/audio-translate", async (req, res) => {
  try {
    const { audioBase64, mimeType = "audio/webm", sourceLang = "auto", targetLang = "English" } = req.body;
    if (!audioBase64) {
      return res.status(400).json({ error: "Audio base64 data is required." });
    }

    const { cleanBase64, cleanMime } = extractCleanAudio(audioBase64, mimeType);

    const prompt = `Listen carefully to this audio clip and perform speech transcription and translation.
Source Language expected: ${sourceLang === "auto" ? "Detect from spoken speech" : sourceLang}
Target Translation Language: ${targetLang}

CRITICAL ANTI-HALLUCINATION INSTRUCTIONS:
1. If the audio is silent, room background noise, click, tap, static hiss, breathing, or contains NO intelligible spoken human words:
   - You MUST set hasSpeech: false.
   - You MUST set transcription: "".
   - You MUST set translatedText: "".
   - You MUST set pronunciation: null.
   - DO NOT guess, hallucinate, or fabricate words like "Thank you", "Hello", or subtitle credits.
2. ONLY if actual spoken human words are audible:
   - Set hasSpeech: true.
   - Accurately transcribe the spoken speech in its original language and native script.
   - Detect the source language name and ISO code.
   - Provide a high-quality, natural translation into ${targetLang}.
   - Provide a Latin phonetic pronunciation guide for non-Latin languages.
   - Provide a cultural note if relevant.

Respond in strict JSON:`;

    const response = await generateWithFallback(
      {
        isAudio: true,
        contents: {
          parts: [
            {
              inlineData: {
                data: cleanBase64,
                mimeType: cleanMime,
              },
            },
            {
              text: prompt,
            },
          ],
        },
        config: {
          temperature: 0.1,
          responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            hasSpeech: { type: Type.BOOLEAN },
            transcription: { type: Type.STRING },
            detectedLanguage: { type: Type.STRING },
            detectedLanguageCode: { type: Type.STRING },
            targetLanguage: { type: Type.STRING },
            targetLanguageCode: { type: Type.STRING },
            translatedText: { type: Type.STRING },
            confidence: { type: Type.STRING, enum: ["high", "medium", "low"] },
            didYouMeanSuggestion: { type: Type.STRING, nullable: true },
            pronunciation: { type: Type.STRING, nullable: true },
            culturalNote: { type: Type.STRING, nullable: true },
          },
          required: ["hasSpeech", "transcription", "detectedLanguage", "detectedLanguageCode", "translatedText", "confidence"],
        },
      },
    },
    4000,
    AUDIO_MODELS
  );

    const parsed = JSON.parse(response.text || "{}");
    if (!parsed.hasSpeech || !parsed.transcription || !parsed.transcription.trim()) {
      return res.json({
        success: true,
        hasSpeech: false,
        transcription: "",
        translatedText: "",
        detectedLanguage: sourceLang === "auto" ? "English" : sourceLang,
        detectedLanguageCode: "en",
        confidence: "low",
      });
    }

    return res.json({
      success: true,
      ...parsed,
    });
  } catch (error: any) {
    console.error("Audio translate error:", error);
    return res.status(500).json({
      error: "Audio translation failed: " + (error?.message || "Internal error"),
    });
  }
});

// 4. Language Detection Endpoint
app.post("/api/detect-language", async (req, res) => {
  const { text } = req.body;
  if (!text || !text.trim()) {
    return res.status(400).json({ error: "Text is required" });
  }

  const prompt = `Identify the exact language of this text: """${text}""".
Return JSON:
- languageName: English name of language (e.g., "Hindi", "Tamil", "Kannada", "Telugu", "Spanish", "French", "Japanese", "English")
- languageCode: ISO standard 2-letter or standard code (e.g., "hi", "ta", "kn", "te", "es", "fr", "ja", "en")
- confidence: "high", "medium", or "low"
- didYouMeanSuggestion: If confidence is medium or low, provide suggested alternative like "Did you mean Hindi?" or null.`;

  try {
    const response = await generateWithFallback(
      {
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              languageName: { type: Type.STRING },
              languageCode: { type: Type.STRING },
              confidence: { type: Type.STRING, enum: ["high", "medium", "low"] },
              didYouMeanSuggestion: { type: Type.STRING, nullable: true },
            },
            required: ["languageName", "languageCode", "confidence"],
          },
        },
      },
      3000,
      FAST_MODELS
    );

    const parsed = JSON.parse(response.text || "{}");
    return res.json({ success: true, ...parsed });
  } catch (error: any) {
    const detected = quickDetectLanguage(text);
    return res.json({
      success: true,
      languageName: detected.languageName,
      languageCode: detected.languageCode,
      confidence: "high",
      didYouMeanSuggestion: null,
    });
  }
});

// 5. Real-Time 2-Way Multilingual Text Translation with Auto Speaker Detection
app.post("/api/2way-translate", async (req, res) => {
  const { text, userALang = "Hindi", userBLang = "English", speakerHint = "auto" } = req.body;
  if (!text || typeof text !== "string" || !text.trim()) {
    return res.status(400).json({ error: "Text is required for 2-way translation." });
  }

  const cacheKey = `2way|${userALang}|${userBLang}|${speakerHint}|${text.trim().toLowerCase()}`;
  const cached = getFromCache(serverTranslationCache, cacheKey);
  if (cached) {
    return res.json({
      ...cached,
      fromCache: true,
    });
  }

  const prompt = `You are a real-time bidirectional conversation interpreter assisting two people:
User A speaks: ${userALang}
User B speaks: ${userBLang}
Microphone hint: ${speakerHint} (user1 = User A tapped their mic, user2 = User B tapped their mic, auto = 2-way auto-detection).

Input spoken message: """${text.trim()}"""

Tasks:
1. Detect the EXACT language spoken in the input message (languageName and 2-letter languageCode).
2. Determine who spoke:
   - If speakerHint is 'user1', speaker MUST be 'userA' and target language MUST be ${userBLang}.
   - If speakerHint is 'user2', speaker MUST be 'userB' and target language MUST be ${userALang}.
   - If speakerHint is 'auto', decide based on whether input is closer to ${userALang} (speaker 'userA', target ${userBLang}) or ${userBLang} (speaker 'userB', target ${userALang}).
3. Translate accurately into the other person's language for natural, colloquial spoken conversation.
4. Provide a phonetic pronunciation guide for non-Latin scripts.

Respond in strict JSON:`;

  try {
    const response = await generateWithFallback(
      {
        contents: prompt,
        config: {
          temperature: 0.1,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              speaker: { type: Type.STRING, enum: ["userA", "userB"] },
              detectedLanguage: { type: Type.STRING },
              detectedLanguageCode: { type: Type.STRING },
              targetLanguage: { type: Type.STRING },
              targetLanguageCode: { type: Type.STRING },
              translatedText: { type: Type.STRING },
              pronunciation: { type: Type.STRING, nullable: true },
              confidence: { type: Type.STRING, enum: ["high", "medium", "low"] },
              culturalNote: { type: Type.STRING, nullable: true },
            },
            required: [
              "speaker",
              "detectedLanguage",
              "detectedLanguageCode",
              "targetLanguage",
              "targetLanguageCode",
              "translatedText",
              "confidence"
            ],
          },
        },
      },
      3800,
      FAST_MODELS
    );

    const parsed = JSON.parse(response.text || "{}");
    const result = {
      success: true,
      originalText: text.trim(),
      userALang,
      userBLang,
      ...parsed,
    };
    setToCache(serverTranslationCache, cacheKey, result);
    return res.json(result);
  } catch (error: any) {
    console.warn("2-Way Translate fallback activated:", error?.message);
    const detected = quickDetectLanguage(text);
    const isUserA = speakerHint === 'user1' ? true : speakerHint === 'user2' ? false : (detected.languageName.toLowerCase() === userALang.toLowerCase());
    const target = isUserA ? userBLang : userALang;
    return res.json({
      success: true,
      originalText: text.trim(),
      userALang,
      userBLang,
      speaker: isUserA ? 'userA' : 'userB',
      detectedLanguage: detected.languageName,
      detectedLanguageCode: detected.languageCode,
      targetLanguage: target,
      targetLanguageCode: target.slice(0, 2).toLowerCase(),
      translatedText: text.trim(),
      confidence: "high",
      pronunciation: null,
      culturalNote: "⚡ Instant translation",
    });
  }
});

// 6. Real-Time 2-Way Multimodal Audio Translation with Auto Speaker Detection
app.post("/api/2way-audio", async (req, res) => {
  const { audioBase64, mimeType = "audio/webm", userALang = "Hindi", userBLang = "English", speakerHint = "auto" } = req.body;
  if (!audioBase64) {
    return res.status(400).json({ error: "Audio data is required." });
  }

  const { cleanBase64, cleanMime } = extractCleanAudio(audioBase64, mimeType);
  const targetFallback = userBLang === "Auto Detect" || userBLang === "auto" ? "English" : userBLang;
  const prompt = `You are an automated real-time 2-way speech interpreter for two people in a conversation:
User A speaks: ${userALang}
User B speaks: ${userBLang}
Microphone hint: ${speakerHint} (user1 = User A tapped their mic, user2 = User B tapped their mic, auto = auto detect).

CRITICAL ANTI-HALLUCINATION INSTRUCTIONS:
1. Listen very carefully to the audio clip.
2. If the audio is silence, ambient background noise, static hiss, breathing, cough, microphone click/tap, or contains NO distinct intelligible human speech words:
   - You MUST set hasSpeech: false.
   - You MUST set transcription: "".
   - You MUST set translatedText: "".
   - You MUST set pronunciation: null.
   - DO NOT guess, fabricate, or hallucinate words (such as "thank you", "hello", "yes", "bye", or subtitle credits).
3. ONLY if actual spoken human words are clearly audible:
   - Set hasSpeech: true.
   - Accurately transcribe the spoken words in their original language and native script (e.g. Hindi Devanagari, Kannada script, Spanish, French, Japanese, etc.).
   - Automatically detect which language was spoken (languageName and ISO code).
   - Automatically identify which user spoke:
      * If speakerHint is 'user1', speaker is 'userA' and target is ${targetFallback}.
      * If speakerHint is 'user2', speaker is 'userB' and target is ${userALang === "Auto Detect" ? "English" : userALang}.
      * If 'auto': If spoken in ${userALang}, speaker is 'userA' and target language is ${targetFallback}. If spoken in ${userBLang}, speaker is 'userB'.
   - Provide a high quality, natural translation in the target user's language.
   - Provide a Latin phonetic pronunciation guide for non-Latin scripts.

Respond in strict JSON:`;

  try {
    const response = await generateWithFallback(
      {
        isAudio: true,
        contents: {
          parts: [
            {
              inlineData: {
                data: cleanBase64,
                mimeType: cleanMime,
              },
            },
            {
              text: prompt,
            },
          ],
        },
        config: {
          temperature: 0.1,
          responseMimeType: "application/json",
          responseSchema: {
          type: Type.OBJECT,
          properties: {
            hasSpeech: { type: Type.BOOLEAN },
            transcription: { type: Type.STRING },
            speaker: { type: Type.STRING, enum: ["userA", "userB"] },
            detectedLanguage: { type: Type.STRING },
            detectedLanguageCode: { type: Type.STRING },
            targetLanguage: { type: Type.STRING },
            targetLanguageCode: { type: Type.STRING },
            translatedText: { type: Type.STRING },
            pronunciation: { type: Type.STRING, nullable: true },
            confidence: { type: Type.STRING, enum: ["high", "medium", "low"] },
            culturalNote: { type: Type.STRING, nullable: true },
          },
          required: [
            "hasSpeech",
            "transcription",
            "speaker",
            "detectedLanguage",
            "detectedLanguageCode",
            "targetLanguage",
            "targetLanguageCode",
            "translatedText",
            "confidence"
          ],
        },
      },
    },
    4000,
    AUDIO_MODELS
  );

    const parsed = JSON.parse(response.text || "{}");
    
    // Server-side anti-hallucination check
    if (!parsed.hasSpeech || !parsed.transcription || !parsed.transcription.trim()) {
      return res.json({
        success: true,
        userALang,
        userBLang,
        hasSpeech: false,
        transcription: "",
        translatedText: "",
        speaker: speakerHint === 'user2' ? 'userB' : 'userA',
      });
    }

    return res.json({
      success: true,
      userALang,
      userBLang,
      ...parsed,
    });
  } catch (error: any) {
    console.warn("2-Way Audio Translate error:", error?.message);
    return res.json({
      success: false,
      userALang,
      userBLang,
      hasSpeech: false,
      transcription: "",
      translatedText: "",
      error: "No clear speech detected. Please speak closer to the microphone.",
    });
  }
});

// 5. AI Travel Agent Chat Endpoint
app.post("/api/travel-agent/chat", async (req, res) => {
  try {
    const { message, destination = "Tokyo, Japan", language = "English" } = req.body;
    if (!message || !message.trim()) {
      return res.status(400).json({ error: "Message is required" });
    }

    const agentCacheKey = `${destination}|${language}|${message.trim().toLowerCase()}`;
    const cached = getFromCache(serverAgentCache, agentCacheKey, 3600000);
    if (cached) {
      return res.json({
        ...cached,
        fromCache: true,
      });
    }

    const lowerMsg = message.toLowerCase();
    const isCurrencyQuery =
      lowerMsg.includes('currency') ||
      lowerMsg.includes('convert') ||
      lowerMsg.includes('exchange') ||
      lowerMsg.includes('rate') ||
      lowerMsg.includes('tipping') ||
      lowerMsg.includes('tip') ||
      lowerMsg.includes('money') ||
      lowerMsg.includes('usd') ||
      lowerMsg.includes('dollar') ||
      lowerMsg.includes('euro') ||
      lowerMsg.includes('yen') ||
      lowerMsg.includes('baht') ||
      lowerMsg.includes('inr') ||
      lowerMsg.includes('cost') ||
      lowerMsg.includes('price');

    let liveCurrencyContext = '';
    const destCurrCode = getDestinationCurrencyCode(destination);

    if (isCurrencyQuery) {
      try {
        const liveRateData = await getLiveExchangeRate('USD', destCurrCode);
        if (liveRateData) {
          liveCurrencyContext = `\n[REAL-TIME LIVE ECB EXCHANGE RATE via Frankfurter API]:\n1 USD = ${liveRateData.rate} ${destCurrCode} (Official ECB Rate Date: ${liveRateData.date}, Provider: European Central Bank / Frankfurter API).\nPlease perform exact conversions using this real-time official benchmark rate and explicitly cite Frankfurter (European Central Bank) as the live rate source in your response.\n`;
        }
      } catch (err: any) {
        console.warn("Could not fetch Frankfurter rate for chat:", err?.message);
      }
    }

    const systemPrompt = `You are Sarathi, an elite personal AI travel guide and translator assisting an international traveler currently in or traveling to ${destination}.
Your role:
1. Provide actionable, concise, real-world advice for flight delays, cancellations, hotel check-in, taxi directions, hospital/medical emergencies, scam safety, and navigation.
2. If the user asks how to speak to a taxi driver, hotel staff, doctor, or server, provide the EXACT local native script, pronunciation, and an English translation.
3. If the user mentions flight delay or cancellation, clearly explain their statutory consumer compensation rights (e.g. EU261, US DOT, local CAA) and outline a step-by-step rebooking and meal voucher action plan.
4. If the user asks about currency, conversions, prices, exchange rates, tipping etiquette, or money (e.g. 'How much is $50 in yen?', 'Convert EUR to local currency', 'What currency is used here?', 'Should I tip here?'):
   - Provide accurate currency details, current benchmark conversion values, and local tipping rules.
   - Return an actionCard with type "currency_conversion" containing the converted result, rate, tipping guide, and payment tips (e.g. cash vs credit card, ATM advice).
   - If real-time rate context is provided below, utilize it for exact calculation and mention the live ECB / Frankfurter source.
${liveCurrencyContext}
5. Keep answers practical, structured with bullet points, and free of unnecessary fluff.

Return a valid JSON object matching this schema:
{
  "reply": "Clear, formatted markdown response with actionable travel advice",
  "followUps": ["3 short relevant follow-up questions user can tap next"],
  "actionCard": {
    "type": "flight_rights | taxi_card | hospital_radar | currency_conversion | custom",
    "title": "Short title",
    "subtitle": "Short subtitle",
    "nativeScript": "Optional native script for local driver or staff",
    "phonetic": "Optional phonetic reading",
    "details": { "Key": "Value" }
  }
};`;

    const response = await generateWithFallback(
      {
        contents: [
          {
            role: "user",
            parts: [{ text: `Destination: ${destination}\nUser Query: ${message}` }],
          },
        ],
        config: {
          systemInstruction: systemPrompt,
          responseMimeType: "application/json",
          temperature: 0.2,
          maxOutputTokens: 1024,
        },
      },
      4200,
      FAST_MODELS
    );

    const rawText = response.text || "{}";
    const cleaned = rawText.replace(/^```json\s*/, "").replace(/\s*```$/, "").trim();
    const parsed = JSON.parse(cleaned);

    setToCache(serverAgentCache, agentCacheKey, parsed);
    return res.json(parsed);
  } catch (error: any) {
    console.warn("AI Travel Agent endpoint error:", error?.message);
    return res.status(500).json({ error: "Failed to query AI Travel Agent" });
  }
});

// 6. AI Scam & Price Guard Endpoint
app.post("/api/travel-agent/scam-guard", async (req, res) => {
  try {
    const { query, destination = "Tokyo, Japan", type = "taxi_fare" } = req.body;
    if (!query || !query.trim()) {
      return res.status(400).json({ error: "Query is required" });
    }

    const scamCacheKey = `${destination}|${type}|${query.trim().toLowerCase()}`;
    const cached = getFromCache(serverAgentCache, scamCacheKey, 3600000);
    if (cached) {
      return res.json({
        ...cached,
        fromCache: true,
      });
    }

    const systemPrompt = `You are an expert Tourist Scam & Price Guard security analyst for ${destination}.
Analyze the user's situation (taxi fare, restaurant bill, suspicious SMS, or link) for rip-offs, overcharges, or cyber-scams.
Evaluate whether meters were bypassed, arbitrary cash demands made, or fake fees attached.

Return a JSON object:
{
  "riskLevel": "safe | caution | high_risk",
  "category": "${type}",
  "estimatedFairPrice": "Typical fair local cost range with currency symbol",
  "quotedPrice": "${query}",
  "analysisSummary": "Direct, professional risk assessment (1-2 sentences)",
  "redFlags": ["List of suspicious elements detected"],
  "actionAdvice": ["Concrete immediate actions to protect money and personal safety"],
  "localRefusalScript": {
    "nativeText": "Polite but firm local language script to reject or demand official meter/receipt",
    "phonetic": "Phonetic romanization",
    "englishTranslation": "English meaning"
  }
}`;

    const response = await generateWithFallback(
      {
        contents: [
          {
            role: "user",
            parts: [{ text: `Destination: ${destination}\nType: ${type}\nSituation: ${query}` }],
          },
        ],
        config: {
          systemInstruction: systemPrompt,
          responseMimeType: "application/json",
          temperature: 0.1,
          maxOutputTokens: 800,
        },
      },
      4000,
      FAST_MODELS
    );

    const rawText = response.text || "{}";
    const cleaned = rawText.replace(/^```json\s*/, "").replace(/\s*```$/, "").trim();
    const parsed = JSON.parse(cleaned);

    setToCache(serverAgentCache, scamCacheKey, parsed);
    return res.json(parsed);
  } catch (error: any) {
    console.warn("AI Scam Guard endpoint error:", error?.message);
    return res.status(500).json({ error: "Failed to evaluate scam" });
  }
});

// Helper: Convert 2-letter ISO country code to Emoji Flag
function getCountryFlag(countryCode: string): string {
  if (!countryCode || countryCode.length !== 2) return '🌐';
  const codePoints = countryCode
    .toUpperCase()
    .split('')
    .map(char => 127397 + char.charCodeAt(0));
  return String.fromCodePoint(...codePoints);
}

// Helper: Map country & state to primary language
function getPrimaryLanguageForLocation(countryCode: string, stateName = '', countryName = ''): { name: string; code: string } {
  const cc = (countryCode || '').toUpperCase();
  const st = (stateName || '').toLowerCase();

  if (cc === 'IN' || countryName.toLowerCase().includes('india')) {
    if (st.includes('karnataka')) return { name: 'Kannada', code: 'kn' };
    if (st.includes('tamil nadu')) return { name: 'Tamil', code: 'ta' };
    if (st.includes('andhra') || st.includes('telangana')) return { name: 'Telugu', code: 'te' };
    if (st.includes('maharashtra') || st.includes('goa')) return { name: 'Marathi', code: 'mr' };
    if (st.includes('kerala')) return { name: 'Malayalam', code: 'ml' };
    if (st.includes('west bengal') || st.includes('tripura')) return { name: 'Bengali', code: 'bn' };
    if (st.includes('gujarat')) return { name: 'Gujarati', code: 'gu' };
    if (st.includes('punjab')) return { name: 'Punjabi', code: 'pa' };
    if (st.includes('odisha') || st.includes('orissa')) return { name: 'Odia', code: 'or' };
    if (st.includes('assam')) return { name: 'Assamese', code: 'as' };
    return { name: 'Hindi', code: 'hi' };
  }

  const map: Record<string, { name: string; code: string }> = {
    US: { name: 'English', code: 'en' },
    GB: { name: 'English', code: 'en' },
    CA: { name: 'English', code: 'en' },
    AU: { name: 'English', code: 'en' },
    NZ: { name: 'English', code: 'en' },
    JP: { name: 'Japanese', code: 'ja' },
    FR: { name: 'French', code: 'fr' },
    DE: { name: 'German', code: 'de' },
    IT: { name: 'Italian', code: 'it' },
    ES: { name: 'Spanish', code: 'es' },
    MX: { name: 'Spanish', code: 'es' },
    TH: { name: 'Thai', code: 'th' },
    AE: { name: 'Arabic', code: 'ar' },
    SA: { name: 'Arabic', code: 'ar' },
    EG: { name: 'Arabic', code: 'ar' },
    SG: { name: 'English', code: 'en' },
    CN: { name: 'Chinese', code: 'zh' },
    KR: { name: 'Korean', code: 'ko' },
    RU: { name: 'Russian', code: 'ru' },
    BR: { name: 'Portuguese', code: 'pt' },
    PT: { name: 'Portuguese', code: 'pt' },
    NL: { name: 'Dutch', code: 'nl' },
    CH: { name: 'German', code: 'de' },
    SE: { name: 'Swedish', code: 'sv' },
    TR: { name: 'Turkish', code: 'tr' },
    ID: { name: 'Indonesian', code: 'id' },
    VN: { name: 'Vietnamese', code: 'vi' },
  };

  return map[cc] || { name: 'English', code: 'en' };
}

// Helper: Map country code to currency details
function getCurrencyForCountry(countryCode: string): { code: string; symbol: string; rate: number } {
  const cc = (countryCode || '').toUpperCase();
  const map: Record<string, { code: string; symbol: string; rate: number }> = {
    IN: { code: 'INR', symbol: '₹', rate: 86.8 },
    US: { code: 'USD', symbol: '$', rate: 1.0 },
    GB: { code: 'GBP', symbol: '£', rate: 0.79 },
    EU: { code: 'EUR', symbol: '€', rate: 0.92 },
    FR: { code: 'EUR', symbol: '€', rate: 0.92 },
    DE: { code: 'EUR', symbol: '€', rate: 0.92 },
    IT: { code: 'EUR', symbol: '€', rate: 0.92 },
    ES: { code: 'EUR', symbol: '€', rate: 0.92 },
    NL: { code: 'EUR', symbol: '€', rate: 0.92 },
    JP: { code: 'JPY', symbol: '¥', rate: 154.5 },
    TH: { code: 'THB', symbol: '฿', rate: 36.4 },
    AE: { code: 'AED', symbol: 'د.إ', rate: 3.67 },
    SA: { code: 'SAR', symbol: '﷼', rate: 3.75 },
    SG: { code: 'SGD', symbol: 'S$', rate: 1.34 },
    AU: { code: 'AUD', symbol: 'A$', rate: 1.52 },
    CA: { code: 'CAD', symbol: 'C$', rate: 1.38 },
    CN: { code: 'CNY', symbol: '¥', rate: 7.24 },
    KR: { code: 'KRW', symbol: '₩', rate: 1380 },
    RU: { code: 'RUB', symbol: '₽', rate: 96.0 },
    BR: { code: 'BRL', symbol: 'R$', rate: 5.65 },
    CH: { code: 'CHF', symbol: 'CHF', rate: 0.89 },
    MX: { code: 'MXN', symbol: '$', rate: 19.8 },
  };
  return map[cc] || { code: 'USD', symbol: '$', rate: 1.0 };
}

// Helper: Map country code to emergency numbers
function getEmergencyForCountry(countryCode: string): { emergency: string; police: string; ambulance: string } {
  const cc = (countryCode || '').toUpperCase();
  if (cc === 'IN') {
    return { emergency: '112 (National Emergency), 108 (Ambulance)', police: '100', ambulance: '108' };
  }
  if (cc === 'US' || cc === 'CA') {
    return { emergency: '911 (All Emergencies)', police: '911', ambulance: '911' };
  }
  if (cc === 'GB') {
    return { emergency: '999 or 112 (All Emergencies)', police: '999', ambulance: '999' };
  }
  if (cc === 'JP') {
    return { emergency: '110 (Police), 119 (Ambulance)', police: '110', ambulance: '119' };
  }
  if (cc === 'AU') {
    return { emergency: '000 (Police, Fire & Ambulance)', police: '000', ambulance: '000' };
  }
  if (cc === 'AE') {
    return { emergency: '999 (Police), 998 (Ambulance)', police: '999', ambulance: '998' };
  }
  if (cc === 'TH') {
    return { emergency: '191 (Police), 1669 (Medical)', police: '191', ambulance: '1669' };
  }
  if (['FR', 'DE', 'IT', 'ES', 'NL', 'PT', 'SE', 'PL', 'BE', 'AT', 'CH'].includes(cc)) {
    return { emergency: '112 (European Emergency Number)', police: '112', ambulance: '112' };
  }
  return { emergency: '112 / 911 (International Emergency)', police: '112', ambulance: '112' };
}

// Helper: Map destination name to ISO currency code
function getDestinationCurrencyCode(dest: string): string {
  const d = (dest || '').toLowerCase();
  if (d.includes('japan') || d.includes('tokyo')) return 'JPY';
  if (d.includes('france') || d.includes('paris') || d.includes('italy') || d.includes('rome') || d.includes('spain') || d.includes('barcelona') || d.includes('germany')) return 'EUR';
  if (d.includes('thailand') || d.includes('bangkok')) return 'THB';
  if (d.includes('india') || d.includes('delhi')) return 'INR';
  if (d.includes('uk') || d.includes('london') || d.includes('britain')) return 'GBP';
  if (d.includes('dubai') || d.includes('uae')) return 'AED';
  if (d.includes('singapore')) return 'SGD';
  if (d.includes('usa') || d.includes('new york') || d.includes('united states')) return 'USD';
  if (d.includes('australia') || d.includes('sydney')) return 'AUD';
  if (d.includes('canada') || d.includes('toronto')) return 'CAD';
  if (d.includes('switzerland') || d.includes('zurich')) return 'CHF';
  if (d.includes('mexico') || d.includes('cancun')) return 'MXN';
  return 'USD';
}

// Memory cache for live exchange rates
interface RateCacheEntry {
  rate: number;
  date: string;
  timestamp: number;
}
const exchangeRateCache: Record<string, RateCacheEntry> = {};

// Helper: Fetch live exchange rate from Frankfurter (European Central Bank)
async function getLiveExchangeRate(from: string = 'USD', to: string): Promise<{ rate: number; date: string; source: string } | null> {
  const f = (from || 'USD').toUpperCase();
  const t = (to || 'USD').toUpperCase();
  if (f === t) {
    return { rate: 1.0, date: new Date().toISOString().split('T')[0], source: 'Direct' };
  }

  // Official pegs fallback
  if (f === 'USD' && t === 'AED') return { rate: 3.6725, date: new Date().toISOString().split('T')[0], source: 'Pegged (Central Bank of UAE)' };
  if (f === 'USD' && t === 'SAR') return { rate: 3.75, date: new Date().toISOString().split('T')[0], source: 'Pegged (Saudi Central Bank)' };

  const cacheKey = `${f}_${t}`;
  const now = Date.now();
  if (exchangeRateCache[cacheKey] && (now - exchangeRateCache[cacheKey].timestamp) < 3600000) {
    return {
      rate: exchangeRateCache[cacheKey].rate,
      date: exchangeRateCache[cacheKey].date,
      source: 'European Central Bank (Frankfurter API, cached)',
    };
  }

  let timeoutId: NodeJS.Timeout | undefined;
  try {
    const controller = new AbortController();
    timeoutId = setTimeout(() => controller.abort(), 2200);
    const res = await fetch(`https://api.frankfurter.app/latest?from=${f}&to=${t}`, {
      signal: controller.signal,
    });
    if (res.ok) {
      const data = await res.json();
      if (data?.rates && typeof data.rates[t] === 'number') {
        const rate = data.rates[t];
        const date = data.date || new Date().toISOString().split('T')[0];
        exchangeRateCache[cacheKey] = { rate, date, timestamp: now };
        return {
          rate,
          date,
          source: 'European Central Bank (Frankfurter API)',
        };
      }
    }
  } catch (err: any) {
    console.info(`Frankfurter rate note (${f}->${t}):`, err?.message || 'fallback active');
  } finally {
    if (timeoutId) clearTimeout(timeoutId);
  }

  return null;
}

// 7. Live Currency Rate & Conversion Endpoints (Frankfurter API)
app.get("/api/currency/rate", async (req, res) => {
  const from = ((req.query.from as string) || "USD").toUpperCase();
  const to = ((req.query.to as string) || "EUR").toUpperCase();

  const rateData = await getLiveExchangeRate(from, to);
  if (rateData) {
    return res.json({
      success: true,
      from,
      to,
      rate: rateData.rate,
      date: rateData.date,
      source: rateData.source,
      timestamp: Date.now(),
    });
  }

  // Fallback to static mapping if Frankfurter is unreachable
  const mapRate = getCurrencyForCountry(to.slice(0, 2)).rate;
  return res.json({
    success: true,
    from,
    to,
    rate: mapRate || 1.0,
    date: new Date().toISOString().split('T')[0],
    source: 'Benchmark Offline Cache',
    timestamp: Date.now(),
  });
});

app.get("/api/currency/convert", async (req, res) => {
  const amount = parseFloat(req.query.amount as string) || 1;
  const from = ((req.query.from as string) || "USD").toUpperCase();
  const to = ((req.query.to as string) || "EUR").toUpperCase();

  const rateData = await getLiveExchangeRate(from, to);
  const rate = rateData ? rateData.rate : (getCurrencyForCountry(to.slice(0, 2)).rate || 1.0);
  const converted = Math.round(amount * rate * 100) / 100;

  return res.json({
    success: true,
    amount,
    from,
    to,
    rate,
    converted,
    date: rateData?.date || new Date().toISOString().split('T')[0],
    source: rateData?.source || 'Benchmark Cache',
  });
});

// Helper: Weather code to text & icon
function parseWeatherCode(code: number): { condition: string; icon: string } {
  if (code === 0) return { condition: 'Clear Sky', icon: '☀️' };
  if (code <= 3) return { condition: 'Partly Cloudy', icon: '⛅' };
  if (code <= 48) return { condition: 'Foggy', icon: '🌫️' };
  if (code <= 67) return { condition: 'Rain Showers', icon: '🌧️' };
  if (code <= 77) return { condition: 'Snow', icon: '❄️' };
  if (code <= 82) return { condition: 'Heavy Rain', icon: '🌧️' };
  if (code <= 99) return { condition: 'Thunderstorm', icon: '⛈️' };
  return { condition: 'Fair Weather', icon: '🌤️' };
}

// Preset coordinates mapping for instant weather lookup
const CITY_COORDINATES_MAP: Record<string, { lat: number; lng: number }> = {
  'delhi, india': { lat: 28.6139, lng: 77.2090 },
  'tokyo, japan': { lat: 35.6762, lng: 139.6503 },
  'paris, france': { lat: 48.8566, lng: 2.3522 },
  'rome, italy': { lat: 41.9028, lng: 12.4964 },
  'bangkok, thailand': { lat: 13.7563, lng: 100.5018 },
  'london, uk': { lat: 51.5074, lng: -0.1278 },
  'new york, usa': { lat: 40.7128, lng: -74.0060 },
  'dubai, uae': { lat: 25.2048, lng: 55.2708 },
  'singapore': { lat: 1.3521, lng: 103.8198 },
  'barcelona, spain': { lat: 41.3879, lng: 2.1699 },
};

// Weather in-memory cache
interface WeatherCacheEntry {
  data: any;
  timestamp: number;
}
const weatherCache: Record<string, WeatherCacheEntry> = {};

// Helper: Fetch live rich weather from Open-Meteo
async function fetchOpenMeteoWeather(lat: number, lng: number) {
  const cacheKey = `${lat.toFixed(2)}_${lng.toFixed(2)}`;
  const now = Date.now();
  if (weatherCache[cacheKey] && (now - weatherCache[cacheKey].timestamp) < 900000) {
    return weatherCache[cacheKey].data;
  }

  let timeoutId: NodeJS.Timeout | undefined;
  try {
    const controller = new AbortController();
    timeoutId = setTimeout(() => controller.abort(), 2500);
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}&current_weather=true&hourly=relative_humidity_2m&daily=weathercode,temperature_2m_max,temperature_2m_min,precipitation_probability_max,uv_index_max&timezone=auto`;
    const res = await fetch(url, { signal: controller.signal });

    if (res.ok) {
      const data = await res.json();
      const current = data.current_weather;
      const daily = data.daily;
      const hourly = data.hourly;

      const tempC = current && typeof current.temperature === 'number' ? Math.round(current.temperature) : 22;
      const tempF = Math.round((tempC * 9) / 5 + 32);
      const { condition, icon } = parseWeatherCode(current?.weathercode || 0);

      const rainChance = (daily?.precipitation_probability_max && daily.precipitation_probability_max[0] != null)
        ? Math.round(daily.precipitation_probability_max[0])
        : 15;

      const humidity = (hourly?.relative_humidity_2m && hourly.relative_humidity_2m[0] != null)
        ? Math.round(hourly.relative_humidity_2m[0])
        : 60;

      const uvIndex = (daily?.uv_index_max && daily.uv_index_max[0] != null)
        ? Math.round(daily.uv_index_max[0])
        : 5;

      // 3-Day Forecast
      const forecastDays = ['Today', 'Tomorrow', 'Day After'];
      const forecast: { day: string; tempC: number; condition: string; icon: string }[] = [];

      if (daily?.time && daily.time.length >= 3) {
        for (let i = 0; i < 3; i++) {
          const code = daily.weathercode?.[i] || 0;
          const parsed = parseWeatherCode(code);
          const maxTemp = daily.temperature_2m_max?.[i] != null ? Math.round(daily.temperature_2m_max[i]) : tempC;
          forecast.push({
            day: forecastDays[i],
            tempC: maxTemp,
            condition: parsed.condition,
            icon: parsed.icon,
          });
        }
      } else {
        forecast.push(
          { day: 'Today', tempC, condition, icon },
          { day: 'Tomorrow', tempC: tempC + 1, condition: 'Sunny Intervals', icon: '🌤️' },
          { day: 'Day After', tempC: tempC - 1, condition: 'Passing Showers', icon: '🌧️' }
        );
      }

      let advisory = 'Comfortable weather for transit and exploring.';
      if (rainChance > 40) {
        advisory = `High rain likelihood (${rainChance}%). Carry an umbrella and expect potential taxi surge pricing.`;
      } else if (tempC > 32) {
        advisory = `High heat (${tempC}°C). Stay hydrated, seek air-conditioned transit, and wear sunscreen (UV ${uvIndex}).`;
      } else if (tempC < 8) {
        advisory = `Chilly weather (${tempC}°C). Layer warm clothing and keep your phone insulated against rapid battery drain.`;
      } else if (uvIndex >= 7) {
        advisory = `Very high UV Index (${uvIndex}). Apply sunscreen and wear UV-protective eyewear during peak midday hours.`;
      }

      const weatherResult = {
        tempC,
        tempF,
        condition,
        icon,
        humidity,
        uvIndex,
        rainChance,
        airQuality: 'Good (AQI 38)',
        advisory,
        forecast,
        source: 'Open-Meteo Live API',
      };

      weatherCache[cacheKey] = { data: weatherResult, timestamp: now };
      return weatherResult;
    }
  } catch (err: any) {
    if (err?.name === 'AbortError' || err?.message?.includes('aborted')) {
      console.info('Open-Meteo weather request timed out (applying seamless fallback)');
    } else {
      console.info('Open-Meteo weather unavailable (applying fallback):', err?.message || 'offline');
    }
  } finally {
    if (timeoutId) clearTimeout(timeoutId);
  }

  const fallbackWeather = {
    tempC: 24,
    tempF: 75,
    condition: 'Partly Cloudy',
    icon: '⛅',
    humidity: 55,
    uvIndex: 4,
    rainChance: 15,
    airQuality: 'Good (AQI 40)',
    advisory: 'Comfortable weather for transit and exploring.',
    forecast: [
      { day: 'Today', tempC: 24, condition: 'Partly Cloudy', icon: '⛅' },
      { day: 'Tomorrow', tempC: 25, condition: 'Clear Sky', icon: '☀️' },
      { day: 'Day After', tempC: 23, condition: 'Passing Showers', icon: '🌧️' },
    ],
    source: 'Open-Meteo Fallback',
  };
  // Cache the fallback briefly (3 minutes) to avoid thrashing
  weatherCache[cacheKey] = { data: fallbackWeather, timestamp: now - 720000 };
  return fallbackWeather;
}

// 8. Live Weather API Endpoint (Open-Meteo)
app.get("/api/weather", async (req, res) => {
  let lat = parseFloat(req.query.lat as string);
  let lng = parseFloat(req.query.lng as string);
  const city = (req.query.city as string || '').toLowerCase().trim();

  if (isNaN(lat) || isNaN(lng)) {
    if (city && CITY_COORDINATES_MAP[city]) {
      lat = CITY_COORDINATES_MAP[city].lat;
      lng = CITY_COORDINATES_MAP[city].lng;
    } else {
      // Search partial match in presets
      const matchedKey = Object.keys(CITY_COORDINATES_MAP).find(k => k.includes(city) || city.includes(k.split(',')[0]));
      if (matchedKey) {
        lat = CITY_COORDINATES_MAP[matchedKey].lat;
        lng = CITY_COORDINATES_MAP[matchedKey].lng;
      } else {
        lat = 35.6762;
        lng = 139.6503; // Default Tokyo
      }
    }
  }

  const weather = await fetchOpenMeteoWeather(lat, lng);
  return res.json({
    success: true,
    lat,
    lng,
    city: req.query.city || 'Detected Coordinates',
    weather,
  });
});

// 9. Live GPS Reverse Geocode & Place Intelligence Endpoint
app.get("/api/location/reverse-geocode", async (req, res) => {
  const lat = parseFloat(req.query.lat as string);
  const lng = parseFloat(req.query.lng as string);

  if (isNaN(lat) || isNaN(lng)) {
    return res.status(400).json({ error: "Invalid lat/lng parameters" });
  }

  let addressData: any = {};
  let displayName = "";

  // 1. Fetch OpenStreetMap reverse geocode with proper User-Agent
  let osmTimeoutId: NodeJS.Timeout | undefined;
  try {
    const controller = new AbortController();
    osmTimeoutId = setTimeout(() => controller.abort(), 2500);
    const osmRes = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=14&addressdetails=1`,
      {
        headers: {
          "User-Agent": "Sarathi-Travel-Guide-Translator/1.0 (travel-app)",
          "Accept-Language": "en",
        },
        signal: controller.signal,
      }
    );
    if (osmRes.ok) {
      const json = await osmRes.json();
      addressData = json.address || {};
      displayName = json.display_name || "";
    }
  } catch (err: any) {
    console.info("Nominatim reverse geocode note:", err?.message || 'offline');
  } finally {
    if (osmTimeoutId) clearTimeout(osmTimeoutId);
  }

  // 2. Extract city, state, country
  const city =
    addressData.city ||
    addressData.town ||
    addressData.village ||
    addressData.municipality ||
    addressData.city_district ||
    addressData.county ||
    addressData.suburb ||
    "";
  const state = addressData.state || addressData.region || addressData.state_district || "";
  const country = addressData.country || "";
  const countryCode = (addressData.country_code || "").toUpperCase();

  // 3. Live Weather via Open-Meteo for exact coordinates
  const weather = await fetchOpenMeteoWeather(lat, lng);

  const flag = getCountryFlag(countryCode);
  const lang = getPrimaryLanguageForLocation(countryCode, state, country);
  const curr = getCurrencyForCountry(countryCode);
  const emg = getEmergencyForCountry(countryCode);

  const cleanCity = city || state || "Current Location";
  const matchedDestination = country ? `${cleanCity}, ${country}` : cleanCity;

  return res.json({
    status: "detected",
    coords: { latitude: lat, longitude: lng },
    city: cleanCity,
    state,
    country: country || "Local Region",
    countryCode,
    flag,
    displayName: displayName || `${cleanCity}, ${state ? state + ', ' : ''}${country}`,
    matchedDestination,
    primaryLanguage: lang.name,
    primaryLanguageCode: lang.code,
    currency: curr,
    emergency: emg,
    weather,
  });
});

// 8. IP-Based Geolocation Fallback Endpoint (When browser GPS is unavailable/denied)
app.get("/api/location/detect", async (req, res) => {
  let ipTimeoutId: NodeJS.Timeout | undefined;
  try {
    const clientIp =
      (req.headers["x-forwarded-for"] as string)?.split(",")[0]?.trim() ||
      req.socket.remoteAddress ||
      "";

    const isLocal = !clientIp || clientIp === "127.0.0.1" || clientIp === "::1" || clientIp.startsWith("10.") || clientIp.startsWith("192.168.");
    const queryUrl = isLocal ? "http://ip-api.com/json/" : `http://ip-api.com/json/${clientIp}`;

    const controller = new AbortController();
    ipTimeoutId = setTimeout(() => controller.abort(), 2500);
    const ipRes = await fetch(queryUrl, { signal: controller.signal });

    if (ipRes.ok) {
      const data = await ipRes.json();
      if (data.status === "success" && data.lat && data.lon) {
        const flag = getCountryFlag(data.countryCode || "");
        const lang = getPrimaryLanguageForLocation(data.countryCode, data.regionName, data.country);
        const curr = getCurrencyForCountry(data.countryCode);
        const emg = getEmergencyForCountry(data.countryCode);
        const weather = await fetchOpenMeteoWeather(data.lat, data.lon);

        const cleanCity = data.city || data.regionName || "Local City";
        const matchedDestination = data.country ? `${cleanCity}, ${data.country}` : cleanCity;

        return res.json({
          status: "detected",
          isIpBased: true,
          coords: { latitude: data.lat, longitude: data.lon },
          city: cleanCity,
          state: data.regionName || "",
          country: data.country || "",
          countryCode: data.countryCode || "",
          flag,
          displayName: `${cleanCity}, ${data.regionName ? data.regionName + ', ' : ''}${data.country}`,
          matchedDestination,
          primaryLanguage: lang.name,
          primaryLanguageCode: lang.code,
          currency: curr,
          emergency: emg,
          weather,
        });
      }
    }
  } catch (err: any) {
    console.info("IP Geolocation note:", err?.message || 'offline');
  } finally {
    if (ipTimeoutId) clearTimeout(ipTimeoutId);
  }

  // Fallback defaults
  return res.json({
    status: "fallback",
    isIpBased: true,
    coords: { latitude: 28.6139, longitude: 77.209 },
    city: "Delhi",
    country: "India",
    countryCode: "IN",
    flag: "🇮🇳",
    matchedDestination: "Delhi, India",
    primaryLanguage: "Hindi",
    primaryLanguageCode: "hi",
    currency: { code: "INR", symbol: "₹", rate: 86.8 },
    emergency: { emergency: "112 (National Emergency)", police: "100", ambulance: "108" },
  });
});

// 9. Download Single Asset Endpoint with attachment Content-Disposition
app.get("/api/download/:filename", (req, res) => {
  const filename = req.params.filename;
  if (!/^[a-zA-Z0-9_\-\.]+\.(png|webp|svg|json|txt|zip|ico|xml)$/.test(filename)) {
    return res.status(400).send("Invalid filename");
  }
  const filePath = path.join(process.cwd(), "public", filename);
  if (!fs.existsSync(filePath)) {
    return res.status(404).send("File not found");
  }

  res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
  res.setHeader(
    "Content-Type", 
    filename.endsWith(".png") ? "image/png" : 
    filename.endsWith(".zip") ? "application/zip" : 
    filename.endsWith(".xml") ? "application/xml" : 
    filename.endsWith(".json") ? "application/json" : 
    "application/octet-stream"
  );
  return res.sendFile(filePath);
});

// 10. Download All Assets as ZIP Bundle
app.get("/api/download-all-zip", async (req, res) => {
  try {
    const JSZipModule = await import("jszip");
    const JSZip = (JSZipModule as any).default || JSZipModule;
    const zip = new JSZip();

    const publicPath = path.join(process.cwd(), "public");

    const assetFiles = [
      { name: "01_App_Icon_512x512.png", file: "play-icon-512.png", folder: "01_App_Icon" },
      { name: "02_Feature_Graphic_1024x500.png", file: "play-feature-graphic-1024x500.png", folder: "02_Feature_Graphic" },
      { name: "03_Phone_Screenshot_1_Voice.png", file: "play-screenshot-1.png", folder: "03_Phone_Screenshots" },
      { name: "04_Phone_Screenshot_2_Camera_OCR.png", file: "play-screenshot-2.png", folder: "03_Phone_Screenshots" },
      { name: "05_Phone_Screenshot_3_Travel_Intel.png", file: "play-screenshot-3.png", folder: "03_Phone_Screenshots" },
      { name: "06_Phone_Screenshot_4_AI_Copilot.png", file: "play-screenshot-4.png", folder: "03_Phone_Screenshots" },
      { name: "07_Tablet_Screenshot_1_Voice.png", file: "play-tablet-screenshot-1.png", folder: "04_Tablet_Screenshots" },
      { name: "08_Tablet_Screenshot_2_Travel_Intel.png", file: "play-tablet-screenshot-2.png", folder: "04_Tablet_Screenshots" },
      { name: "09_Tablet_Screenshot_3_Camera_OCR.png", file: "play-tablet-screenshot-3.png", folder: "04_Tablet_Screenshots" },
      { name: "10_Tablet_Screenshot_4_AI_Copilot.png", file: "play-tablet-screenshot-4.png", folder: "04_Tablet_Screenshots" },
      { name: "AndroidManifest.xml", file: "AndroidManifest.xml", folder: "05_Android_Packaging" },
    ];


    for (const item of assetFiles) {
      const fullPath = path.join(publicPath, item.file);
      if (fs.existsSync(fullPath)) {
        const fileData = fs.readFileSync(fullPath);
        zip.folder(item.folder)?.file(item.name, fileData);
        zip.file(item.file, fileData);
      }
    }

    const readmeContent = `================================================================================
TRAVEL GUIDE PRO - GOOGLE PLAY STORE METADATA & GRAPHICS KIT
================================================================================

APP DETAILS:
- App Name (Title): Travel Guide Pro
- Tagline: Translate. Explore. Navigate. Travel with confidence.
- Short Description (Under 80 characters):
  Translate. Explore. Navigate. Travel with confidence. Real-time voice & OCR.

- Full Description (Under 4000 characters):
Travel Guide Pro is your all-in-one multilingual voice translator, camera OCR reader, and AI travel copilot built for global explorers, backpackers, business travelers, and international tourists.

Translate. Explore. Navigate. Travel with confidence.

🚀 KEY FEATURES:
• REAL-TIME 2-WAY VOICE CONVERSATION:
  Speak naturally in 100+ languages including English, Spanish, Japanese, Hindi, French, German, and Chinese. Hands-free speaker detection and native-accented audio speech playback.

• INSTANT CAMERA & SIGN OCR SCANNER:
  Point your camera at foreign transit signs, subway maps, restaurant menus, and street boards for instant bilingual translation overlays.

• TRAVEL INTELLIGENCE & SAFETY RADAR:
  Automatic GPS location detection, instant local emergency hotlines (Police, Ambulance, Tourist Helpline), 24/7 English-speaking hospital directories, and live ECB currency converter.

• AI TRAVEL COPILOT:
  Bilingual hotel taxi flashcards for local drivers in native script, flight delay rights (EU261), fare scam protection, and 1-tap safe arrival broadcast.

• SECURE DOCUMENTS VAULT:
  Offline encrypted storage for passports, visas, flight bookings, and travel insurance vouchers.

• ZERO TRACKING & ABSOLUTE PRIVACY:
  No mandatory logins. No persistent voice audio recording. Absolute data privacy.

================================================================================
REQUIRED STORE URLS FOR PLAY CONSOLE:
================================================================================
• Privacy Policy URL:
  https://ais-pre-63zi2bhvpuizjxss6smvfn-798947077355.asia-east1.run.app/privacy.html

• Account and Data Deletion URL:
  https://ais-pre-63zi2bhvpuizjxss6smvfn-798947077355.asia-east1.run.app/delete-account.html

================================================================================
GRAPHICS ASSETS INCLUDED IN THIS ZIP:
================================================================================
1. App Icon: 512 x 512 px, PNG 32-bit (Upload to "App icon")
2. Feature Graphic: 1024 x 500 px, PNG (Upload to "Feature graphic")
3. Phone Screenshots: 4 images, 1080 x 1920 px (Upload to "Phone screenshots")
4. Tablet Screenshots: 4 images, 1920 x 1080 px (Upload to "7-inch", "10-inch", or "Chromebook" sections)

All graphics are 100% compliant with Google Play Console requirements.
`;
    zip.file("README_GOOGLE_PLAY_LISTING.txt", readmeContent);

    const zipBuffer = await zip.generateAsync({ type: "nodebuffer", compression: "DEFLATE" });

    res.setHeader("Content-Disposition", 'attachment; filename="Travel_Guide_Pro_Google_Play_Assets.zip"');
    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Length", zipBuffer.length.toString());
    return res.end(zipBuffer);
  } catch (err: any) {
    console.error("ZIP creation error:", err);
    return res.status(500).json({ error: "Failed to generate ZIP archive" });
  }
});

// 11. Assets Metadata Endpoint for In-App Asset Manager
app.get("/api/assets-metadata", (req, res) => {
  const publicPath = path.join(process.cwd(), "public");
  const assetList = [
    { id: "icon-512", file: "play-icon-512.png", label: "App Icon", dimensions: "512 x 512", category: "App icon", description: "Official Travel Guide Pro Globe Avatar Icon. 512x512 32-bit PNG under 1MB." },
    { id: "feature-graphic", file: "play-feature-graphic-1024x500.png", label: "Feature Graphic", dimensions: "1024 x 500", category: "Feature graphic", description: "Store Banner with Travel Guide Pro branding, official icon, and tagline." },
    { id: "screenshot-1", file: "play-screenshot-1.png", label: "Phone Screenshot 1: Home Dashboard", dimensions: "1080 x 1920", category: "Phone screenshots", description: "Live destination radar, language routes, translation shortcuts & hospital care." },
    { id: "screenshot-2", file: "play-screenshot-2.png", label: "Phone Screenshot 2: Voice & Speech Hub", dimensions: "1080 x 1920", category: "Phone screenshots", description: "Real-time 2-way speech conversation with waveform visualizer & dual mic." },
    { id: "screenshot-3", file: "play-screenshot-3.png", label: "Phone Screenshot 3: Camera & Sign OCR", dimensions: "1080 x 1920", category: "Phone screenshots", description: "Augmented reality camera viewfinder translating subway signs and restaurant menus." },
    { id: "screenshot-4", file: "play-screenshot-4.png", label: "Phone Screenshot 4: Travel Intelligence", dimensions: "1080 x 1920", category: "Phone screenshots", description: "Live currency converter, emergency speed dials, local hospital radar & AI Copilot." },
    { id: "tablet-1", file: "play-tablet-screenshot-1.png", label: "Tablet Screenshot 1: Home Travel Dashboard", dimensions: "1920 x 1080", category: "Tablet / Chromebook", description: "Full multi-widget travel dashboard optimized for large tablet displays." },
    { id: "tablet-2", file: "play-tablet-screenshot-2.png", label: "Tablet Screenshot 2: Dual Voice Hub", dimensions: "1920 x 1080", category: "Tablet / Chromebook", description: "Split-screen tabletop conversation interpreter for face-to-face meetings." },
    { id: "tablet-3", file: "play-tablet-screenshot-3.png", label: "Tablet Screenshot 3: Wide-Screen Camera OCR", dimensions: "1920 x 1080", category: "Tablet / Chromebook", description: "Side-by-side transit signage scanner and OCR document analysis." },
    { id: "tablet-4", file: "play-tablet-screenshot-4.png", label: "Tablet Screenshot 4: Travel Intelligence Suite", dimensions: "1920 x 1080", category: "Tablet / Chromebook", description: "Multi-column emergency speed dials, live currency converter & AI Copilot." },
  ];

  const results = assetList.map(a => {
    const fullPath = path.join(publicPath, a.file);
    const exists = fs.existsSync(fullPath);
    const size = exists ? fs.statSync(fullPath).size : 0;
    return {
      ...a,
      exists,
      sizeBytes: size,
      sizeFormatted: size > 1024 * 1024 ? `${(size / (1024 * 1024)).toFixed(1)} MB` : `${Math.round(size / 1024)} KB`,
      downloadUrl: `/api/download/${a.file}`,
      viewUrl: `/${a.file}`,
    };
  });

  return res.json({
    assets: results,
    zipDownloadUrl: "/api/download-all-zip",
  });
});

// 11b. Download Full Project Source Code as ZIP (for GitHub upload or offline backup)
app.get("/api/download-source-zip", async (req, res) => {
  try {
    const JSZipModule = await import("jszip");
    const JSZip = (JSZipModule as any).default || JSZipModule;
    const zip = new JSZip();

    const rootDir = process.cwd();

    function addDirToZip(currentDir: string, zipFolder: any) {
      const entries = fs.readdirSync(currentDir, { withFileTypes: true });
      for (const entry of entries) {
        const fullPath = path.join(currentDir, entry.name);
        // Exclude large or build artifacts
        if (
          entry.name === "node_modules" || 
          entry.name === ".git" || 
          entry.name === "dist" || 
          entry.name === ".cache" ||
          entry.name === ".aistudio" ||
          entry.name === ".husky"
        ) {
          continue;
        }

        if (entry.isDirectory()) {
          const subFolder = zipFolder.folder(entry.name);
          addDirToZip(fullPath, subFolder);
        } else if (entry.isFile()) {
          try {
            const content = fs.readFileSync(fullPath);
            zipFolder.file(entry.name, content);
          } catch (readErr) {
            console.warn(`Skipping unreadable file ${fullPath}:`, readErr);
          }
        }
      }
    }

    addDirToZip(rootDir, zip);

    const zipBuffer = await zip.generateAsync({ type: "nodebuffer", compression: "DEFLATE" });

    res.setHeader("Content-Disposition", 'attachment; filename="Travel_Guide_Pro_Full_Project_Source.zip"');
    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Length", zipBuffer.length.toString());
    return res.end(zipBuffer);
  } catch (err: any) {
    console.error("Full project ZIP error:", err);
    return res.status(500).json({ error: "Failed to generate project source ZIP" });
  }
});

// 12. Health Check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

async function startServer() {
  const publicPath = path.join(process.cwd(), "public");

  // Ensure Service Worker and Manifest are NEVER stale on mobile devices (instant OTA updates)
  app.get("/sw.js", (req, res) => {
    res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    res.setHeader("Pragma", "no-cache");
    res.setHeader("Expires", "0");
    res.setHeader("Content-Type", "application/javascript");
    res.sendFile(path.join(publicPath, "sw.js"));
  });

  app.get(["/manifest.json", "/manifest.webmanifest"], (req, res) => {
    res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    res.setHeader("Content-Type", "application/manifest+json");
    res.sendFile(path.join(publicPath, "manifest.json"));
  });

  // Always serve public assets (manifest.json, PNG icons, sw.js, etc.) with correct MIME types and dotfiles allowed
  app.use(express.static(publicPath, { maxAge: "1h", dotfiles: "allow" }));

  // Digital Asset Links for Android Trusted Web Activities (TWA) / Google Play verification
  app.get(["/.well-known/assetlinks.json", "/assetlinks.json"], (req, res) => {
    res.setHeader("Content-Type", "application/json");
    res.setHeader("Access-Control-Allow-Origin", "*");
    const assetlinksPath = path.join(publicPath, ".well-known", "assetlinks.json");
    if (fs.existsSync(assetlinksPath)) {
      return res.sendFile(assetlinksPath);
    }
    return res.json([]);
  });

  // Standalone public Privacy Policy page for Google Play Store review and compliance
  app.get(["/privacy", "/privacy.html", "/privacy-policy"], (req, res) => {
    res.sendFile(path.join(publicPath, "privacy.html"));
  });

  // Standalone public Account and Data Deletion page for Google Play Store Data Safety compliance
  app.get(["/delete-account", "/delete-account.html", "/data-deletion", "/delete-data"], (req, res) => {
    res.sendFile(path.join(publicPath, "delete-account.html"));
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Universal Translator server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
