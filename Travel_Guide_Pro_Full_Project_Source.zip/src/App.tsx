import React, { useState, useEffect, useMemo } from 'react';
import { 
  Home, 
  Mic, 
  Users, 
  MessagesSquare, 
  Camera, 
  FileText, 
  AlertTriangle, 
  History, 
  Compass, 
  Download, 
  Settings,
  Bot,
  Sparkles,
  Languages,
  MapPin
} from 'lucide-react';
import { Language, TranslationRecord, VoiceSettings, AuthUser, UserLanguagePreferences } from './types';
import { POPULAR_LANGUAGES, DEFAULT_SOURCE_LANG, DEFAULT_TARGET_LANG, findLanguageByCode } from './data/languages';
import { speakText } from './utils/speech';
import { Header } from './components/Header';
import { HomeScreen } from './components/HomeScreen';
import { LiveConversationHubScreen } from './components/LiveConversationHubScreen';
import { ConversationScreen, ConversationMode } from './components/ConversationScreen';
import { CameraTranslateScreen } from './components/CameraTranslateScreen';
import { TextTranslateScreen } from './components/TextTranslateScreen';
import { EmergencyScreen } from './components/EmergencyScreen';
import { TranslateHubScreen } from './components/translate/TranslateHubScreen';
import { TravelIntelligenceScreen } from './components/travel/TravelIntelligenceScreen';
import { AITravelAgentScreen } from './components/travel/AITravelAgentScreen';
import { DestinationCity, TravelDocument } from './types/travel';
import { CITIES_DATA, resolveCityProfile } from './data/travelData';
import { 
  loadStoredTravelDocuments, 
  saveStoredTravelDocuments, 
  loadActiveDestination, 
  saveActiveDestination 
} from './services/travelService';
import { 
  detectDeviceLocation, 
  loadStoredLocationState, 
  LocationDetectionResult 
} from './services/locationService';
import { LanguageSelectorModal } from './components/LanguageSelectorModal';
import { TravelPhrasebookModal } from './components/TravelPhrasebookModal';
import { OfflinePacksModal } from './components/OfflinePacksModal';
import { HistoryModal } from './components/HistoryModal';
import { SettingsModal } from './components/SettingsModal';
import { PermissionsModal } from './components/PermissionsModal';
import { InstantPermissionPrompt } from './components/InstantPermissionPrompt';
import { checkLocationPermission, checkAllPermissions } from './utils/permissions';
import { AuthScreen } from './components/AuthScreen';
import { signOutGoogleReal, deleteUserAccountReal, subscribeToAuthState } from './utils/firebaseAuth';



export type AppScreen = 
  | 'home' 
  | 'translate' 
  | 'intelligence' 
  | 'agent' 
  | 'conversation-hub' 
  | 'voice' 
  | 'face-to-face' 
  | 'camera' 
  | 'text' 
  | 'emergency';

export default function App() {
  // Navigation State: Supports Home, Translation Hub, Travel Intelligence, and AI Travel Agent
  const [currentScreen, setCurrentScreen] = useState<AppScreen>('home');
  const [navHistory, setNavHistory] = useState<AppScreen[]>(['home']);

  // Initial tab for Travel Intelligence Screen
  const [intelligenceInitialTab, setIntelligenceInitialTab] = useState<
    'dashboard' | 'nearby' | 'navigation' | 'documents' | 'transport'
  >('dashboard');

  // Unified Conversation View Mode ('handheld' | 'tabletop')
  const [conversationMode, setConversationMode] = useState<ConversationMode>('handheld');

  // Active Sub-mode within Translate Tab
  const [translateSubMode, setTranslateSubMode] = useState<'conversation' | 'camera' | 'text' | 'emergency'>('conversation');

  // Travel Intelligence & Documents Persistent State
  const [activeDestination, setActiveDestination] = useState<DestinationCity>(() => loadActiveDestination());
  const [travelDocuments, setTravelDocuments] = useState<TravelDocument[]>(() => loadStoredTravelDocuments());

  // Location-Based Destination State
  const [locationState, setLocationState] = useState<LocationDetectionResult | null>(() => loadStoredLocationState());
  const [isDetectingLocation, setIsDetectingLocation] = useState(false);

  // Deep Prompt routing for AI Travel Agent
  const [agentInitialPrompt, setAgentInitialPrompt] = useState<string | undefined>(undefined);

  const handleUpdateDestination = (city: DestinationCity, detectedResult?: LocationDetectionResult) => {
    setActiveDestination(city);
    saveActiveDestination(city);
    const resolved = resolveCityProfile(city, detectedResult || locationState);
    const langCode = detectedResult?.primaryLanguageCode || resolved?.primaryLanguageCode;
    if (langCode) {
      const destLang = findLanguageByCode(langCode);
      if (destLang) {
        setTargetLanguage(destLang);
        setPersonBLanguage(destLang);
      }
    }
  };

  const handleDetectLocation = async () => {
    setIsDetectingLocation(true);
    try {
      const result = await detectDeviceLocation();
      setLocationState(result);
      if (result.matchedDestination) {
        handleUpdateDestination(result.matchedDestination, result);
      }
    } catch (err) {
      console.warn('Location detection failed:', err);
    } finally {
      setIsDetectingLocation(false);
    }
  };

  // Attempt automatic detection on initial load
  useEffect(() => {
    handleDetectLocation();
  }, []);

  const handleUpdateDocuments = (docs: TravelDocument[]) => {
    setTravelDocuments(docs);
    saveStoredTravelDocuments(docs);
  };

  // User Default Language Preferences with LocalStorage & AuthUser sync
  const [userLangPrefs, setUserLangPrefs] = useState<UserLanguagePreferences>(() => {
    try {
      const saved = localStorage.getItem('omnitranslate_user_lang_prefs');
      if (saved) return JSON.parse(saved);
      const authSaved = localStorage.getItem('omnitranslate_auth_user');
      if (authSaved) {
        const parsed = JSON.parse(authSaved);
        if (parsed.preferences) return parsed.preferences;
      }
    } catch {}
    return {
      defaultUserLanguageCode: 'hi',
      preferredTranslationLanguageCode: 'en',
    };
  });

  const defaultUserLanguage = useMemo(() => {
    return findLanguageByCode(userLangPrefs.defaultUserLanguageCode);
  }, [userLangPrefs.defaultUserLanguageCode]);

  const preferredTranslationLanguage = useMemo(() => {
    return findLanguageByCode(userLangPrefs.preferredTranslationLanguageCode);
  }, [userLangPrefs.preferredTranslationLanguageCode]);

  // Active Languages (initial defaults loaded from user language preferences)
  const [sourceLanguage, setSourceLanguage] = useState<Language>(() => {
    return findLanguageByCode(userLangPrefs.defaultUserLanguageCode);
  });
  const [targetLanguage, setTargetLanguage] = useState<Language>(() => {
    return findLanguageByCode(userLangPrefs.preferredTranslationLanguageCode);
  });

  // F2F Person Languages
  const [personALanguage, setPersonALanguage] = useState<Language>(() => {
    return findLanguageByCode(userLangPrefs.defaultUserLanguageCode);
  });
  const [personBLanguage, setPersonBLanguage] = useState<Language>(() => {
    return findLanguageByCode(userLangPrefs.preferredTranslationLanguageCode);
  });

  // User Authentication State
  const [authUser, setAuthUser] = useState<AuthUser | null>(() => {
    try {
      const saved = localStorage.getItem('omnitranslate_auth_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const handleUpdateDefaultUserLanguage = (lang: Language) => {
    setUserLangPrefs(prev => {
      const newPrefs: UserLanguagePreferences = {
        ...prev,
        defaultUserLanguageCode: lang.code,
      };
      try {
        localStorage.setItem('omnitranslate_user_lang_prefs', JSON.stringify(newPrefs));
        if (authUser) {
          const updated = { ...authUser, preferences: newPrefs };
          setAuthUser(updated);
          localStorage.setItem('omnitranslate_auth_user', JSON.stringify(updated));
        }
      } catch (e) {
        console.warn('Failed to save language preferences', e);
      }
      return newPrefs;
    });
    setSourceLanguage(lang);
    setPersonALanguage(lang);
  };

  const handleUpdatePreferredTranslationLanguage = (lang: Language) => {
    setUserLangPrefs(prev => {
      const newPrefs: UserLanguagePreferences = {
        ...prev,
        preferredTranslationLanguageCode: lang.code,
      };
      try {
        localStorage.setItem('omnitranslate_user_lang_prefs', JSON.stringify(newPrefs));
        if (authUser) {
          const updated = { ...authUser, preferences: newPrefs };
          setAuthUser(updated);
          localStorage.setItem('omnitranslate_auth_user', JSON.stringify(updated));
        }
      } catch (e) {
        console.warn('Failed to save language preferences', e);
      }
      return newPrefs;
    });
    setTargetLanguage(lang);
    setPersonBLanguage(lang);
  };

  const handleUpdateLanguagePair = (userLang: Language, transLang: Language) => {
    const newPrefs: UserLanguagePreferences = {
      defaultUserLanguageCode: userLang.code,
      preferredTranslationLanguageCode: transLang.code,
    };
    setUserLangPrefs(newPrefs);
    setSourceLanguage(userLang);
    setPersonALanguage(userLang);
    setTargetLanguage(transLang);
    setPersonBLanguage(transLang);
    try {
      localStorage.setItem('omnitranslate_user_lang_prefs', JSON.stringify(newPrefs));
      if (authUser) {
        const updated = { ...authUser, preferences: newPrefs };
        setAuthUser(updated);
        localStorage.setItem('omnitranslate_auth_user', JSON.stringify(updated));
      }
    } catch (e) {
      console.warn('Failed to save language preferences', e);
    }
  };

  const handleSwapDefaultLanguages = () => {
    setUserLangPrefs(prev => {
      const newPrefs: UserLanguagePreferences = {
        defaultUserLanguageCode: prev.preferredTranslationLanguageCode,
        preferredTranslationLanguageCode: prev.defaultUserLanguageCode,
      };
      const newSource = findLanguageByCode(newPrefs.defaultUserLanguageCode);
      const newTarget = findLanguageByCode(newPrefs.preferredTranslationLanguageCode);
      setSourceLanguage(newSource);
      setPersonALanguage(newSource);
      setTargetLanguage(newTarget);
      setPersonBLanguage(newTarget);
      try {
        localStorage.setItem('omnitranslate_user_lang_prefs', JSON.stringify(newPrefs));
        if (authUser) {
          const updated = { ...authUser, preferences: newPrefs };
          setAuthUser(updated);
          localStorage.setItem('omnitranslate_auth_user', JSON.stringify(updated));
        }
      } catch (e) {
        console.warn('Failed to save language preferences', e);
      }
      return newPrefs;
    });
  };

  const handleLogin = (user: AuthUser) => {
    if (user.preferences) {
      setUserLangPrefs(user.preferences);
      setSourceLanguage(findLanguageByCode(user.preferences.defaultUserLanguageCode));
      setPersonALanguage(findLanguageByCode(user.preferences.defaultUserLanguageCode));
      setTargetLanguage(findLanguageByCode(user.preferences.preferredTranslationLanguageCode));
      setPersonBLanguage(findLanguageByCode(user.preferences.preferredTranslationLanguageCode));
      try {
        localStorage.setItem('omnitranslate_user_lang_prefs', JSON.stringify(user.preferences));
      } catch {}
    } else {
      user.preferences = userLangPrefs;
    }
    setAuthUser(user);
    try {
      localStorage.setItem('omnitranslate_auth_user', JSON.stringify(user));
    } catch (e) {
      console.warn('Failed to save auth session', e);
    }
  };

  const handleSignOut = () => {
    signOutGoogleReal();
    setAuthUser(null);
    try {
      localStorage.removeItem('omnitranslate_auth_user');
    } catch (e) {
      console.warn('Failed to clear auth session', e);
    }
  };

  const handleDeleteAccount = async () => {
    try {
      await deleteUserAccountReal();
    } catch (e) {
      console.warn('Failed to delete user account:', e);
    }
    setAuthUser(null);
    setHistory([]);
    setTravelDocuments([]);
    try {
      localStorage.removeItem('omnitranslate_auth_user');
      localStorage.removeItem('omnitranslate_user_lang_prefs');
      localStorage.removeItem('live_ai_history');
      localStorage.removeItem('omnitranslate_travel_documents');
      localStorage.removeItem('omnitranslate_user_location');
      localStorage.removeItem('omnitranslate_fast_cache');
      localStorage.removeItem('live_ai_permissions_checked');
      localStorage.removeItem('live_ai_home_permissions_handled');
      localStorage.removeItem('omnitranslate_permissions_checked');
      localStorage.removeItem('omnitranslate_destination');
    } catch (e) {
      console.warn('Failed to clear stored data during account deletion:', e);
    }
  };

  // Synchronize authentic Firebase Google session if present
  useEffect(() => {
    const unsubscribe = subscribeToAuthState((firebaseUser) => {
      if (firebaseUser) {
        setAuthUser(prev => {
          if (prev && prev.id === firebaseUser.uid && prev.provider === 'google') {
            return prev;
          }
          const updated: AuthUser = {
            id: firebaseUser.uid,
            name: firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'Google User',
            email: firebaseUser.email || undefined,
            avatar: firebaseUser.photoURL || undefined,
            isGuest: false,
            provider: 'google',
            loginTime: Date.now(),
            preferences: prev?.preferences || userLangPrefs,
          };
          try {
            localStorage.setItem('omnitranslate_auth_user', JSON.stringify(updated));
          } catch {}
          return updated;
        });
      }
    });
    return () => unsubscribe();
  }, []);

  // Modals
  const [langSelectorTarget, setLangSelectorTarget] = useState<
    'source' | 'target' | 'personA' | 'personB' | 'emergency' | 'defaultUser' | 'preferredTranslation' | null
  >(null);
  const [isTravelPhrasebookOpen, setIsTravelPhrasebookOpen] = useState(false);
  const [isOfflinePacksOpen, setIsOfflinePacksOpen] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isPermissionsModalOpen, setIsPermissionsModalOpen] = useState(false);
  const [isInitialPermissionsCheck, setIsInitialPermissionsCheck] = useState(false);

  // Instant prompt for location & device permissions (can be triggered from Settings if requested)
  const [isInstantPromptOpen, setIsInstantPromptOpen] = useState<boolean>(false);


  // Connectivity & Offline
  const [isOffline, setIsOffline] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('live_ai_offline_mode') || localStorage.getItem('omni_offline_mode');
      if (saved !== null) return saved === 'true';
      return !navigator.onLine;
    } catch {
      return false;
    }
  });

  useEffect(() => {
    const handleOnline = () => {
      const manualOffline = (localStorage.getItem('live_ai_offline_mode') || localStorage.getItem('omni_offline_mode')) === 'true';
      if (!manualOffline) setIsOffline(false);
    };
    const handleOffline = () => {
      setIsOffline(true);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handleToggleOfflineMode = () => {
    setIsOffline(prev => {
      const next = !prev;
      try {
        localStorage.setItem('live_ai_offline_mode', String(next));
      } catch (e) {
        console.warn('Failed to save offline mode state', e);
      }
      return next;
    });
  };

  // Settings
  const [voiceSettings, setVoiceSettings] = useState<VoiceSettings>({
    speechRate: 1.0,
    pitch: 1.0,
    volume: 1.0,
    voiceGender: 'neutral',
  });

  // History State with LocalStorage Persistence (Starts empty for clean Live mode)
  const [history, setHistory] = useState<TranslationRecord[]>(() => {
    try {
      const saved = localStorage.getItem('live_ai_history') || localStorage.getItem('omnitranslate_history');
      if (!saved) return [];
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed)) {
        // Strip out any dummy/demo/sample records so user sees NO data until they use features
        return parsed.filter(item => 
          item && 
          item.id && 
          !item.id.startsWith('hist_') && 
          !item.id.startsWith('dummy_') && 
          !item.id.startsWith('sample_') && 
          !item.id.startsWith('demo_')
        );
      }
      return [];
    } catch {
      return [];
    }
  });

  // Purge any legacy dummy records from localStorage on initial load
  useEffect(() => {
    try {
      const savedHist = localStorage.getItem('live_ai_history');
      if (savedHist) {
        const parsed = JSON.parse(savedHist);
        if (Array.isArray(parsed)) {
          const clean = parsed.filter((item: any) => 
            item && 
            item.id && 
            !item.id.startsWith('hist_') && 
            !item.id.startsWith('dummy_') && 
            !item.id.startsWith('sample_') && 
            !item.id.startsWith('demo_')
          );
          localStorage.setItem('live_ai_history', JSON.stringify(clean));
          if (clean.length === 0) {
            setHistory([]);
          }
        }
      }
      const savedDocs = localStorage.getItem('omnitranslate_travel_documents');
      if (savedDocs) {
        const parsed = JSON.parse(savedDocs);
        if (Array.isArray(parsed)) {
          const clean = parsed.filter((doc: any) => 
            doc && 
            doc.id && 
            !doc.id.startsWith('dummy_') && 
            !doc.id.startsWith('sample_') && 
            !doc.id.startsWith('demo_')
          );
          localStorage.setItem('omnitranslate_travel_documents', JSON.stringify(clean));
          setTravelDocuments(clean);
        }
      }
    } catch {}
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem('live_ai_history', JSON.stringify(history));
    } catch (err) {
      console.warn('Failed to save translation history to localStorage:', err);
    }
  }, [history]);

  const addTranslationRecord = (record: TranslationRecord) => {
    setHistory(prev => [record, ...prev]);
  };

  const handleToggleStar = (id: string) => {
    setHistory(prev =>
      prev.map(item => (item.id === id ? { ...item, starred: !item.starred } : item))
    );
  };

  const handleClearHistory = () => {
    setHistory([]);
  };

  // Language Swapping
  const handleSwapMainLanguages = () => {
    if (sourceLanguage.code === 'auto') return;
    const temp = sourceLanguage;
    setSourceLanguage(targetLanguage);
    setTargetLanguage(temp);
  };

  const handleSwapF2FLanguages = () => {
    const temp = personALanguage;
    setPersonALanguage(personBLanguage);
    setPersonBLanguage(temp);
  };

  const handleLanguageSelect = (lang: Language) => {
    if (langSelectorTarget === 'source') {
      setSourceLanguage(lang);
    } else if (langSelectorTarget === 'target') {
      setTargetLanguage(lang);
    } else if (langSelectorTarget === 'personA') {
      setPersonALanguage(lang);
    } else if (langSelectorTarget === 'personB') {
      setPersonBLanguage(lang);
    } else if (langSelectorTarget === 'emergency') {
      setTargetLanguage(lang);
    } else if (langSelectorTarget === 'defaultUser') {
      handleUpdateDefaultUserLanguage(lang);
    } else if (langSelectorTarget === 'preferredTranslation') {
      handleUpdatePreferredTranslationLanguage(lang);
    }
    closeModal();
  };

  // Navigation & Browser History Sync for Mobile Back Buttons & Desktop
  const closeAllModalsState = () => {
    setIsSettingsOpen(false);
    setIsHistoryOpen(false);
    setIsOfflinePacksOpen(false);
    setIsTravelPhrasebookOpen(false);
    setIsPermissionsModalOpen(false);
    setLangSelectorTarget(null);
  };

  const navigateTo = (
    screen: AppScreen,
    mode?: ConversationMode
  ) => {
    closeAllModalsState();
    const effectiveMode = mode || conversationMode;
    if (screen === currentScreen && effectiveMode === conversationMode) return;

    setNavHistory(prev => {
      if (prev[prev.length - 1] === screen) return prev;
      return [...prev, screen];
    });

    window.history.pushState(
      { screen, conversationMode: effectiveMode, modal: null },
      ''
    );
    setCurrentScreen(screen);
    if (mode) setConversationMode(mode);
  };

  const openModal = (
    modal: 'settings' | 'history' | 'offline' | 'phrasebook' | 'permissions' | 'langSelector',
    target?: 'source' | 'target' | 'personA' | 'personB' | 'emergency' | 'defaultUser' | 'preferredTranslation' | null
  ) => {
    window.history.pushState(
      {
        screen: currentScreen,
        conversationMode,
        modal,
        langTarget: target || null,
      },
      ''
    );

    if (modal === 'settings') setIsSettingsOpen(true);
    else if (modal === 'history') setIsHistoryOpen(true);
    else if (modal === 'offline') setIsOfflinePacksOpen(true);
    else if (modal === 'phrasebook') setIsTravelPhrasebookOpen(true);
    else if (modal === 'permissions') setIsPermissionsModalOpen(true);
    else if (modal === 'langSelector') setLangSelectorTarget(target || 'source');
  };

  const closeModal = () => {
    if (window.history.state?.modal) {
      window.history.back();
    } else {
      closeAllModalsState();
    }
  };

  const handleBack = () => {
    const isAnyModalOpen =
      isSettingsOpen ||
      isHistoryOpen ||
      isOfflinePacksOpen ||
      isTravelPhrasebookOpen ||
      isPermissionsModalOpen ||
      langSelectorTarget !== null;

    if (isAnyModalOpen) {
      if (window.history.state?.modal) {
        window.history.back();
      } else {
        closeAllModalsState();
      }
      return;
    }

    // If currently in Tabletop mode within conversation, switch to handheld first
    if ((currentScreen === 'voice' || currentScreen === 'face-to-face') && conversationMode === 'tabletop') {
      if (window.history.state?.conversationMode === 'tabletop') {
        window.history.back();
      } else {
        setConversationMode('handheld');
      }
      return;
    }

    // Pop screen from true in-app navigation stack
    if (navHistory.length > 1) {
      const updated = [...navHistory];
      updated.pop(); // remove current active screen
      const prevScreen = updated[updated.length - 1] || 'home';
      setNavHistory(updated);
      setCurrentScreen(prevScreen);
      window.history.replaceState({ screen: prevScreen, conversationMode: 'handheld', modal: null }, '');
      return;
    }

    // Default fallback: go to home
    if (currentScreen !== 'home') {
      setNavHistory(['home']);
      setCurrentScreen('home');
      window.history.replaceState({ screen: 'home', conversationMode: 'handheld', modal: null }, '');
    }
  };

  // Popstate Listener: Handles physical mobile back button & browser back navigation
  useEffect(() => {
    if (!window.history.state || !window.history.state.screen) {
      window.history.replaceState(
        { screen: 'home', conversationMode: 'handheld', modal: null },
        ''
      );
    }

    const handlePopState = (e: PopStateEvent) => {
      const state = e.state as any;

      if (!state) {
        closeAllModalsState();
        setCurrentScreen('home');
        setConversationMode('handheld');
        return;
      }

      // 1. Sync Modals
      if (!state.modal) {
        closeAllModalsState();
      } else {
        setIsSettingsOpen(state.modal === 'settings');
        setIsHistoryOpen(state.modal === 'history');
        setIsOfflinePacksOpen(state.modal === 'offline');
        setIsTravelPhrasebookOpen(state.modal === 'phrasebook');
        setIsPermissionsModalOpen(state.modal === 'permissions');
        setLangSelectorTarget(state.modal === 'langSelector' ? (state.langTarget || 'source') : null);
      }

      // 2. Sync Screen & Mode
      if (state.screen) {
        setCurrentScreen(state.screen);
      } else {
        setCurrentScreen('home');
      }

      if (state.conversationMode) {
        setConversationMode(state.conversationMode);
      } else {
        setConversationMode('handheld');
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  // Keyboard shortcut: Esc key navigates back or closes active modal
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        handleBack();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [
    currentScreen,
    conversationMode,
    isSettingsOpen,
    isHistoryOpen,
    isOfflinePacksOpen,
    isTravelPhrasebookOpen,
    isPermissionsModalOpen,
    langSelectorTarget,
  ]);

  const getScreenTitle = () => {
    switch (currentScreen) {
      case 'translate':
        return 'Translation Hub';
      case 'intelligence':
        return 'Travel Intelligence';
      case 'agent':
        return 'AI Travel Agent';
      case 'conversation-hub':
        return 'Live Conversation';
      case 'voice':
      case 'face-to-face':
        return conversationMode === 'tabletop' 
          ? 'Tabletop Face-to-Face' 
          : 'Live Conversation';
      case 'camera':
        return 'Camera & Sign OCR';
      case 'text':
        return 'Text Translation';
      case 'emergency':
        return 'Emergency SOS';
      default:
        return 'Travel Guide Pro';
    }
  };

  const isTabletopActive = (currentScreen === 'voice' || currentScreen === 'face-to-face') && conversationMode === 'tabletop';

  // If user is not authenticated, show the Auth / Sign-in screen first
  if (!authUser) {
    return <AuthScreen onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* Top Universal App Header - Fixed Header */}
      {!isTabletopActive && currentScreen !== 'emergency' && (
        <Header
          onOpenSettings={() => openModal('settings')}
          isOffline={isOffline}
          onToggleOfflineMode={handleToggleOfflineMode}
          currentScreenTitle={currentScreen !== 'home' ? getScreenTitle() : undefined}
          onBack={currentScreen !== 'home' ? handleBack : undefined}
          authUser={authUser}
          onSignOut={handleSignOut}
          onOpenAuth={() => setAuthUser(null)}
        />
      )}

      {/* Main Screen Content Area - fits comfortably between fixed header and fixed bottom nav */}
      <main className="flex-1 mx-auto w-full max-w-4xl p-2.5 sm:p-4 pt-[76px] sm:pt-24 pb-20 sm:pb-24">
        {currentScreen === 'home' && (
          <HomeScreen
            onNavigate={screen => {
              if (screen === 'travel') openModal('phrasebook');
              else if (screen === 'offline') openModal('offline');
              else if (screen === 'history') openModal('history');
              else if (screen === 'settings') openModal('settings');
              else if (screen === 'face-to-face') {
                navigateTo('voice', 'tabletop');
              } else if (screen === 'voice') {
                navigateTo('voice', 'handheld');
              } else if (screen === 'conversation-hub') {
                navigateTo('conversation-hub');
              } else if (screen === 'translate') {
                navigateTo('translate');
              } else if (screen === 'intelligence') {
                navigateTo('intelligence');
              } else if (screen === 'agent') {
                navigateTo('agent');
              } else {
                navigateTo(screen as any);
              }
            }}
            onNavigateToIntelligenceTab={(tab) => {
              setIntelligenceInitialTab(tab as any);
              navigateTo('intelligence');
            }}
            recentTranslations={(Array.isArray(history) ? history : []).slice(0, 5)}
            onPlaySpeech={(text, langCode) => {
              speakText(text, langCode, {
                speechRate: voiceSettings.speechRate,
                volume: voiceSettings.volume,
                voiceGender: voiceSettings.voiceGender,
              });
            }}
            onToggleStar={handleToggleStar}
            isOffline={isOffline}
            defaultUserLanguage={defaultUserLanguage}
            preferredTranslationLanguage={preferredTranslationLanguage}
            onSwapLanguages={handleSwapDefaultLanguages}
            onSelectDefaultUserLanguage={handleUpdateDefaultUserLanguage}
            onOpenDefaultUserLanguageSelector={() => openModal('langSelector', 'defaultUser')}
            currentDestination={activeDestination}
            activeDestination={activeDestination}
            onSelectDestination={handleUpdateDestination}
            locationState={locationState}
            isDetectingLocation={isDetectingLocation}
            onDetectLocation={handleDetectLocation}
            travelDocuments={travelDocuments}
            onOpenPermissions={() => setIsPermissionsModalOpen(true)}
            onOpenInstantPrompt={() => setIsInstantPromptOpen(true)}
            onSelectPromptForAgent={(prompt) => {
              setAgentInitialPrompt(prompt);
              navigateTo('agent');
            }}
          />
        )}

        {/* Tab 1: Consolidated Translation Hub */}
        {currentScreen === 'translate' && (
          <TranslateHubScreen
            sourceLang={sourceLanguage}
            targetLang={targetLanguage}
            onOpenSourceSelector={() => openModal('langSelector', 'source')}
            onOpenTargetSelector={() => openModal('langSelector', 'target')}
            onSwapLanguages={handleSwapMainLanguages}
            voiceSettings={voiceSettings}
            onAddTranslation={addTranslationRecord}
            isOffline={isOffline}
            onOpenPhrasebook={() => openModal('phrasebook')}
            onOpenOfflinePacks={() => openModal('offline')}
            onOpenHistory={() => openModal('history')}
            onOpenSettings={() => openModal('settings')}
            initialSubMode={translateSubMode}
          />
        )}

        {/* Tab 2: Travel Intelligence Dashboard */}
        {currentScreen === 'intelligence' && (
          <TravelIntelligenceScreen
            initialTab={intelligenceInitialTab}
            currentDestination={activeDestination}
            activeDestination={activeDestination}
            onSelectDestination={handleUpdateDestination}
            locationState={locationState}
            isDetectingLocation={isDetectingLocation}
            onDetectLocation={handleDetectLocation}
            travelDocuments={travelDocuments}
            documents={travelDocuments}
            onSaveDocuments={handleUpdateDocuments}
            onUpdateDocuments={handleUpdateDocuments}
            onNavigateToAgent={(prompt) => {
              if (prompt) setAgentInitialPrompt(prompt);
              navigateTo('agent');
            }}
            onAskAgent={(prompt) => {
              if (prompt) setAgentInitialPrompt(prompt);
              navigateTo('agent');
            }}
            onNavigateToTranslate={() => navigateTo('translate')}
          />
        )}

        {/* Tab 3: AI Travel Agent */}
        {currentScreen === 'agent' && (
          <AITravelAgentScreen
            currentDestination={activeDestination}
            destination={activeDestination}
            travelDocuments={travelDocuments}
            documents={travelDocuments}
            initialPrompt={agentInitialPrompt}
            onClearInitialPrompt={() => setAgentInitialPrompt(undefined)}
            onNavigateToTranslate={(subMode) => {
              if (subMode === 'camera') setTranslateSubMode('camera');
              else if (subMode === 'text') setTranslateSubMode('text');
              else if (subMode === 'emergency') setTranslateSubMode('emergency');
              else setTranslateSubMode('conversation');
              navigateTo('translate');
            }}
            onNavigateToIntelligence={() => navigateTo('intelligence')}
            onOpenDocuments={() => {
              setIntelligenceInitialTab('documents');
              navigateTo('intelligence');
            }}
          />
        )}

        {/* Direct Subscreens (also accessible from Hubs) */}
        {currentScreen === 'conversation-hub' && (
          <LiveConversationHubScreen
            sourceLang={sourceLanguage}
            targetLang={targetLanguage}
            onOpenSourceSelector={() => openModal('langSelector', 'source')}
            onOpenTargetSelector={() => openModal('langSelector', 'target')}
            onSwapLanguages={handleSwapMainLanguages}
            onSelectMode={(mode) => {
              navigateTo('voice', mode);
            }}
            onBack={handleBack}
          />
        )}

        {(currentScreen === 'voice' || currentScreen === 'face-to-face') && (
          <ConversationScreen
            sourceLang={sourceLanguage}
            targetLang={targetLanguage}
            onOpenSourceSelector={() => openModal('langSelector', 'source')}
            onOpenTargetSelector={() => openModal('langSelector', 'target')}
            onSwapLanguages={handleSwapMainLanguages}
            voiceSettings={voiceSettings}
            onAddTranslation={addTranslationRecord}
            isOffline={isOffline}
            initialMode={conversationMode}
            onModeChange={(mode) => setConversationMode(mode)}
            onClose={handleBack}
          />
        )}

        {currentScreen === 'camera' && (
          <CameraTranslateScreen
            sourceLang={sourceLanguage}
            targetLang={targetLanguage}
            onSelectTargetLang={handleUpdatePreferredTranslationLanguage}
            onOpenTargetSelector={() => openModal('langSelector', 'target')}
            onSwapLanguages={handleSwapMainLanguages}
            voiceSettings={voiceSettings}
            onAddTranslation={addTranslationRecord}
            onClose={handleBack}
          />
        )}

        {currentScreen === 'text' && (
          <TextTranslateScreen
            sourceLang={sourceLanguage}
            targetLang={targetLanguage}
            onOpenSourceSelector={() => openModal('langSelector', 'source')}
            onOpenTargetSelector={() => openModal('langSelector', 'target')}
            onSwapLanguages={handleSwapMainLanguages}
            voiceSettings={voiceSettings}
            onAddTranslation={addTranslationRecord}
            onClose={handleBack}
          />
        )}

        {currentScreen === 'emergency' && (
          <EmergencyScreen
            currentLanguage={targetLanguage}
            onSelectLanguage={(lang) => setTargetLanguage(lang)}
            onOpenLanguageSelector={() => openModal('langSelector', 'emergency')}
            voiceSettings={voiceSettings}
            onClose={handleBack}
          />
        )}
      </main>

      {/* Bottom Fixed Mobile Navigation Bar - Always visible and pinned to bottom */}
      {!isTabletopActive && (
        <nav className="fixed bottom-0 inset-x-0 bg-slate-900/95 backdrop-blur-md border-t border-slate-800/90 py-1.5 sm:py-2 px-1.5 sm:px-4 z-40 shrink-0 shadow-lg pb-[max(0.5rem,env(safe-area-inset-bottom))]">
          <div className="mx-auto max-w-md sm:max-w-xl flex items-center justify-around gap-1 sm:gap-2">
            {/* 1. Home Dashboard Button */}
            <button
              id="nav-home-btn"
              onClick={() => navigateTo('home')}
              className={`flex flex-col items-center gap-0.5 sm:gap-1 transition-colors px-2 py-1 rounded-xl cursor-pointer ${
                currentScreen === 'home' 
                  ? 'text-indigo-400 font-bold' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Home Dashboard"
            >
              <Home className="w-5 h-5" />
              <span className="text-[10px] tracking-tight">Home</span>
            </button>

            {/* 2. Translation Hub Button */}
            <button
              id="nav-translate-btn"
              onClick={() => {
                setTranslateSubMode('conversation');
                navigateTo('translate');
              }}
              className={`flex flex-col items-center gap-0.5 sm:gap-1 transition-colors px-2 py-1 rounded-xl cursor-pointer ${
                currentScreen === 'translate' || currentScreen === 'conversation-hub' || currentScreen === 'voice' || currentScreen === 'camera' || currentScreen === 'text'
                  ? 'text-indigo-400 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Translation Hub - Live Voice, Camera OCR & Text"
            >
              <Languages className="w-5 h-5" />
              <span className="text-[10px] tracking-tight whitespace-nowrap">Translate</span>
            </button>

            {/* Central Prominent SOS Emergency Button */}
            <button
              id="nav-emergency-sos-btn"
              onClick={() => navigateTo('emergency')}
              className={`flex flex-col items-center -mt-4 bg-gradient-to-tr from-red-600 to-rose-500 text-white w-11 h-11 sm:w-12 sm:h-12 rounded-full shadow-lg shadow-red-600/40 border-2 border-slate-950 items-center justify-center active:scale-95 transition-transform cursor-pointer ${
                currentScreen === 'emergency' ? 'ring-2 ring-red-400 ring-offset-2 ring-offset-slate-950' : ''
              }`}
              title="Instant Emergency SOS & First Responders"
            >
              <AlertTriangle className="w-5 h-5 sm:w-6 sm:h-6" />
            </button>

            {/* 3. Travel Intelligence Button */}
            <button
              id="nav-intelligence-btn"
              onClick={() => navigateTo('intelligence')}
              className={`flex flex-col items-center gap-0.5 sm:gap-1 transition-colors px-2 py-1 rounded-xl cursor-pointer ${
                currentScreen === 'intelligence' 
                  ? 'text-teal-400 font-bold' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Travel Intelligence Dashboard"
            >
              <Compass className="w-5 h-5" />
              <span className="text-[10px] tracking-tight">Intelligence</span>
            </button>

            {/* 4. AI Travel Agent Button */}
            <button
              id="nav-agent-btn"
              onClick={() => navigateTo('agent')}
              className={`flex flex-col items-center gap-0.5 sm:gap-1 transition-colors px-2 py-1 rounded-xl cursor-pointer ${
                currentScreen === 'agent' 
                  ? 'text-violet-400 font-bold' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="AI Travel Agent & Flight / Taxi Copilot"
            >
              <Bot className="w-5 h-5" />
              <span className="text-[10px] tracking-tight">AI Agent</span>
            </button>
          </div>
        </nav>
      )}

      {/* Global Modals */}
      <LanguageSelectorModal
        isOpen={langSelectorTarget !== null}
        onClose={closeModal}
        onSelectLanguage={handleLanguageSelect}
        selectedLanguage={
          langSelectorTarget === 'source'
            ? sourceLanguage
            : langSelectorTarget === 'personA'
            ? personALanguage
            : langSelectorTarget === 'personB'
            ? personBLanguage
            : langSelectorTarget === 'defaultUser'
            ? defaultUserLanguage
            : langSelectorTarget === 'preferredTranslation'
            ? preferredTranslationLanguage
            : targetLanguage
        }
        allowAutoDetect={
          langSelectorTarget === 'source' || 
          langSelectorTarget === 'personA' || 
          langSelectorTarget === 'defaultUser'
        }
        title={
          langSelectorTarget === 'source'
            ? 'Select Source Language'
            : langSelectorTarget === 'personA'
            ? 'Select Speaker A Language'
            : langSelectorTarget === 'personB'
            ? 'Select Speaker B Language'
            : langSelectorTarget === 'defaultUser'
            ? 'Default User Language (You Speak)'
            : langSelectorTarget === 'preferredTranslation'
            ? 'Preferred Translation Language'
            : 'Select Target Translation Language'
        }
      />

      <TravelPhrasebookModal
        isOpen={isTravelPhrasebookOpen}
        onClose={closeModal}
        targetLang={targetLanguage}
        onOpenTargetSelector={() => openModal('langSelector', 'target')}
        voiceSettings={voiceSettings}
      />

      <OfflinePacksModal
        isOpen={isOfflinePacksOpen}
        onClose={closeModal}
        isOffline={isOffline}
        onToggleOfflineMode={handleToggleOfflineMode}
      />

      <HistoryModal
        isOpen={isHistoryOpen}
        onClose={closeModal}
        history={history}
        onClearHistory={handleClearHistory}
        onToggleStar={handleToggleStar}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={closeModal}
        voiceSettings={voiceSettings}
        onRerunPopups={() => {
          closeModal();
          setIsInstantPromptOpen(true);
        }}
        onRerunOnboarding={() => {
          closeModal();
          setIsInstantPromptOpen(true);
        }}
        onOpenPermissionsModal={() => {
          closeModal();
          setIsInitialPermissionsCheck(false);
          openModal('permissions');
        }}
        authUser={authUser}
        onSignOut={handleSignOut}
        onDeleteAccount={handleDeleteAccount}
        onSwitchToGoogle={() => {
          signOutGoogleReal();
          setAuthUser(null);
        }}
        defaultUserLanguage={defaultUserLanguage}
        preferredTranslationLanguage={preferredTranslationLanguage}
        onChangeDefaultUserLanguage={handleUpdateDefaultUserLanguage}
        onChangePreferredTranslationLanguage={handleUpdatePreferredTranslationLanguage}
        onSetLanguagePair={handleUpdateLanguagePair}
        onSwapDefaultLanguages={handleSwapDefaultLanguages}
        onRequestOpenLanguageSelector={(target) => {
          openModal('langSelector', target);
        }}
      />

      {/* Instant 1-Tap Location & Permissions Prompt on App Launch */}
      <InstantPermissionPrompt
        isOpen={isInstantPromptOpen}
        onClose={() => setIsInstantPromptOpen(false)}
        onLocationDetected={() => {
          handleDetectLocation();
        }}
      />

      <PermissionsModal
        isOpen={isPermissionsModalOpen}
        onClose={() => {
          setIsInitialPermissionsCheck(false);
          setIsPermissionsModalOpen(false);
        }}
        isInitialOnboarding={isInitialPermissionsCheck}
      />
    </div>
  );
}

