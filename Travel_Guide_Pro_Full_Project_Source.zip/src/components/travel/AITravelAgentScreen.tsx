import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, 
  Send, 
  Mic, 
  MicOff, 
  Sparkles, 
  ShieldAlert, 
  Plane, 
  Car, 
  Hotel, 
  Users, 
  FileText, 
  Volume2, 
  Copy, 
  Check, 
  ExternalLink, 
  X, 
  Share2, 
  AlertTriangle, 
  Clock, 
  Compass, 
  Camera, 
  Hospital,
  ChevronRight,
  ShieldCheck,
  Fuel,
  Info,
  Banknote,
  Navigation,
  MapPin,
  Square
} from 'lucide-react';
import { 
  DestinationCity, 
  AgentChatMessage, 
  AgentActionCard, 
  ScamGuardResult,
  TravelDocument 
} from '../../types/travel';
import { CITIES_DATA, resolveCityProfile } from '../../data/travelData';
import { askAITravelAgent, checkScamAndPriceGuard } from '../../services/travelService';
import { speakText } from '../../utils/speech';
import { getGoogleMapsSearchUrl } from '../../utils/googleMaps';
import { UnifiedVoiceRecorder } from '../../utils/audioRecorder';
import { translateAudioApi } from '../../services/translationService';

interface AITravelAgentScreenProps {
  currentDestination?: DestinationCity;
  destination?: DestinationCity;
  travelDocuments?: TravelDocument[];
  documents?: TravelDocument[];
  onNavigateToTranslate?: (subMode?: string) => void;
  onNavigateToIntelligence?: (subTab?: string) => void;
  onOpenDocuments?: () => void;
  initialPrompt?: string;
  onClearInitialPrompt?: () => void;
}

export const AITravelAgentScreen: React.FC<AITravelAgentScreenProps> = ({
  currentDestination,
  destination,
  travelDocuments: propTravelDocuments,
  documents,
  onNavigateToTranslate,
  onNavigateToIntelligence,
  onOpenDocuments,
  initialPrompt,
  onClearInitialPrompt,
}) => {
  const effectiveDestination = destination || currentDestination || 'Tokyo, Japan';
  const cityData = resolveCityProfile(effectiveDestination);
  const travelDocuments = propTravelDocuments || documents || [];

  // Chat message history (Starts empty in Live mode until user starts using it)
  const [messages, setMessages] = useState<AgentChatMessage[]>([]);

  const [inputQuery, setInputQuery] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Active Specialized Copilot Modals
  const [activeCopilot, setActiveCopilot] = useState<
    'none' | 'flight' | 'scam' | 'roadtrip' | 'family' | 'documents'
  >('none');

  // Scam Guard Input State
  const [scamInput, setScamInput] = useState('');
  const [scamType, setScamType] = useState<'taxi_fare' | 'restaurant_bill' | 'suspicious_message'>('taxi_fare');
  const [scamResult, setScamResult] = useState<ScamGuardResult | null>(null);
  const [isEvaluatingScam, setIsEvaluatingScam] = useState(false);

  // Family Guardian State
  const [familyShareStatus, setFamilyShareStatus] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recorderRef = useRef<UnifiedVoiceRecorder | null>(null);

  useEffect(() => {
    recorderRef.current = new UnifiedVoiceRecorder();
    return () => {
      recorderRef.current?.cancel();
    };
  }, []);

  // Scroll to bottom on message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isProcessing]);

  // Execute initial prompt if passed
  useEffect(() => {
    if (initialPrompt && initialPrompt.trim()) {
      handleSendMessage(initialPrompt);
      if (onClearInitialPrompt) {
        onClearInitialPrompt();
      }
    }
  }, [initialPrompt]);

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputQuery).trim();
    if (!query || isProcessing) return;

    const userMessageId = `user_${Date.now()}`;
    const newMsg: AgentChatMessage = {
      id: userMessageId,
      sender: 'user',
      text: query,
      timestamp: Date.now(),
    };

    setMessages(prev => [...prev, newMsg]);
    setInputQuery('');
    setIsProcessing(true);

    try {
      const response = await askAITravelAgent(query, effectiveDestination, cityData.primaryLanguage);
      const agentMsg: AgentChatMessage = {
        id: `agent_${Date.now()}`,
        sender: 'agent',
        text: response.reply,
        timestamp: Date.now(),
        actionCard: response.actionCard,
        suggestedFollowUps: response.followUps,
      };
      setMessages(prev => [...prev, agentMsg]);
    } catch (e) {
      setMessages(prev => [
        ...prev,
        {
          id: `err_${Date.now()}`,
          sender: 'agent',
          text: `I had trouble connecting to the travel agent engine. Please check your internet connection or try again. In the meantime, the local emergency hotline is ${cityData.emergencyNumber}.`,
          timestamp: Date.now(),
        },
      ]);
    } finally {
      setIsProcessing(false);
    }
  };

  // Robust Voice Query STT using UnifiedVoiceRecorder (Dual WebSpeech + Multimodal Audio AI)
  const toggleSpeechRecognition = async () => {
    if (isListening) {
      setIsListening(false);
      if (!recorderRef.current) return;
      try {
        const recResult = await recorderRef.current.stop();
        const spoken = (recResult.transcript || inputQuery).trim();
        if (spoken) {
          setInputQuery(spoken);
          handleSendMessage(spoken);
        } else if (recResult.audioBase64) {
          setIsProcessing(true);
          const audioRes = await translateAudioApi({
            audioBase64: recResult.audioBase64,
            mimeType: recResult.mimeType,
            targetLang: 'English',
          });
          if (audioRes.success && (audioRes.transcription || audioRes.translatedText)) {
            const query = audioRes.transcription || audioRes.translatedText;
            setInputQuery(query);
            handleSendMessage(query);
          }
        }
      } catch (e) {
        console.warn('Voice query processing error:', e);
      } finally {
        setIsProcessing(false);
      }
      return;
    }

    if (!recorderRef.current) {
      recorderRef.current = new UnifiedVoiceRecorder();
    }

    setIsListening(true);
    const speechCode = cityData.primaryLanguageCode ? `${cityData.primaryLanguageCode}-IN` : 'en-US';

    const started = await recorderRef.current.start(speechCode, {
      onStart: () => {
        setIsListening(true);
      },
      onInterimTranscript: (text: string) => {
        setInputQuery(text);
      },
      onFinalTranscript: (text: string) => {
        setInputQuery(text);
      },
      onError: (err: string) => {
        console.warn('Agent mic error:', err);
        setIsListening(false);
      },
      onEnd: () => {
        setIsListening(false);
      },
    });

    if (!started) {
      setIsListening(false);
    }
  };

  const handleCopyText = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleRunScamCheck = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!scamInput.trim()) return;
    setIsEvaluatingScam(true);
    try {
      const res = await checkScamAndPriceGuard(scamInput, currentDestination, scamType);
      setScamResult(res);
    } catch (err) {
      console.warn('Scam guard evaluation failed', err);
    } finally {
      setIsEvaluatingScam(false);
    }
  };

  const handleShareFamilyStatus = () => {
    const hotelDoc = (travelDocuments || []).find(d => d.type === 'hotel');
    const hotelName = hotelDoc?.title.replace('Hotel Reservation: ', '') || 'Park Hyatt';
    const message = `👋 Safe Check-in from ${cityData.city}!\n` +
      `• Location: ${cityData.city} (${cityData.flag})\n` +
      `• Hotel: ${hotelName}\n` +
      `• Local Time: ${new Date().toLocaleTimeString()}\n` +
      `• Battery & GPS: Optimal\n` +
      `• Emergency hotline here: ${cityData.emergencyNumber}\n` +
      `Track my live trip status via Travel Guide Pro Travel Guardian.`;

    if (navigator.share) {
      navigator.share({
        title: `Safe Trip Check-in: ${cityData.city}`,
        text: message,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(message);
      setFamilyShareStatus('Check-in status copied to clipboard! Paste it into WhatsApp or SMS.');
      setTimeout(() => setFamilyShareStatus(null), 4000);
    }
  };

  return (
    <div className="space-y-4 pb-12 animate-fade-in max-w-4xl mx-auto flex flex-col h-[calc(100vh-140px)] min-h-[620px]">
      {/* 1. Header with Destination badge & Copilot tools launcher */}
      <section className="bg-slate-900 border border-slate-800 rounded-3xl p-3.5 sm:p-4 shadow-lg shrink-0">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-600 via-violet-600 to-teal-400 p-0.5 shadow-md flex items-center justify-center text-white">
              <Bot className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-sm sm:text-base font-black text-white">
                  AI Travel Agent
                </h1>
                <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-full font-bold">
                  Active in {cityData.city}
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                Actionable assistance for flight delays, scam protection, pickups & local navigation
              </p>
            </div>
          </div>

          <div className="hidden sm:flex items-center gap-1 text-xs">
            <span className="text-slate-400">Language:</span>
            <span className="font-bold text-white font-mono">{cityData.primaryLanguage}</span>
          </div>
        </div>

        {/* Actionable Specialized Copilots Ribbon */}
        <div className="flex items-center gap-1.5 overflow-x-auto pt-3 mt-3 border-t border-slate-800/80 no-scrollbar text-xs font-semibold">
          <button
            onClick={() => setActiveCopilot('scam')}
            className={`px-3 py-1.5 rounded-xl border flex items-center gap-1.5 shrink-0 transition-all ${
              activeCopilot === 'scam'
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                : 'bg-slate-800/80 text-slate-300 border-slate-700/80 hover:bg-slate-800'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
            <span>AI Scam & Price Guard</span>
          </button>

          <button
            onClick={() => setActiveCopilot('flight')}
            className={`px-3 py-1.5 rounded-xl border flex items-center gap-1.5 shrink-0 transition-all ${
              activeCopilot === 'flight'
                ? 'bg-indigo-500/20 text-indigo-300 border-indigo-500/50'
                : 'bg-slate-800/80 text-slate-300 border-slate-700/80 hover:bg-slate-800'
            }`}
          >
            <Plane className="w-3.5 h-3.5 text-indigo-400" />
            <span>Flight Delay & Rebooking</span>
          </button>

          <button
            onClick={() => setActiveCopilot('family')}
            className={`px-3 py-1.5 rounded-xl border flex items-center gap-1.5 shrink-0 transition-all ${
              activeCopilot === 'family'
                ? 'bg-teal-500/20 text-teal-300 border-teal-500/50'
                : 'bg-slate-800/80 text-slate-300 border-slate-700/80 hover:bg-slate-800'
            }`}
          >
            <Users className="w-3.5 h-3.5 text-teal-400" />
            <span>Family Travel Guardian</span>
          </button>

          <button
            onClick={() => setActiveCopilot('roadtrip')}
            className={`px-3 py-1.5 rounded-xl border flex items-center gap-1.5 shrink-0 transition-all ${
              activeCopilot === 'roadtrip'
                ? 'bg-blue-500/20 text-blue-300 border-blue-500/50'
                : 'bg-slate-800/80 text-slate-300 border-slate-700/80 hover:bg-slate-800'
            }`}
          >
            <Car className="w-3.5 h-3.5 text-blue-400" />
            <span>Road Trip Copilot</span>
          </button>
        </div>
      </section>

      {/* 2. Interactive Chat Stream */}
      <div className="flex-1 bg-slate-900/90 border border-slate-800 rounded-3xl p-4 overflow-y-auto space-y-4 shadow-inner min-h-[300px]">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center py-12 px-4 space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-violet-600/15 border border-violet-500/25 text-violet-400 flex items-center justify-center">
              <Bot className="w-6 h-6" />
            </div>
            <div className="space-y-1 max-w-sm">
              <h3 className="text-sm font-bold text-white">AI Travel Agent & Copilot</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                No chat history yet. Ask a question about your destination, flights, taxis, or local safety to begin.
              </p>
            </div>
            <div className="flex flex-wrap gap-2 justify-center pt-2 max-w-md">
              {[
                'My flight is delayed. What should I do?',
                'How do I tell the taxi driver where my hotel is?',
                'Convert $100 to local currency & tipping rules',
                'Find the nearest hospital.',
                'Translate this menu.',
              ].map((prompt, i) => (
                <button
                  key={i}
                  onClick={() => handleSendMessage(prompt)}
                  className="text-[11px] px-3 py-1.5 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-colors"
                >
                  {prompt}
                </button>
              ))}
            </div>
          </div>
        ) : (
          messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'} space-y-2`}
          >
            <div
              className={`max-w-[88%] sm:max-w-[80%] rounded-2xl p-3.5 text-xs sm:text-sm leading-relaxed ${
                msg.sender === 'user'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                  : 'bg-slate-800/90 text-slate-200 border border-slate-700/80'
              }`}
            >
              <div className="whitespace-pre-line">{msg.text}</div>

              {/* Actionable Card inside Agent Message */}
              {msg.actionCard && (
                <div className="mt-3 bg-slate-900/90 border border-indigo-500/40 rounded-2xl p-3.5 text-xs space-y-2.5">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                    <div>
                      <div className="font-bold text-white text-sm">{msg.actionCard.title}</div>
                      {msg.actionCard.subtitle && (
                        <div className="text-[11px] text-indigo-300">{msg.actionCard.subtitle}</div>
                      )}
                    </div>
                    <span className="text-[10px] bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded font-bold uppercase">
                      {msg.actionCard.type === 'currency_conversion' ? 'Live ECB Rates' : 'Action Card'}
                    </span>
                  </div>

                  {/* Native Script Box (e.g. for taxi drivers or emergency signs) */}
                  {msg.actionCard.nativeScript && (
                    <div className="bg-white text-slate-950 p-3 rounded-xl font-bold text-sm leading-snug">
                      <div className="text-[10px] text-slate-500 uppercase font-sans mb-1">
                        Show to Driver / Local:
                      </div>
                      {msg.actionCard.nativeScript}
                      {msg.actionCard.phonetic && (
                        <div className="text-[11px] text-indigo-700 italic font-medium mt-1">
                          Say: "{msg.actionCard.phonetic}"
                        </div>
                      )}
                    </div>
                  )}

                  {/* Details KV Table */}
                  {msg.actionCard.details && (
                    <div className="grid grid-cols-2 gap-2 text-[11px] bg-slate-800/60 p-2.5 rounded-xl border border-slate-700/50">
                      {Object.entries(msg.actionCard.details).map(([k, v]) => (
                        <div key={k}>
                          <span className="text-slate-400 block">{k}:</span>
                          <span className="text-slate-100 font-medium">{v}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Action Buttons */}
                  <div className="flex items-center gap-2 pt-1">
                    {msg.actionCard.nativeScript && (
                      <button
                        onClick={() => speakText(
                          msg.actionCard?.nativeScript || '',
                          cityData.primaryLanguageCode
                        )}
                        className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-indigo-600/30"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                        <span>Play Native Speech</span>
                      </button>
                    )}

                    {msg.actionCard.type === 'flight_rights' && (
                      <button
                        onClick={() => setActiveCopilot('flight')}
                        className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold"
                      >
                        Open Rebooking Helper
                      </button>
                    )}

                    {msg.actionCard.type === 'hospital_radar' && (
                      <button
                        onClick={() => onNavigateToIntelligence && onNavigateToIntelligence('nearby')}
                        className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold cursor-pointer"
                      >
                        View Route & Medical Details
                      </button>
                    )}

                    {(msg.actionCard.type === 'hospital_radar' || 
                      msg.actionCard.type === 'taxi_card' || 
                      msg.actionCard.details?.['Address'] || 
                      msg.actionCard.details?.['Nearest Station'] || 
                      msg.actionCard.details?.['Emergency Room']) && (
                      <a
                        href={getGoogleMapsSearchUrl(`${msg.actionCard.details?.['Address'] || msg.actionCard.title || msg.actionCard.nativeScript}, ${cityData.city}`)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                        title="Open in Google Maps App for live GPS navigation"
                      >
                        <Navigation className="w-3.5 h-3.5 text-rose-400" />
                        <span>Google Maps</span>
                      </a>
                    )}

                    {msg.actionCard.type === 'currency_conversion' && (
                      <div className="flex items-center gap-1.5 flex-wrap pt-0.5">
                        <span className="text-[10px] text-emerald-400 font-semibold flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                          Live ECB (Frankfurter):
                        </span>
                        {['$20', '$50', '$100', '$250', '$500'].map((amt) => (
                          <button
                            key={amt}
                            onClick={() => handleSendMessage(`Convert ${amt} USD to local currency in ${cityData.city}`)}
                            className="px-2 py-1 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30 text-[11px] font-semibold transition-colors flex items-center gap-1 cursor-pointer"
                          >
                            <Banknote className="w-3 h-3 text-emerald-400" />
                            <span>{amt}</span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Message Action Footer */}
              {msg.sender === 'agent' && (
                <div className="flex items-center justify-between pt-2 mt-2 border-t border-slate-700/50 text-[10px] text-slate-400">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => speakText(msg.text.replace(/\*\*/g, ''), 'en')}
                      className="hover:text-white flex items-center gap-1 p-0.5"
                      title="Read aloud"
                    >
                      <Volume2 className="w-3 h-3" />
                      <span>Speak</span>
                    </button>
                    <button
                      onClick={() => handleCopyText(msg.id, msg.text)}
                      className="hover:text-white flex items-center gap-1 p-0.5"
                      title="Copy response"
                    >
                      {copiedId === msg.id ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-400" />
                          <span className="text-emerald-400">Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>
                  </div>
                  <span>{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                </div>
              )}
            </div>

            {/* Suggested Follow-up Action Chips */}
            {msg.suggestedFollowUps && msg.suggestedFollowUps.length > 0 && (
              <div className="flex items-center gap-1.5 flex-wrap max-w-[90%]">
                {msg.suggestedFollowUps.map((chip, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSendMessage(chip)}
                    className="px-2.5 py-1 rounded-xl bg-slate-800/80 hover:bg-indigo-950/60 hover:border-indigo-500/60 border border-slate-700/80 text-slate-300 hover:text-indigo-300 text-[11px] font-medium transition-all text-left"
                  >
                    💬 {chip}
                  </button>
                ))}
              </div>
            )}
          </div>
        ))
      )}

        {isProcessing && (
          <div className="flex items-center gap-2.5 text-xs text-indigo-400 bg-slate-800/60 border border-slate-700/60 rounded-2xl p-3 w-fit animate-pulse">
            <Bot className="w-4 h-4 animate-spin" />
            <span>AI Travel Agent is analyzing your itinerary and local policies...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* 3. Natural Language Input Bar with Voice Support */}
      <div className="shrink-0 space-y-2">
        {/* Quick natural-language prompt buttons */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs font-semibold">
          <button
            onClick={() => handleSendMessage('My flight is delayed. What should I do?')}
            className="px-2.5 py-1 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 shrink-0 border border-slate-700"
          >
            ✈️ Flight delayed?
          </button>
          <button
            onClick={() => handleSendMessage('How do I tell the taxi driver where my hotel is?')}
            className="px-2.5 py-1 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 shrink-0 border border-slate-700"
          >
            🚕 Hotel taxi card
          </button>
          <button
            onClick={() => handleSendMessage('Find the nearest hospital.')}
            className="px-2.5 py-1 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 shrink-0 border border-slate-700"
          >
            🏥 Nearest hospital
          </button>
          <button
            onClick={() => {
              onNavigateToTranslate('camera');
            }}
            className="px-2.5 py-1 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 shrink-0 border border-slate-700"
          >
            📷 Translate menu
          </button>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="flex items-center gap-2"
        >
          <div className="flex-1 relative">
            <input
              type="text"
              value={inputQuery}
              onChange={(e) => setInputQuery(e.target.value)}
              placeholder={isListening ? "🔴 Listening... Speak your question now (Tap square to ask)..." : "Ask anything (e.g. 'Is this taxi fare fair?', 'How to ask for water?')..."}
              className="w-full bg-slate-800 text-white rounded-2xl px-4 py-3 text-xs sm:text-sm border border-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 pr-12"
            />
            <button
              type="button"
              onClick={toggleSpeechRecognition}
              className={`absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-xl transition-all cursor-pointer ${
                isListening
                  ? 'bg-rose-600 text-white ring-4 ring-rose-500/30 animate-pulse'
                  : 'text-slate-400 hover:text-white hover:bg-slate-700'
              }`}
              title={isListening ? 'Listening... Tap to stop & submit' : 'Voice input (Ask AI Agent)'}
            >
              {isListening ? <Square className="w-4 h-4 fill-white" /> : <Mic className="w-4 h-4" />}
            </button>
          </div>

          <button
            type="submit"
            disabled={!inputQuery.trim() || isProcessing}
            className="p-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl transition-all shadow-md shadow-indigo-600/30 disabled:opacity-40 disabled:cursor-not-allowed shrink-0"
            title="Send query"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>

      {/* 4. Sub-Modal: AI SCAM & PRICE GUARD */}
      {activeCopilot === 'scam' && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-3 animate-fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 w-full max-w-lg space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
                  <ShieldAlert className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">AI Scam & Price Guard</h3>
                  <p className="text-[11px] text-slate-400">Evaluate taxi fares, bills, links & quotes in {cityData.city}</p>
                </div>
              </div>
              <button
                onClick={() => setActiveCopilot('none')}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleRunScamCheck} className="space-y-3 text-xs">
              <div className="grid grid-cols-3 gap-1.5">
                {[
                  { key: 'taxi_fare', label: '🚕 Taxi Fare' },
                  { key: 'restaurant_bill', label: '🍲 Bill / Receipt' },
                  { key: 'suspicious_message', label: '📱 Link / SMS' },
                ].map(item => (
                  <button
                    key={item.key}
                    type="button"
                    onClick={() => setScamType(item.key as any)}
                    className={`py-1.5 px-2 rounded-xl text-center font-bold border transition-all ${
                      scamType === item.key
                        ? 'bg-amber-500/20 border-amber-500/60 text-amber-300'
                        : 'bg-slate-800 border-slate-700 text-slate-300'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>

              <div>
                <label className="text-slate-400 font-semibold block mb-1">
                  Describe the price, meter refusal, or message:
                </label>
                <textarea
                  rows={2}
                  required
                  placeholder="e.g. Driver refused meter and demanded 5000 yen, or SMS asking to verify flight ticket link..."
                  value={scamInput}
                  onChange={(e) => setScamInput(e.target.value)}
                  className="w-full bg-slate-800 text-white rounded-xl p-3 border border-slate-700 focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div className="flex justify-end">
                <button
                  type="submit"
                  disabled={isEvaluatingScam}
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-xl font-bold shadow-md shadow-amber-600/30 flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>{isEvaluatingScam ? 'Analyzing Risk...' : 'Run Scam Analysis'}</span>
                </button>
              </div>
            </form>

            {scamResult && (
              <div className="space-y-3 pt-3 border-t border-slate-800 text-xs animate-fade-in">
                <div className={`p-3.5 rounded-2xl border flex items-center justify-between ${
                  scamResult.riskLevel === 'high_risk'
                    ? 'bg-red-950/30 border-red-500/60 text-red-200'
                    : scamResult.riskLevel === 'caution'
                    ? 'bg-amber-950/30 border-amber-500/60 text-amber-200'
                    : 'bg-emerald-950/30 border-emerald-500/60 text-emerald-200'
                }`}>
                  <div>
                    <div className="font-black text-sm uppercase">
                      Risk Level: {scamResult.riskLevel.replace('_', ' ')}
                    </div>
                    <div className="text-[11px] opacity-90 mt-0.5">{scamResult.analysisSummary}</div>
                  </div>
                  {scamResult.estimatedFairPrice && (
                    <div className="text-right shrink-0">
                      <div className="text-[10px] opacity-75">Estimated Fair Price:</div>
                      <div className="font-bold text-white text-xs">{scamResult.estimatedFairPrice}</div>
                    </div>
                  )}
                </div>

                {/* Red flags */}
                {Array.isArray(scamResult.redFlags) && scamResult.redFlags.length > 0 && (
                  <div className="bg-slate-800/70 p-3 rounded-2xl space-y-1 border border-slate-700/60">
                    <div className="font-bold text-rose-300">Detected Red Flags:</div>
                    <ul className="list-disc pl-4 space-y-0.5 text-slate-300 text-[11px]">
                      {scamResult.redFlags.map((rf, i) => (
                        <li key={i}>{rf}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Native Script to decline safely */}
                {scamResult.localRefusalScript && (
                  <div className="bg-white text-slate-950 p-3.5 rounded-2xl space-y-1">
                    <div className="text-[10px] uppercase font-bold text-slate-500">
                      Say or Show this in {cityData.primaryLanguage} to decline:
                    </div>
                    <div className="text-sm font-bold">
                      {scamResult.localRefusalScript.nativeText}
                    </div>
                    <div className="text-[11px] text-indigo-700 italic">
                      Pronunciation: "{scamResult.localRefusalScript.phonetic}"
                    </div>
                    <button
                      onClick={() => speakText(
                        scamResult?.localRefusalScript.nativeText || '',
                        cityData.primaryLanguageCode
                      )}
                      className="mt-1 px-3 py-1 bg-slate-900 text-white rounded-lg text-[11px] font-bold flex items-center gap-1"
                    >
                      <Volume2 className="w-3 h-3" />
                      <span>Speak Phrase</span>
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* 5. Sub-Modal: FLIGHT DELAY & REBOOKING COPILOT */}
      {activeCopilot === 'flight' && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-3 animate-fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 w-full max-w-lg space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto text-xs">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30">
                  <Plane className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">Flight Delay & Cancellation Copilot</h3>
                  <p className="text-[11px] text-slate-400">Step-by-step passenger rights & compensation claims</p>
                </div>
              </div>
              <button
                onClick={() => setActiveCopilot('none')}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              <div className="bg-slate-800/80 p-3.5 rounded-2xl border border-slate-700/80 space-y-2">
                <div className="font-bold text-white text-xs flex items-center gap-1.5">
                  <Info className="w-4 h-4 text-indigo-400" />
                  Your Statutory Rights by Delay Length
                </div>
                <div className="space-y-1.5 text-slate-300 text-[11px]">
                  <div>• <strong>2+ Hours Delay:</strong> Free meal and beverage vouchers; two free telephone calls or emails.</div>
                  <div>• <strong>3+ Hours Delay:</strong> Up to $700 / €600 compensation under EU261 / UK261 regulations if airline controllable.</div>
                  <div>• <strong>5+ Hours Delay:</strong> Right to full ticket refund within 7 days if you choose not to travel.</div>
                  <div>• <strong>Overnight Delay:</strong> Free hotel room + transport between airport and hotel provided by the carrier.</div>
                </div>
              </div>

              {/* Ready-to-copy Claim Script */}
              <div className="bg-slate-800/50 p-3.5 rounded-2xl border border-slate-700/60 space-y-2">
                <div className="font-bold text-white flex items-center justify-between">
                  <span>Formal Gate Script / Email Draft:</span>
                  <button
                    onClick={() => handleCopyText(
                      'claim_script',
                      `To Airline Customer Relations:\nMy flight from ${cityData.city} was delayed over 3 hours. Under applicable aviation consumer protection regulations, I am formally requesting compensation and meal vouchers. Please find my boarding pass attached.`
                    )}
                    className="text-indigo-400 hover:text-indigo-300 flex items-center gap-1 text-[11px]"
                  >
                    {copiedId === 'claim_script' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>Copy Text</span>
                  </button>
                </div>
                <p className="text-[11px] text-slate-300 bg-slate-900/90 p-2.5 rounded-xl border border-slate-700 font-mono">
                  "Under applicable consumer protection guidelines, my flight was delayed. I request my duty-of-care meal voucher immediately and the official written Reason for Delay statement."
                </p>
              </div>

              <div className="flex justify-end gap-2 pt-1">
                <button
                  onClick={() => {
                    setActiveCopilot('none');
                    handleSendMessage('Draft a formal compensation request letter for my delayed flight');
                  }}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold text-xs"
                >
                  Generate Full Claim Letter in Chat
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 6. Sub-Modal: FAMILY TRAVEL GUARDIAN */}
      {activeCopilot === 'family' && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-3 animate-fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 w-full max-w-lg space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto text-xs">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center border border-teal-500/30">
                  <Users className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">Family Travel Guardian</h3>
                  <p className="text-[11px] text-slate-400">One-tap trip status broadcast, location sharing & emergency speed-dial</p>
                </div>
              </div>
              <button
                onClick={() => setActiveCopilot('none')}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              <div className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700/80 space-y-2.5">
                <div className="font-bold text-white flex items-center justify-between">
                  <span>Trip Status Snapshot:</span>
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded font-bold">
                    Safe & Active
                  </span>
                </div>
                <div className="text-slate-300 text-[11px] space-y-1 bg-slate-900/80 p-3 rounded-xl border border-slate-700">
                  <div>📍 <strong>City:</strong> {cityData.city}</div>
                  <div>🏨 <strong>Hotel:</strong> Park Hyatt (Tokyo)</div>
                  <div>🚨 <strong>Local Emergency Hotline:</strong> {cityData.emergencyNumber}</div>
                  <div>🕒 <strong>Time:</strong> {new Date().toLocaleTimeString()}</div>
                </div>

                <button
                  onClick={handleShareFamilyStatus}
                  className="w-full py-2.5 bg-teal-600 hover:bg-teal-500 text-white font-bold rounded-xl flex items-center justify-center gap-2 shadow-md shadow-teal-600/30"
                >
                  <Share2 className="w-4 h-4" />
                  <span>Share "I Am Safe" Update (WhatsApp/SMS)</span>
                </button>

                {familyShareStatus && (
                  <div className="text-emerald-400 font-semibold text-center text-[11px] animate-fade-in">
                    {familyShareStatus}
                  </div>
                )}
              </div>

              {/* Emergency Speed Dial */}
              <div className="space-y-2">
                <div className="font-bold text-slate-300">Emergency Speed Dial in {cityData.city}:</div>
                <div className="grid grid-cols-2 gap-2">
                  <a
                    href={`tel:${cityData.policeNumber}`}
                    className="p-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 flex items-center justify-between"
                  >
                    <span>👮 Police</span>
                    <strong className="text-white">{cityData.policeNumber}</strong>
                  </a>
                  <a
                    href={`tel:${cityData.ambulanceNumber}`}
                    className="p-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 flex items-center justify-between"
                  >
                    <span>🚑 Ambulance</span>
                    <strong className="text-white">{cityData.ambulanceNumber}</strong>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 7. Sub-Modal: ROAD TRIP COPILOT */}
      {activeCopilot === 'roadtrip' && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-3 animate-fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 w-full max-w-lg space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto text-xs">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center border border-blue-500/30">
                  <Car className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">Road Trip Copilot</h3>
                  <p className="text-[11px] text-slate-400">Weather, rest stops, speed limits & vehicle regulations in {cityData.country}</p>
                </div>
              </div>
              <button
                onClick={() => setActiveCopilot('none')}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2 text-slate-300">
                <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700">
                  <div className="text-[11px] text-slate-400">Driving Side:</div>
                  <div className="font-bold text-white text-xs mt-0.5">
                    {cityData.country === 'Japan' || cityData.country === 'United Kingdom' || cityData.country === 'Thailand' || cityData.country === 'India' || cityData.country === 'Singapore' ? 'Left Side (RHD)' : 'Right Side (LHD)'}
                  </div>
                </div>
                <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700">
                  <div className="text-[11px] text-slate-400">Highway Speed Limit:</div>
                  <div className="font-bold text-white text-xs mt-0.5">
                    {cityData.country === 'Japan' ? '100 km/h (Expressway)' : cityData.country === 'France' ? '130 km/h (Autoroute)' : 'Standard highway rules'}
                  </div>
                </div>
              </div>

              <div className="bg-slate-800/60 p-3.5 rounded-2xl border border-slate-700/60 space-y-1.5">
                <div className="font-bold text-white flex items-center gap-1.5">
                  <Fuel className="w-4 h-4 text-blue-400" />
                  Road Trip Essentials Checklist
                </div>
                <ul className="list-disc pl-4 space-y-1 text-slate-300 text-[11px]">
                  <li>International Driving Permit (IDP) + Home Driver's License</li>
                  <li>ETC Toll Card or Highway Vignette / Toll transponder installed</li>
                  <li>Emergency Reflective Triangle & High-Vis vest (mandated in EU)</li>
                  <li>Download offline navigation maps for mountain or tunnel zones</li>
                </ul>
              </div>

              <div className="flex justify-end">
                <button
                  onClick={() => {
                    setActiveCopilot('none');
                    handleSendMessage(`What are the key road rules and toll tips for driving in ${cityData.country}?`);
                  }}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold"
                >
                  Ask Copilot for Custom Route Advice
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
