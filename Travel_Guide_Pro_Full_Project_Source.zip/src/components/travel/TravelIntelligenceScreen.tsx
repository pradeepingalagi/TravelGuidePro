import React, { useState, useEffect } from 'react';
import { 
  MapPin, 
  CloudSun, 
  Navigation, 
  AlertTriangle, 
  Hospital, 
  Shield, 
  Pill, 
  CreditCard, 
  Fuel, 
  Train, 
  Phone, 
  ChevronRight, 
  ArrowRight, 
  ExternalLink, 
  Copy, 
  Check, 
  FileText, 
  Plus, 
  Trash2, 
  Compass, 
  Info, 
  Layers, 
  Sliders, 
  X, 
  Volume2, 
  Car, 
  Bell, 
  Sparkles,
  RefreshCw,
  Eye,
  Download,
  Image as ImageIcon
} from 'lucide-react';
import { 
  DestinationCity, 
  NearbyPlace, 
  PlaceCategory, 
  TravelDocument, 
  DocumentType, 
  TravelAlert,
  WeatherCondition 
} from '../../types/travel';
import { CITIES_DATA, resolveCityProfile } from '../../data/travelData';
import { speakText } from '../../utils/speech';
import { LocationStatusModal } from './LocationStatusModal';
import { LocationDetectionResult } from '../../services/locationService';
import { fetchLiveWeather } from '../../services/weatherService';
import { getGoogleMapsSearchUrl, getGoogleMapsDirectionsUrl } from '../../utils/googleMaps';

interface TravelIntelligenceScreenProps {
  currentDestination?: DestinationCity;
  activeDestination?: DestinationCity;
  onSelectDestination: (city: DestinationCity) => void;
  locationState?: LocationDetectionResult | null;
  isDetectingLocation?: boolean;
  onDetectLocation?: () => Promise<void>;
  travelDocuments?: TravelDocument[];
  documents?: TravelDocument[];
  onSaveDocuments?: (docs: TravelDocument[]) => void;
  onUpdateDocuments?: (docs: TravelDocument[]) => void;
  onNavigateToAgent?: (prompt?: string) => void;
  onAskAgent?: (prompt?: string) => void;
  onNavigateToTranslate?: () => void;
  initialTab?: 'dashboard' | 'nearby' | 'navigation' | 'documents' | 'transport';
}

export const TravelIntelligenceScreen: React.FC<TravelIntelligenceScreenProps> = ({
  currentDestination,
  activeDestination,
  onSelectDestination,
  locationState,
  isDetectingLocation,
  onDetectLocation,
  travelDocuments: propTravelDocuments,
  documents,
  onSaveDocuments,
  onUpdateDocuments,
  onNavigateToAgent,
  onAskAgent,
  onNavigateToTranslate,
  initialTab,
}) => {
  const [isLocationModalOpen, setIsLocationModalOpen] = useState(false);
  const effectiveDestination = activeDestination || currentDestination || locationState?.matchedDestination || 'Delhi, India';
  const cityData = resolveCityProfile(effectiveDestination, locationState);
  const travelDocuments = propTravelDocuments || documents || [];

  // Live Open-Meteo weather state
  const [liveWeather, setLiveWeather] = useState<WeatherCondition | null>(null);
  const [isLoadingWeather, setIsLoadingWeather] = useState(false);

  const fetchWeather = async () => {
    setIsLoadingWeather(true);
    try {
      const coords = locationState?.coords;
      const w = await fetchLiveWeather(effectiveDestination, coords);
      if (w) setLiveWeather(w);
    } finally {
      setIsLoadingWeather(false);
    }
  };

  useEffect(() => {
    fetchWeather();
  }, [effectiveDestination, locationState?.coords?.latitude, locationState?.coords?.longitude]);

  // Sync initialTab when navigated from external button (like HomeScreen documents button)
  const [activeTab, setActiveTab] = useState<
    'dashboard' | 'nearby' | 'navigation' | 'documents' | 'transport'
  >(initialTab || 'dashboard');

  useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab]);

  const activeWeather: WeatherCondition = liveWeather || cityData.weather;

  const handleSaveDocs = (docs: TravelDocument[]) => {
    if (onSaveDocuments) onSaveDocuments(docs);
    if (onUpdateDocuments) onUpdateDocuments(docs);
  };

  const handleAskAgent = (prompt?: string) => {
    if (onNavigateToAgent) onNavigateToAgent(prompt);
    else if (onAskAgent) onAskAgent(prompt);
  };

  // Nearby Filter
  const [selectedPlaceCategory, setSelectedPlaceCategory] = useState<PlaceCategory | 'all'>('all');
  const [activeDriverCardPlace, setActiveDriverCardPlace] = useState<NearbyPlace | null>(null);

  // Route Guidance State
  const [routeFrom, setRouteFrom] = useState<string>('Current Hotel');
  const [routeTo, setRouteTo] = useState<string>('Central Station');
  const [routeResult, setRouteResult] = useState<{
    metroRoute: string;
    walkingTime: string;
    taxiCost: string;
    transitSteps: string[];
    localTips: string;
  } | null>(null);
  const [isCalculatingRoute, setIsCalculatingRoute] = useState(false);
  const [copiedDocId, setCopiedDocId] = useState<string | null>(null);

  // Document Modal State
  const [isAddDocOpen, setIsAddDocOpen] = useState(false);
  const [newDocType, setNewDocType] = useState<DocumentType>('passport');
  const [newDocTitle, setNewDocTitle] = useState('');
  const [newDocHolder, setNewDocHolder] = useState('Traveler');
  const [newDocNumber, setNewDocNumber] = useState('');
  const [newDocExpiry, setNewDocExpiry] = useState('');
  const [newDocBookingRef, setNewDocBookingRef] = useState('');
  const [newDocNotes, setNewDocNotes] = useState('');
  const [newDocFileData, setNewDocFileData] = useState<string | null>(null);
  const [newDocFileName, setNewDocFileName] = useState<string | null>(null);
  const [viewingDoc, setViewingDoc] = useState<TravelDocument | null>(null);
  const [docFilterType, setDocFilterType] = useState<DocumentType | 'all'>('all');

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setNewDocFileName(file.name);
    const reader = new FileReader();
    reader.onload = (event) => {
      if (typeof event.target?.result === 'string') {
        setNewDocFileData(event.target.result);
      }
    };
    reader.readAsDataURL(file);
  };

  // Notification Feed Dismissal
  const [dismissedAlerts, setDismissedAlerts] = useState<Record<string, boolean>>({});

  // Context Notification Preferences
  const [notifPrefs, setNotifPrefs] = useState({
    weatherAdvisories: true,
    transitDelays: true,
    safetyAlerts: true,
    exchangeRateSpikes: false,
  });

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedDocId(id);
    setTimeout(() => setCopiedDocId(null), 2000);
  };

  const handleCalculateRoute = (e: React.FormEvent) => {
    e.preventDefault();
    setIsCalculatingRoute(true);
    setTimeout(() => {
      setRouteResult({
        metroRoute: `${cityData.transport[0]?.name || 'Metro Line'} direct transit`,
        walkingTime: '6 min walk to station + 12 min train ride',
        taxiCost: 'Standard metered fare (approx 15-20 min ride)',
        transitSteps: [
          `Walk 400m from ${routeFrom} to the nearest subway entrance`,
          `Board the inbound train towards ${routeTo}`,
          `Travel 4 stops, exit at Gate 2 (Elevator available for luggage)`,
          `Follow signs directly to ${routeTo} lobby`,
        ],
        localTips: `${cityData.primaryLanguage === 'Japanese' ? 'Use IC card tap (Suica/Pasmo)' : 'Tap contactless bank card on turnstile'}. Avoid rush hour peak 08:00 - 09:00.`,
      });
      setIsCalculatingRoute(false);
    }, 450);
  };

  const handleAddDocument = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDocTitle.trim() || !newDocNumber.trim()) return;

    const newDoc: TravelDocument = {
      id: `user_doc_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      type: newDocType,
      title: newDocTitle.trim(),
      holderName: newDocHolder.trim(),
      documentNumber: newDocNumber.trim(),
      expiryDate: newDocExpiry || undefined,
      bookingRef: newDocBookingRef.trim() || undefined,
      notes: newDocNotes.trim() || undefined,
      fileData: newDocFileData || undefined,
      fileName: newDocFileName || undefined,
      lastUpdated: Date.now(),
    };

    handleSaveDocs([...travelDocuments, newDoc]);
    setIsAddDocOpen(false);
    setNewDocTitle('');
    setNewDocNumber('');
    setNewDocBookingRef('');
    setNewDocNotes('');
    setNewDocFileData(null);
    setNewDocFileName(null);
  };

  const handleDeleteDocument = (id: string) => {
    handleSaveDocs(travelDocuments.filter(d => d.id !== id));
    if (viewingDoc?.id === id) setViewingDoc(null);
  };

  const filteredPlaces = (cityData?.nearbyPlaces || []).filter(
    p => selectedPlaceCategory === 'all' || p.category === selectedPlaceCategory
  );

  const activeAlerts = (cityData?.alerts || []).filter(a => !dismissedAlerts[a.id]);

  return (
    <div className="space-y-4 pb-12 animate-fade-in max-w-4xl mx-auto">
      {/* 1. Header Banner: Current Location, Weather & Destination Selector */}
      <section className="bg-gradient-to-br from-slate-900 via-slate-900 to-indigo-950/70 border border-slate-800 rounded-3xl p-4 sm:p-5 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 relative z-10">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-indigo-400 mb-1">
              <span className="flex h-2 w-2 rounded-full bg-emerald-400 animate-ping" />
              <span>LIVE TRAVEL INTELLIGENCE DASHBOARD</span>
            </div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <span className="text-2xl sm:text-3xl">{cityData.flag}</span>
              <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                {cityData.city}
              </h1>
              <span className="text-xs px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 border border-slate-700 font-medium">
                {cityData.nativeCountryName}
              </span>
              <button
                onClick={() => setIsLocationModalOpen(true)}
                className="inline-flex items-center gap-1.5 text-[11px] px-2.5 py-0.5 rounded-full bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/35 text-emerald-300 font-semibold transition-all cursor-pointer group"
                title="Click to view Live Location details"
              >
                <MapPin className="w-3 h-3 text-emerald-400 group-hover:scale-110 transition-transform" />
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span>
                  {locationState?.isLocationBased
                    ? `Destination based on your location${locationState.accuracy ? ` (±${locationState.accuracy}m)` : ''}`
                    : 'Destination based on your location'}
                </span>
              </button>
            </div>
            <p className="text-xs text-slate-400 mt-1 flex items-center gap-2">
              <span>Primary: <strong className="text-slate-200">{cityData.primaryLanguage}</strong></span>
              <span>•</span>
              <span>Emergency: <strong className="text-red-400">{cityData.emergencyNumber}</strong></span>
            </p>
          </div>

          {/* Location Actions */}
          <div className="flex items-center gap-2 shrink-0">
            {onDetectLocation && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onDetectLocation();
                }}
                disabled={isDetectingLocation}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-all disabled:opacity-50 text-xs font-semibold"
                title="Refresh Live Location (GPS)"
              >
                <RefreshCw className={`w-3.5 h-3.5 text-indigo-400 ${isDetectingLocation ? 'animate-spin' : ''}`} />
                <span className="text-[11px]">Refresh GPS</span>
              </button>
            )}
          </div>
        </div>

        {/* Real-time Weather & Environmental Status Bar */}
        <div className="mt-4 pt-3 border-t border-slate-800/80">
          <div className="flex items-center justify-between text-[11px] mb-2 font-medium">
            <div className="flex items-center gap-1.5 text-emerald-400">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>Live Satellite Weather • Open-Meteo API</span>
            </div>
            <button
              onClick={fetchWeather}
              disabled={isLoadingWeather}
              className="flex items-center gap-1 text-slate-400 hover:text-white transition-colors cursor-pointer"
              title="Refresh live weather forecast"
            >
              <RefreshCw className={`w-3 h-3 text-indigo-400 ${isLoadingWeather ? 'animate-spin' : ''}`} />
              <span className="text-[10px]">Refresh Radar</span>
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <div className="bg-slate-800/60 rounded-2xl p-3 border border-slate-700/50 flex items-center gap-2.5">
              <span className="text-2xl">{activeWeather.icon}</span>
              <div>
                <div className="text-base font-bold text-white leading-none">
                  {activeWeather.tempC}°C <span className="text-xs text-slate-400 font-normal">({activeWeather.tempF}°F)</span>
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">{activeWeather.condition}</div>
              </div>
            </div>

            <div className="bg-slate-800/60 rounded-2xl p-3 border border-slate-700/50 flex flex-col justify-center">
              <div className="text-[11px] text-slate-400 font-medium">Rain & Humidity</div>
              <div className="text-xs font-bold text-slate-200 mt-0.5">
                ☔ {activeWeather.rainChance}% rain • {activeWeather.humidity}% hum
              </div>
            </div>

            <div className="bg-slate-800/60 rounded-2xl p-3 border border-slate-700/50 flex flex-col justify-center">
              <div className="text-[11px] text-slate-400 font-medium">UV & Air Quality</div>
              <div className="text-xs font-bold text-slate-200 mt-0.5">
                ☀️ UV Index {activeWeather.uvIndex} • {activeWeather.airQuality.split(' ')[0]}
              </div>
            </div>

            <div className="bg-slate-800/60 rounded-2xl p-3 border border-slate-700/50 flex flex-col justify-center">
              <div className="text-[11px] text-indigo-400 font-semibold">3-Day Forecast</div>
              <div className="text-[11px] text-slate-300 mt-0.5 flex items-center gap-1.5">
                {activeWeather.forecast.map((f, i) => (
                  <span key={i} className="text-[10px] bg-slate-900/60 px-1 py-0.5 rounded">
                    {f.day.slice(0, 3)}: {f.tempC}°
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        {activeWeather.advisory && (
          <div className="mt-3 text-xs bg-indigo-500/10 border border-indigo-500/20 text-indigo-200 rounded-xl px-3 py-2 flex items-center gap-2">
            <Info className="w-4 h-4 text-indigo-400 shrink-0" />
            <span>{activeWeather.advisory}</span>
          </div>
        )}
      </section>

      {/* 2. Sub-Navigation Tabs within Travel Intelligence */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs font-semibold">
        <button
          onClick={() => setActiveTab('dashboard')}
          className={`px-3 py-2 rounded-xl transition-all flex items-center gap-1.5 shrink-0 ${
            activeTab === 'dashboard'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
              : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700/90'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Dashboard Overview</span>
        </button>

        <button
          onClick={() => setActiveTab('nearby')}
          className={`px-3 py-2 rounded-xl transition-all flex items-center gap-1.5 shrink-0 ${
            activeTab === 'nearby'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
              : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700/90'
          }`}
        >
          <Hospital className="w-3.5 h-3.5" />
          <span>Nearby Essentials</span>
        </button>

        <button
          onClick={() => setActiveTab('navigation')}
          className={`px-3 py-2 rounded-xl transition-all flex items-center gap-1.5 shrink-0 ${
            activeTab === 'navigation'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
              : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700/90'
          }`}
        >
          <Navigation className="w-3.5 h-3.5" />
          <span>AI Navigation & Route</span>
        </button>


        <button
          onClick={() => setActiveTab('documents')}
          className={`px-3 py-2 rounded-xl transition-all flex items-center gap-1.5 shrink-0 ${
            activeTab === 'documents'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
              : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700/90'
          }`}
        >
          <FileText className="w-3.5 h-3.5" />
          <span>Documents Vault ({travelDocuments.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('transport')}
          className={`px-3 py-2 rounded-xl transition-all flex items-center gap-1.5 shrink-0 ${
            activeTab === 'transport'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
              : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700/90'
          }`}
        >
          <Train className="w-3.5 h-3.5" />
          <span>Local Transit</span>
        </button>
      </div>

      {/* 3. Real-time Traffic, Road & Safety Alerts Feed (Persistent when alerts exist) */}
      {activeAlerts.length > 0 && (
        <section className="space-y-2">
          <div className="flex items-center justify-between text-xs px-1">
            <span className="font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
              Real-Time Traffic & Weather Alerts ({activeAlerts.length})
            </span>
          </div>

          <div className="space-y-2">
            {activeAlerts.map(alert => (
              <div 
                key={alert.id}
                className={`p-3.5 rounded-2xl border transition-all flex items-start justify-between gap-3 ${
                  alert.severity === 'warning'
                    ? 'bg-amber-950/20 border-amber-500/40 text-amber-200'
                    : alert.severity === 'critical'
                    ? 'bg-red-950/30 border-red-500/50 text-red-200'
                    : 'bg-slate-800/70 border-slate-700/70 text-slate-200'
                }`}
              >
                <div className="space-y-1 text-xs">
                  <div className="font-bold flex items-center gap-2">
                    <span className={`px-2 py-0.5 rounded text-[10px] uppercase font-black ${
                      alert.severity === 'warning' ? 'bg-amber-500/20 text-amber-300' : 'bg-slate-700 text-slate-300'
                    }`}>
                      {alert.category}
                    </span>
                    <span className="text-white text-sm">{alert.title}</span>
                  </div>
                  <p className="text-slate-300 leading-relaxed">{alert.description}</p>
                  {alert.actionRecommendation && (
                    <div className="text-indigo-300 font-medium flex items-center gap-1 mt-1">
                      <Sparkles className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                      <span>Advice: {alert.actionRecommendation}</span>
                    </div>
                  )}
                </div>

                <button
                  onClick={() => setDismissedAlerts(prev => ({ ...prev, [alert.id]: true }))}
                  className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 shrink-0"
                  title="Dismiss alert"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 4. Tab 1: DASHBOARD OVERVIEW */}
      {activeTab === 'dashboard' && (
        <div className="space-y-4">
          {/* Quick AI Action Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <button
              onClick={() => handleAskAgent('How do I tell the taxi driver where my hotel is?')}
              className="bg-gradient-to-br from-indigo-950/50 to-slate-900 border border-indigo-500/30 hover:border-indigo-500/70 p-4 rounded-2xl text-left transition-all hover:shadow-lg flex items-center justify-between group"
            >
              <div>
                <div className="w-9 h-9 rounded-xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center mb-2 border border-indigo-500/30">
                  <Car className="w-5 h-5" />
                </div>
                <div className="text-sm font-bold text-white group-hover:text-indigo-300">Taxi Driver Card</div>
                <p className="text-[11px] text-slate-400 mt-0.5">Show destination in {cityData.primaryLanguage}</p>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-500 group-hover:translate-x-1 transition-transform" />
            </button>

            <button
              onClick={() => handleAskAgent('Check if this taxi quote or bill is a scam')}
              className="bg-gradient-to-br from-amber-950/40 to-slate-900 border border-amber-500/30 hover:border-amber-500/70 p-4 rounded-2xl text-left transition-all hover:shadow-lg flex items-center justify-between group"
            >
              <div>
                <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center mb-2 border border-amber-500/30">
                  <Shield className="w-5 h-5" />
                </div>
                <div className="text-sm font-bold text-white group-hover:text-amber-300">Scam & Price Guard</div>
                <p className="text-[11px] text-slate-400 mt-0.5">Verify bills, taxi fares & SMS links</p>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-500 group-hover:translate-x-1 transition-transform" />
            </button>

            <button
              onClick={() => handleAskAgent('My flight is delayed. What should I do?')}
              className="bg-gradient-to-br from-rose-950/40 to-slate-900 border border-rose-500/30 hover:border-rose-500/70 p-4 rounded-2xl text-left transition-all hover:shadow-lg flex items-center justify-between group"
            >
              <div>
                <div className="w-9 h-9 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center mb-2 border border-rose-500/30">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div className="text-sm font-bold text-white group-hover:text-rose-300">Flight Delay Copilot</div>
                <p className="text-[11px] text-slate-400 mt-0.5">Compensation rights & rebooking</p>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-500 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          {/* Quick Nearby Essentials Preview */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-4 sm:p-5 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Hospital className="w-4 h-4 text-rose-400" />
                  Nearby Emergency & Essentials Radar
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Verified English & native-speaking facilities with 1-tap emergency taxi cards
                </p>
              </div>
              <button
                onClick={() => setActiveTab('nearby')}
                className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
              >
                <span>View all</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {cityData.nearbyPlaces.slice(0, 4).map(place => (
                <div
                  key={place.id}
                  className="bg-slate-800/70 border border-slate-700/60 rounded-2xl p-3 hover:border-slate-600 transition-all flex items-start justify-between gap-2.5"
                >
                  <div className="min-w-0 space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-white truncate">{place.name}</span>
                      {place.isEmergency && (
                        <span className="text-[9px] bg-rose-500/20 text-rose-300 border border-rose-500/30 px-1 rounded font-bold">
                          24/7 ER
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-indigo-300 truncate font-mono">
                      {place.localName}
                    </div>
                    <div className="text-[10px] text-slate-400 flex items-center gap-2">
                      <span>📍 {place.distance}</span>
                      <span>•</span>
                      <span>⏱️ {place.walkingTime}</span>
                      <span>•</span>
                      <span className="text-emerald-400">{place.openStatus}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <a
                      href={getGoogleMapsSearchUrl(`${place.name}, ${place.address}, ${cityData.city}`)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 text-xs font-medium flex items-center gap-1 transition-colors"
                      title="Open in Google Maps App"
                    >
                      <Navigation className="w-3.5 h-3.5 text-rose-400" />
                      <span className="hidden sm:inline">Maps</span>
                    </a>

                    <button
                      onClick={() => setActiveDriverCardPlace(place)}
                      className="px-2.5 py-1.5 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/40 text-indigo-300 border border-indigo-500/30 text-xs font-medium flex items-center gap-1 transition-colors"
                      title="Show Taxi Driver Card in Native Script"
                    >
                      <span>Taxi Card</span>
                      <ExternalLink className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      )}

      {/* 5. Tab 2: NEARBY ESSENTIALS (Hospitals, Police, Pharmacies, ATMs, Fuel, Transit) */}
      {activeTab === 'nearby' && (
        <div className="space-y-4">
          {/* Category Filter Chips */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar text-xs">
            {[
              { key: 'all', label: 'All Essentials', icon: Compass },
              { key: 'hospital', label: '🏥 Hospitals & ER', icon: Hospital },
              { key: 'police', label: '👮 Police & Koban', icon: Shield },
              { key: 'pharmacy', label: '💊 Pharmacies (24/7)', icon: Pill },
              { key: 'atm', label: '🏧 Foreign ATMs', icon: CreditCard },
              { key: 'transit', label: '🚇 Transit Hubs', icon: Train },
            ].map(cat => (
              <button
                key={cat.key}
                onClick={() => setSelectedPlaceCategory(cat.key as any)}
                className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-all font-semibold ${
                  selectedPlaceCategory === cat.key
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Place Cards */}
          <div className="space-y-3">
            {filteredPlaces.map(place => (
              <div
                key={place.id}
                className="bg-slate-900 border border-slate-800 rounded-2xl p-4 hover:border-slate-700 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3.5"
              >
                <div className="space-y-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-base font-bold text-white">{place.name}</span>
                    <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-300 font-semibold">
                      {place.openStatus}
                    </span>
                    <span className="text-xs text-amber-400 font-semibold">★ {place.rating}</span>
                  </div>

                  {place.localName && (
                    <div className="text-sm text-indigo-300 font-medium">
                      {place.localName}
                    </div>
                  )}

                  <p className="text-xs text-slate-400 flex items-center gap-2">
                    <span>📍 {place.distance} ({place.walkingTime})</span>
                    <span>•</span>
                    <span className="truncate max-w-md">{place.address}</span>
                  </p>

                  <div className="text-xs text-slate-300 bg-slate-800/80 rounded-xl px-2.5 py-1 font-mono inline-block mt-1">
                    Native Address: {place.localLanguageAddress}
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0 flex-wrap sm:flex-nowrap">
                  <a
                    href={getGoogleMapsSearchUrl(`${place.name}, ${place.address}, ${cityData.city}`)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 sm:px-3 sm:py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700 transition-colors flex items-center gap-1.5 text-xs font-semibold"
                    title="Open in Google Maps App for live GPS navigation"
                  >
                    <Navigation className="w-4 h-4 text-rose-400" />
                    <span>Maps</span>
                  </a>

                  <a
                    href={`tel:${place.phone}`}
                    className="p-2 sm:px-3 sm:py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700 transition-colors flex items-center gap-1.5 text-xs font-semibold"
                    title={`Call ${place.phone}`}
                  >
                    <Phone className="w-4 h-4 text-emerald-400" />
                    <span>Call</span>
                  </a>

                  <button
                    onClick={() => setActiveDriverCardPlace(place)}
                    className="px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs transition-all shadow-md shadow-indigo-600/30 flex items-center gap-1.5 cursor-pointer"
                  >
                    <span>Show Driver Card</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 6. Tab 3: AI NAVIGATION & ROUTE GUIDANCE */}
      {activeTab === 'navigation' && (
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-5 space-y-4">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Navigation className="w-5 h-5 text-indigo-400" />
                AI Route Planner & Local Transit Advisor
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Calculates fastest train/subway vs walking vs taxi cost in {cityData.city}
              </p>
            </div>

            <form onSubmit={handleCalculateRoute} className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="text-[11px] font-semibold text-slate-400 block mb-1">From:</label>
                  <input
                    type="text"
                    value={routeFrom}
                    onChange={(e) => setRouteFrom(e.target.value)}
                    placeholder="e.g. Park Hyatt Hotel or Current Location"
                    className="w-full bg-slate-800/90 text-white text-xs rounded-xl px-3 py-2.5 border border-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-slate-400 block mb-1">To Destination:</label>
                  <input
                    type="text"
                    value={routeTo}
                    onChange={(e) => setRouteTo(e.target.value)}
                    placeholder="e.g. Tokyo Tower, Louvre Museum, Airport"
                    className="w-full bg-slate-800/90 text-white text-xs rounded-xl px-3 py-2.5 border border-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div className="flex justify-end">
                <button
                  type="submit"
                  disabled={isCalculatingRoute}
                  className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all shadow-md shadow-indigo-600/30 flex items-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <Navigation className="w-4 h-4" />
                  <span>{isCalculatingRoute ? 'Calculating Route...' : 'Get AI Route Guidance'}</span>
                </button>
              </div>
            </form>

            {routeResult && (
              <div className="mt-4 pt-4 border-t border-slate-800 space-y-3 animate-fade-in">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
                  <div className="bg-slate-800/80 border border-slate-700 p-3 rounded-2xl">
                    <div className="text-slate-400 text-[11px] font-semibold">🚆 Best Transit Route</div>
                    <div className="font-bold text-white mt-1">{routeResult.metroRoute}</div>
                    <div className="text-emerald-400 text-[11px] mt-0.5">{routeResult.walkingTime}</div>
                  </div>

                  <div className="bg-slate-800/80 border border-slate-700 p-3 rounded-2xl">
                    <div className="text-slate-400 text-[11px] font-semibold">🚕 Taxi Estimate</div>
                    <div className="font-bold text-amber-300 mt-1">{routeResult.taxiCost}</div>
                    <div className="text-slate-400 text-[11px] mt-0.5">Subject to traffic</div>
                  </div>

                  <div className="bg-slate-800/80 border border-slate-700 p-3 rounded-2xl">
                    <div className="text-slate-400 text-[11px] font-semibold">💡 Local Travel Tip</div>
                    <div className="text-slate-200 text-xs mt-1">{routeResult.localTips}</div>
                  </div>
                </div>

                <div className="bg-slate-800/50 border border-slate-700/60 rounded-2xl p-3.5 text-xs space-y-2">
                  <div className="font-bold text-white flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-indigo-400" />
                    Turn-by-Turn Transit Steps
                  </div>
                  <ol className="space-y-1.5 pl-4 list-decimal text-slate-300">
                    {routeResult.transitSteps.map((step, idx) => (
                      <li key={idx} className="leading-relaxed">{step}</li>
                    ))}
                  </ol>
                </div>

                {/* Direct Google Maps App Navigation Buttons */}
                <div className="bg-slate-800/40 border border-slate-700/50 rounded-2xl p-3 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
                  <div className="text-xs text-slate-300 flex items-center gap-2">
                    <Navigation className="w-4 h-4 text-rose-400 shrink-0" />
                    <div>
                      <div className="font-bold text-white">Navigate with Google Maps App</div>
                      <div className="text-[11px] text-slate-400">Launch live GPS turn-by-turn navigation or subway departures</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <a
                      href={getGoogleMapsDirectionsUrl(routeFrom, routeTo, 'transit')}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-indigo-600/30 transition-all flex-1 sm:flex-initial"
                      title="Open Transit Navigation in Google Maps App"
                    >
                      <Train className="w-3.5 h-3.5" />
                      <span>Transit in Maps</span>
                      <ExternalLink className="w-3 h-3 text-indigo-200" />
                    </a>

                    <a
                      href={getGoogleMapsDirectionsUrl(routeFrom, routeTo, 'driving')}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700 font-semibold text-xs flex items-center justify-center gap-1.5 transition-all flex-1 sm:flex-initial"
                      title="Open Driving Navigation in Google Maps App"
                    >
                      <Car className="w-3.5 h-3.5 text-amber-400" />
                      <span>Driving</span>
                    </a>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}


      {/* 8. Tab 5: TRAVEL DOCUMENTS VAULT */}
      {activeTab === 'documents' && (
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-5 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <FileText className="w-5 h-5 text-indigo-400" />
                  Travel Documents Digital Vault
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Secure local offline storage with photo scans for Passport, Visa, Flights, Hotel Bookings & Insurance
                </p>
              </div>

              <button
                id="add-document-button"
                onClick={() => setIsAddDocOpen(true)}
                className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-md shadow-indigo-600/30 shrink-0"
              >
                <Plus className="w-4 h-4" />
                <span>Add Document</span>
              </button>
            </div>

            {/* Document Type Filter Chips */}
            {travelDocuments.length > 0 && (
              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1 text-xs">
                {(['all', 'passport', 'visa', 'ticket', 'hotel', 'insurance'] as const).map(cat => {
                  const count = cat === 'all' 
                    ? travelDocuments.length 
                    : travelDocuments.filter(d => d.type === cat).length;
                  return (
                    <button
                      key={cat}
                      onClick={() => setDocFilterType(cat)}
                      className={`px-3 py-1.5 rounded-xl font-semibold capitalize whitespace-nowrap transition-all flex items-center gap-1.5 ${
                        docFilterType === cat
                          ? 'bg-indigo-600 text-white shadow-sm'
                          : 'bg-slate-800/80 text-slate-400 hover:text-white'
                      }`}
                    >
                      <span>{cat === 'all' ? 'All Documents' : cat}</span>
                      <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-slate-900/60 font-mono">
                        {count}
                      </span>
                    </button>
                  );
                })}
              </div>
            )}

            {/* Documents List */}
            {travelDocuments.length === 0 ? (
              <div className="text-center py-10 px-4 bg-slate-950/40 rounded-2xl border border-dashed border-slate-800 space-y-3">
                <div className="w-12 h-12 rounded-2xl bg-indigo-600/10 text-indigo-400 flex items-center justify-center mx-auto border border-indigo-500/20">
                  <FileText className="w-6 h-6" />
                </div>
                <div className="space-y-1">
                  <h4 className="text-sm font-bold text-white">No Travel Documents Added Yet</h4>
                  <p className="text-xs text-slate-400 max-w-sm mx-auto">
                    Your digital vault is currently empty. Tap "Add Document" to securely store your Passport, Flight E-Ticket, Hotel Reservation, or Insurance policy offline.
                  </p>
                </div>
                <button
                  onClick={() => setIsAddDocOpen(true)}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all shadow-md shadow-indigo-600/30"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add First Document</span>
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {travelDocuments
                  .filter(doc => docFilterType === 'all' || doc.type === docFilterType)
                  .map(doc => (
                    <div
                      key={doc.id}
                      className="bg-slate-800/70 border border-slate-700/80 rounded-2xl p-4 space-y-2.5 hover:border-slate-600 transition-all relative group flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex items-start justify-between gap-2">
                          <div className="space-y-0.5">
                            <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                              {doc.type}
                            </span>
                            <h4 className="text-sm font-bold text-white mt-1">{doc.title}</h4>
                            <p className="text-xs text-slate-400">Holder: {doc.holderName}</p>
                          </div>

                          <div className="flex items-center gap-1">
                            {doc.fileData && (
                              <button
                                onClick={() => setViewingDoc(doc)}
                                className="text-slate-400 hover:text-indigo-300 p-1.5 rounded-lg bg-slate-900/60 border border-slate-700"
                                title="View Document Photo"
                              >
                                <Eye className="w-3.5 h-3.5" />
                              </button>
                            )}
                            <button
                              onClick={() => handleDeleteDocument(doc.id)}
                              className="text-slate-500 hover:text-rose-400 p-1.5 rounded-lg bg-slate-900/60 border border-slate-700 transition-colors"
                              title="Delete document"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        <div className="bg-slate-900/80 rounded-xl p-2.5 flex items-center justify-between text-xs font-mono mt-2">
                          <span className="text-slate-200 truncate font-semibold">{doc.documentNumber}</span>
                          <button
                            onClick={() => handleCopy(doc.id, doc.documentNumber)}
                            className="text-indigo-400 hover:text-indigo-300 p-1 transition-colors flex items-center gap-1 text-[11px] shrink-0"
                          >
                            {copiedDocId === doc.id ? (
                              <>
                                <Check className="w-3.5 h-3.5 text-emerald-400" />
                                <span className="text-emerald-400 font-sans font-bold">Copied</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-3.5 h-3.5" />
                                <span className="font-sans">Copy</span>
                              </>
                            )}
                          </button>
                        </div>

                        <div className="text-[11px] text-slate-400 flex items-center justify-between mt-2">
                          <span>Expiry: {doc.expiryDate || 'No date set'}</span>
                          {doc.bookingRef && (
                            <span className="text-teal-300 font-mono font-bold">Ref: {doc.bookingRef}</span>
                          )}
                        </div>

                        {doc.notes && (
                          <p className="text-[11px] text-slate-300 bg-slate-800/40 p-2 rounded-lg border border-slate-700/50 mt-2">
                            {doc.notes}
                          </p>
                        )}
                      </div>

                      {doc.fileData && (
                        <div className="pt-2 border-t border-slate-700/50 flex items-center justify-between text-xs">
                          <span className="text-emerald-400 text-[11px] flex items-center gap-1">
                            <ImageIcon className="w-3 h-3" />
                            <span>Photo Attached</span>
                          </span>
                          <button
                            onClick={() => setViewingDoc(doc)}
                            className="text-indigo-400 hover:text-indigo-300 font-semibold text-[11px] flex items-center gap-1"
                          >
                            <span>Preview</span>
                            <Eye className="w-3 h-3" />
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* 9. Tab 6: LOCAL TRANSIT GUIDE */}
      {activeTab === 'transport' && (
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-5 space-y-4">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Train className="w-5 h-5 text-indigo-400" />
                Local Transport & Etiquette Guide
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Recommended apps, ticketing methods, and local transit rules in {cityData.city}
              </p>
            </div>

            <div className="space-y-3">
              {cityData.transport.map((opt, i) => (
                <div key={i} className="bg-slate-800/70 border border-slate-700/80 rounded-2xl p-4 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-bold text-white flex items-center gap-2">
                      <span className="text-xs px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 uppercase font-bold">
                        {opt.type}
                      </span>
                      {opt.name}
                    </span>
                    <span className="text-xs text-emerald-400 font-semibold">{opt.typicalCost}</span>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed">
                    <strong>Payment:</strong> {opt.paymentMethods}
                  </p>

                  <p className="text-xs text-slate-400">
                    <strong>Key Advice:</strong> {opt.keyAdvice}
                  </p>

                  <div className="flex items-center gap-1.5 flex-wrap pt-1 text-[11px]">
                    <span className="text-slate-400">Recommended Apps:</span>
                    {opt.recommendedApps.map(app => (
                      <span key={app} className="bg-slate-900 text-indigo-300 px-2 py-0.5 rounded border border-slate-700">
                        {app}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Modal: Add Document */}
      {isAddDocOpen && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-3 animate-fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 w-full max-w-md space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <FileText className="w-5 h-5 text-indigo-400" />
                Add Travel Document
              </h3>
              <button
                onClick={() => setIsAddDocOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddDocument} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 font-semibold block mb-1">Document Type:</label>
                <select
                  value={newDocType}
                  onChange={(e) => setNewDocType(e.target.value as DocumentType)}
                  className="w-full bg-slate-800 text-white rounded-xl p-2.5 border border-slate-700 focus:outline-none focus:border-indigo-500"
                >
                  <option value="passport">Passport</option>
                  <option value="visa">Visa</option>
                  <option value="ticket">Flight / Train Ticket</option>
                  <option value="hotel">Hotel Booking</option>
                  <option value="insurance">Travel Insurance</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 font-semibold block mb-1">Title / Description:</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. US Passport, Flight to Tokyo, Hilton Hotel"
                  value={newDocTitle}
                  onChange={(e) => setNewDocTitle(e.target.value)}
                  className="w-full bg-slate-800 text-white rounded-xl p-2.5 border border-slate-700 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-slate-400 font-semibold block mb-1">Document / ID / Ticket Number:</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. P12345678, Booking Ref 7XKW9P"
                  value={newDocNumber}
                  onChange={(e) => setNewDocNumber(e.target.value)}
                  className="w-full bg-slate-800 text-white rounded-xl p-2.5 border border-slate-700 focus:outline-none focus:border-indigo-500 font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-slate-400 font-semibold block mb-1">Holder Name:</label>
                  <input
                    type="text"
                    value={newDocHolder}
                    onChange={(e) => setNewDocHolder(e.target.value)}
                    className="w-full bg-slate-800 text-white rounded-xl p-2.5 border border-slate-700 focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="text-slate-400 font-semibold block mb-1">Booking Ref (Optional):</label>
                  <input
                    type="text"
                    placeholder="e.g. 7XKW9P"
                    value={newDocBookingRef}
                    onChange={(e) => setNewDocBookingRef(e.target.value)}
                    className="w-full bg-slate-800 text-white rounded-xl p-2.5 border border-slate-700 focus:outline-none focus:border-indigo-500 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-400 font-semibold block mb-1">Expiry / Valid Date:</label>
                <input
                  type="date"
                  value={newDocExpiry}
                  onChange={(e) => setNewDocExpiry(e.target.value)}
                  className="w-full bg-slate-800 text-white rounded-xl p-2.5 border border-slate-700 focus:outline-none focus:border-indigo-500"
                />
              </div>

              {/* Photo / Scan File Attachment */}
              <div>
                <label className="text-slate-400 font-semibold block mb-1">
                  Attach Photo / Scan (Offline Storage):
                </label>
                <label className="flex items-center justify-center gap-2 p-3 rounded-xl border border-dashed border-slate-700 bg-slate-800/50 hover:bg-slate-800 cursor-pointer text-slate-300 transition-colors">
                  <ImageIcon className="w-4 h-4 text-indigo-400" />
                  <span className="truncate">{newDocFileName ? newDocFileName : 'Upload Photo or Document Scan'}</span>
                  <input
                    type="file"
                    accept="image/*,.pdf"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                </label>
                {newDocFileData && (
                  <div className="mt-2 relative rounded-xl overflow-hidden border border-slate-700 max-h-32">
                    <img src={newDocFileData} alt="Preview" className="w-full h-32 object-cover" />
                    <button
                      type="button"
                      onClick={() => {
                        setNewDocFileData(null);
                        setNewDocFileName(null);
                      }}
                      className="absolute top-1 right-1 p-1 bg-black/70 rounded-full text-white text-xs"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>

              <div>
                <label className="text-slate-400 font-semibold block mb-1">Notes / Emergency Contact:</label>
                <textarea
                  rows={2}
                  placeholder="Gate 12, Terminal 1, Policy coverage notes, emergency hotline..."
                  value={newDocNotes}
                  onChange={(e) => setNewDocNotes(e.target.value)}
                  className="w-full bg-slate-800 text-white rounded-xl p-2.5 border border-slate-700 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddDocOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold shadow-md shadow-indigo-600/30"
                >
                  Save to Vault
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: View Document Fullscreen */}
      {viewingDoc && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-3 animate-fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 w-full max-w-lg space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  {viewingDoc.type}
                </span>
                <h3 className="text-base font-bold text-white mt-1">{viewingDoc.title}</h3>
                <p className="text-xs text-slate-400">Holder: {viewingDoc.holderName}</p>
              </div>
              <button
                onClick={() => setViewingDoc(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-slate-800/80 rounded-2xl p-3 space-y-2 border border-slate-700 text-xs">
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Number / Code:</span>
                <span className="font-mono font-bold text-white text-sm">{viewingDoc.documentNumber}</span>
              </div>
              {viewingDoc.bookingRef && (
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Booking Reference:</span>
                  <span className="font-mono font-bold text-teal-300">{viewingDoc.bookingRef}</span>
                </div>
              )}
              {viewingDoc.expiryDate && (
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Expiry Date:</span>
                  <span className="text-slate-200">{viewingDoc.expiryDate}</span>
                </div>
              )}
              {viewingDoc.notes && (
                <div className="pt-2 border-t border-slate-700 text-slate-300">
                  <span className="text-slate-400 block mb-0.5 font-semibold">Notes:</span>
                  {viewingDoc.notes}
                </div>
              )}
            </div>

            {viewingDoc.fileData && (
              <div className="space-y-2">
                <span className="text-xs font-semibold text-slate-300 block">Attached Scan / Photo:</span>
                <div className="rounded-2xl overflow-hidden border border-slate-700 bg-slate-950 flex items-center justify-center max-h-80">
                  <img
                    src={viewingDoc.fileData}
                    alt={viewingDoc.title}
                    className="max-h-80 w-auto object-contain"
                  />
                </div>
              </div>
            )}

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => handleCopy(viewingDoc.id, viewingDoc.documentNumber)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs flex items-center gap-1.5"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>Copy Number</span>
              </button>
              <button
                onClick={() => setViewingDoc(null)}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Fullscreen Native Language Driver Destination Card */}
      {activeDriverCardPlace && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-slate-900 border-2 border-indigo-500/80 rounded-3xl p-5 sm:p-7 w-full max-w-lg space-y-4 shadow-2xl relative text-center">
            <button
              onClick={() => setActiveDriverCardPlace(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-2 rounded-full bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="space-y-1">
              <span className="text-xs font-black uppercase tracking-widest text-indigo-400">
                TAXI DRIVER DESTINATION CARD
              </span>
              <p className="text-xs text-slate-400">
                Show this screen directly to your driver in {cityData.country}
              </p>
            </div>

            {/* Giant Native Display for Driver */}
            <div className="bg-white text-slate-950 p-6 rounded-3xl shadow-inner space-y-3">
              <div className="text-xs font-bold text-slate-500 uppercase">
                DESTINATION / 行き先 / ปลายทาง:
              </div>
              <div className="text-2xl sm:text-3xl font-black tracking-tight leading-tight">
                {activeDriverCardPlace.localName || activeDriverCardPlace.name}
              </div>
              <div className="text-base font-bold text-slate-700 border-t border-slate-200 pt-2 font-mono">
                {activeDriverCardPlace.localLanguageAddress}
              </div>
              {activeDriverCardPlace.phoneticAddress && (
                <div className="text-xs text-indigo-700 italic font-medium">
                  Pronunciation: "{activeDriverCardPlace.phoneticAddress}"
                </div>
              )}
            </div>

            {/* Audio & Phone actions */}
            <div className="flex items-center justify-center gap-2 pt-2">
              <button
                onClick={() => speakText(
                  `${activeDriverCardPlace.localName || activeDriverCardPlace.name}, ${activeDriverCardPlace.localLanguageAddress}`,
                  cityData.primaryLanguageCode
                )}
                className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-indigo-600/40"
              >
                <Volume2 className="w-4 h-4" />
                <span>Play Native Speech</span>
              </button>

              <a
                href={getGoogleMapsSearchUrl(`${activeDriverCardPlace.name}, ${activeDriverCardPlace.address}, ${cityData.city}`)}
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-bold text-xs flex items-center gap-2 border border-slate-700 transition-colors"
                title="Launch Google Maps App for live GPS navigation"
              >
                <Navigation className="w-4 h-4 text-rose-400" />
                <span>Open in Google Maps</span>
              </a>

              <a
                href={`tel:${activeDriverCardPlace.phone}`}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center gap-2 border border-slate-700"
              >
                <Phone className="w-4 h-4 text-emerald-400" />
                <span>Call ({activeDriverCardPlace.phone})</span>
              </a>
            </div>
          </div>
        </div>
      )}

      {/* Location-Based Destination Details Modal */}
      <LocationStatusModal
        isOpen={isLocationModalOpen}
        onClose={() => setIsLocationModalOpen(false)}
        currentDestination={effectiveDestination}
        locationState={locationState || null}
        isDetecting={!!isDetectingLocation}
        onDetectLocation={async () => {
          if (onDetectLocation) await onDetectLocation();
        }}
        onSelectManualDestination={onSelectDestination}
      />
    </div>
  );
};
