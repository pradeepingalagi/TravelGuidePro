import React from 'react';
import { 
  MapPin, 
  Navigation, 
  RefreshCw, 
  CheckCircle2, 
  AlertCircle, 
  X, 
  ShieldCheck, 
  Compass, 
  Globe2,
  ChevronRight
} from 'lucide-react';
import { DestinationCity } from '../../types/travel';
import { CITIES_DATA, resolveCityProfile } from '../../data/travelData';
import { LocationDetectionResult, CITY_COORDINATES } from '../../services/locationService';

interface LocationStatusModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentDestination: DestinationCity;
  locationState: LocationDetectionResult | null;
  isDetecting: boolean;
  onDetectLocation: () => Promise<void>;
  onSelectManualDestination?: (city: DestinationCity) => void;
}

export const LocationStatusModal: React.FC<LocationStatusModalProps> = ({
  isOpen,
  onClose,
  currentDestination,
  locationState,
  isDetecting,
  onDetectLocation,
  onSelectManualDestination,
}) => {
  const [showOverride, setShowOverride] = React.useState(false);

  if (!isOpen) return null;

  const cityData = resolveCityProfile(currentDestination, locationState);
  const hasCoords = locationState?.coords?.latitude !== undefined;
  const isGpsActive = locationState?.status === 'detected' && locationState?.isLocationBased;
  const isOverridden = isGpsActive && locationState.matchedDestination && currentDestination !== locationState.matchedDestination;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
      <div 
        className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl animate-scale-up"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
              <MapPin className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <span>Location-Based Destination</span>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full font-mono uppercase font-bold">
                  Live GPS
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Destination automatically adapted from your physical location
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 max-h-[75vh] overflow-y-auto">
          {/* Active Matched Hub Card */}
          <div className="bg-gradient-to-br from-slate-800/90 to-indigo-950/50 border border-indigo-500/30 rounded-2xl p-4 space-y-3">
            <div className="flex items-start justify-between gap-3">
              <div className="space-y-1">
                <span className="text-[10px] uppercase font-bold text-indigo-400 tracking-wider">
                  Active Travel Hub
                </span>
                <div className="flex items-center gap-2">
                  <span className="text-3xl">{cityData.flag}</span>
                  <div>
                    <h3 className="text-lg font-black text-white">{cityData.city}</h3>
                    <p className="text-xs text-slate-400">{cityData.nativeCountryName} • {cityData.country}</p>
                  </div>
                </div>
              </div>

              <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/30 flex items-center gap-1 shrink-0">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Auto-Matched</span>
              </span>
            </div>

            {/* GPS Metrics */}
            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-700/60 text-xs">
              <div className="bg-slate-900/60 p-2.5 rounded-xl border border-slate-800">
                <span className="text-slate-400 text-[10px] block">Live Coordinates</span>
                <span className="font-mono text-slate-200 font-semibold truncate block">
                  {hasCoords
                    ? `${locationState?.coords?.latitude.toFixed(4)}°, ${locationState?.coords?.longitude.toFixed(4)}°`
                    : `${CITY_COORDINATES[currentDestination]?.lat?.toFixed(4) || '28.6139'}°, ${CITY_COORDINATES[currentDestination]?.lng?.toFixed(4) || '77.2090'}°`}
                </span>
              </div>
              <div className="bg-slate-900/60 p-2.5 rounded-xl border border-slate-800">
                <span className="text-slate-400 text-[10px] block">Detection Precision</span>
                <span className="font-semibold text-emerald-400 flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span>
                    {locationState?.isIpBased
                      ? 'Network IP Geolocation'
                      : locationState?.accuracy
                      ? `GPS Sensor (±${locationState.accuracy}m)`
                      : 'GPS Sensor Active'}
                  </span>
                </span>
              </div>
            </div>

            {locationState?.message && (
              <p className="text-[11px] text-slate-300 bg-slate-900/40 p-2 rounded-lg border border-slate-800/80">
                📍 {locationState.message}
              </p>
            )}

            {isOverridden && locationState?.matchedDestination && onSelectManualDestination && (
              <button
                onClick={() => {
                  onSelectManualDestination(locationState.matchedDestination);
                  onClose();
                }}
                className="w-full py-2 px-3 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                <span>Switch to Live Detected GPS: {locationState.matchedDestination}</span>
              </button>
            )}
          </div>

          {/* Location-Driven Services Summary */}
          <div className="bg-slate-950/60 border border-slate-800/80 rounded-2xl p-4 space-y-2.5 text-xs">
            <h4 className="font-bold text-slate-300 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Services Dynamically Adapted to this Location</span>
            </h4>
            <ul className="space-y-1.5 text-slate-300 pl-1">
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                <span><strong>Emergency Hotline:</strong> {cityData.emergencyNumber}</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
                <span><strong>Local Weather:</strong> {cityData.weather.tempC}°C ({cityData.weather.condition})</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-teal-400" />
                <span><strong>Destination Language:</strong> {cityData.primaryLanguage}</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                <span><strong>Live Nearby Services:</strong> Hospitals, Police & Pharmacies closest to your coordinates</span>
              </li>
            </ul>
          </div>

          {/* Action: Re-Scan GPS */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => onDetectLocation()}
              disabled={isDetecting}
              className="flex-1 py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 text-white font-bold text-xs flex items-center justify-center gap-2 transition-colors shadow-lg shadow-indigo-600/20"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isDetecting ? 'animate-spin' : ''}`} />
              <span>{isDetecting ? 'Detecting Live GPS Location...' : 'Re-Detect Current Location (GPS)'}</span>
            </button>
          </div>

          {/* Optional Trip Planner / Hub Override */}
          <div className="pt-2 border-t border-slate-800">
            <button
              onClick={() => setShowOverride(!showOverride)}
              className="w-full text-left text-xs text-slate-400 hover:text-slate-200 font-medium flex items-center justify-between py-1"
            >
              <span>Traveling soon? Preview another travel hub</span>
              <ChevronRight className={`w-3.5 h-3.5 transition-transform ${showOverride ? 'rotate-90' : ''}`} />
            </button>

            {showOverride && onSelectManualDestination && (
              <div className="mt-2 space-y-1.5 grid grid-cols-2 gap-1.5">
                {Object.keys(CITIES_DATA).map(cityName => (
                  <button
                    key={cityName}
                    onClick={() => {
                      onSelectManualDestination(cityName as DestinationCity);
                      onClose();
                    }}
                    className={`text-left p-2 rounded-xl text-xs flex items-center gap-2 transition-colors border ${
                      currentDestination === cityName 
                        ? 'bg-indigo-600/30 border-indigo-500/50 text-white font-bold' 
                        : 'bg-slate-800/70 border-slate-700/60 text-slate-300 hover:bg-slate-800 hover:text-white'
                    }`}
                  >
                    <span>{CITIES_DATA[cityName as DestinationCity].flag}</span>
                    <span className="truncate">{cityName}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
