import React, { useState, useEffect } from 'react';
import { 
  MapPin, 
  Mic, 
  Camera, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  ShieldCheck, 
  Sparkles, 
  ArrowRight, 
  Loader2, 
  Settings, 
  ExternalLink,
  Compass,
  Volume2,
  ScanLine,
  ChevronRight,
  Info
} from 'lucide-react';
import { 
  requestLocationAccess, 
  requestMicrophoneAccess, 
  requestCameraAccess, 
  checkLocationPermission, 
  checkMicrophonePermission, 
  checkCameraPermission,
  openAndroidAppSettings,
  PermissionStateValue
} from '../utils/permissions';

export type OnboardingStep = 'welcome' | 'location' | 'microphone' | 'camera' | 'finished';

interface WelcomePermissionsOnboardingProps {
  isOpen: boolean;
  onFinished: () => void;
}

export const WelcomePermissionsOnboarding: React.FC<WelcomePermissionsOnboardingProps> = ({
  isOpen,
  onFinished,
}) => {
  const [currentStep, setCurrentStep] = useState<OnboardingStep>('welcome');
  const [isRequesting, setIsRequesting] = useState(false);
  const [permissionResults, setPermissionResults] = useState<{
    location: PermissionStateValue | 'untested';
    microphone: PermissionStateValue | 'untested';
    camera: PermissionStateValue | 'untested';
  }>({
    location: 'untested',
    microphone: 'untested',
    camera: 'untested',
  });
  const [stepFeedback, setStepFeedback] = useState<{
    type: 'success' | 'denied' | 'blocked' | null;
    message: string | null;
  }>({ type: null, message: null });

  // On mount, inspect if any permission was already granted previously
  useEffect(() => {
    if (!isOpen) return;
    const checkInitial = async () => {
      try {
        const [loc, mic, cam] = await Promise.all([
          checkLocationPermission(),
          checkMicrophonePermission(),
          checkCameraPermission()
        ]);
        setPermissionResults({
          location: loc,
          microphone: mic,
          camera: cam
        });
      } catch (e) {
        console.warn('Initial permission state check failed:', e);
      }
    };
    checkInitial();
  }, [isOpen]);

  if (!isOpen) return null;

  // 1. LOCATION PERMISSION HANDLER
  const handleRequestLocation = async () => {
    setIsRequesting(true);
    setStepFeedback({ type: null, message: null });
    try {
      const res = await requestLocationAccess();
      if (res.granted) {
        setPermissionResults(prev => ({ ...prev, location: 'granted' }));
        setStepFeedback({
          type: 'success',
          message: 'Location access granted. Nearby places, weather, and SOS are active.'
        });
        setTimeout(() => {
          advanceToStep('microphone');
        }, 1200);
      } else {
        const isBlocked = res.error?.includes('blocked') || res.error?.includes('Settings');
        setPermissionResults(prev => ({ ...prev, location: 'denied' }));
        setStepFeedback({
          type: isBlocked ? 'blocked' : 'denied',
          message: isBlocked
            ? 'Location is blocked in Android Settings. You can enable it anytime or continue with manual city selection.'
            : 'Location was not granted. Automatic city detection is unavailable, but you can select your destination manually.'
        });
      }
    } catch (err: any) {
      setPermissionResults(prev => ({ ...prev, location: 'denied' }));
      setStepFeedback({
        type: 'denied',
        message: 'Could not access location. Continuing with manual destination mode.'
      });
    } finally {
      setIsRequesting(false);
    }
  };

  // 2. MICROPHONE PERMISSION HANDLER
  const handleRequestMicrophone = async () => {
    setIsRequesting(true);
    setStepFeedback({ type: null, message: null });
    try {
      const res = await requestMicrophoneAccess();
      if (res.granted) {
        setPermissionResults(prev => ({ ...prev, microphone: 'granted' }));
        setStepFeedback({
          type: 'success',
          message: 'Microphone access granted. Real-time voice translation is ready.'
        });
        setTimeout(() => {
          advanceToStep('camera');
        }, 1200);
      } else {
        const isBlocked = res.error?.includes('blocked') || res.error?.includes('Settings');
        setPermissionResults(prev => ({ ...prev, microphone: 'denied' }));
        setStepFeedback({
          type: isBlocked ? 'blocked' : 'denied',
          message: isBlocked
            ? 'Microphone is blocked in device settings. Voice features will require manual unblocking in App Settings.'
            : 'Microphone was not granted. Voice conversation is unavailable, but text translation and phrasebook remain fully available.'
        });
      }
    } catch (err: any) {
      setPermissionResults(prev => ({ ...prev, microphone: 'denied' }));
      setStepFeedback({
        type: 'denied',
        message: 'Could not access microphone. You can still use text translation.'
      });
    } finally {
      setIsRequesting(false);
    }
  };

  // 3. CAMERA PERMISSION HANDLER
  const handleRequestCamera = async () => {
    setIsRequesting(true);
    setStepFeedback({ type: null, message: null });
    try {
      const res = await requestCameraAccess();
      if (res.granted) {
        setPermissionResults(prev => ({ ...prev, camera: 'granted' }));
        setStepFeedback({
          type: 'success',
          message: 'Camera access granted. Live sign, menu, and OCR translation is active.'
        });
        setTimeout(() => {
          finishOnboarding();
        }, 1200);
      } else {
        const isBlocked = res.error?.includes('blocked') || res.error?.includes('Settings');
        setPermissionResults(prev => ({ ...prev, camera: 'denied' }));
        setStepFeedback({
          type: isBlocked ? 'blocked' : 'denied',
          message: isBlocked
            ? 'Camera is blocked in device settings. Sign OCR can be enabled anytime in App Settings.'
            : 'Camera was not granted. Live camera scanning is unavailable, but photo gallery upload and text translation remain active.'
        });
      }
    } catch (err: any) {
      setPermissionResults(prev => ({ ...prev, camera: 'denied' }));
      setStepFeedback({
        type: 'denied',
        message: 'Could not access camera. You can still upload images from your gallery.'
      });
    } finally {
      setIsRequesting(false);
    }
  };

  const advanceToStep = (next: OnboardingStep) => {
    setStepFeedback({ type: null, message: null });
    setCurrentStep(next);
  };

  const finishOnboarding = () => {
    try {
      localStorage.setItem('travelsarathi_onboarding_completed', 'true');
      localStorage.setItem('omnitranslate_permissions_intro_shown', 'true');
      localStorage.setItem('live_ai_permissions_checked', 'true');
      localStorage.setItem('omnitranslate_permissions_checked', 'true');
    } catch (e) {
      console.warn('Failed saving onboarding state:', e);
    }
    onFinished();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-3 sm:p-4 animate-fade-in select-none">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[94vh]">
        
        {/* Glow Header Accent Bar */}
        <div className="h-1.5 w-full bg-gradient-to-r from-teal-400 via-cyan-500 to-indigo-600" />

        {/* STEP 0: WELCOME SCREEN */}
        {currentStep === 'welcome' && (
          <div className="p-5 sm:p-7 flex flex-col overflow-y-auto">
            {/* Header Badge & Brand */}
            <div className="flex items-center justify-between mb-4">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-500/10 border border-teal-500/30 text-teal-300 text-xs font-bold tracking-wide">
                <Sparkles className="w-3.5 h-3.5 text-teal-400" />
                <span>Quick Setup</span>
              </div>
              <span className="text-[11px] font-semibold text-slate-400">Step 1 of 4</span>
            </div>

            {/* Title & Subtitle */}
            <div className="mb-5 text-center sm:text-left">
              <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                Welcome to Travel Guide Pro
              </h1>
              <p className="text-sm font-medium text-teal-300/90 mt-1">
                Translate. Explore. Navigate. Travel with confidence.
              </p>
              <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                To help you travel seamlessly, Travel Guide Pro uses device capabilities for real-time translation and guidance. Here is how each permission powers your journey:
              </p>
            </div>

            {/* The 3 Required Permissions Explained */}
            <div className="space-y-3 mb-6">
              
              {/* Location Card */}
              <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 flex items-start gap-3 hover:border-slate-700 transition-colors">
                <div className="w-10 h-10 rounded-xl bg-amber-500/15 text-amber-400 border border-amber-500/30 flex items-center justify-center shrink-0 mt-0.5">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-bold text-white flex items-center gap-1.5">
                    <span>Location</span>
                    <span className="text-[10px] font-medium text-amber-300 bg-amber-500/10 px-1.5 py-0.2 rounded border border-amber-500/20">Step 1</span>
                  </div>
                  <p className="text-xs text-slate-300 mt-1 leading-snug">
                    Discover nearby places, local weather, currency-related local information, emergency services, and travel assistance.
                  </p>
                </div>
              </div>

              {/* Microphone Card */}
              <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 flex items-start gap-3 hover:border-slate-700 transition-colors">
                <div className="w-10 h-10 rounded-xl bg-indigo-500/15 text-indigo-400 border border-indigo-500/30 flex items-center justify-center shrink-0 mt-0.5">
                  <Mic className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-bold text-white flex items-center gap-1.5">
                    <span>Microphone</span>
                    <span className="text-[10px] font-medium text-indigo-300 bg-indigo-500/10 px-1.5 py-0.2 rounded border border-indigo-500/20">Step 2</span>
                  </div>
                  <p className="text-xs text-slate-300 mt-1 leading-snug">
                    Enable real-time voice conversations, speech recognition, and voice translation.
                  </p>
                </div>
              </div>

              {/* Camera Card */}
              <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 flex items-start gap-3 hover:border-slate-700 transition-colors">
                <div className="w-10 h-10 rounded-xl bg-teal-500/15 text-teal-400 border border-teal-500/30 flex items-center justify-center shrink-0 mt-0.5">
                  <Camera className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-bold text-white flex items-center gap-1.5">
                    <span>Camera</span>
                    <span className="text-[10px] font-medium text-teal-300 bg-teal-500/10 px-1.5 py-0.2 rounded border border-teal-500/20">Step 3</span>
                  </div>
                  <p className="text-xs text-slate-300 mt-1 leading-snug">
                    Enable live camera translation, text recognition, and translation of signs, menus, and documents.
                  </p>
                </div>
              </div>
            </div>

            {/* Privacy Assurance */}
            <div className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-950/40 border border-slate-800/80 text-[11px] text-slate-400 mb-5">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Permissions are only activated when using features. No background tracking or audio recording.</span>
            </div>

            {/* Action Buttons */}
            <div className="space-y-2 mt-auto">
              <button
                id="begin-permission-flow-btn"
                onClick={() => advanceToStep('location')}
                className="w-full py-3.5 px-5 rounded-2xl bg-gradient-to-r from-teal-500 via-cyan-600 to-indigo-600 hover:from-teal-400 hover:to-indigo-500 text-white font-bold text-sm shadow-xl shadow-teal-500/20 flex items-center justify-center gap-2 transition-all active:scale-[0.98] cursor-pointer"
              >
                <span>Begin Permission Setup</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                onClick={finishOnboarding}
                className="w-full py-2.5 text-xs text-slate-400 hover:text-slate-200 transition-colors font-medium text-center"
              >
                Skip to Home (Configure Later in Settings)
              </button>
            </div>
          </div>
        )}

        {/* STEP 1: LOCATION PERMISSION */}
        {currentStep === 'location' && (
          <div className="p-5 sm:p-7 flex flex-col overflow-y-auto">
            {/* Progress indicator */}
            <div className="flex items-center justify-between mb-4">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-bold">
                <MapPin className="w-3.5 h-3.5" />
                <span>Permission 1 of 3: Location</span>
              </div>
              <span className="text-[11px] font-semibold text-slate-400">Step 2 of 4</span>
            </div>

            {/* Icon Banner */}
            <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center shadow-lg shadow-amber-500/10">
              <Compass className="w-8 h-8 animate-pulse" />
            </div>

            <div className="text-center mb-5">
              <h2 className="text-xl font-black text-white tracking-tight">
                Enable Location Access
              </h2>
              <p className="text-xs text-slate-300 mt-2 leading-relaxed max-w-sm mx-auto">
                Discover nearby places, local weather, currency-related local information, emergency services, and travel assistance.
              </p>
            </div>

            {/* Contextual feature explanation */}
            <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-3.5 space-y-2 mb-5">
              <div className="text-[11px] font-bold uppercase tracking-wider text-amber-300 flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5" />
                <span>Features that rely on Location:</span>
              </div>
              <ul className="text-xs text-slate-300 space-y-1.5 pl-1">
                <li className="flex items-start gap-2">
                  <span className="text-emerald-400 font-bold">✓</span>
                  <span><strong>Automatic Local Currency & Weather:</strong> Shows Tokyo, Paris, or Delhi live exchange rates automatically.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-emerald-400 font-bold">✓</span>
                  <span><strong>1-Tap Emergency SOS:</strong> Pre-loads exact police, ambulance, and consulate hotlines for your current country.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-emerald-400 font-bold">✓</span>
                  <span><strong>Smart Language Suggestion:</strong> Prompts the local spoken language when you land.</span>
                </li>
              </ul>
            </div>

            {/* Status & Feedback */}
            {stepFeedback.message && (
              <div className={`p-3 rounded-2xl text-xs font-medium mb-4 flex items-start gap-2.5 ${
                stepFeedback.type === 'success'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                  : stepFeedback.type === 'blocked'
                  ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                  : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
              }`}>
                {stepFeedback.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                ) : stepFeedback.type === 'blocked' ? (
                  <XCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                )}
                <div className="flex-1 leading-snug">{stepFeedback.message}</div>
              </div>
            )}

            {/* Buttons */}
            <div className="space-y-2.5 mt-auto">
              {permissionResults.location !== 'granted' && (
                <button
                  id="trigger-location-permission-btn"
                  onClick={handleRequestLocation}
                  disabled={isRequesting}
                  className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-white font-bold text-sm shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 transition-all active:scale-[0.98] disabled:opacity-50 cursor-pointer"
                >
                  {isRequesting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Requesting Android Permission...</span>
                    </>
                  ) : (
                    <>
                      <MapPin className="w-4 h-4" />
                      <span>Allow Location Access</span>
                    </>
                  )}
                </button>
              )}

              {stepFeedback.type === 'blocked' && (
                <button
                  onClick={openAndroidAppSettings}
                  className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-rose-300 border border-rose-500/30 text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <Settings className="w-3.5 h-3.5 text-rose-400" />
                  <span>Open Phone Settings ➔ App Permissions</span>
                </button>
              )}

              <button
                id="skip-or-next-location-btn"
                onClick={() => advanceToStep('microphone')}
                className="w-full py-2.5 px-4 rounded-xl bg-slate-800/80 hover:bg-slate-800 text-slate-300 text-xs font-bold transition-all flex items-center justify-center gap-1.5"
              >
                <span>{permissionResults.location === 'granted' ? 'Continue to Microphone' : 'Continue to Microphone (Without Location)'}</span>
                <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: MICROPHONE PERMISSION */}
        {currentStep === 'microphone' && (
          <div className="p-5 sm:p-7 flex flex-col overflow-y-auto">
            {/* Progress indicator */}
            <div className="flex items-center justify-between mb-4">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/15 border border-indigo-500/30 text-indigo-300 text-xs font-bold">
                <Mic className="w-3.5 h-3.5" />
                <span>Permission 2 of 3: Microphone</span>
              </div>
              <span className="text-[11px] font-semibold text-slate-400">Step 3 of 4</span>
            </div>

            {/* Icon Banner */}
            <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center shadow-lg shadow-indigo-500/10">
              <Volume2 className="w-8 h-8 animate-pulse" />
            </div>

            <div className="text-center mb-5">
              <h2 className="text-xl font-black text-white tracking-tight">
                Enable Microphone Access
              </h2>
              <p className="text-xs text-slate-300 mt-2 leading-relaxed max-w-sm mx-auto">
                Enable real-time voice conversations, speech recognition, and voice translation.
              </p>
            </div>

            {/* Contextual feature explanation */}
            <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-3.5 space-y-2 mb-5">
              <div className="text-[11px] font-bold uppercase tracking-wider text-indigo-300 flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5" />
                <span>Features that rely on Microphone:</span>
              </div>
              <ul className="text-xs text-slate-300 space-y-1.5 pl-1">
                <li className="flex items-start gap-2">
                  <span className="text-emerald-400 font-bold">✓</span>
                  <span><strong>Live 2-Way Voice Interpreter:</strong> Speak in Hindi, English, Spanish or any language and hear the instant translation spoken back.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-emerald-400 font-bold">✓</span>
                  <span><strong>Face-to-Face Tabletop Mode:</strong> Dual inverted microphones for natural conversation with taxi drivers, hotel desks, and locals.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-emerald-400 font-bold">✓</span>
                  <span><strong>Speech Dictation:</strong> Dictate long travel inquiries to the AI Sarathi Copilot without typing.</span>
                </li>
              </ul>
            </div>

            {/* Status & Feedback */}
            {stepFeedback.message && (
              <div className={`p-3 rounded-2xl text-xs font-medium mb-4 flex items-start gap-2.5 ${
                stepFeedback.type === 'success'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                  : stepFeedback.type === 'blocked'
                  ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                  : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
              }`}>
                {stepFeedback.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                ) : stepFeedback.type === 'blocked' ? (
                  <XCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                )}
                <div className="flex-1 leading-snug">{stepFeedback.message}</div>
              </div>
            )}

            {/* Buttons */}
            <div className="space-y-2.5 mt-auto">
              {permissionResults.microphone !== 'granted' && (
                <button
                  id="trigger-microphone-permission-btn"
                  onClick={handleRequestMicrophone}
                  disabled={isRequesting}
                  className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white font-bold text-sm shadow-lg shadow-indigo-600/20 flex items-center justify-center gap-2 transition-all active:scale-[0.98] disabled:opacity-50 cursor-pointer"
                >
                  {isRequesting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Requesting Android Permission...</span>
                    </>
                  ) : (
                    <>
                      <Mic className="w-4 h-4" />
                      <span>Allow Microphone Access</span>
                    </>
                  )}
                </button>
              )}

              {stepFeedback.type === 'blocked' && (
                <button
                  onClick={openAndroidAppSettings}
                  className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-rose-300 border border-rose-500/30 text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <Settings className="w-3.5 h-3.5 text-rose-400" />
                  <span>Open Phone Settings ➔ App Permissions</span>
                </button>
              )}

              <button
                id="skip-or-next-microphone-btn"
                onClick={() => advanceToStep('camera')}
                className="w-full py-2.5 px-4 rounded-xl bg-slate-800/80 hover:bg-slate-800 text-slate-300 text-xs font-bold transition-all flex items-center justify-center gap-1.5"
              >
                <span>{permissionResults.microphone === 'granted' ? 'Continue to Camera' : 'Continue to Camera (Without Microphone)'}</span>
                <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: CAMERA PERMISSION */}
        {currentStep === 'camera' && (
          <div className="p-5 sm:p-7 flex flex-col overflow-y-auto">
            {/* Progress indicator */}
            <div className="flex items-center justify-between mb-4">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-500/15 border border-teal-500/30 text-teal-300 text-xs font-bold">
                <Camera className="w-3.5 h-3.5" />
                <span>Permission 3 of 3: Camera</span>
              </div>
              <span className="text-[11px] font-semibold text-slate-400">Step 4 of 4</span>
            </div>

            {/* Icon Banner */}
            <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-teal-500/20 text-teal-400 border border-teal-500/30 flex items-center justify-center shadow-lg shadow-teal-500/10">
              <ScanLine className="w-8 h-8 animate-pulse" />
            </div>

            <div className="text-center mb-5">
              <h2 className="text-xl font-black text-white tracking-tight">
                Enable Camera Access
              </h2>
              <p className="text-xs text-slate-300 mt-2 leading-relaxed max-w-sm mx-auto">
                Enable live camera translation, text recognition, and translation of signs, menus, and documents.
              </p>
            </div>

            {/* Contextual feature explanation */}
            <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-3.5 space-y-2 mb-5">
              <div className="text-[11px] font-bold uppercase tracking-wider text-teal-300 flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5" />
                <span>Features that rely on Camera:</span>
              </div>
              <ul className="text-xs text-slate-300 space-y-1.5 pl-1">
                <li className="flex items-start gap-2">
                  <span className="text-emerald-400 font-bold">✓</span>
                  <span><strong>Live AR Sign Translation:</strong> Point at Tokyo subway signs, German airport notices, or Cyrillic street names.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-emerald-400 font-bold">✓</span>
                  <span><strong>Menu & OCR Scanner:</strong> Translate restaurant food menus, receipts, and flight boarding passes.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-emerald-400 font-bold">✓</span>
                  <span><strong>Photo Translation:</strong> Take photos of medical warnings, allergy ingredients, or train timetables.</span>
                </li>
              </ul>
            </div>

            {/* Status & Feedback */}
            {stepFeedback.message && (
              <div className={`p-3 rounded-2xl text-xs font-medium mb-4 flex items-start gap-2.5 ${
                stepFeedback.type === 'success'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                  : stepFeedback.type === 'blocked'
                  ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                  : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
              }`}>
                {stepFeedback.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                ) : stepFeedback.type === 'blocked' ? (
                  <XCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                )}
                <div className="flex-1 leading-snug">{stepFeedback.message}</div>
              </div>
            )}

            {/* Buttons */}
            <div className="space-y-2.5 mt-auto">
              {permissionResults.camera !== 'granted' && (
                <button
                  id="trigger-camera-permission-btn"
                  onClick={handleRequestCamera}
                  disabled={isRequesting}
                  className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-600 hover:from-teal-400 hover:to-emerald-500 text-white font-bold text-sm shadow-lg shadow-teal-500/20 flex items-center justify-center gap-2 transition-all active:scale-[0.98] disabled:opacity-50 cursor-pointer"
                >
                  {isRequesting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Requesting Android Permission...</span>
                    </>
                  ) : (
                    <>
                      <Camera className="w-4 h-4" />
                      <span>Allow Camera Access</span>
                    </>
                  )}
                </button>
              )}

              {stepFeedback.type === 'blocked' && (
                <button
                  onClick={openAndroidAppSettings}
                  className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-rose-300 border border-rose-500/30 text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <Settings className="w-3.5 h-3.5 text-rose-400" />
                  <span>Open Phone Settings ➔ App Permissions</span>
                </button>
              )}

              <button
                id="finish-onboarding-btn"
                onClick={finishOnboarding}
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-lg shadow-emerald-600/20 cursor-pointer"
              >
                <span>Complete Setup & Open Travel Guide Pro</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
