import React, { useState } from 'react';
import { 
  Settings, 
  Volume2, 
  Sparkles, 
  X, 
  BookOpen, 
  Sliders, 
  ShieldCheck, 
  Shield, 
  Mic, 
  Camera, 
  MapPin, 
  ArrowLeft, 
  User, 
  LogOut, 
  LogIn,
  Languages,
  ArrowDownUp,
  Search,
  CheckCircle2,
  Repeat,
  ExternalLink,
  Trash2,
  AlertTriangle,
  Mail,
  Loader2,
  XCircle,
  HelpCircle,
  Zap
} from 'lucide-react';
import { VoiceSettings, AuthUser, Language } from '../types';
import { SUPPORTED_LANGUAGES, AUTO_DETECT_LANGUAGE, findLanguageByCode } from '../data/languages';
import { UserGuideSection } from './UserGuideSection';
import { 
  openAndroidAppSettings, 
  requestLocationAccess, 
  requestMicrophoneAccess, 
  requestCameraAccess, 
  checkAllPermissions, 
  getSavedPermissionState,
  savePermissionState,
  PermissionStateValue 
} from '../utils/permissions';
import { AndroidSettingsGuideModal } from './AndroidSettingsGuideModal';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  voiceSettings: VoiceSettings;
  onUpdateVoiceSettings: (settings: Partial<VoiceSettings>) => void;
  onOpenPermissionsModal?: () => void;
  onRerunPopups?: () => void;
  onRerunOnboarding?: () => void;
  authUser?: AuthUser | null;

  onSignOut?: () => void;
  onDeleteAccount?: () => void;
  onSwitchToGoogle?: () => void;
  defaultUserLanguage?: Language;
  preferredTranslationLanguage?: Language;
  onChangeDefaultUserLanguage?: (language: Language) => void;
  onChangePreferredTranslationLanguage?: (language: Language) => void;
  onSetLanguagePair?: (userLanguage: Language, translationLanguage: Language) => void;
  onSwapDefaultLanguages?: () => void;
  onRequestOpenLanguageSelector?: (target: 'defaultUser' | 'preferredTranslation') => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  voiceSettings,
  onUpdateVoiceSettings,
  onOpenPermissionsModal,
  onRerunPopups,
  onRerunOnboarding,
  authUser,
  onSignOut,
  onDeleteAccount,
  onSwitchToGoogle,
  defaultUserLanguage = SUPPORTED_LANGUAGES.find(l => l.code === 'hi') || SUPPORTED_LANGUAGES[0],
  preferredTranslationLanguage = SUPPORTED_LANGUAGES.find(l => l.code === 'en') || SUPPORTED_LANGUAGES[1],
  onChangeDefaultUserLanguage,
  onChangePreferredTranslationLanguage,
  onSetLanguagePair,
  onSwapDefaultLanguages,
  onRequestOpenLanguageSelector,
}) => {
  const [activeTab, setActiveTab] = useState<'account' | 'guide' | 'voice' | 'permissions' | 'engine'>('account');
  const [isConfirmingDelete, setIsConfirmingDelete] = useState(false);

  // Dynamic permission states inside Settings
  const [permStates, setPermStates] = useState<{
    location: PermissionStateValue;
    microphone: PermissionStateValue;
    camera: PermissionStateValue;
  }>({
    location: 'prompt',
    microphone: 'prompt',
    camera: 'prompt',
  });
  const [permActionLoading, setPermActionLoading] = useState<'location' | 'microphone' | 'camera' | 'all' | null>(null);
  const [isGuideOpen, setIsGuideOpen] = useState(false);
  const [guideTargetFeature, setGuideTargetFeature] = useState<'Location' | 'Microphone' | 'Camera' | 'All'>('All');

  const refreshPerms = async () => {
    try {
      const all = await checkAllPermissions();
      const savedLoc = getSavedPermissionState('location');
      const savedMic = getSavedPermissionState('microphone');
      const savedCam = getSavedPermissionState('camera');

      setPermStates({
        location: all.location !== 'prompt' ? all.location : (savedLoc || 'prompt'),
        microphone: all.microphone !== 'prompt' ? all.microphone : (savedMic || 'prompt'),
        camera: all.camera !== 'prompt' ? all.camera : (savedCam || 'prompt'),
      });
    } catch {}
  };

  React.useEffect(() => {
    if (isOpen && activeTab === 'permissions') {
      refreshPerms();
    }
  }, [isOpen, activeTab]);

  const handleTogglePerm = async (type: 'location' | 'microphone' | 'camera' | 'all') => {
    setPermActionLoading(type);
    try {
      if (type === 'all') {
        // Run sequentially on mobile devices because Android dismisses simultaneous modals!
        try {
          const locRes = await requestLocationAccess();
          savePermissionState('location', locRes.granted ? 'granted' : 'denied');
        } catch {}

        await new Promise(r => setTimeout(r, 350));

        try {
          const micRes = await requestMicrophoneAccess();
          savePermissionState('microphone', micRes.granted ? 'granted' : 'denied');
        } catch {}

        await new Promise(r => setTimeout(r, 350));

        try {
          const camRes = await requestCameraAccess();
          savePermissionState('camera', camRes.granted ? 'granted' : 'denied');
        } catch {}
      } else if (type === 'location') {
        const res = await requestLocationAccess();
        savePermissionState('location', res.granted ? 'granted' : 'denied');
      } else if (type === 'microphone') {
        const res = await requestMicrophoneAccess();
        savePermissionState('microphone', res.granted ? 'granted' : 'denied');
      } else if (type === 'camera') {
        const res = await requestCameraAccess();
        savePermissionState('camera', res.granted ? 'granted' : 'denied');
      }
    } finally {
      await refreshPerms();
      setPermActionLoading(null);
    }
  };


  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-3 sm:p-4 select-none animate-fade-in">
      <div className="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="p-3.5 sm:p-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/95 gap-2">
          <div className="flex items-center gap-2 sm:gap-2.5 min-w-0">
            <button
              onClick={onClose}
              className="sm:hidden p-1.5 -ml-1 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
              title="Back"
              aria-label="Back"
            >
              <ArrowLeft className="w-5 h-5 text-indigo-400" />
            </button>
            <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center shrink-0">
              <Settings className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <div className="min-w-0">
              <h2 className="text-sm sm:text-base font-bold text-slate-100 truncate">Settings & Preferences</h2>
              <p className="text-[11px] sm:text-xs text-slate-400 hidden sm:block truncate">Account, audio playback, permissions & AI engine preferences</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="flex items-center gap-1.5 px-2.5 py-1 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors text-xs font-semibold shrink-0"
            title="Close (Esc)"
          >
            <span className="hidden sm:inline">Close</span>
            <kbd className="hidden sm:inline-block text-[10px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded border border-slate-700 font-mono">Esc</kbd>
            <X className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-800 bg-slate-950/60 p-1.5 gap-1 overflow-x-auto scrollbar-none">
          <button
            onClick={() => setActiveTab('guide')}
            className={`flex-1 py-2 px-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all whitespace-nowrap ${
              activeTab === 'guide'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Guide</span>
          </button>

          <button
            onClick={() => setActiveTab('account')}
            className={`flex-1 py-2 px-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all whitespace-nowrap ${
              activeTab === 'account'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>Account</span>
          </button>

          <button
            onClick={() => setActiveTab('voice')}
            className={`flex-1 py-2 px-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all whitespace-nowrap ${
              activeTab === 'voice'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Voice</span>
          </button>

          <button
            onClick={() => setActiveTab('permissions')}
            className={`flex-1 py-2 px-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all whitespace-nowrap ${
              activeTab === 'permissions'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span>Permissions</span>
          </button>

          <button
            onClick={() => setActiveTab('engine')}
            className={`flex-1 py-2 px-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all whitespace-nowrap ${
              activeTab === 'engine'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI Engine</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 space-y-5 overflow-y-auto flex-1">
          {/* USER GUIDE TAB */}
          {activeTab === 'guide' && (
            <UserGuideSection />
          )}

          {/* ACCOUNT & PROFILE TAB */}
          {activeTab === 'account' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                  Authentication & Profile
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Manage your active login session and Google Account synchronization
                </p>
              </div>

              {authUser ? (
                <div className="p-4 bg-slate-800/70 border border-slate-700/70 rounded-2xl flex flex-col gap-4">
                  <div className="flex items-center gap-3.5">
                    {authUser.avatar ? (
                      <img
                        src={authUser.avatar}
                        alt={authUser.name}
                        className="w-12 h-12 rounded-2xl object-cover ring-2 ring-indigo-500/30 shrink-0"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-12 h-12 rounded-2xl bg-indigo-600/30 text-indigo-400 flex items-center justify-center shrink-0">
                        <User className="w-6 h-6" />
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-100 text-sm truncate">{authUser.name}</span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          authUser.isGuest
                            ? 'bg-slate-700 text-slate-300 border border-slate-600'
                            : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        }`}>
                          {authUser.isGuest ? 'Guest' : 'Google Verified'}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 truncate mt-0.5">
                        {authUser.isGuest ? 'Temporary session • On-device' : authUser.email}
                      </p>
                    </div>
                  </div>

                  {authUser.isGuest && onSwitchToGoogle && (
                    <div className="p-3 bg-indigo-950/40 border border-indigo-500/20 rounded-xl flex items-center justify-between gap-2">
                      <div className="min-w-0 text-xs">
                        <p className="font-semibold text-indigo-200">Connect Google Account</p>
                        <p className="text-[11px] text-indigo-300/80">Sync your starred phrases across devices</p>
                      </div>
                      <button
                        onClick={() => {
                          onClose();
                          onSwitchToGoogle();
                        }}
                        className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-900 rounded-xl text-xs font-bold shrink-0 transition-colors shadow-sm"
                      >
                        Sign In
                      </button>
                    </div>
                  )}

                  {onSignOut && (
                    <div className="flex flex-col gap-2 pt-2 border-t border-slate-700/50">
                      <button
                        onClick={() => {
                          onClose();
                          onSignOut();
                        }}
                        className="w-full py-2.5 px-4 bg-slate-700/40 hover:bg-slate-700/70 border border-slate-600/40 text-slate-300 hover:text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2"
                      >
                        <LogOut className="w-4 h-4 text-slate-400" />
                        <span>Sign Out / Switch Account</span>
                      </button>

                      {onDeleteAccount && !isConfirmingDelete && (
                        <button
                          onClick={() => setIsConfirmingDelete(true)}
                          className="w-full py-2.5 px-4 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-rose-300 hover:text-rose-200 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2"
                        >
                          <Trash2 className="w-4 h-4 text-rose-400" />
                          <span>Delete Account & Erase All Data</span>
                        </button>
                      )}

                      {onDeleteAccount && isConfirmingDelete && (
                        <div className="p-3.5 bg-rose-950/40 border border-rose-500/50 rounded-xl text-left space-y-2.5 animate-fade-in">
                          <div className="flex items-start gap-2.5">
                            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                            <div>
                              <p className="text-xs font-bold text-rose-200">Permanently Delete Account?</p>
                              <p className="text-[11px] text-rose-300/80 mt-0.5">
                                This will permanently purge your account session, delete all translation history, clear saved travel documents, and erase device preferences immediately. This cannot be undone.
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2 pt-1">
                            <button
                              onClick={() => {
                                setIsConfirmingDelete(false);
                                onClose();
                                onDeleteAccount();
                              }}
                              className="flex-1 py-2 px-3 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold transition-colors flex items-center justify-center gap-1.5 shadow-sm"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              <span>Yes, Delete Everything</span>
                            </button>
                            <button
                              onClick={() => setIsConfirmingDelete(false)}
                              className="py-2 px-3 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg text-xs font-semibold transition-colors"
                            >
                              Cancel
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ) : (
                <div className="p-4 bg-slate-800/60 rounded-2xl border border-slate-700 text-center">
                  <p className="text-xs text-slate-400 mb-3">No active account session found.</p>
                  {onSwitchToGoogle && (
                    <button
                      onClick={() => {
                        onClose();
                        onSwitchToGoogle();
                      }}
                      className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold"
                    >
                      Go to Sign In
                    </button>
                  )}
                </div>
              )}

              {/* DEFAULT LANGUAGES & CROSS-FEATURE PREFERENCES SECTION */}
              <div className="pt-2 border-t border-slate-800/80">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center">
                      <Languages className="w-3.5 h-3.5" />
                    </div>
                    <div>
                      <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                        Default App Languages
                      </h3>
                      <p className="text-[11px] text-slate-400">
                        Default User Language & Preferred Translation Language
                      </p>
                    </div>
                  </div>

                  {onSwapDefaultLanguages && (
                    <button
                      id="account-swap-default-langs-btn"
                      onClick={onSwapDefaultLanguages}
                      className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-indigo-300 text-[11px] font-semibold border border-slate-700 active:scale-95 transition-all cursor-pointer"
                      title="Swap Default Languages"
                    >
                      <ArrowDownUp className="w-3 h-3" />
                      <span>Swap</span>
                    </button>
                  )}
                </div>

                {/* Explanation Banner */}
                <div className="p-3 bg-slate-800/40 border border-slate-700/60 rounded-2xl mb-3 text-xs text-slate-300 flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <p className="text-[11px] leading-relaxed text-slate-300">
                    These languages are automatically loaded across <span className="text-white font-semibold">Live Voice</span>, <span className="text-white font-semibold">Tabletop Face-to-Face</span>, <span className="text-white font-semibold">Camera OCR</span>, <span className="text-white font-semibold">Smart Text</span>, and <span className="text-white font-semibold">Emergency SOS</span>. You can still switch languages on the fly anytime.
                  </p>
                </div>

                {/* The Two Language Selectors */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {/* Default User Language */}
                  <div className="p-3.5 bg-slate-800/80 border border-slate-700/80 rounded-2xl flex flex-col justify-between gap-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] uppercase font-bold tracking-wider text-indigo-300 bg-indigo-950/60 px-2 py-0.5 rounded-md border border-indigo-500/30">
                        Default User Language
                      </span>
                      <span className="text-[10px] text-slate-400">You Speak</span>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="text-2xl select-none">{defaultUserLanguage.flag}</span>
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-bold text-white truncate">{defaultUserLanguage.name}</p>
                        <p className="text-xs text-slate-400 truncate">{defaultUserLanguage.nativeName}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 pt-1 border-t border-slate-700/60">
                      {/* Direct dropdown */}
                      <select
                        id="account-select-default-user-lang"
                        value={defaultUserLanguage.code}
                        onChange={(e) => {
                          const found = findLanguageByCode(e.target.value);
                          if (found && onChangeDefaultUserLanguage) {
                            onChangeDefaultUserLanguage(found);
                          }
                        }}
                        className="flex-1 bg-slate-900 border border-slate-700 text-slate-200 text-xs rounded-xl px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-indigo-500 cursor-pointer"
                      >
                        <option value="auto">✨ Auto Detect</option>
                        <optgroup label="Popular Languages">
                          {SUPPORTED_LANGUAGES.filter(l => l.isPopular).map(l => (
                            <option key={`user-${l.code}`} value={l.code}>
                              {l.flag} {l.name} ({l.nativeName})
                            </option>
                          ))}
                        </optgroup>
                        <optgroup label="All Languages (A-Z)">
                          {SUPPORTED_LANGUAGES.map(l => (
                            <option key={`user-all-${l.code}`} value={l.code}>
                              {l.flag} {l.name}
                            </option>
                          ))}
                        </optgroup>
                      </select>

                      {onRequestOpenLanguageSelector && (
                        <button
                          onClick={() => {
                            onClose();
                            onRequestOpenLanguageSelector('defaultUser');
                          }}
                          className="p-1.5 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-xl transition-colors shrink-0 cursor-pointer"
                          title="Search all 100+ languages"
                        >
                          <Search className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Preferred Translation Language */}
                  <div className="p-3.5 bg-slate-800/80 border border-slate-700/80 rounded-2xl flex flex-col justify-between gap-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] uppercase font-bold tracking-wider text-teal-300 bg-teal-950/60 px-2 py-0.5 rounded-md border border-teal-500/30">
                        Preferred Translation Language
                      </span>
                      <span className="text-[10px] text-slate-400">Translate To</span>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="text-2xl select-none">{preferredTranslationLanguage.flag}</span>
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-bold text-white truncate">{preferredTranslationLanguage.name}</p>
                        <p className="text-xs text-slate-400 truncate">{preferredTranslationLanguage.nativeName}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 pt-1 border-t border-slate-700/60">
                      {/* Direct dropdown */}
                      <select
                        id="account-select-preferred-trans-lang"
                        value={preferredTranslationLanguage.code}
                        onChange={(e) => {
                          const found = findLanguageByCode(e.target.value);
                          if (found && onChangePreferredTranslationLanguage) {
                            onChangePreferredTranslationLanguage(found);
                          }
                        }}
                        className="flex-1 bg-slate-900 border border-slate-700 text-slate-200 text-xs rounded-xl px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-teal-500 cursor-pointer"
                      >
                        <optgroup label="Popular Languages">
                          {SUPPORTED_LANGUAGES.filter(l => l.isPopular && l.code !== 'auto').map(l => (
                            <option key={`target-${l.code}`} value={l.code}>
                              {l.flag} {l.name} ({l.nativeName})
                            </option>
                          ))}
                        </optgroup>
                        <optgroup label="All Languages (A-Z)">
                          {SUPPORTED_LANGUAGES.filter(l => l.code !== 'auto').map(l => (
                            <option key={`target-all-${l.code}`} value={l.code}>
                              {l.flag} {l.name}
                            </option>
                          ))}
                        </optgroup>
                      </select>

                      {onRequestOpenLanguageSelector && (
                        <button
                          onClick={() => {
                            onClose();
                            onRequestOpenLanguageSelector('preferredTranslation');
                          }}
                          className="p-1.5 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-xl transition-colors shrink-0 cursor-pointer"
                          title="Search all 100+ languages"
                        >
                          <Search className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                {/* 1-Tap Popular Traveler Presets */}
                <div className="mt-3">
                  <p className="text-[10px] uppercase font-bold tracking-wider text-slate-400 mb-1.5">
                    1-Tap Traveler Presets
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {[
                      { user: 'en', trans: 'hi', label: 'English ⇄ Hindi' },
                      { user: 'kn', trans: 'en', label: 'Kannada ⇄ English' },
                      { user: 'hi', trans: 'en', label: 'Hindi ⇄ English' },
                      { user: 'en', trans: 'es', label: 'English ⇄ Spanish' },
                      { user: 'te', trans: 'en', label: 'Telugu ⇄ English' },
                      { user: 'ta', trans: 'en', label: 'Tamil ⇄ English' },
                      { user: 'en', trans: 'ja', label: 'English ⇄ Japanese' },
                      { user: 'en', trans: 'fr', label: 'English ⇄ French' },
                      { user: 'auto', trans: 'en', label: 'Auto Detect ⇄ English' },
                    ].map((preset) => {
                      const isCurrent =
                        defaultUserLanguage.code === preset.user &&
                        preferredTranslationLanguage.code === preset.trans;
                      return (
                        <button
                          key={`${preset.user}-${preset.trans}`}
                          onClick={() => {
                            const u = findLanguageByCode(preset.user);
                            const t = findLanguageByCode(preset.trans);
                            if (u && t) {
                              if (onSetLanguagePair) {
                                onSetLanguagePair(u, t);
                              } else {
                                if (onChangeDefaultUserLanguage) onChangeDefaultUserLanguage(u);
                                if (onChangePreferredTranslationLanguage) onChangePreferredTranslationLanguage(t);
                              }
                            }
                          }}
                          className={`text-[11px] px-2.5 py-1 rounded-xl border transition-all cursor-pointer ${
                            isCurrent
                              ? 'bg-indigo-600/30 text-indigo-200 border-indigo-500 font-bold'
                              : 'bg-slate-800/60 hover:bg-slate-800 text-slate-300 border-slate-700 hover:border-slate-600'
                          }`}
                        >
                          {preset.label}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Developer Support & Legal Compliance Card */}
              <div className="p-3.5 bg-slate-800/50 border border-slate-700/60 rounded-2xl flex flex-col gap-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-indigo-400" />
                    <span className="text-xs font-bold text-slate-200">Developer & App Support</span>
                  </div>
                  <a
                    href="mailto:piappsupport@gmail.com?subject=Travel%20Guide%20Pro%20App%20Support"
                    className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 transition-colors"
                  >
                    piappsupport@gmail.com
                  </a>
                </div>
                <div className="flex items-center justify-between pt-2 border-t border-slate-750 text-[11px] text-slate-400">
                  <a
                    href="/privacy.html"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-slate-200 flex items-center gap-1 transition-colors"
                  >
                    <span>Privacy Policy</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                  <a
                    href="/delete-account.html"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-slate-200 flex items-center gap-1 transition-colors"
                  >
                    <span>Data & Account Deletion</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            </div>
          )}


          {/* PERMISSIONS TAB */}
          {activeTab === 'permissions' && (
            <div className="space-y-3.5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                <div>
                  <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                    Device Hardware & Permissions
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Tap below to immediately trigger Android system permission prompts
                  </p>
                </div>
                {(permStates.location !== 'granted' || permStates.microphone !== 'granted' || permStates.camera !== 'granted') && (
                  <button
                    id="settings-allow-all-btn"
                    onClick={() => handleTogglePerm('all')}
                    disabled={permActionLoading !== null}
                    className="py-1.5 px-3 bg-gradient-to-r from-indigo-600 via-teal-500 to-amber-500 hover:brightness-110 text-white rounded-xl text-xs font-black shadow-md flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-95 shrink-0"
                  >
                    {permActionLoading === 'all' ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        <span>Requesting...</span>
                      </>
                    ) : (
                      <>
                        <Zap className="w-3.5 h-3.5 fill-amber-300 text-amber-300" />
                        <span>Allow All 3 Accesses</span>
                      </>
                    )}
                  </button>
                )}
              </div>

              {/* 1. Location Access */}
              <div className="p-3.5 bg-slate-800/70 rounded-2xl border border-slate-700/80 space-y-2">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                      permStates.location === 'granted'
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                        : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                    }`}>
                      <MapPin className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-100">Location Access</div>
                      <div className="text-[11px] text-slate-400">Destination, local currency & emergency numbers</div>
                    </div>
                  </div>

                  <button
                    id="settings-allow-location-btn"
                    onClick={() => handleTogglePerm('location')}
                    disabled={permActionLoading !== null}
                    className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 cursor-pointer shrink-0 ${
                      permStates.location === 'granted'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30'
                        : 'bg-amber-600 hover:bg-amber-500 text-white shadow-md shadow-amber-600/30'
                    }`}
                  >
                    {permActionLoading === 'location' ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : permStates.location === 'granted' ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Allowed</span>
                      </>
                    ) : (
                      <>
                        <MapPin className="w-3.5 h-3.5" />
                        <span>Allow Location</span>
                      </>
                    )}
                  </button>
                </div>
                {permStates.location === 'denied' && (
                  <p className="text-[11px] text-rose-300 bg-rose-950/40 border border-rose-800/40 p-2 rounded-xl">
                    Location permission was dismissed or blocked in Android. Tap "Open App Settings" below to allow.
                  </p>
                )}
              </div>

              {/* 2. Microphone Access */}
              <div className="p-3.5 bg-slate-800/70 rounded-2xl border border-slate-700/80 space-y-2">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                      permStates.microphone === 'granted'
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                        : 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/30'
                    }`}>
                      <Mic className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-100">Microphone Access</div>
                      <div className="text-[11px] text-slate-400">Live 2-way voice interpreter & dictation</div>
                    </div>
                  </div>

                  <button
                    id="settings-allow-mic-btn"
                    onClick={() => handleTogglePerm('microphone')}
                    disabled={permActionLoading !== null}
                    className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 cursor-pointer shrink-0 ${
                      permStates.microphone === 'granted'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30'
                        : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/30'
                    }`}
                  >
                    {permActionLoading === 'microphone' ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : permStates.microphone === 'granted' ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Allowed</span>
                      </>
                    ) : (
                      <>
                        <Mic className="w-3.5 h-3.5" />
                        <span>Allow Mic</span>
                      </>
                    )}
                  </button>
                </div>
                {permStates.microphone === 'denied' && (
                  <p className="text-[11px] text-rose-300 bg-rose-950/40 border border-rose-800/40 p-2 rounded-xl">
                    Microphone is blocked. Tap "Open App Settings" below to enable voice translation.
                  </p>
                )}
              </div>

              {/* 3. Camera Access */}
              <div className="p-3.5 bg-slate-800/70 rounded-2xl border border-slate-700/80 space-y-2">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                      permStates.camera === 'granted'
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                        : 'bg-teal-500/20 text-teal-400 border border-teal-500/30'
                    }`}>
                      <Camera className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-100">Camera & OCR Access</div>
                      <div className="text-[11px] text-slate-400">Street sign, menu, and notice scanner</div>
                    </div>
                  </div>

                  <button
                    id="settings-allow-camera-btn"
                    onClick={() => handleTogglePerm('camera')}
                    disabled={permActionLoading !== null}
                    className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 cursor-pointer shrink-0 ${
                      permStates.camera === 'granted'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30'
                        : 'bg-teal-600 hover:bg-teal-500 text-white shadow-md shadow-teal-600/30'
                    }`}
                  >
                    {permActionLoading === 'camera' ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : permStates.camera === 'granted' ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Allowed</span>
                      </>
                    ) : (
                      <>
                        <Camera className="w-3.5 h-3.5" />
                        <span>Allow Camera</span>
                      </>
                    )}
                  </button>
                </div>
                {permStates.camera === 'denied' && (
                  <p className="text-[11px] text-rose-300 bg-rose-950/40 border border-rose-800/40 p-2 rounded-xl">
                    Camera is blocked. Tap "Open App Settings" below to enable camera translation.
                  </p>
                )}
              </div>

              {/* Android Settings Guidance Card */}
              <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="text-[11px] text-slate-300 leading-snug">
                  <div className="font-bold text-slate-100 flex items-center gap-1.5 mb-0.5">
                    <Settings className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Android Device Settings</span>
                  </div>
                  If blocked, toggle permissions under Phone Settings ➔ Apps ➔ Travel Guide Pro.
                </div>
                <button
                  onClick={() => {
                    setGuideTargetFeature('All');
                    setIsGuideOpen(true);
                  }}
                  className="w-full sm:w-auto px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-indigo-300 border border-slate-700 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer shrink-0"
                >
                  <Settings className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Settings Guide</span>
                </button>
              </div>

              <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-2xl text-[11px] text-slate-400 leading-relaxed">
                💡 <strong>Zero Background Usage</strong>: Travel Guide Pro never records audio or tracks your location in the background. Hardware streams are only accessed while actively translating.
              </div>

              <div className="pt-2 px-1 flex items-center justify-between text-xs text-slate-400 border-t border-slate-800/80">
                <span>Privacy & Data Policy</span>
                <a
                  href="/privacy"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-indigo-400 hover:text-indigo-300 font-medium inline-flex items-center gap-1 underline transition-colors"
                >
                  View Privacy Policy
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
          )}

          {/* VOICE SETTINGS TAB */}
          {activeTab === 'voice' && (
            <div className="space-y-5">
              {/* Voice Gender Selection */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Volume2 className="w-3.5 h-3.5 text-indigo-400" />
                  Voice Tone & Gender
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'neutral', label: 'Adaptive' },
                    { id: 'female', label: 'Natural Female' },
                    { id: 'male', label: 'Natural Male' },
                  ].map(g => (
                    <button
                      key={g.id}
                      onClick={() => onUpdateVoiceSettings({ voiceGender: g.id as any })}
                      className={`py-2 px-2 rounded-xl text-xs font-semibold border transition-all ${
                        voiceSettings.voiceGender === g.id
                          ? 'bg-indigo-600 border-indigo-500 text-white shadow-md'
                          : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      {g.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Speech Rate Slider */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-slate-300">
                  <span>Speech Speed Rate</span>
                  <span className="text-indigo-400 font-mono">{voiceSettings.speechRate}x</span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="1.5"
                  step="0.1"
                  value={voiceSettings.speechRate}
                  onChange={e => onUpdateVoiceSettings({ speechRate: parseFloat(e.target.value) })}
                  className="w-full accent-indigo-500"
                />
                <div className="flex justify-between text-[10px] text-slate-500">
                  <span>0.5x (Slow - Easy Listening)</span>
                  <span>1.0x (Normal)</span>
                  <span>1.5x (Fast)</span>
                </div>
              </div>

              {/* Pitch Slider */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-slate-300">
                  <span>Voice Pitch</span>
                  <span className="text-indigo-400 font-mono">{voiceSettings.pitch}x</span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="1.5"
                  step="0.1"
                  value={voiceSettings.pitch}
                  onChange={e => onUpdateVoiceSettings({ pitch: parseFloat(e.target.value) })}
                  className="w-full accent-indigo-500"
                />
              </div>

              {/* Volume Slider */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-slate-300">
                  <span>Audio Volume</span>
                  <span className="text-indigo-400 font-mono">{Math.round(voiceSettings.volume * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0.2"
                  max="1.0"
                  step="0.05"
                  value={voiceSettings.volume}
                  onChange={e => onUpdateVoiceSettings({ volume: parseFloat(e.target.value) })}
                  className="w-full accent-indigo-500"
                />
              </div>
            </div>
          )}

          {/* AI ENGINE TAB */}
          {activeTab === 'engine' && (
            <div className="space-y-4">
              <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                Smart Context & Etiquette Modules
              </h3>

              {/* Cultural Nuance Tip Toggle */}
              <div className="flex items-center justify-between p-3.5 bg-slate-800/60 rounded-2xl border border-slate-700/60">
                <div>
                  <div className="text-xs font-semibold text-slate-200">Cultural Etiquette Notes</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Provides local politeness advice, honorific guidance, and gesture awareness
                  </div>
                </div>
                <span className="text-xs font-bold text-emerald-400 shrink-0 ml-3">Active</span>
              </div>

              {/* Phonetic Pronunciation Guide */}
              <div className="flex items-center justify-between p-3.5 bg-slate-800/60 rounded-2xl border border-slate-700/60">
                <div>
                  <div className="text-xs font-semibold text-slate-200">Romanized Phonetic Spelling</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Transliterates non-Latin scripts (Japanese, Korean, Chinese, Hindi, Arabic) into Latin letters
                  </div>
                </div>
                <span className="text-xs font-bold text-emerald-400 shrink-0 ml-3">Active</span>
              </div>

              {/* Offline Pack Integration */}
              <div className="flex items-center justify-between p-3.5 bg-slate-800/60 rounded-2xl border border-slate-700/60">
                <div>
                  <div className="text-xs font-semibold text-slate-200">Offline Fallback Engine</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Automatically switches to pre-cached dictionaries and emergency packs without internet
                  </div>
                </div>
                <span className="text-xs font-bold text-emerald-400 shrink-0 ml-3">Active</span>
              </div>

              {/* AI Engine attribution */}
              <div className="p-3 bg-indigo-950/30 border border-indigo-500/20 rounded-2xl flex items-center gap-2.5 text-xs text-indigo-300 mt-3">
                <Sparkles className="w-4 h-4 text-indigo-400 shrink-0" />
                <span>Powered by Google Gemini 2.5 Flash for contextual translation, OCR visual recognition & etiquette analysis.</span>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/40 flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Ready for real-time travel & conversation</span>
          </div>
          <button
            onClick={onClose}
            className="py-2 px-5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold shadow-md transition-all active:scale-95 cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>

      <AndroidSettingsGuideModal
        isOpen={isGuideOpen}
        onClose={() => setIsGuideOpen(false)}
        onVerify={refreshPerms}
        targetFeature={guideTargetFeature}
      />
    </div>
  );
};

