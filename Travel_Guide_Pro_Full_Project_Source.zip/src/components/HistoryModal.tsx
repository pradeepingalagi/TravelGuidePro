import React, { useState, useMemo } from 'react';
import { History, Search, Star, Trash2, Volume2, Copy, Check, X, Download, ArrowLeft } from 'lucide-react';
import { TranslationRecord } from '../types';
import { speakText } from '../utils/speech';

interface HistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  history: TranslationRecord[];
  onClearHistory: () => void;
  onToggleStar: (id: string) => void;
}

export const HistoryModal: React.FC<HistoryModalProps> = ({
  isOpen,
  onClose,
  history,
  onClearHistory,
  onToggleStar,
}) => {
  const [search, setSearch] = useState('');
  const [filterStarredOnly, setFilterStarredOnly] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filtered = useMemo(() => {
    return history.filter(item => {
      if (filterStarredOnly && !item.starred) return false;
      if (!search.trim()) return true;
      const q = search.toLowerCase();
      return (
        item.originalText.toLowerCase().includes(q) ||
        item.translatedText.toLowerCase().includes(q) ||
        item.sourceLang.toLowerCase().includes(q) ||
        item.targetLang.toLowerCase().includes(q)
      );
    });
  }, [history, search, filterStarredOnly]);

  if (!isOpen) return null;

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1800);
  };

  const handleExport = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(history, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `sarathi_history_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-3 sm:p-4 select-none animate-fade-in">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl flex flex-col max-h-[85vh] overflow-hidden">
        {/* Header */}
        <div className="p-3.5 sm:p-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/95 gap-2">
          <div className="flex items-center gap-2 sm:gap-2.5 min-w-0">
            <button
              onClick={onClose}
              className="sm:hidden p-1.5 -ml-1 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors shrink-0"
              title="Back"
              aria-label="Back"
            >
              <ArrowLeft className="w-5 h-5 text-indigo-400" />
            </button>
            <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center shrink-0">
              <History className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <div className="min-w-0">
              <h2 className="text-sm sm:text-base font-bold text-slate-100 truncate">Translation History</h2>
              <p className="text-[11px] sm:text-xs text-slate-400 hidden sm:block truncate">Past conversations & saved bookmarks</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="flex items-center gap-1.5 px-2.5 py-1 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors text-xs font-semibold shrink-0"
            title="Close (Esc)"
          >
            <span className="hidden sm:inline">Close</span>
            <kbd className="hidden sm:inline-block text-[10px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded border border-slate-700 font-mono">Esc</kbd>
            <X className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>
        </div>

        {/* Search & Filter Bar */}
        <div className="p-3 bg-slate-950/60 border-b border-slate-800 space-y-2.5">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search past translations..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-9 pr-4 py-2 text-xs text-slate-100 placeholder-slate-400 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="flex items-center justify-between text-xs">
            <button
              onClick={() => setFilterStarredOnly(!filterStarredOnly)}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-full font-semibold border transition-colors ${
                filterStarredOnly
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                  : 'bg-slate-800 text-slate-400 border-slate-700'
              }`}
            >
              <Star className={`w-3.5 h-3.5 ${filterStarredOnly ? 'fill-amber-400 text-amber-400' : ''}`} />
              <span>Starred only</span>
            </button>

            <div className="flex items-center gap-2">
              {history.length > 0 && (
                <>
                  <button
                    onClick={handleExport}
                    className="flex items-center gap-1 text-slate-400 hover:text-slate-200"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Export</span>
                  </button>
                  <button
                    onClick={onClearHistory}
                    className="flex items-center gap-1 text-red-400 hover:text-red-300"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Clear</span>
                  </button>
                </>
              )}
            </div>
          </div>
        </div>

        {/* History List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {filtered.length === 0 ? (
            <div className="text-center py-12 text-slate-400 text-xs">
              No translation records found.
            </div>
          ) : (
            filtered.map(item => (
              <div
                key={item.id}
                className="bg-slate-800/70 border border-slate-700/70 rounded-2xl p-3.5 space-y-2 hover:border-slate-600 transition-all"
              >
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <div className="flex items-center gap-1 font-semibold text-slate-300">
                    <span>{item.sourceLang}</span>
                    <span className="text-slate-500">→</span>
                    <span className="text-indigo-400">{item.targetLang}</span>
                    {item.category && (
                      <span className="text-[10px] bg-slate-700/60 px-1.5 py-0.2 rounded font-normal text-slate-300">
                        {item.category}
                      </span>
                    )}
                  </div>
                  <span className="text-[11px] text-slate-500">
                    {new Date(item.timestamp).toLocaleString([], {
                      month: 'short',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>

                <div className="space-y-1 text-sm">
                  <div className="text-slate-400 text-xs">"{item.originalText}"</div>
                  <div className="text-slate-100 font-bold">"{item.translatedText}"</div>
                  {item.pronunciation && (
                    <div className="text-xs text-indigo-300/80 italic font-mono">
                      🗣 {item.pronunciation}
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-end gap-1.5 pt-2 border-t border-slate-700/40">
                  <button
                    onClick={() => speakText(item.translatedText, item.targetLangCode)}
                    className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-700"
                    title="Listen"
                  >
                    <Volume2 className="w-3.5 h-3.5 text-indigo-400" />
                  </button>

                  <button
                    onClick={() => handleCopy(item.id, item.translatedText)}
                    className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-700"
                    title="Copy"
                  >
                    {copiedId === item.id ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>

                  <button
                    onClick={() => onToggleStar(item.id)}
                    className={`p-1.5 rounded-lg transition-colors ${
                      item.starred ? 'text-amber-400' : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <Star className={`w-3.5 h-3.5 ${item.starred ? 'fill-amber-400' : ''}`} />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
