import React, { useState } from 'react';
import { Download, Check, Trash2, HardDrive, Wifi, WifiOff, X, Sparkles, ArrowLeft } from 'lucide-react';
import { OfflineLanguagePack } from '../types';

interface OfflinePacksModalProps {
  isOpen: boolean;
  onClose: () => void;
  isOffline: boolean;
  onToggleOfflineMode: () => void;
}

const INITIAL_PACKS: OfflineLanguagePack[] = [
  { code: 'hi', name: 'Hindi (हिन्दी)', flag: '🇮🇳', sizeMB: 48, isDownloaded: true, downloadDate: 'Pre-installed' },
  { code: 'kn', name: 'Kannada (ಕನ್ನಡ)', flag: '🇮🇳', sizeMB: 45, isDownloaded: true, downloadDate: 'Pre-installed' },
  { code: 'ta', name: 'Tamil (தமிழ்)', flag: '🇮🇳', sizeMB: 46, isDownloaded: true, downloadDate: 'Pre-installed' },
  { code: 'te', name: 'Telugu (తెలుగు)', flag: '🇮🇳', sizeMB: 47, isDownloaded: false },
  { code: 'bn', name: 'Bengali (বাংলা)', flag: '🇮🇳', sizeMB: 49, isDownloaded: false },
  { code: 'mr', name: 'Marathi (मराठी)', flag: '🇮🇳', sizeMB: 46, isDownloaded: false },
  { code: 'gu', name: 'Gujarati (ગુજરાતી)', flag: '🇮🇳', sizeMB: 44, isDownloaded: false },
  { code: 'ml', name: 'Malayalam (മലയാളം)', flag: '🇮🇳', sizeMB: 46, isDownloaded: false },
  { code: 'pa', name: 'Punjabi (ਪੰਜਾਬੀ)', flag: '🇮🇳', sizeMB: 43, isDownloaded: false },
  { code: 'es', name: 'Spanish (Español)', flag: '🇪🇸', sizeMB: 44, isDownloaded: true, downloadDate: 'Pre-installed' },
  { code: 'fr', name: 'French (Français)', flag: '🇫🇷', sizeMB: 42, isDownloaded: true, downloadDate: 'Pre-installed' },
  { code: 'ja', name: 'Japanese (日本語)', flag: '🇯🇵', sizeMB: 56, isDownloaded: false },
  { code: 'de', name: 'German (Deutsch)', flag: '🇩🇪', sizeMB: 45, isDownloaded: false },
  { code: 'zh', name: 'Chinese (中文)', flag: '🇨🇳', sizeMB: 62, isDownloaded: false },
  { code: 'ar', name: 'Arabic (العربية)', flag: '🇸🇦', sizeMB: 51, isDownloaded: false },
  { code: 'pt', name: 'Portuguese (Português)', flag: '🇧🇷', sizeMB: 43, isDownloaded: false },
  { code: 'ru', name: 'Russian (Русский)', flag: '🇷🇺', sizeMB: 49, isDownloaded: false },
];

export const OfflinePacksModal: React.FC<OfflinePacksModalProps> = ({
  isOpen,
  onClose,
  isOffline,
  onToggleOfflineMode,
}) => {
  const [packs, setPacks] = useState<OfflineLanguagePack[]>(INITIAL_PACKS);
  const [downloadingCode, setDownloadingCode] = useState<string | null>(null);

  if (!isOpen) return null;

  const totalUsedStorage = packs
    .filter(p => p.isDownloaded)
    .reduce((acc, curr) => acc + curr.sizeMB, 0);

  const handleDownload = (code: string) => {
    setDownloadingCode(code);
    setTimeout(() => {
      setPacks(prev =>
        prev.map(p =>
          p.code === code
            ? { ...p, isDownloaded: true, downloadDate: new Date().toLocaleDateString() }
            : p
        )
      );
      setDownloadingCode(null);
    }, 1500);
  };

  const handleDelete = (code: string) => {
    setPacks(prev =>
      prev.map(p => (p.code === code ? { ...p, isDownloaded: false } : p))
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-3 sm:p-4 select-none animate-fade-in">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl flex flex-col max-h-[85vh] overflow-hidden">
        {/* Header */}
        <div className="p-3.5 sm:p-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/95 gap-2">
          <div className="flex items-center gap-2 sm:gap-2.5 min-w-0">
            <button
              onClick={onClose}
              className="sm:hidden p-1.5 -ml-1 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors shrink-0"
              title="Back"
              aria-label="Back"
            >
              <ArrowLeft className="w-5 h-5 text-emerald-400" />
            </button>
            <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center shrink-0">
              <Download className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <div className="min-w-0">
              <h2 className="text-sm sm:text-base font-bold text-slate-100 truncate">Offline Language Packs</h2>
              <p className="text-[11px] sm:text-xs text-slate-400 hidden sm:block truncate">Translate without internet connection</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="flex items-center gap-1.5 px-2.5 py-1 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors text-xs font-semibold shrink-0"
            title="Close (Esc)"
          >
            <span className="hidden sm:inline">Close</span>
            <kbd className="hidden sm:inline-block text-[10px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded border border-slate-700 font-mono">Esc</kbd>
            <X className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>
        </div>

        {/* Offline Mode Simulation Switch */}
        <div className="p-4 bg-slate-950/60 border-b border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {isOffline ? <WifiOff className="w-4 h-4 text-amber-400" /> : <Wifi className="w-4 h-4 text-emerald-400" />}
              <div>
                <div className="text-xs font-bold text-slate-200">
                  {isOffline ? 'Offline Mode Active' : 'Online Mode (Cloud AI)'}
                </div>
                <div className="text-[11px] text-slate-400">
                  {isOffline ? 'Simulating offline airplane mode' : 'Using real-time Gemini server translation'}
                </div>
              </div>
            </div>
            <button
              onClick={onToggleOfflineMode}
              className={`px-3 py-1 rounded-full text-xs font-bold transition-all ${
                isOffline
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700'
              }`}
            >
              {isOffline ? 'Disable Offline' : 'Test Offline'}
            </button>
          </div>

          {/* Storage Bar */}
          <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
            <span className="flex items-center gap-1">
              <HardDrive className="w-3.5 h-3.5 text-indigo-400" />
              <span>Offline Storage Used:</span>
            </span>
            <span className="font-semibold text-slate-200">{totalUsedStorage} MB / 512 MB</span>
          </div>
        </div>

        {/* Pack List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
          {packs.map(pack => {
            const isDownloading = downloadingCode === pack.code;

            return (
              <div
                key={pack.code}
                className="bg-slate-800/60 border border-slate-700/60 rounded-2xl p-3.5 flex items-center justify-between gap-3 hover:border-slate-600 transition-all"
              >
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{pack.flag}</span>
                  <div>
                    <div className="text-sm font-bold text-slate-100 flex items-center gap-1.5">
                      <span>{pack.name}</span>
                      {pack.isDownloaded && (
                        <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.2 rounded font-medium">
                          Downloaded
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-slate-400">
                      {pack.sizeMB} MB • {pack.downloadDate || 'Not downloaded'}
                    </div>
                  </div>
                </div>

                <div>
                  {pack.isDownloaded ? (
                    <button
                      onClick={() => handleDelete(pack.code)}
                      className="p-2 text-slate-400 hover:text-red-400 hover:bg-slate-700 rounded-xl transition-colors"
                      title="Remove pack"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  ) : (
                    <button
                      onClick={() => handleDownload(pack.code)}
                      disabled={isDownloading}
                      className="flex items-center gap-1 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-sm transition-all active:scale-95 disabled:opacity-50"
                    >
                      {isDownloading ? (
                        <span className="animate-spin text-xs">⏳</span>
                      ) : (
                        <Download className="w-3.5 h-3.5" />
                      )}
                      <span>{isDownloading ? 'Installing...' : 'Download'}</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
