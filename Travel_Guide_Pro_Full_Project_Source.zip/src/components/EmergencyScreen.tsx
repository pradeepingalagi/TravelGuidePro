import React, { useState, useEffect } from 'react';
import { 
  AlertTriangle, 
  HeartPulse, 
  Flame, 
  ShieldAlert, 
  HelpCircle, 
  Volume2, 
  Copy, 
  Share2, 
  Maximize2, 
  PhoneCall, 
  Square, 
  RotateCw, 
  Check, 
  X, 
  WifiOff, 
  Radio, 
  BellRing,
  Globe,
  Loader2,
  ArrowLeft
} from 'lucide-react';
import { Language, EmergencyPhrase, VoiceSettings } from '../types';
import { EMERGENCY_PHRASES } from '../data/emergencyPhrases';
import { SUPPORTED_LANGUAGES } from '../data/languages';
import { speakText, stopSpeaking } from '../utils/speech';
import { translateTextApi } from '../services/translationService';

interface EmergencyScreenProps {
  currentLanguage: Language;
  onSelectLanguage?: (language: Language) => void;
  onOpenLanguageSelector: () => void;
  voiceSettings: VoiceSettings;
  onClose: () => void;
}

// Top emergency languages for quick 1-tap switching in India & globally
const QUICK_EMERGENCY_LANG_CODES = ['kn', 'hi', 'en', 'te', 'ta', 'mr', 'bn', 'gu', 'ml', 'es', 'ar', 'fr'];

export const EmergencyScreen: React.FC<EmergencyScreenProps> = ({
  currentLanguage,
  onSelectLanguage,
  onOpenLanguageSelector,
  voiceSettings,
  onClose,
}) => {
  const [activeCategory, setActiveCategory] = useState<'all' | 'medical' | 'accident' | 'police' | 'general'>('all');
  const [fullscreenPhrase, setFullscreenPhrase] = useState<{
    phrase: EmergencyPhrase;
    translation: { text: string; phonetic?: string };
  } | null>(null);
  const [isBroadcastingAudio, setIsBroadcastingAudio] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [showCallConfirmModal, setShowCallConfirmModal] = useState<string | null>(null);
  const [dynamicTranslations, setDynamicTranslations] = useState<Record<string, { text: string; phonetic?: string }>>({});
  const [isTranslatingDynamically, setIsTranslatingDynamically] = useState(false);

  const langCode = currentLanguage.code === 'auto' ? 'hi' : currentLanguage.code;

  // Filter phrases based on category
  const filteredPhrases = EMERGENCY_PHRASES.filter(
    p => activeCategory === 'all' || p.category === activeCategory
  );

  // Quick emergency language objects
  const quickLanguages = QUICK_EMERGENCY_LANG_CODES.map(code => 
    SUPPORTED_LANGUAGES.find(l => l.code === code)
  ).filter(Boolean) as Language[];

  // Dynamic fallback translation if the user picked a language not in the static map
  useEffect(() => {
    // If language is English or already has static translation in majority of phrases, no dynamic fetch needed
    if (langCode === 'en') return;

    const missingPhrases = EMERGENCY_PHRASES.filter(p => !p.translations[langCode] && !dynamicTranslations[`${langCode}_${p.id}`]);
    if (missingPhrases.length === 0) return;

    let isMounted = true;
    setIsTranslatingDynamically(true);

    const translateMissing = async () => {
      try {
        const newTranslations: Record<string, { text: string; phonetic?: string }> = {};
        // Translate missing phrases in parallel batch
        await Promise.all(
          missingPhrases.slice(0, 10).map(async (phrase) => {
            const res = await translateTextApi({
              text: phrase.englishText,
              sourceLang: 'English',
              targetLang: currentLanguage.name,
              context: 'Emergency safety phrase',
            });
            if (res.translatedText) {
              newTranslations[`${langCode}_${phrase.id}`] = {
                text: res.translatedText,
                phonetic: res.pronunciation || undefined,
              };
            }
          })
        );
        if (isMounted) {
          setDynamicTranslations(prev => ({ ...prev, ...newTranslations }));
          setIsTranslatingDynamically(false);
        }
      } catch (err) {
        if (isMounted) setIsTranslatingDynamically(false);
      }
    };

    translateMissing();

    return () => {
      isMounted = false;
    };
  }, [langCode, currentLanguage.name]);

  // Keep fullscreen emergency card in sync if user changes language while open
  useEffect(() => {
    if (fullscreenPhrase) {
      const updatedTrans = getTranslationForPhrase(fullscreenPhrase.phrase);
      setFullscreenPhrase(prev => (prev ? { ...prev, translation: updatedTrans } : null));
    }
  }, [langCode, dynamicTranslations]);

  const getTranslationForPhrase = (phrase: EmergencyPhrase): { text: string; phonetic?: string } => {
    // 1. Direct language code match in pre-cached phrasebook
    if (phrase.translations[langCode]) {
      return phrase.translations[langCode];
    }
    // 2. Dynamic translation cache
    if (dynamicTranslations[`${langCode}_${phrase.id}`]) {
      return dynamicTranslations[`${langCode}_${phrase.id}`];
    }
    // 3. English text if English selected or fallback
    if (langCode === 'en') {
      return { text: phrase.englishText, phonetic: phrase.englishText };
    }
    // 4. Default to phrase English text rather than wrongly showing Hindi for Kannada/Telugu/etc.
    return { text: phrase.englishText, phonetic: phrase.englishText };
  };

  const playEmergencyAudio = async (text: string, repeat: boolean = false) => {
    setIsBroadcastingAudio(true);
    const speechCode = currentLanguage.code === 'auto' ? 'hi-IN' : currentLanguage.speechCode;

    await speakText(
      text,
      speechCode,
      {
        speechRate: 0.9,
        volume: 1.0,
        pitch: 1.05,
      },
      () => setIsBroadcastingAudio(true),
      () => {
        setIsBroadcastingAudio(false);
        if (repeat) {
          setTimeout(() => playEmergencyAudio(text, false), 1500);
        }
      },
      () => setIsBroadcastingAudio(false)
    );
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1800);
  };

  const handleShare = async (text: string) => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: '🚨 EMERGENCY TRANSLATION',
          text: `EMERGENCY ASSISTANCE NEEDED:\n"${text}"`,
        });
      } catch (err) {}
    } else {
      handleCopy('share', text);
    }
  };


  return (
    <div className="absolute inset-0 z-50 bg-slate-950 flex flex-col justify-between overflow-y-auto select-none animate-fade-in text-white">
      {/* Top Warning Banner & Controls */}
      <div className="bg-gradient-to-r from-red-950 via-rose-900 to-red-950 border-b border-red-500/50 p-3 sm:p-4 shadow-xl">
        <div className="flex items-center justify-between max-w-4xl mx-auto gap-2">
          <div className="flex items-center gap-2 sm:gap-3 min-w-0">
            {/* Prominent Back Option for Laptops, Tabs, Computers, and Mobile */}
            <button
              id="emergency-back-btn"
              onClick={onClose}
              className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl bg-black/50 hover:bg-black/70 text-white border border-red-400/40 hover:border-red-300 text-xs font-bold transition-all shrink-0 active:scale-95 shadow-sm"
              title="Back to Dashboard (Esc)"
              aria-label="Back to Dashboard"
            >
              <ArrowLeft className="w-4 h-4 text-red-300" />
              <span className="hidden sm:inline">Back to Dashboard</span>
              <span className="sm:hidden">Back</span>
              <kbd className="hidden md:inline-block text-[10px] bg-black/60 text-red-200 px-1 py-0.2 rounded border border-red-500/40 ml-0.5 font-mono">
                Esc
              </kbd>
            </button>

            <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-2xl bg-red-600 flex items-center justify-center text-white shadow-lg shadow-red-600/50 animate-pulse shrink-0">
              <AlertTriangle className="w-5 h-5 sm:w-6 sm:h-6" />
            </div>
            <div className="min-w-0">
              <h1 className="text-sm sm:text-base font-extrabold tracking-wide text-white uppercase flex items-center gap-1.5 truncate">
                Emergency SOS
                <span className="text-[10px] bg-red-500 text-white font-bold px-1.5 py-0.2 rounded shrink-0">CRITICAL</span>
              </h1>
              <p className="text-[11px] sm:text-xs text-red-200 hidden sm:block truncate">Instant offline safety phrasebook</p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* Target Language selector button */}
            <button
              id="emergency-target-lang-btn"
              onClick={onOpenLanguageSelector}
              className="flex items-center gap-1.5 bg-black/40 hover:bg-black/60 border border-red-400/50 px-2.5 sm:px-3 py-1.5 rounded-full text-xs font-bold transition-colors"
            >
              <span>{currentLanguage.flag}</span>
              <span className="hidden sm:inline">{currentLanguage.name}</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 sm:p-2 text-red-200 hover:text-white rounded-xl hover:bg-black/30 transition-colors"
              aria-label="Exit Emergency"
              title="Close (Esc)"
            >
              <X className="w-5 h-5 sm:w-6 sm:h-6" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Body */}
      <div className="flex-1 max-w-4xl mx-auto w-full p-3 sm:p-4 space-y-4">
        {/* Quick Emergency Language Selector Bar */}
        <div className="space-y-1.5 bg-slate-900/90 border border-slate-800 rounded-2xl p-3">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5 text-red-400" />
              <span>Emergency Translation Language:</span>
            </span>
            <button
              onClick={onOpenLanguageSelector}
              className="text-[11px] text-red-400 hover:text-red-300 font-semibold underline underline-offset-2"
            >
              All 22+ Languages
            </button>
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
            {quickLanguages.map(lang => {
              const isSelected = currentLanguage.code === lang.code;
              return (
                <button
                  key={lang.code}
                  id={`emergency-lang-pill-${lang.code}`}
                  onClick={() => onSelectLanguage && onSelectLanguage(lang)}
                  className={`whitespace-nowrap flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                    isSelected
                      ? 'bg-red-600 text-white shadow-lg shadow-red-600/30 ring-2 ring-red-400/50 scale-105'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white border border-slate-700'
                  }`}
                >
                  <span>{lang.flag}</span>
                  <span>{lang.name}</span>
                </button>
              );
            })}
          </div>

          {isTranslatingDynamically && (
            <div className="flex items-center gap-1.5 text-[11px] text-amber-300 animate-pulse pt-1">
              <Loader2 className="w-3 h-3 animate-spin" />
              <span>Translating safety phrases into {currentLanguage.name}...</span>
            </div>
          )}
        </div>

        {/* Offline Safety Badge */}
        <div className="bg-red-900/20 border border-red-500/30 rounded-2xl p-3 flex items-center justify-between text-xs text-red-200">
          <div className="flex items-center gap-2">
            <WifiOff className="w-4 h-4 text-amber-400" />
            <span>Works 100% offline with pre-cached local packs.</span>
          </div>
          <span className="text-[10px] uppercase font-bold text-amber-400">Offline Ready</span>
        </div>

        {/* Category Tabs */}
        <div className="grid grid-cols-4 gap-1.5 bg-slate-900 p-1.5 rounded-2xl border border-slate-800">
          <button
            onClick={() => setActiveCategory('all')}
            className={`py-2 rounded-xl text-xs font-bold transition-all ${
              activeCategory === 'all' ? 'bg-red-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            All SOS
          </button>
          <button
            onClick={() => setActiveCategory('medical')}
            className={`py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition-all ${
              activeCategory === 'medical' ? 'bg-red-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <HeartPulse className="w-3.5 h-3.5 text-rose-400" />
            <span>Medical</span>
          </button>
          <button
            onClick={() => setActiveCategory('accident')}
            className={`py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition-all ${
              activeCategory === 'accident' ? 'bg-red-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Flame className="w-3.5 h-3.5 text-amber-400" />
            <span>Accident</span>
          </button>
          <button
            onClick={() => setActiveCategory('police')}
            className={`py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition-all ${
              activeCategory === 'police' ? 'bg-red-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5 text-blue-400" />
            <span>Police</span>
          </button>
        </div>

        {/* Phrases List */}
        <div className="space-y-3 pb-6">
          {filteredPhrases.map(phrase => {
            const translation = getTranslationForPhrase(phrase);
            return (
              <div
                key={phrase.id}
                id={`emergency-phrase-${phrase.id}`}
                className={`bg-slate-900 border rounded-3xl p-4 shadow-lg transition-all space-y-3 ${
                  phrase.urgentPriority
                    ? 'border-red-500/60 bg-gradient-to-br from-red-950/40 via-slate-900 to-slate-900'
                    : 'border-slate-800'
                }`}
              >
                {/* Header tag */}
                <div className="flex items-center justify-between text-xs">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-red-400 flex items-center gap-1">
                    {phrase.category === 'medical' && <HeartPulse className="w-3.5 h-3.5" />}
                    {phrase.category === 'accident' && <Flame className="w-3.5 h-3.5" />}
                    {phrase.category === 'police' && <ShieldAlert className="w-3.5 h-3.5" />}
                    {phrase.category === 'general' && <HelpCircle className="w-3.5 h-3.5" />}
                    {phrase.category}
                  </span>
                  <span className="text-slate-400 text-xs">{phrase.englishText}</span>
                </div>

                {/* Main Translated Text (Large & High Contrast) */}
                <div className="text-xl font-black text-white tracking-wide leading-snug">
                  "{translation.text}"
                </div>

                {translation.phonetic && (
                  <div className="text-xs text-red-300 font-mono italic">
                    🗣 Pronunciation: {translation.phonetic}
                  </div>
                )}

                {/* Bottom Action Row */}
                <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
                  {/* Fullscreen Flashcard Button */}
                  <button
                    onClick={() => setFullscreenPhrase({ phrase, translation })}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 transition-colors"
                  >
                    <Maximize2 className="w-3.5 h-3.5 text-red-400" />
                    <span>Large Display</span>
                  </button>

                  <div className="flex items-center gap-1.5">
                    {/* Speak loudly */}
                    <button
                      id={`emergency-speak-${phrase.id}`}
                      onClick={() => playEmergencyAudio(translation.text, false)}
                      className="flex items-center gap-1 px-3 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded-xl text-xs font-bold shadow-md active:scale-95 transition-all"
                    >
                      <Volume2 className="w-4 h-4" />
                      <span>Speak SOS</span>
                    </button>

                    {/* Copy */}
                    <button
                      onClick={() => handleCopy(phrase.id, translation.text)}
                      className="p-2 text-slate-400 hover:text-white rounded-xl bg-slate-800 hover:bg-slate-700 transition-colors"
                      title="Copy phrase"
                    >
                      {copiedId === phrase.id ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    </button>

                    {/* Share */}
                    <button
                      onClick={() => handleShare(translation.text)}
                      className="p-2 text-slate-400 hover:text-white rounded-xl bg-slate-800 hover:bg-slate-700 transition-colors"
                      title="Share emergency message"
                    >
                      <Share2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Emergency Call Quick Confirmation */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-4 space-y-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <PhoneCall className="w-3.5 h-3.5 text-red-400" />
            Emergency Contacts & Services
          </h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Per safety regulations, calls require explicit user confirmation before initiating.
          </p>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => setShowCallConfirmModal('112 / 911 (Local Emergency Services)')}
              className="flex items-center justify-center gap-2 p-3 bg-red-600/20 hover:bg-red-600/30 border border-red-500/50 rounded-2xl text-xs font-bold text-red-200 transition-all active:scale-95"
            >
              <PhoneCall className="w-4 h-4 text-red-400" />
              <span>Call Emergency (112 / 911)</span>
            </button>
            <button
              onClick={() => setShowCallConfirmModal('ICE Primary Emergency Contact')}
              className="flex items-center justify-center gap-2 p-3 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-2xl text-xs font-bold text-slate-200 transition-all active:scale-95"
            >
              <HeartPulse className="w-4 h-4 text-rose-400" />
              <span>Call ICE Contact</span>
            </button>
          </div>
        </div>
      </div>

      {/* ---------------- FULLSCREEN FLASHCARD POPUP ---------------- */}
      {fullscreenPhrase && (
        <div className="absolute inset-0 z-50 bg-red-950 flex flex-col justify-between p-6 select-none animate-fade-in text-center">
          {/* Top close */}
          <div className="flex items-center justify-between">
            <span className="text-sm uppercase font-black tracking-widest text-red-300 bg-red-900/60 px-3 py-1 rounded-full border border-red-500/40">
              🚨 EMERGENCY CARD
            </span>
            <button
              onClick={() => {
                stopSpeaking();
                setFullscreenPhrase(null);
              }}
              className="p-2 text-white bg-black/40 hover:bg-black/60 rounded-full"
            >
              <X className="w-8 h-8" />
            </button>
          </div>

          {/* Huge Readable Text Centerpiece */}
          <div className="my-auto space-y-6">
            <div className="text-3xl sm:text-4xl font-black text-white leading-tight drop-shadow-2xl">
              {fullscreenPhrase.translation.text}
            </div>

            {fullscreenPhrase.translation.phonetic && (
              <div className="text-base sm:text-lg text-red-200 font-mono italic">
                🗣 {fullscreenPhrase.translation.phonetic}
              </div>
            )}

            <div className="text-sm text-red-300/80 max-w-sm mx-auto">
              English: "{fullscreenPhrase.phrase.englishText}"
            </div>
          </div>

          {/* Bottom Broadcast Audio Bar */}
          <div className="space-y-3">
            <button
              onClick={() => playEmergencyAudio(fullscreenPhrase.translation.text, true)}
              className="w-full py-4 bg-white text-red-700 hover:bg-red-50 rounded-2xl font-black text-lg shadow-2xl flex items-center justify-center gap-3 active:scale-95 transition-all"
            >
              <Volume2 className="w-6 h-6 text-red-600 animate-bounce" />
              <span>BROADCAST LOUDLY (REPEAT)</span>
            </button>

            <button
              onClick={stopSpeaking}
              className="w-full py-2 bg-black/40 text-red-200 rounded-xl text-xs font-semibold"
            >
              Stop Audio Playback
            </button>
          </div>
        </div>
      )}

      {/* Confirmation Modal before dialing external services */}
      {showCallConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-sm w-full space-y-4 text-center">
            <div className="w-14 h-14 rounded-full bg-red-600/20 text-red-400 border border-red-500/40 flex items-center justify-center mx-auto">
              <PhoneCall className="w-7 h-7" />
            </div>
            <h3 className="text-lg font-bold text-slate-100">Confirm Emergency Call</h3>
            <p className="text-xs text-slate-400">
              Are you sure you want to dial <strong className="text-white">{showCallConfirmModal}</strong>?
            </p>
            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setShowCallConfirmModal(null)}
                className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  window.open('tel:112', '_self');
                  setShowCallConfirmModal(null);
                }}
                className="flex-1 py-2.5 bg-red-600 hover:bg-red-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-red-600/40"
              >
                Confirm & Call
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
