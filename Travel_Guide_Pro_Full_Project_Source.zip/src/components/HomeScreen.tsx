import React, { useState } from 'react';
import { 
  Mic, 
  Users, 
  MessagesSquare,
  Smartphone,
  Camera, 
  FileText, 
  AlertTriangle, 
  Compass, 
  Download, 
  History, 
  Volume2, 
  Star, 
  Copy, 
  ChevronRight,
  ChevronDown,
  Clock,
  Languages,
  ArrowLeftRight,
  Bot,
  MapPin,
  Hospital,
  Shield,
  Plane,
  Sparkles,
  ExternalLink,
  Car,
  CloudSun,
  ShieldAlert,
  Share2,
  RefreshCw,
  Navigation
} from 'lucide-react';
import { Language, TranslationRecord } from '../types';
import { SUPPORTED_LANGUAGES, findLanguageByCode } from '../data/languages';
import { DestinationCity, TravelDocument } from '../types/travel';
import { CITIES_DATA, resolveCityProfile } from '../data/travelData';
import { speakText } from '../utils/speech';
import { LocationStatusModal } from './travel/LocationStatusModal';
import { LocationDetectionResult } from '../services/locationService';

interface HomeScreenProps {
  onNavigate: (screen: 'home' | 'translate' | 'intelligence' | 'agent' | 'emergency' | 'settings') => void;
  onNavigateToTranslateSubMode?: (subMode: 'conversation' | 'camera' | 'text' | 'emergency') => void;
  onNavigateToAgentWithPrompt?: (prompt: string) => void;
  onSelectPromptForAgent?: (prompt: string) => void;
  onNavigateToIntelligenceTab?: (tab: string) => void;
  recentTranslations?: TranslationRecord[];
  onPlaySpeech: (text: string, langCode: string) => void;
  onToggleStar: (id: string) => void;
  isOffline: boolean;
  defaultUserLanguage?: Language;
  preferredTranslationLanguage?: Language;
  onSwapLanguages?: () => void;
  onSelectDefaultUserLanguage?: (lang: Language) => void;
  onOpenDefaultUserLanguageSelector?: () => void;
  currentDestination?: DestinationCity;
  activeDestination?: DestinationCity;
  onSelectDestination?: (city: DestinationCity) => void;
  locationState?: LocationDetectionResult | null;
  isDetectingLocation?: boolean;
  onDetectLocation?: () => Promise<void>;
  travelDocuments?: TravelDocument[];
  onOpenHistory?: () => void;
  onOpenPhrasebook?: () => void;
  onOpenOfflinePacks?: () => void;
  onOpenPermissions?: () => void;
  onOpenInstantPrompt?: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  onNavigate,
  onNavigateToTranslateSubMode,
  onNavigateToAgentWithPrompt,
  onSelectPromptForAgent,
  onNavigateToIntelligenceTab,
  recentTranslations = [],
  onPlaySpeech,
  onToggleStar,
  isOffline,
  defaultUserLanguage,
  preferredTranslationLanguage,
  onSwapLanguages,
  onSelectDefaultUserLanguage,
  onOpenDefaultUserLanguageSelector,
  currentDestination,
  activeDestination,
  onSelectDestination,
  locationState,
  isDetectingLocation,
  onDetectLocation,
  travelDocuments = [],
  onOpenHistory,
  onOpenPhrasebook,
  onOpenOfflinePacks,
  onOpenPermissions,
  onOpenInstantPrompt,
}) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isLocationModalOpen, setIsLocationModalOpen] = useState(false);


  const effectiveDestination = activeDestination || currentDestination || locationState?.matchedDestination || 'Delhi, India';
  const cityData = resolveCityProfile(effectiveDestination, locationState);
  const effectiveUserLang = defaultUserLanguage || findLanguageByCode('hi');
  const destinationLang = SUPPORTED_LANGUAGES.find(l => l.code === cityData.primaryLanguageCode) || findLanguageByCode(cityData.primaryLanguageCode || 'ja');
  const nearbyList = cityData?.nearbyPlaces || [];
  const nearestHospital = nearbyList.find(p => p.category === 'hospital') || nearbyList[0];
  const safeTranslations = Array.isArray(recentTranslations) ? recentTranslations : [];
  const safeDocs = Array.isArray(travelDocuments) ? travelDocuments : [];

  const handleAgentPrompt = (prompt: string) => {
    const cleanPrompt = prompt.replace(/[“”"]/g, '');
    if (onSelectPromptForAgent) {
      onSelectPromptForAgent(cleanPrompt);
    } else if (onNavigateToAgentWithPrompt) {
      onNavigateToAgentWithPrompt(cleanPrompt);
    } else {
      onNavigate('agent');
    }
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1800);
  };

  return (
    <div className="space-y-5 pb-12 animate-fade-in max-w-4xl mx-auto">
      {/* 1. TOP TRI-FEATURE HERO HUB BAR */}
      <section className="bg-gradient-to-br from-slate-900 via-indigo-950/40 to-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-5 shadow-xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs font-bold text-teal-400">
              <span className="flex h-2 w-2 rounded-full bg-emerald-400 animate-ping" />
              <span>CURRENT DESTINATION & TRAVEL INTEL</span>
            </div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <span className="text-2xl sm:text-3xl">{cityData.flag}</span>
              <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                {cityData.city}
              </h1>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700 font-medium">
                {cityData.country}
              </span>
              <button
                onClick={() => setIsLocationModalOpen(true)}
                className="inline-flex items-center gap-1.5 text-[11px] px-2.5 py-0.5 rounded-full bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/35 text-emerald-300 font-semibold transition-all cursor-pointer group"
                title="Click to view Live Location details"
              >
                <MapPin className="w-3 h-3 text-emerald-400 group-hover:scale-110 transition-transform" />
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span>
                  {locationState?.isLocationBased
                    ? `Destination based on your location${locationState.accuracy ? ` (±${locationState.accuracy}m)` : ''}`
                    : 'Destination based on your location'}
                </span>
              </button>
            </div>
            <p className="text-xs text-slate-400 flex items-center gap-2 flex-wrap">
              <span>{cityData.weather.icon} {cityData.weather.tempC}°C ({cityData.weather.condition})</span>
              <span>•</span>
              <span>Emergency: <strong className="text-rose-400 font-bold">{cityData.emergencyNumber}</strong></span>
            </p>
          </div>

          {/* Location Actions */}
          <div className="flex items-center gap-2 shrink-0">
            {onDetectLocation && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onDetectLocation();
                }}
                disabled={isDetectingLocation}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-all disabled:opacity-50 text-xs font-semibold"
                title="Refresh Live Location (GPS)"
              >
                <RefreshCw className={`w-3.5 h-3.5 text-indigo-400 ${isDetectingLocation ? 'animate-spin' : ''}`} />
                <span className="text-[11px]">Refresh GPS</span>
              </button>
            )}
          </div>
        </div>

        {/* Dynamic Default Language Details & Trip Translation Route */}
        <div className="mt-3.5 pt-3 border-t border-slate-800/80 bg-slate-950/50 rounded-2xl p-3 border border-slate-800/80">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
            {/* Left: Default user language details with interactive selection */}
            <div className="space-y-1">
              <div className="flex items-center gap-1.5 text-xs text-slate-400">
                <Languages className="w-3.5 h-3.5 text-indigo-400" />
                <span className="font-bold text-slate-300">Default Language (You Speak):</span>
                <span className="text-[10px] bg-indigo-500/20 text-indigo-300 px-1.5 py-0.5 rounded font-mono font-bold">
                  {effectiveUserLang.code.toUpperCase()}
                </span>
                {effectiveUserLang.region && (
                  <span className="text-[10px] text-slate-400 hidden md:inline">
                    • {effectiveUserLang.region}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                {/* Interactive dropdown to select and update Default User Language */}
                <div className="relative inline-flex items-center">
                  <select
                    id="hub-default-user-language-select"
                    value={effectiveUserLang.code}
                    onChange={(e) => {
                      const selected = findLanguageByCode(e.target.value);
                      if (selected && onSelectDefaultUserLanguage) {
                        onSelectDefaultUserLanguage(selected);
                      }
                    }}
                    className="bg-slate-800 hover:bg-slate-700/90 text-white font-bold text-xs sm:text-sm rounded-xl px-3 py-1.5 pr-8 border border-indigo-500/40 focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer appearance-none shadow-sm"
                    title="Select Default User Language"
                  >
                    <optgroup label="🇮🇳 Indian Languages (22 Official)">
                      {SUPPORTED_LANGUAGES.filter(l => l.region === 'India').map(lang => (
                        <option key={lang.code} value={lang.code}>
                          {lang.flag} {lang.name} ({lang.nativeName})
                        </option>
                      ))}
                    </optgroup>
                    <optgroup label="🌍 Global & Popular Languages">
                      {SUPPORTED_LANGUAGES.filter(l => l.region !== 'India').map(lang => (
                        <option key={lang.code} value={lang.code}>
                          {lang.flag} {lang.name} ({lang.nativeName})
                        </option>
                      ))}
                    </optgroup>
                  </select>
                  <div className="pointer-events-none absolute right-2.5 top-1/2 -translate-y-1/2 text-indigo-300">
                    <ChevronDown className="w-3.5 h-3.5" />
                  </div>
                </div>

                {onOpenDefaultUserLanguageSelector && (
                  <button
                    onClick={onOpenDefaultUserLanguageSelector}
                    className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold px-2 py-1 rounded-lg hover:bg-slate-800/80 transition-colors"
                  >
                    All Languages ({SUPPORTED_LANGUAGES.length})
                  </button>
                )}
              </div>
            </div>

            {/* Right: Bilingual Route: Default User Language ⇄ Destination Local */}
            <div className="flex items-center gap-2 bg-slate-900/90 border border-slate-800 px-3 py-2 rounded-xl text-xs shrink-0 self-start sm:self-auto">
              <div className="text-right">
                <div className="text-[10px] uppercase font-bold text-slate-400">Your Language</div>
                <div className="font-bold text-indigo-300 flex items-center gap-1 justify-end">
                  <span>{effectiveUserLang.flag}</span>
                  <span className="truncate max-w-[85px]">{effectiveUserLang.name}</span>
                </div>
              </div>

              <button
                onClick={onSwapLanguages}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-all hover:scale-105 active:scale-95"
                title="Swap translation direction"
              >
                <ArrowLeftRight className="w-3.5 h-3.5 text-indigo-400" />
              </button>

              <div>
                <div className="text-[10px] uppercase font-bold text-teal-400">Destination</div>
                <div className="font-bold text-teal-300 flex items-center gap-1">
                  <span>{destinationLang?.flag || cityData.flag}</span>
                  <span className="truncate max-w-[85px]">{cityData.primaryLanguage}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>



      {/* 2. FEATURE 1: TRANSLATION HUB (Voice, Camera & Text) */}
      <section className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <Languages className="w-3.5 h-3.5 text-indigo-400" />
            <span>Feature 1: Translation Hub</span>
          </h2>
          <button
            onClick={() => onNavigate('translate')}
            className="text-xs text-indigo-400 hover:text-indigo-300 font-bold flex items-center gap-1"
          >
            <span>Open Translation Hub</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Translation Mode Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
          <button
            onClick={() => {
              onNavigateToTranslateSubMode?.('conversation');
              onNavigate('translate');
            }}
            className="bg-slate-900 border border-slate-800 hover:border-indigo-500/60 p-4 rounded-2xl text-left transition-all group flex flex-col justify-between"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="w-10 h-10 rounded-xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30 group-hover:scale-105 transition-transform">
                <MessagesSquare className="w-5 h-5" />
              </div>
              <span className="text-[10px] bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded font-bold uppercase">
                Voice Hub
              </span>
            </div>
            <div>
              <div className="text-sm font-bold text-white group-hover:text-indigo-300">
                Live Voice Conversation
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Handheld & Tabletop split-screen bilingual voice
              </p>
            </div>
          </button>

          <button
            onClick={() => {
              onNavigateToTranslateSubMode?.('camera');
              onNavigate('translate');
            }}
            className="bg-slate-900 border border-slate-800 hover:border-teal-500/60 p-4 rounded-2xl text-left transition-all group flex flex-col justify-between"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="w-10 h-10 rounded-xl bg-teal-600/20 text-teal-400 flex items-center justify-center border border-teal-500/30 group-hover:scale-105 transition-transform">
                <Camera className="w-5 h-5" />
              </div>
              <span className="text-[10px] bg-teal-500/20 text-teal-300 px-2 py-0.5 rounded font-bold uppercase">
                Camera OCR
              </span>
            </div>
            <div>
              <div className="text-sm font-bold text-white group-hover:text-teal-300">
                Camera & Sign Translate
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Menus, street signs & live image OCR scanner
              </p>
            </div>
          </button>

          <button
            onClick={() => {
              onNavigateToTranslateSubMode?.('text');
              onNavigate('translate');
            }}
            className="bg-slate-900 border border-slate-800 hover:border-blue-500/60 p-4 rounded-2xl text-left transition-all group flex flex-col justify-between"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="w-10 h-10 rounded-xl bg-blue-600/20 text-blue-400 flex items-center justify-center border border-blue-500/30 group-hover:scale-105 transition-transform">
                <FileText className="w-5 h-5" />
              </div>
              <span className="text-[10px] bg-blue-500/20 text-blue-300 px-2 py-0.5 rounded font-bold uppercase">
                Text & Paste
              </span>
            </div>
            <div>
              <div className="text-sm font-bold text-white group-hover:text-blue-300">
                Text & Paste Translation
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Smart typing, quick pronunciation & clipboard copy
              </p>
            </div>
          </button>
        </div>
      </section>

      {/* 3. FEATURE 2: TRAVEL INTELLIGENCE PREVIEW (Location, Weather, Nearby ER, Vault & Transit) */}
      <section className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <Compass className="w-3.5 h-3.5 text-teal-400" />
            <span>Feature 2: Travel Intelligence</span>
          </h2>
          <button
            onClick={() => onNavigate('intelligence')}
            className="text-xs text-teal-400 hover:text-teal-300 font-bold flex items-center gap-1"
          >
            <span>Open Intelligence Dashboard</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {/* Nearby Emergency & Hospital Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center border border-rose-500/30">
                  <Hospital className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-bold text-white">Nearest Emergency Care</div>
                  <div className="text-[11px] text-slate-400">{cityData.city}</div>
                </div>
              </div>
              <span className="text-[10px] bg-rose-500/20 text-rose-300 border border-rose-500/30 px-2 py-0.5 rounded font-bold">
                {nearestHospital.openStatus}
              </span>
            </div>

            <div className="bg-slate-800/60 rounded-xl p-2.5 text-xs space-y-1 border border-slate-700/50">
              <div className="font-bold text-white truncate">{nearestHospital.name}</div>
              <div className="text-slate-300 font-mono text-[11px]">{nearestHospital.localName}</div>
              <div className="text-slate-400 text-[11px]">
                📍 {nearestHospital.distance} away ({nearestHospital.walkingTime}) • Phone: {nearestHospital.phone}
              </div>
            </div>

            <div className="flex items-center justify-between pt-1 text-xs">
              <button
                onClick={() => {
                  onNavigateToIntelligenceTab?.('nearby');
                  onNavigate('intelligence');
                }}
                className="text-teal-400 hover:text-teal-300 font-semibold flex items-center gap-1"
              >
                <span>View Police, ATMs & Pharmacies</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Travel Documents Vault Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-2.5 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30">
                    <FileText className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white">Travel Documents Vault</div>
                    <div className="text-[11px] text-slate-400">Offline Secure Storage</div>
                  </div>
                </div>
                <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                  {travelDocuments.length} Stored
                </span>
              </div>

              <p className="text-xs text-slate-300 mt-2.5 line-clamp-2 leading-relaxed">
                {travelDocuments.length > 0
                  ? `Access your encrypted passports, visas, hotel bookings, and travel insurance offline.`
                  : `Securely save copies of your passport, flight tickets, hotel vouchers, and visa for offline emergency access.`}
              </p>
            </div>

            <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs">
              <span className="text-slate-400">100% Offline Accessible</span>
              <button
                onClick={() => {
                  onNavigateToIntelligenceTab?.('documents');
                  onNavigate('intelligence');
                }}
                className="text-indigo-400 hover:text-indigo-300 font-semibold flex items-center gap-1"
              >
                <span>Open Documents Vault</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 4. FEATURE 3: AI TRAVEL AGENT (Flight assistance, Hotel taxi card, Scam Guard, Family Guardian) */}
      <section className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <Bot className="w-3.5 h-3.5 text-violet-400" />
            <span>Feature 3: AI Travel Agent</span>
          </h2>
          <button
            onClick={() => onNavigate('agent')}
            className="text-xs text-violet-400 hover:text-violet-300 font-bold flex items-center gap-1"
          >
            <span>Open Agent Assistant</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* 4 Actionable Copilot Action Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
          <button
            onClick={() => handleAgentPrompt('My flight is delayed. What should I do?')}
            className="bg-slate-900 border border-slate-800 hover:border-violet-500/60 p-3 rounded-2xl text-left transition-all group flex flex-col justify-between"
          >
            <div className="w-8 h-8 rounded-xl bg-violet-600/20 text-violet-400 flex items-center justify-center mb-2">
              <Plane className="w-4 h-4" />
            </div>
            <div>
              <div className="font-bold text-white group-hover:text-violet-300">Flight Copilot</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Delays & passenger rights</div>
            </div>
          </button>

          <button
            onClick={() => handleAgentPrompt('How do I tell the taxi driver where my hotel is?')}
            className="bg-slate-900 border border-slate-800 hover:border-indigo-500/60 p-3 rounded-2xl text-left transition-all group flex flex-col justify-between"
          >
            <div className="w-8 h-8 rounded-xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center mb-2">
              <Car className="w-4 h-4" />
            </div>
            <div>
              <div className="font-bold text-white group-hover:text-indigo-300">Hotel Taxi Card</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Native script for driver</div>
            </div>
          </button>

          <button
            onClick={() => handleAgentPrompt('Check if this taxi quote or restaurant bill is a scam')}
            className="bg-slate-900 border border-slate-800 hover:border-amber-500/60 p-3 rounded-2xl text-left transition-all group flex flex-col justify-between"
          >
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center mb-2">
              <ShieldAlert className="w-4 h-4" />
            </div>
            <div>
              <div className="font-bold text-white group-hover:text-amber-300">Scam & Price Guard</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Evaluate fares & bills</div>
            </div>
          </button>

          <button
            onClick={() => handleAgentPrompt('Help me share my safe check-in status with family')}
            className="bg-slate-900 border border-slate-800 hover:border-emerald-500/60 p-3 rounded-2xl text-left transition-all group flex flex-col justify-between"
          >
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center mb-2">
              <Share2 className="w-4 h-4" />
            </div>
            <div>
              <div className="font-bold text-white group-hover:text-emerald-300">Family Guardian</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Safe status broadcast</div>
            </div>
          </button>
        </div>

        {/* Natural Language Prompt suggestions */}
        <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-3 flex items-center gap-2 overflow-x-auto no-scrollbar text-xs">
          <span className="text-slate-400 font-medium shrink-0">Ask Agent:</span>
          {[
            '“My flight is delayed. What should I do?”',
            '“How do I tell the taxi driver where my hotel is?”',
            '“Find the nearest hospital.”',
            '“Translate this menu.”',
          ].map((prompt, i) => (
            <button
              key={i}
              onClick={() => handleAgentPrompt(prompt)}
              className="px-2.5 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white whitespace-nowrap text-[11px] transition-colors border border-slate-700/60 shrink-0"
            >
              {prompt}
            </button>
          ))}
        </div>
      </section>

      {/* 5. RECENT TRANSLATIONS FEED */}
      <section className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-indigo-400" />
            <span>Recent Translations</span>
          </h2>
          {safeTranslations.length > 0 && onOpenHistory && (
            <button
              onClick={onOpenHistory}
              className="text-xs text-indigo-400 hover:text-indigo-300 font-medium"
            >
              See all ({safeTranslations.length})
            </button>
          )}
        </div>

        {safeTranslations.length === 0 ? (
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4 text-center space-y-1">
            <p className="text-xs text-slate-300 font-semibold">No translations recorded yet.</p>
            <p className="text-[11px] text-slate-400">
              Start a Live Voice conversation, scan a sign with Camera, or enter text to see your history appear here.
            </p>
          </div>
        ) : (
          <div className="space-y-2">
            {safeTranslations.slice(0, 3).map((record) => (
              <div
                key={record.id}
                className="bg-slate-900 border border-slate-800 rounded-2xl p-3 flex items-center justify-between gap-3 text-xs"
              >
                <div className="min-w-0 space-y-0.5">
                  <div className="text-slate-400 text-[11px]">
                    {record.sourceLang} → {record.targetLang}
                  </div>
                  <div className="text-slate-300 truncate">{record.originalText}</div>
                  <div className="font-bold text-white truncate">{record.translatedText}</div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={() => onPlaySpeech(record.translatedText, record.targetLangCode)}
                    className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800"
                    title="Play Audio"
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleCopy(record.id, record.translatedText)}
                    className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800"
                    title="Copy translation"
                  >
                    <Copy className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Location-Based Destination Details Modal */}
      <LocationStatusModal
        isOpen={isLocationModalOpen}
        onClose={() => setIsLocationModalOpen(false)}
        currentDestination={effectiveDestination}
        locationState={locationState || null}
        isDetecting={!!isDetectingLocation}
        onDetectLocation={async () => {
          if (onDetectLocation) await onDetectLocation();
        }}
        onSelectManualDestination={onSelectDestination}
      />
    </div>
  );
};
