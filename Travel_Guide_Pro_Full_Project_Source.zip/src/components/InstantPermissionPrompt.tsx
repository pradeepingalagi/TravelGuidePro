import React, { useState, useEffect } from 'react';
import { 
  MapPin, 
  Mic, 
  Camera, 
  CheckCircle2, 
  X, 
  Loader2, 
  Settings, 
  ShieldCheck, 
  Sparkles,
  Zap,
  ArrowRight,
  AlertTriangle
} from 'lucide-react';
import { 
  requestLocationAccess, 
  requestMicrophoneAccess, 
  requestCameraAccess, 
  checkAllPermissions,
  savePermissionState,
  isStandaloneApp
} from '../utils/permissions';
import { AndroidSettingsGuideModal } from './AndroidSettingsGuideModal';

interface InstantPermissionPromptProps {
  isOpen: boolean;
  onClose: () => void;
  onLocationDetected?: (coords: { latitude: number; longitude: number }) => void;
}

export const InstantPermissionPrompt: React.FC<InstantPermissionPromptProps> = ({
  isOpen,
  onClose,
  onLocationDetected,
}) => {
  const [loading, setLoading] = useState<'all' | 'loc' | 'mic' | 'cam' | null>(null);
  const [locGranted, setLocGranted] = useState(false);
  const [micGranted, setMicGranted] = useState(false);
  const [camGranted, setCamGranted] = useState(false);
  const [deniedFeature, setDeniedFeature] = useState<'Location' | 'Microphone' | 'Camera' | null>(null);
  const [isGuideOpen, setIsGuideOpen] = useState(false);

  // Check current permission states when opened
  useEffect(() => {
    if (!isOpen) return;
    const check = async () => {
      try {
        const perms = await checkAllPermissions();
        if (perms.location === 'granted') setLocGranted(true);
        if (perms.microphone === 'granted') setMicGranted(true);
        if (perms.camera === 'granted') setCamGranted(true);
      } catch (e) {
        console.warn('Error checking permissions:', e);
      }
    };
    check();
  }, [isOpen]);

  if (!isOpen) return null;

  const allGranted = locGranted && micGranted && camGranted;

  // 1. Direct trigger for Location
  const handleAllowLocation = async (): Promise<boolean> => {
    setLoading('loc');
    try {
      const res = await requestLocationAccess();
      if (res.granted && res.coords) {
        setLocGranted(true);
        savePermissionState('location', 'granted');
        if (onLocationDetected) onLocationDetected(res.coords);
        return true;
      } else {
        setDeniedFeature('Location');
        return false;
      }
    } catch {
      setDeniedFeature('Location');
      return false;
    } finally {
      setLoading(null);
    }
  };

  // 2. Direct trigger for Microphone
  const handleAllowMic = async (): Promise<boolean> => {
    setLoading('mic');
    try {
      const res = await requestMicrophoneAccess();
      if (res.granted) {
        setMicGranted(true);
        savePermissionState('microphone', 'granted');
        return true;
      } else {
        setDeniedFeature('Microphone');
        return false;
      }
    } catch {
      setDeniedFeature('Microphone');
      return false;
    } finally {
      setLoading(null);
    }
  };

  // 3. Direct trigger for Camera
  const handleAllowCamera = async (): Promise<boolean> => {
    setLoading('cam');
    try {
      const res = await requestCameraAccess();
      if (res.granted) {
        setCamGranted(true);
        savePermissionState('camera', 'granted');
        return true;
      } else {
        setDeniedFeature('Camera');
        return false;
      }
    } catch {
      setDeniedFeature('Camera');
      return false;
    } finally {
      setLoading(null);
    }
  };

  // 4. Trigger all permissions sequentially
  const handleAllowAll = async () => {
    setLoading('all');
    setDeniedFeature(null);
    try {
      // Step A: Location
      if (!locGranted) {
        const lRes = await requestLocationAccess();
        if (lRes.granted && lRes.coords) {
          setLocGranted(true);
          savePermissionState('location', 'granted');
          if (onLocationDetected) onLocationDetected(lRes.coords);
        } else {
          setDeniedFeature('Location');
        }
      }

      // Step B: Microphone
      if (!micGranted) {
        const mRes = await requestMicrophoneAccess();
        if (mRes.granted) {
          setMicGranted(true);
          savePermissionState('microphone', 'granted');
        } else {
          setDeniedFeature('Microphone');
        }
      }

      // Step C: Camera
      if (!camGranted) {
        const cRes = await requestCameraAccess();
        if (cRes.granted) {
          setCamGranted(true);
          savePermissionState('camera', 'granted');
        } else {
          setDeniedFeature('Camera');
        }
      }
    } finally {
      setLoading(null);
    }
  };

  const handleDismiss = () => {
    try {
      sessionStorage.setItem('travelsarathi_instant_prompt_dismissed', 'true');
    } catch {}
    onClose();
  };

  const isApp = isStandaloneApp();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-3 sm:p-4 animate-fade-in select-none">
      <div className="w-full max-w-lg bg-slate-900 border border-indigo-500/30 rounded-3xl shadow-2xl overflow-hidden flex flex-col animate-scale-up max-h-[92vh]">
        
        {/* Glow Header bar */}
        <div className="h-1.5 w-full bg-gradient-to-r from-amber-400 via-teal-400 to-indigo-500" />

        <div className="p-5 sm:p-6 space-y-4 overflow-y-auto">
          
          {/* Top Row with Close & App badge */}
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center shadow-lg shadow-indigo-600/20 shrink-0">
                <Sparkles className="w-6 h-6 text-indigo-400" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-lg font-black text-white tracking-tight">
                    Device Permissions Setup
                  </h2>
                  {isApp && (
                    <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-300 border border-teal-500/30">
                      Installed App
                    </span>
                  )}
                </div>
                <p className="text-xs text-indigo-300 font-medium mt-0.5">
                  Enable Location, Mic & Camera for real-time translation
                </p>
              </div>
            </div>

            <button
              onClick={handleDismiss}
              className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors cursor-pointer"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed">
            Travel Guide Pro requires camera, microphone, and location access to translate speech, detect foreign signs, and auto-detect your destination country.
          </p>

          {/* Quick "ALLOW ALL" 1-Tap Master Button */}
          {!allGranted && (
            <button
              id="instant-allow-all-btn"
              onClick={handleAllowAll}
              disabled={loading !== null}
              className="w-full py-3.5 px-4 rounded-2xl font-black text-sm text-white bg-gradient-to-r from-indigo-600 via-teal-500 to-amber-500 hover:brightness-110 shadow-xl shadow-indigo-600/30 flex items-center justify-center gap-2 transition-all active:scale-[0.98] cursor-pointer"
            >
              {loading === 'all' ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-white" />
                  <span>Requesting System Permissions...</span>
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 fill-amber-300 text-amber-300 animate-pulse" />
                  <span>Allow All Permissions Instantly</span>
                </>
              )}
            </button>
          )}

          {/* The 3 Direct Sensor Rows */}
          <div className="space-y-2.5">
            {/* 1. Location Access */}
            <div className={`p-3 rounded-2xl border transition-all ${
              locGranted 
                ? 'bg-emerald-950/30 border-emerald-500/30' 
                : 'bg-slate-800/80 border-slate-700/80 hover:border-amber-500/40'
            }`}>
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                    locGranted ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'
                  }`}>
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs font-bold text-white flex items-center gap-1.5">
                      <span>Location (GPS)</span>
                      {locGranted && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 inline" />}
                    </div>
                    <div className="text-[11px] text-slate-400 truncate">
                      Auto-detect city, currency & emergency hotlines
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => handleAllowLocation()}
                  disabled={loading !== null || locGranted}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-all cursor-pointer flex items-center gap-1.5 ${
                    locGranted
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-md shadow-amber-500/20'
                  }`}
                >
                  {loading === 'loc' ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : locGranted ? (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Allowed</span>
                    </>
                  ) : (
                    <span>Allow Location</span>
                  )}
                </button>
              </div>
            </div>

            {/* 2. Microphone Access */}
            <div className={`p-3 rounded-2xl border transition-all ${
              micGranted 
                ? 'bg-emerald-950/30 border-emerald-500/30' 
                : 'bg-slate-800/80 border-slate-700/80 hover:border-indigo-500/40'
            }`}>
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                    micGranted ? 'bg-emerald-500/20 text-emerald-400' : 'bg-indigo-500/20 text-indigo-400'
                  }`}>
                    <Mic className="w-5 h-5" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs font-bold text-white flex items-center gap-1.5">
                      <span>Microphone (Voice)</span>
                      {micGranted && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 inline" />}
                    </div>
                    <div className="text-[11px] text-slate-400 truncate">
                      Real-time 2-way speech interpreter & audio dictation
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => handleAllowMic()}
                  disabled={loading !== null || micGranted}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-all cursor-pointer flex items-center gap-1.5 ${
                    micGranted
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/20'
                  }`}
                >
                  {loading === 'mic' ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : micGranted ? (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Allowed</span>
                    </>
                  ) : (
                    <span>Allow Mic</span>
                  )}
                </button>
              </div>
            </div>

            {/* 3. Camera Access */}
            <div className={`p-3 rounded-2xl border transition-all ${
              camGranted 
                ? 'bg-emerald-950/30 border-emerald-500/30' 
                : 'bg-slate-800/80 border-slate-700/80 hover:border-teal-500/40'
            }`}>
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                    camGranted ? 'bg-emerald-500/20 text-emerald-400' : 'bg-teal-500/20 text-teal-400'
                  }`}>
                    <Camera className="w-5 h-5" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs font-bold text-white flex items-center gap-1.5">
                      <span>Camera (Visual OCR)</span>
                      {camGranted && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 inline" />}
                    </div>
                    <div className="text-[11px] text-slate-400 truncate">
                      Translate street signs, food menus & travel documents
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => handleAllowCamera()}
                  disabled={loading !== null || camGranted}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-all cursor-pointer flex items-center gap-1.5 ${
                    camGranted
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : 'bg-teal-600 hover:bg-teal-500 text-white shadow-md shadow-teal-600/20'
                  }`}
                >
                  {loading === 'cam' ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : camGranted ? (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Allowed</span>
                    </>
                  ) : (
                    <span>Allow Camera</span>
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* If Denied: Show In-App Settings Guide */}
          {deniedFeature && (
            <div className="p-3 bg-rose-500/15 border border-rose-500/30 rounded-2xl text-xs space-y-2 text-rose-200">
              <div className="font-bold flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-rose-400" />
                  <span>{deniedFeature} Blocked on Device</span>
                </span>
                <button
                  onClick={() => {
                    if (deniedFeature === 'Location') handleAllowLocation();
                    else if (deniedFeature === 'Microphone') handleAllowMic();
                    else handleAllowCamera();
                  }}
                  className="text-[11px] bg-rose-600 hover:bg-rose-500 text-white px-2 py-0.5 rounded-lg font-bold cursor-pointer"
                >
                  Retry
                </button>
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                If the permission prompt was dismissed or set to "Don't allow" in Android, tap below to view quick steps to toggle it:
              </p>
              <button
                onClick={() => setIsGuideOpen(true)}
                className="w-full py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Settings className="w-3.5 h-3.5 text-indigo-400" />
                <span>Open Settings Guide ➔</span>
              </button>
            </div>
          )}

          {/* All Granted Success Banner */}
          {allGranted && (
            <div className="p-3 bg-emerald-500/15 border border-emerald-500/30 rounded-2xl text-xs text-emerald-300 flex items-center gap-2.5">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
              <div>
                <p className="font-bold text-white">All Device Permissions Active!</p>
                <p className="text-[11px] text-emerald-300/80">Location, Microphone, and Camera are ready for travel translation.</p>
              </div>
            </div>
          )}

          {/* Footer Dismiss / Continue */}
          <div className="pt-2 flex items-center justify-between text-xs text-slate-400">
            <span className="text-[11px] flex items-center gap-1 text-slate-400">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Sensors used only while active</span>
            </span>
            <button
              onClick={handleDismiss}
              className="py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl transition-colors cursor-pointer flex items-center gap-1"
            >
              <span>{allGranted ? 'Done & Continue' : 'Continue to App'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

        </div>
      </div>

      <AndroidSettingsGuideModal
        isOpen={isGuideOpen}
        onClose={() => setIsGuideOpen(false)}
        onVerify={() => {
          if (deniedFeature === 'Location') handleAllowLocation();
          else if (deniedFeature === 'Microphone') handleAllowMic();
          else handleAllowCamera();
        }}
        targetFeature={deniedFeature || 'All'}
      />
    </div>
  );
};
