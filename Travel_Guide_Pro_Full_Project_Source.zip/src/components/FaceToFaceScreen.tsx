import React, { useState, useRef, useEffect } from 'react';
import { 
  Mic, 
  Volume2, 
  RotateCw, 
  ArrowLeftRight, 
  Trash2, 
  Square, 
  Sparkles, 
  Check, 
  Send,
  ShieldAlert,
  Loader2,
  Repeat,
  Headphones,
  UserCheck,
  Smartphone,
  ArrowLeft
} from 'lucide-react';
import { Language, TranslationRecord, VoiceSettings } from '../types';
import { 
  translateTwoWayApi, 
  translateTwoWayAudioApi,
  translateTextApi, 
  translateAudioApi 
} from '../services/translationService';
import { speakText, stopSpeaking } from '../utils/speech';
import { UnifiedVoiceRecorder } from '../utils/audioRecorder';

interface FaceToFaceScreenProps {
  personALang: Language; // Top person (e.g. Hindi, Spanish, etc.)
  personBLang: Language; // Bottom person (e.g. English)
  onOpenPersonALangSelector: () => void;
  onOpenPersonBLangSelector: () => void;
  onSwapLanguages: () => void;
  voiceSettings: VoiceSettings;
  onAddTranslation: (record: TranslationRecord) => void;
  onClose: () => void;
  onSwitchToHandheld?: () => void;
}

export const FaceToFaceScreen: React.FC<FaceToFaceScreenProps> = ({
  personALang,
  personBLang,
  onOpenPersonALangSelector,
  onOpenPersonBLangSelector,
  onSwapLanguages,
  voiceSettings,
  onAddTranslation,
  onClose,
  onSwitchToHandheld,
}) => {
  const [activeSpeaker, setActiveSpeaker] = useState<'A' | 'B' | 'auto' | null>(null);
  const activeSpeakerRef = useRef<'A' | 'B' | 'auto' | null>(null);
  const [transcriptA, setTranscriptA] = useState('');
  const [transcriptB, setTranscriptB] = useState('');
  const [volumeA, setVolumeA] = useState(0);
  const [volumeB, setVolumeB] = useState(0);
  const [manualInputA, setManualInputA] = useState('');
  const [manualInputB, setManualInputB] = useState('');
  const [showInputA, setShowInputA] = useState(false);
  const [showInputB, setShowInputB] = useState(false);
  const [isTranslating, setIsTranslating] = useState(false);
  const [translatingSpeaker, setTranslatingSpeaker] = useState<'A' | 'B' | 'auto' | null>(null);
  const [rotateTop, setRotateTop] = useState(true); // 180 deg flip for opposite standing
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [permissionBlocked, setPermissionBlocked] = useState(false);

  // Auto-dismiss error messages
  useEffect(() => {
    if (errorMessage) {
      const timer = setTimeout(() => setErrorMessage(null), 4000);
      return () => clearTimeout(timer);
    }
  }, [errorMessage]);

  // 2-Way Hands-Free Continuous Loop
  const [autoLoopMode, setAutoLoopMode] = useState(false);
  const autoLoopModeRef = useRef(false);
  const [loopBanner, setLoopBanner] = useState<string | null>(null);
  const loopTimeoutRef = useRef<any>(null);

  const [latestMessageFromA, setLatestMessageFromA] = useState<{
    original: string;
    translated: string;
    pronunciation?: string;
    detectedLang?: string;
  } | null>(null);

  const [latestMessageFromB, setLatestMessageFromB] = useState<{
    original: string;
    translated: string;
    pronunciation?: string;
    detectedLang?: string;
  } | null>(null);

  const recorderRef = useRef<UnifiedVoiceRecorder | null>(null);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const f2fPressStartTimeRef = useRef<number>(0);
  const f2fHoldTriggeredRef = useRef<boolean>(false);

  useEffect(() => {
    let timer: any = null;
    if (activeSpeaker) {
      setRecordingSeconds(0);
      timer = setInterval(() => setRecordingSeconds(p => p + 1), 1000);
    } else {
      setRecordingSeconds(0);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [activeSpeaker]);

  useEffect(() => {
    autoLoopModeRef.current = autoLoopMode;
    if (!autoLoopMode && loopTimeoutRef.current) {
      clearTimeout(loopTimeoutRef.current);
      setLoopBanner(null);
    }
  }, [autoLoopMode]);

  useEffect(() => {
    recorderRef.current = new UnifiedVoiceRecorder();
    return () => {
      stopSpeaking();
      if (loopTimeoutRef.current) clearTimeout(loopTimeoutRef.current);
      recorderRef.current?.cancel();
    };
  }, []);

  // Play audio aloud for recipient
  const playAudio = (text: string, speechCode: string, onDone?: () => void) => {
    speakText(
      text,
      speechCode || 'en-US',
      {
        speechRate: voiceSettings.speechRate,
        volume: voiceSettings.volume,
        voiceGender: voiceSettings.voiceGender,
      },
      undefined,
      () => onDone?.(),
      () => onDone?.()
    );
  };

  // Schedule next speaker in hands-free loop
  const scheduleNextSpeakerLoop = (nextSpeaker: 'A' | 'B') => {
    if (!autoLoopModeRef.current) return;

    const nextLang = nextSpeaker === 'A' ? personALang : personBLang;
    setLoopBanner(`Listening for Person ${nextSpeaker} (${nextLang.name})...`);

    if (loopTimeoutRef.current) clearTimeout(loopTimeoutRef.current);
    loopTimeoutRef.current = setTimeout(() => {
      setLoopBanner(null);
      if (autoLoopModeRef.current && !activeSpeakerRef.current) {
        startListening(nextSpeaker);
      }
    }, 900);
  };

  // Execute 2-Way Translation
  const handleTwoWayTranslate = async (speaker: 'A' | 'B' | 'auto', rawText: string) => {
    if (!rawText || !rawText.trim()) return;

    setTranslatingSpeaker(speaker);
    setIsTranslating(true);
    setErrorMessage(null);

    const personAName = personALang.code === 'auto' ? 'Auto Detect' : personALang.name;
    const personBName = personBLang.name;

    try {
      const res = await translateTwoWayApi({
        text: rawText.trim(),
        userALang: personAName,
        userBLang: personBName,
        context: 'face-to-face-conversation',
      });

      if (res.success) {
        // If 'auto', determine which user spoke based on API detection
        const isSpeakerA = speaker === 'auto' ? res.speaker === 'userA' : speaker === 'A';
        const speakerKey = isSpeakerA ? 'A' : 'B';

        const sourceLangObj = isSpeakerA ? personALang : personBLang;
        const targetLangObj = isSpeakerA ? personBLang : personALang;

        const item: TranslationRecord = {
          id: `f2f_${Date.now()}`,
          originalText: rawText.trim(),
          translatedText: res.translatedText,
          sourceLang: res.detectedLanguage || sourceLangObj.name,
          sourceLangCode: res.detectedLanguageCode || sourceLangObj.code,
          targetLang: res.targetLanguage || targetLangObj.name,
          targetLangCode: res.targetLanguageCode || targetLangObj.code,
          detectedLang: res.detectedLanguage,
          pronunciation: res.pronunciation,
          culturalNote: res.culturalNote,
          timestamp: Date.now(),
          category: 'face-to-face',
          speaker: isSpeakerA ? 'user1' : 'user2',
        };

        if (isSpeakerA) {
          setLatestMessageFromA({
            original: rawText.trim(),
            translated: res.translatedText,
            pronunciation: res.pronunciation || undefined,
            detectedLang: res.detectedLanguage,
          });
          setTranscriptA('');
          setManualInputA('');
          setShowInputA(false);
        } else {
          setLatestMessageFromB({
            original: rawText.trim(),
            translated: res.translatedText,
            pronunciation: res.pronunciation || undefined,
            detectedLang: res.detectedLanguage,
          });
          setTranscriptB('');
          setManualInputB('');
          setShowInputB(false);
        }

        onAddTranslation(item);

        // Speak translation aloud to opposite person
        const speechCode = targetLangObj.speechCode === 'auto' ? 'en-US' : targetLangObj.speechCode;
        playAudio(res.translatedText, speechCode, () => {
          if (autoLoopModeRef.current) {
            scheduleNextSpeakerLoop(isSpeakerA ? 'B' : 'A');
          }
        });
      } else {
        setErrorMessage(res.error || 'Live translation failed.');
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Error occurred during translation.');
    } finally {
      setIsTranslating(false);
      setTranslatingSpeaker(null);
    }
  };

  // Start Voice Listening
  const startListening = async (speaker: 'A' | 'B' | 'auto') => {
    stopSpeaking();
    setIsTranslating(false);
    setTranslatingSpeaker(null);
    if (loopTimeoutRef.current) clearTimeout(loopTimeoutRef.current);
    setLoopBanner(null);
    setErrorMessage(null);
    setPermissionBlocked(false);

    if (speaker === 'A') setTranscriptA('');
    else if (speaker === 'B') setTranscriptB('');
    else {
      setTranscriptA('');
      setTranscriptB('');
    }

    if (!recorderRef.current) {
      recorderRef.current = new UnifiedVoiceRecorder();
    }

    activeSpeakerRef.current = speaker;
    setActiveSpeaker(speaker);

    let speechCode = 'en-US';
    if (speaker === 'A' && personALang.code !== 'auto') {
      speechCode = personALang.speechCode;
    } else if (speaker === 'B') {
      speechCode = personBLang.speechCode;
    } else if (personALang.code !== 'auto') {
      speechCode = personALang.speechCode;
    }

    const started = await recorderRef.current.start(speechCode, {
      onStart: () => {
        activeSpeakerRef.current = speaker;
        setActiveSpeaker(speaker);
      },
      onInterimTranscript: (text: string) => {
        if (speaker === 'A') setTranscriptA(text);
        else if (speaker === 'B') setTranscriptB(text);
        else {
          setTranscriptA(text);
          setTranscriptB(text);
        }
      },
      onFinalTranscript: (text: string) => {
        if (speaker === 'A') setTranscriptA(text);
        else if (speaker === 'B') setTranscriptB(text);
        else {
          setTranscriptA(text);
          setTranscriptB(text);
        }
      },
      onVolumeChange: (vol: number) => {
        if (speaker === 'A') setVolumeA(vol);
        else if (speaker === 'B') setVolumeB(vol);
        else {
          setVolumeA(vol);
          setVolumeB(vol);
        }
      },
      onError: (err: string) => {
        activeSpeakerRef.current = null;
        setActiveSpeaker(null);
        setErrorMessage(err);
        if (err.toLowerCase().includes('blocked') || err.toLowerCase().includes('permission') || err.toLowerCase().includes('denied')) {
          setPermissionBlocked(true);
        }
      },
      onEnd: () => {
        activeSpeakerRef.current = null;
        setActiveSpeaker(null);
        setVolumeA(0);
        setVolumeB(0);
      },
    });

    if (!started) {
      activeSpeakerRef.current = null;
      setActiveSpeaker(null);
    }
  };

  // Stop Listening and Perform Translation
  const stopListening = async (speaker: 'A' | 'B' | 'auto') => {
    activeSpeakerRef.current = null;
    setActiveSpeaker(null);
    setVolumeA(0);
    setVolumeB(0);
    setTranslatingSpeaker(speaker);
    setIsTranslating(true);
    setErrorMessage(null);

    if (!recorderRef.current) {
      setIsTranslating(false);
      setTranslatingSpeaker(null);
      return;
    }

    try {
      // 1. Stop hardware recorder and retrieve the audio chunks, volume metrics & base64
      const recResult = await recorderRef.current.stop();

      const clientTranscript = (
        recResult.transcript ||
        (speaker === 'A' ? transcriptA : speaker === 'B' ? transcriptB : transcriptA || transcriptB)
      ).trim();

      // Check if any transcript OR audio was captured
      const hasAudio = Boolean(recResult.audioBase64 && recResult.audioBase64.length > 30);
      const hasTranscript = Boolean(clientTranscript.length > 0);

      if (!hasAudio && !hasTranscript) {
        setErrorMessage(
          speaker === 'auto'
            ? 'No speech heard. Please tap the mic, speak clearly, and tap again when done.'
            : `No speech heard for Person ${speaker}. Please tap the mic, speak clearly, and tap again when done.`
        );
        setIsTranslating(false);
        setTranslatingSpeaker(null);
        return;
      }

      // ⚡ FAST REAL-TIME PATH: If Web Speech transcript exists, translate instantly via text API (sub-500ms)
      if (clientTranscript.length > 0) {
        await handleTwoWayTranslate(speaker, clientTranscript);
        return;
      }

      // 2. Multimodal Gemini Audio AI with strict anti-hallucination verification
      if (recResult.audioBase64) {
        const personAName = personALang.code === 'auto' ? 'Auto Detect' : personALang.name;
        const personBName = personBLang.name;

        const audioRes = await translateTwoWayAudioApi({
          audioBase64: recResult.audioBase64,
          mimeType: recResult.mimeType,
          userALang: personAName,
          userBLang: personBName,
          speakerHint: speaker === 'A' ? 'user1' : speaker === 'B' ? 'user2' : 'auto',
        });

        if (audioRes.success) {
          // Strict speech detection check: Do not hallucinate when silence / empty speech
          if (!audioRes.hasSpeech || !audioRes.transcription?.trim() || !audioRes.translatedText?.trim()) {
            setErrorMessage(
              speaker === 'auto'
                ? 'No speech heard. Tap the microphone and speak clearly.'
                : `No speech heard for Person ${speaker}. Tap the microphone and speak clearly.`
            );
            return;
          }

          const isSpeakerA = speaker === 'auto' ? audioRes.speaker === 'userA' : speaker === 'A';
          const sourceLangObj = isSpeakerA ? personALang : personBLang;
          const targetLangObj = isSpeakerA ? personBLang : personALang;

          const item: TranslationRecord = {
            id: `f2f_${Date.now()}`,
            originalText: audioRes.transcription.trim(),
            translatedText: audioRes.translatedText.trim(),
            sourceLang: audioRes.detectedLanguage || sourceLangObj.name,
            sourceLangCode: audioRes.detectedLanguageCode || sourceLangObj.code,
            targetLang: audioRes.targetLanguage || targetLangObj.name,
            targetLangCode: audioRes.targetLanguageCode || targetLangObj.code,
            detectedLang: audioRes.detectedLanguage,
            pronunciation: audioRes.pronunciation,
            culturalNote: audioRes.culturalNote,
            timestamp: Date.now(),
            category: 'face-to-face',
            speaker: isSpeakerA ? 'user1' : 'user2',
          };

          if (isSpeakerA) {
            setLatestMessageFromA({
              original: item.originalText,
              translated: item.translatedText,
              pronunciation: item.pronunciation || undefined,
              detectedLang: audioRes.detectedLanguage,
            });
            setTranscriptA('');
          } else {
            setLatestMessageFromB({
              original: item.originalText,
              translated: item.translatedText,
              pronunciation: item.pronunciation || undefined,
              detectedLang: audioRes.detectedLanguage,
            });
            setTranscriptB('');
          }

          onAddTranslation(item);

          // Speak translation aloud
          const speechCode = targetLangObj.speechCode === 'auto' ? 'en-US' : targetLangObj.speechCode;
          playAudio(item.translatedText, speechCode, () => {
            if (autoLoopModeRef.current) {
              scheduleNextSpeakerLoop(isSpeakerA ? 'B' : 'A');
            }
          });
          return;
        } else if (audioRes.error) {
          if (!clientTranscript) {
            setErrorMessage(
              audioRes.error.includes('No clear speech')
                ? `No speech detected for Person ${speaker}.`
                : audioRes.error
            );
            return;
          }
        }
      }

      // 3. Fallback to client-side transcribed text only if genuine words were captured
      if (clientTranscript.length > 0) {
        await handleTwoWayTranslate(speaker, clientTranscript);
      } else {
        setErrorMessage(
          speaker === 'auto'
            ? 'No speech detected. Please speak closer to the microphone.'
            : `No speech detected for Person ${speaker}. Please speak closer to the microphone.`
        );
      }
    } catch (err: any) {
      console.error('Stop listening error:', err);
      setErrorMessage('Could not process speech. Please retry.');
    } finally {
      setIsTranslating(false);
      setTranslatingSpeaker(null);
      activeSpeakerRef.current = null;
      setActiveSpeaker(null);
    }
  };

  const handlePointerDownF2F = (speaker: 'A' | 'B') => {
    f2fPressStartTimeRef.current = Date.now();
    f2fHoldTriggeredRef.current = false;
  };

  const handlePointerUpF2F = (speaker: 'A' | 'B') => {
    const elapsed = Date.now() - f2fPressStartTimeRef.current;
    if (elapsed > 450 && activeSpeaker === speaker) {
      f2fHoldTriggeredRef.current = true;
      stopListening(speaker);
    }
  };

  const handleClickF2F = (speaker: 'A' | 'B') => {
    if (f2fHoldTriggeredRef.current) {
      f2fHoldTriggeredRef.current = false;
      return;
    }
    if (activeSpeaker === (speaker === 'A' ? 'B' : 'A')) return;
    activeSpeaker === speaker ? stopListening(speaker) : startListening(speaker);
  };

  const clearConversation = () => {
    setLatestMessageFromA(null);
    setLatestMessageFromB(null);
    setTranscriptA('');
    setTranscriptB('');
    setErrorMessage(null);
    stopSpeaking();
  };

  return (
    <div className="absolute inset-0 z-50 bg-slate-950 flex flex-col justify-between overflow-hidden select-none animate-fade-in">
      {/* ----------------- TOP HALF: PERSON A (Opposite Person) ----------------- */}
      <div
        className={`flex-1 flex flex-col justify-between p-3.5 bg-gradient-to-b from-slate-900 via-indigo-950/40 to-slate-950 border-b-2 border-indigo-500/40 relative transition-transform duration-300 ${
          rotateTop ? 'rotate-180' : ''
        }`}
      >
        {/* Person A Header info */}
        <div className="flex items-center justify-between">
          <button
            id="f2f-person-a-lang-btn"
            onClick={onOpenPersonALangSelector}
            className="flex items-center gap-2 bg-indigo-600/30 border border-indigo-500/50 hover:bg-indigo-600/50 text-indigo-100 px-3 py-1.5 rounded-full text-xs font-bold shadow-md transition-all active:scale-95"
          >
            <span className="text-lg">{personALang.flag}</span>
            <span>{personALang.code === 'auto' ? 'Auto Detect' : personALang.name}</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowInputA(!showInputA)}
              className="text-[11px] px-2.5 py-1 rounded-full bg-slate-800 text-indigo-300 border border-slate-700 hover:text-white"
            >
              {showInputA ? 'Close' : '⌨️ Type'}
            </button>
            <div className="text-[10px] font-bold uppercase tracking-wider text-indigo-300 px-2 py-0.5 rounded bg-indigo-950/80 border border-indigo-500/40 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
              <span>Person A (Partner)</span>
            </div>
          </div>
        </div>

        {/* Person A Manual Keyboard Input Drawer */}
        {showInputA && (
          <div className="my-1 p-2 bg-slate-900 border border-indigo-500/40 rounded-2xl flex items-center gap-2 z-20">
            <input
              type="text"
              value={manualInputA}
              onChange={e => setManualInputA(e.target.value)}
              onKeyDown={e => {
                if (e.key === 'Enter' && manualInputA.trim()) {
                  handleTwoWayTranslate('A', manualInputA);
                }
              }}
              placeholder={`Type in ${personALang.name}...`}
              className="flex-1 bg-transparent px-2 text-xs text-white placeholder:text-slate-500 focus:outline-none"
            />
            <button
              onClick={() => handleTwoWayTranslate('A', manualInputA)}
              disabled={!manualInputA.trim() || isTranslating}
              className="px-3 py-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold"
            >
              Send
            </button>
          </div>
        )}

        {/* Person A Text Display */}
        <div className="my-auto py-1 text-center space-y-2">
          {activeSpeaker === 'A' || (activeSpeaker === 'auto' && transcriptA) ? (
            <div className="space-y-2">
              <div className="flex items-center justify-center gap-1.5 text-xs text-rose-400 font-bold uppercase tracking-wider">
                <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
                <span>Listening to Person A... Speak now</span>
              </div>
              <p className="text-2xl font-bold text-white tracking-wide">
                {transcriptA || 'Speak clearly now...'}
              </p>
              {/* Animated Volume Wave */}
              <div className="flex items-center justify-center gap-1 h-6 max-w-xs mx-auto">
                {[20, 50, 80, 40, 70, 100, 60, 90, 30].map((h, i) => (
                  <span
                    key={i}
                    className="w-1.5 bg-indigo-400 rounded-full transition-all duration-75"
                    style={{
                      height: `${Math.max(15, Math.min(100, (volumeA > 5 ? volumeA : 25) * (1 + (i % 3) * 0.3)))}%`,
                    }}
                  />
                ))}
              </div>
            </div>
          ) : isTranslating && (translatingSpeaker === 'A' || (translatingSpeaker === 'auto' && !latestMessageFromA)) ? (
            <div className="flex flex-col items-center justify-center gap-1.5 text-indigo-300 py-2">
              <div className="flex items-center gap-2">
                <Loader2 className="w-5 h-5 animate-spin text-indigo-400" />
                <span className="text-sm font-semibold">Gemini detecting language & translating...</span>
              </div>
              <span className="text-[11px] text-indigo-400/80">Processing Person A's speech</span>
            </div>
          ) : latestMessageFromA ? (
            <div className="space-y-1">
              <p className="text-xl font-extrabold text-white tracking-wide">
                "{latestMessageFromA.original}"
              </p>
              <div className="flex items-center justify-center gap-2 text-sm text-indigo-300 font-semibold">
                <span>↓ "{latestMessageFromA.translated}"</span>
                {latestMessageFromA.detectedLang && (
                  <span className="text-[9px] bg-slate-800 text-indigo-200 px-1.5 py-0.5 rounded border border-indigo-500/30">
                    {latestMessageFromA.detectedLang}
                  </span>
                )}
              </div>
              {latestMessageFromA.pronunciation && (
                <p className="text-[11px] text-indigo-400/90 italic font-mono">
                  🗣 {latestMessageFromA.pronunciation}
                </p>
              )}
            </div>
          ) : (
            <div className="space-y-1 max-w-xs mx-auto">
              <p className="text-slate-300 text-sm font-semibold">
                👉 Tap microphone once to speak in {personALang.name}
              </p>
              <p className="text-[11px] text-slate-500">
                Auto detects language and translates to {personBLang.name}
              </p>
            </div>
          )}
        </div>

        {/* Person A Microphone Button & Controls */}
        <div className="flex flex-col items-center gap-1.5">
          <div className="flex items-center justify-center gap-4">
            {latestMessageFromA && (
              <button
                onClick={() => playAudio(latestMessageFromA.translated, personBLang.speechCode)}
                className="w-10 h-10 rounded-full bg-slate-800 border border-slate-700 text-indigo-300 flex items-center justify-center hover:bg-slate-700 active:scale-95 shadow-md"
                title="Replay translation"
              >
                <Volume2 className="w-4 h-4" />
              </button>
            )}

            <button
              id="f2f-mic-a-btn"
              onPointerDown={() => handlePointerDownF2F('A')}
              onPointerUp={() => handlePointerUpF2F('A')}
              onClick={() => handleClickF2F('A')}
              disabled={activeSpeaker === 'B'}
              className={`rounded-full flex flex-col items-center justify-center shadow-2xl transition-all duration-300 active:scale-90 cursor-pointer ${
                activeSpeaker === 'B'
                  ? 'opacity-40 cursor-not-allowed w-16 h-16 bg-slate-800 text-slate-500'
                  : activeSpeaker === 'A'
                  ? 'w-18 h-18 bg-rose-600 text-white ring-8 ring-rose-500/40 animate-pulse'
                  : 'w-16 h-16 bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/40 hover:scale-105'
              }`}
              title={
                isTranslating
                  ? 'Processing translation...'
                  : activeSpeaker === 'B'
                  ? 'Person B is currently speaking'
                  : activeSpeaker === 'A'
                  ? 'Tap or release to finish speaking'
                  : 'Tap or hold to speak as Person A'
              }
            >
              {isTranslating && translatingSpeaker === 'A' ? (
                <Loader2 className="w-7 h-7 animate-spin text-white" />
              ) : activeSpeaker === 'A' ? (
                <Square className="w-7 h-7 fill-white" />
              ) : (
                <Mic className="w-7 h-7" />
              )}
            </button>
          </div>
          <span className="text-[10px] text-slate-400 font-medium">
            {isTranslating && translatingSpeaker === 'A'
              ? 'Translating...'
              : activeSpeaker === 'A'
              ? `⏹ Stop (${recordingSeconds}s)`
              : '🎤 Person A Mic (Hold or Tap)'}
          </span>
        </div>
      </div>

      {/* ----------------- CENTER 2-WAY TOOLBAR & JOINT AUTO MIC ----------------- */}
      <div className="bg-slate-900 border-y border-slate-800 py-2 px-3 flex items-center justify-between text-xs text-slate-300 z-10">
        <div className="flex items-center gap-2">
          {/* Flip 180 toggle */}
          <button
            onClick={() => setRotateTop(!rotateTop)}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-full border transition-colors text-[11px] ${
              rotateTop
                ? 'bg-indigo-600/20 text-indigo-300 border-indigo-500/30 font-medium'
                : 'bg-slate-800 text-slate-400 border-slate-700'
            }`}
            title="Toggle 180° rotation for opposite person"
          >
            <RotateCw className="w-3.5 h-3.5" />
            <span>{rotateTop ? '180° Inverted' : 'Standard'}</span>
          </button>

          {/* Swap Languages */}
          <button
            onClick={onSwapLanguages}
            className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors text-[11px]"
            title="Swap speaker languages"
          >
            <ArrowLeftRight className="w-3.5 h-3.5 text-indigo-400" />
            <span>Swap</span>
          </button>
        </div>

        {/* Hands-free Auto Loop Button */}
        <button
          onClick={() => setAutoLoopMode(!autoLoopMode)}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold transition-all border ${
            autoLoopMode 
              ? 'bg-indigo-600 text-white border-indigo-400 shadow-md shadow-indigo-500/30 animate-pulse' 
              : 'bg-slate-800 text-slate-300 border-slate-700 hover:text-white'
          }`}
          title="Alternates and automatically listens for each speaker in turn"
        >
          <Repeat className="w-3.5 h-3.5" />
          <span>Hands-Free Loop: {autoLoopMode ? 'ON' : 'OFF'}</span>
        </button>

        <div className="flex items-center gap-1.5 sm:gap-2">
          {onSwitchToHandheld && (
            <button
              onClick={onSwitchToHandheld}
              className="flex items-center gap-1 px-2.5 py-1 bg-indigo-600/25 hover:bg-indigo-600/40 text-indigo-300 border border-indigo-500/40 rounded-full font-semibold transition-colors text-[11px]"
              title="Switch to Handheld single-user chat view"
            >
              <Smartphone className="w-3 h-3 text-indigo-400" />
              <span className="hidden sm:inline">Handheld View</span>
              <span className="sm:hidden">Handheld</span>
            </button>
          )}

          <button
            onClick={clearConversation}
            className="p-1.5 text-slate-400 hover:text-red-400 rounded-lg transition-colors"
            title="Clear dialogue"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>

          <button
            id="tabletop-back-btn"
            onClick={onClose}
            className="flex items-center gap-1 px-2.5 sm:px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 hover:border-slate-600 rounded-full font-semibold transition-all text-xs active:scale-95"
            title="Back to Dashboard (Esc)"
          >
            <ArrowLeft className="w-3.5 h-3.5 text-indigo-400" />
            <span className="hidden sm:inline">Back to Dashboard</span>
            <span className="sm:hidden">Back</span>
          </button>
        </div>
      </div>

      {/* Loop Notification Banner */}
      {loopBanner && (
        <div className="bg-indigo-950/80 border border-indigo-500/40 py-1.5 px-3 flex items-center justify-between text-xs text-indigo-200 z-20 animate-pulse">
          <div className="flex items-center gap-2">
            <Headphones className="w-3.5 h-3.5 text-indigo-400 animate-bounce" />
            <span className="font-bold">{loopBanner}</span>
          </div>
          <button 
            onClick={() => setAutoLoopMode(false)}
            className="text-[10px] text-slate-400 hover:text-white underline"
          >
            Pause Loop
          </button>
        </div>
      )}

      {/* Permission alert if blocked */}
      {permissionBlocked && (
        <div className="bg-amber-950/90 border border-amber-500 p-2.5 mx-3 rounded-xl flex items-center justify-between text-xs text-amber-200 z-30">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
            <span>Microphone blocked. Allow mic in browser settings, or use "⌨️ Type".</span>
          </div>
          <button
            onClick={() => startListening('B')}
            className="px-2.5 py-1 bg-amber-500 text-slate-950 font-bold rounded-lg shrink-0 text-xs"
          >
            Retry
          </button>
        </div>
      )}

      {errorMessage && !permissionBlocked && (
        <div className="bg-red-500/20 border border-red-500/40 px-3 py-1.5 mx-3 rounded-xl flex items-center justify-between text-xs text-red-200 z-30">
          <span>{errorMessage}</span>
          <button onClick={() => setErrorMessage(null)} className="text-red-300 hover:text-white font-bold ml-2">
            ✕
          </button>
        </div>
      )}

      {/* ----------------- BOTTOM HALF: PERSON B (Current User) ----------------- */}
      <div className="flex-1 flex flex-col justify-between p-3.5 bg-gradient-to-t from-slate-900 via-violet-950/40 to-slate-950 border-t-2 border-violet-500/40 relative">
        {/* Person B Header info */}
        <div className="flex items-center justify-between">
          <button
            id="f2f-person-b-lang-btn"
            onClick={onOpenPersonBLangSelector}
            className="flex items-center gap-2 bg-violet-600/30 border border-violet-500/50 hover:bg-violet-600/50 text-violet-100 px-3 py-1.5 rounded-full text-xs font-bold shadow-md transition-all active:scale-95"
          >
            <span className="text-lg">{personBLang.flag}</span>
            <span>{personBLang.name}</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowInputB(!showInputB)}
              className="text-[11px] px-2.5 py-1 rounded-full bg-slate-800 text-violet-300 border border-slate-700 hover:text-white"
            >
              {showInputB ? 'Close' : '⌨️ Type'}
            </button>
            <div className="text-[10px] font-bold uppercase tracking-wider text-violet-300 px-2 py-0.5 rounded bg-violet-950/80 border border-violet-500/40 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-violet-400" />
              <span>Person B (You)</span>
            </div>
          </div>
        </div>

        {/* Person B Manual Keyboard Input Drawer */}
        {showInputB && (
          <div className="my-1 p-2 bg-slate-900 border border-violet-500/40 rounded-2xl flex items-center gap-2 z-20">
            <input
              type="text"
              value={manualInputB}
              onChange={e => setManualInputB(e.target.value)}
              onKeyDown={e => {
                if (e.key === 'Enter' && manualInputB.trim()) {
                  handleTwoWayTranslate('B', manualInputB);
                }
              }}
              placeholder={`Type in ${personBLang.name}...`}
              className="flex-1 bg-transparent px-2 text-xs text-white placeholder:text-slate-500 focus:outline-none"
            />
            <button
              onClick={() => handleTwoWayTranslate('B', manualInputB)}
              disabled={!manualInputB.trim() || isTranslating}
              className="px-3 py-1 bg-violet-600 hover:bg-violet-500 text-white rounded-xl text-xs font-bold"
            >
              Send
            </button>
          </div>
        )}

        {/* Person B Text Display */}
        <div className="my-auto py-1 text-center space-y-2">
          {activeSpeaker === 'B' || (activeSpeaker === 'auto' && transcriptB) ? (
            <div className="space-y-2">
              <div className="flex items-center justify-center gap-1.5 text-xs text-rose-400 font-bold uppercase tracking-wider">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
                <span>Listening to Person B... Speak now</span>
              </div>
              <p className="text-2xl font-bold text-white tracking-wide">
                {transcriptB || 'Speak clearly now...'}
              </p>
              {/* Animated Volume Wave */}
              <div className="flex items-center justify-center gap-1 h-6 max-w-xs mx-auto">
                {[20, 50, 80, 40, 70, 100, 60, 90, 30].map((h, i) => (
                  <span
                    key={i}
                    className="w-1.5 bg-violet-400 rounded-full transition-all duration-75"
                    style={{
                      height: `${Math.max(15, Math.min(100, (volumeB > 5 ? volumeB : 25) * (1 + (i % 3) * 0.3)))}%`,
                    }}
                  />
                ))}
              </div>
            </div>
          ) : isTranslating && (translatingSpeaker === 'B' || (translatingSpeaker === 'auto' && !latestMessageFromB)) ? (
            <div className="flex flex-col items-center justify-center gap-1.5 text-violet-300 py-2">
              <div className="flex items-center gap-2">
                <Loader2 className="w-5 h-5 animate-spin text-violet-400" />
                <span className="text-sm font-semibold">Gemini detecting language & translating...</span>
              </div>
              <span className="text-[11px] text-violet-400/80">Processing Person B's speech</span>
            </div>
          ) : latestMessageFromB ? (
            <div className="space-y-1">
              <p className="text-xl font-extrabold text-white tracking-wide">
                "{latestMessageFromB.original}"
              </p>
              <div className="flex items-center justify-center gap-2 text-sm text-violet-300 font-semibold">
                <span>↓ "{latestMessageFromB.translated}"</span>
                {latestMessageFromB.detectedLang && (
                  <span className="text-[9px] bg-slate-800 text-violet-200 px-1.5 py-0.5 rounded border border-violet-500/30">
                    {latestMessageFromB.detectedLang}
                  </span>
                )}
              </div>
              {latestMessageFromB.pronunciation && (
                <p className="text-[11px] text-violet-400/90 italic font-mono">
                  🗣 {latestMessageFromB.pronunciation}
                </p>
              )}
            </div>
          ) : (
            <div className="space-y-1 max-w-xs mx-auto">
              <p className="text-slate-300 text-sm font-semibold">
                👉 Tap the microphone once to speak in {personBLang.name}
              </p>
              <p className="text-[11px] text-slate-500">
                Auto detects language and translates to {personALang.name}
              </p>
            </div>
          )}
        </div>

        {/* Person B Microphone Button & Controls */}
        <div className="flex flex-col items-center gap-1.5">
          <div className="flex items-center justify-center gap-4">
            {latestMessageFromB && (
              <button
                onClick={() => playAudio(latestMessageFromB.translated, personALang.speechCode)}
                className="w-10 h-10 rounded-full bg-slate-800 border border-slate-700 text-violet-300 flex items-center justify-center hover:bg-slate-700 active:scale-95 shadow-md"
                title="Replay translation"
              >
                <Volume2 className="w-4 h-4" />
              </button>
            )}

            <button
              id="f2f-mic-b-btn"
              onPointerDown={() => handlePointerDownF2F('B')}
              onPointerUp={() => handlePointerUpF2F('B')}
              onClick={() => handleClickF2F('B')}
              disabled={activeSpeaker === 'A'}
              className={`rounded-full flex flex-col items-center justify-center shadow-2xl transition-all duration-300 active:scale-90 cursor-pointer ${
                activeSpeaker === 'A'
                  ? 'opacity-40 cursor-not-allowed w-16 h-16 bg-slate-800 text-slate-500'
                  : activeSpeaker === 'B'
                  ? 'w-18 h-18 bg-rose-600 text-white ring-8 ring-rose-500/40 animate-pulse'
                  : 'w-16 h-16 bg-violet-600 hover:bg-violet-500 text-white shadow-violet-600/40 hover:scale-105'
              }`}
              title={
                isTranslating
                  ? 'Processing translation...'
                  : activeSpeaker === 'A'
                  ? 'Person A is currently speaking'
                  : activeSpeaker === 'B'
                  ? 'Tap or release to finish speaking'
                  : 'Tap or hold to speak as Person B'
              }
            >
              {isTranslating && translatingSpeaker === 'B' ? (
                <Loader2 className="w-7 h-7 animate-spin text-white" />
              ) : activeSpeaker === 'B' ? (
                <Square className="w-7 h-7 fill-white" />
              ) : (
                <Mic className="w-7 h-7" />
              )}
            </button>
          </div>
          <span className="text-[10px] text-slate-400 font-medium">
            {isTranslating && translatingSpeaker === 'B'
              ? 'Translating...'
              : activeSpeaker === 'B'
              ? `⏹ Stop (${recordingSeconds}s)`
              : '🎤 Person B Mic (Hold or Tap)'}
          </span>
        </div>
      </div>
    </div>
  );
};
