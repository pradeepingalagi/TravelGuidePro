import React, { useState, useEffect } from 'react';
import { Language, TranslationRecord, VoiceSettings } from '../types';
import { LiveVoiceScreen } from './LiveVoiceScreen';
import { FaceToFaceScreen } from './FaceToFaceScreen';

export type ConversationMode = 'handheld' | 'tabletop';

interface ConversationScreenProps {
  sourceLang: Language;
  targetLang: Language;
  onOpenSourceSelector: () => void;
  onOpenTargetSelector: () => void;
  onSwapLanguages: () => void;
  voiceSettings: VoiceSettings;
  onAddTranslation: (record: TranslationRecord) => void;
  isOffline: boolean;
  initialMode?: ConversationMode;
  onModeChange?: (mode: ConversationMode) => void;
  onClose?: () => void;
}

export const ConversationScreen: React.FC<ConversationScreenProps> = ({
  sourceLang,
  targetLang,
  onOpenSourceSelector,
  onOpenTargetSelector,
  onSwapLanguages,
  voiceSettings,
  onAddTranslation,
  isOffline,
  initialMode = 'handheld',
  onModeChange,
  onClose,
}) => {
  const [mode, setMode] = useState<ConversationMode>(initialMode);

  useEffect(() => {
    if (initialMode && initialMode !== mode) {
      setMode(initialMode);
    }
  }, [initialMode]);

  const handleModeChange = (newMode: ConversationMode) => {
    setMode(newMode);
    onModeChange?.(newMode);
  };

  if (mode === 'tabletop') {
    return (
      <FaceToFaceScreen
        personALang={sourceLang}
        personBLang={targetLang}
        onOpenPersonALangSelector={onOpenSourceSelector}
        onOpenPersonBLangSelector={onOpenTargetSelector}
        onSwapLanguages={onSwapLanguages}
        voiceSettings={voiceSettings}
        onAddTranslation={onAddTranslation}
        onClose={() => {
          handleModeChange('handheld');
          if (onClose) onClose();
        }}
        onSwitchToHandheld={() => handleModeChange('handheld')}
      />
    );
  }

  return (
    <LiveVoiceScreen
      sourceLang={sourceLang}
      targetLang={targetLang}
      onOpenSourceSelector={onOpenSourceSelector}
      onOpenTargetSelector={onOpenTargetSelector}
      onSwapLanguages={onSwapLanguages}
      voiceSettings={voiceSettings}
      onAddTranslation={onAddTranslation}
      isOffline={isOffline}
      onSwitchToTabletop={() => handleModeChange('tabletop')}
    />
  );
};
