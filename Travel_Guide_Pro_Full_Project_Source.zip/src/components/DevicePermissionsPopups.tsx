import React, { useState } from 'react';
import { 
  Mic, 
  MapPin, 
  Camera, 
  CheckCircle2, 
  XCircle, 
  Loader2, 
  ShieldCheck, 
  Sparkles, 
  ArrowRight,
  Upload,
  X
} from 'lucide-react';
import { 
  requestMicrophoneAccess, 
  requestLocationAccess, 
  requestCameraAccess 
} from '../utils/permissions';

// --- MICROPHONE PERMISSION POPUP ---
interface MicrophonePermissionPopupProps {
  isOpen: boolean;
  onAllowed: () => void;
  onSkipped: () => void;
}

export const MicrophonePermissionPopup: React.FC<MicrophonePermissionPopupProps> = ({
  isOpen,
  onAllowed,
  onSkipped,
}) => {
  const [loading, setLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [isSuccess, setIsSuccess] = useState<boolean | null>(null);

  if (!isOpen) return null;

  const handleAllow = async () => {
    setLoading(true);
    setStatusMessage(null);
    try {
      const res = await requestMicrophoneAccess();
      if (res.granted) {
        setIsSuccess(true);
        setStatusMessage('Microphone access granted!');
        setTimeout(() => {
          onAllowed();
        }, 700);
      } else {
        setIsSuccess(false);
        setStatusMessage(res.error || 'Microphone access was denied.');
        setTimeout(() => {
          onSkipped();
        }, 1500);
      }
    } catch (err: any) {
      setIsSuccess(false);
      setStatusMessage('Could not request microphone access.');
      setTimeout(() => {
        onSkipped();
      }, 1500);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-fade-in">
      <div className="w-full max-w-sm bg-slate-900 border border-indigo-500/30 rounded-3xl shadow-2xl overflow-hidden p-6 text-center relative animate-scale-up">
        {/* Glow indicator */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-1 bg-gradient-to-r from-transparent via-indigo-500 to-transparent" />

        {/* Icon */}
        <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-tr from-indigo-600 to-blue-500 p-0.5 shadow-lg shadow-indigo-600/30 flex items-center justify-center">
          <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center text-indigo-400">
            <Mic className="w-8 h-8 animate-pulse" />
          </div>
        </div>

        {/* Step Indicator */}
        <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-indigo-500/15 border border-indigo-500/30 text-indigo-300 text-[11px] font-bold mb-2">
          <span>Step 1 of 2</span>
          <span>•</span>
          <span>Audio Input</span>
        </div>

        {/* Title */}
        <h3 className="text-lg font-black text-white tracking-tight mb-2">
          Allow Microphone Access
        </h3>

        {/* Description */}
        <p className="text-xs text-slate-300 leading-relaxed mb-5">
          Omni Translate uses your microphone for real-time 2-way voice conversation and instant language detection.
        </p>

        {/* Key Points */}
        <div className="bg-slate-950/60 border border-slate-800/80 rounded-2xl p-3 text-left space-y-2 mb-5">
          <div className="flex items-center gap-2 text-xs text-slate-300">
            <div className="w-5 h-5 rounded-full bg-emerald-500/15 text-emerald-400 flex items-center justify-center shrink-0">
              ✓
            </div>
            <span>Auto-detects spoken languages automatically</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-slate-300">
            <div className="w-5 h-5 rounded-full bg-emerald-500/15 text-emerald-400 flex items-center justify-center shrink-0">
              ✓
            </div>
            <span>Two-way voice translation for both speakers</span>
          </div>
        </div>

        {/* Status Message */}
        {statusMessage && (
          <div className={`p-2.5 rounded-xl text-xs font-semibold mb-4 flex items-center justify-center gap-2 ${
            isSuccess 
              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' 
              : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
          }`}>
            {isSuccess ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <XCircle className="w-4 h-4 text-rose-400" />}
            <span>{statusMessage}</span>
          </div>
        )}

        {/* Actions */}
        <div className="space-y-2">
          <button
            id="allow-microphone-popup-btn"
            onClick={handleAllow}
            disabled={loading}
            className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white font-bold text-sm shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition-all active:scale-[0.98] disabled:opacity-50"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Requesting Access...</span>
              </>
            ) : (
              <>
                <Mic className="w-4 h-4" />
                <span>Allow Microphone Access</span>
              </>
            )}
          </button>

          <button
            id="skip-microphone-popup-btn"
            onClick={onSkipped}
            disabled={loading}
            className="w-full py-2 px-3 text-xs text-slate-400 hover:text-slate-200 transition-colors font-medium"
          >
            Maybe Later
          </button>
        </div>
      </div>
    </div>
  );
};


// --- LOCATION PERMISSION POPUP ---
interface LocationPermissionPopupProps {
  isOpen: boolean;
  onAllowed: () => void;
  onSkipped: () => void;
}

export const LocationPermissionPopup: React.FC<LocationPermissionPopupProps> = ({
  isOpen,
  onAllowed,
  onSkipped,
}) => {
  const [loading, setLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [isSuccess, setIsSuccess] = useState<boolean | null>(null);

  if (!isOpen) return null;

  const handleAllow = async () => {
    setLoading(true);
    setStatusMessage(null);
    try {
      const res = await requestLocationAccess();
      if (res.granted) {
        setIsSuccess(true);
        setStatusMessage('Location access granted!');
        setTimeout(() => {
          onAllowed();
        }, 700);
      } else {
        setIsSuccess(false);
        setStatusMessage(res.error || 'Location access was denied.');
        setTimeout(() => {
          onSkipped();
        }, 1500);
      }
    } catch (err: any) {
      setIsSuccess(false);
      setStatusMessage('Could not request location access.');
      setTimeout(() => {
        onSkipped();
      }, 1500);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-fade-in">
      <div className="w-full max-w-sm bg-slate-900 border border-emerald-500/30 rounded-3xl shadow-2xl overflow-hidden p-6 text-center relative animate-scale-up">
        {/* Glow indicator */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-1 bg-gradient-to-r from-transparent via-emerald-500 to-transparent" />

        {/* Icon */}
        <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 p-0.5 shadow-lg shadow-emerald-600/30 flex items-center justify-center">
          <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center text-emerald-400">
            <MapPin className="w-8 h-8 animate-bounce" />
          </div>
        </div>

        {/* Step Indicator */}
        <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-[11px] font-bold mb-2">
          <span>Step 2 of 2</span>
          <span>•</span>
          <span>Regional Context</span>
        </div>

        {/* Title */}
        <h3 className="text-lg font-black text-white tracking-tight mb-2">
          Allow Location Access
        </h3>

        {/* Description */}
        <p className="text-xs text-slate-300 leading-relaxed mb-5">
          Allow location to automatically detect your country and region, suggest local spoken languages, and provide emergency SOS contacts.
        </p>

        {/* Key Points */}
        <div className="bg-slate-950/60 border border-slate-800/80 rounded-2xl p-3 text-left space-y-2 mb-5">
          <div className="flex items-center gap-2 text-xs text-slate-300">
            <div className="w-5 h-5 rounded-full bg-emerald-500/15 text-emerald-400 flex items-center justify-center shrink-0">
              ✓
            </div>
            <span>Auto-suggests local country languages</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-slate-300">
            <div className="w-5 h-5 rounded-full bg-emerald-500/15 text-emerald-400 flex items-center justify-center shrink-0">
              ✓
            </div>
            <span>Pre-loads local police, ambulance & embassy numbers</span>
          </div>
        </div>

        {/* Status Message */}
        {statusMessage && (
          <div className={`p-2.5 rounded-xl text-xs font-semibold mb-4 flex items-center justify-center gap-2 ${
            isSuccess 
              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' 
              : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
          }`}>
            {isSuccess ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <XCircle className="w-4 h-4 text-rose-400" />}
            <span>{statusMessage}</span>
          </div>
        )}

        {/* Actions */}
        <div className="space-y-2">
          <button
            id="allow-location-popup-btn"
            onClick={handleAllow}
            disabled={loading}
            className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-sm shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2 transition-all active:scale-[0.98] disabled:opacity-50"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Requesting Access...</span>
              </>
            ) : (
              <>
                <MapPin className="w-4 h-4" />
                <span>Allow Location Access</span>
              </>
            )}
          </button>

          <button
            id="skip-location-popup-btn"
            onClick={onSkipped}
            disabled={loading}
            className="w-full py-2 px-3 text-xs text-slate-400 hover:text-slate-200 transition-colors font-medium"
          >
            Maybe Later
          </button>
        </div>
      </div>
    </div>
  );
};


// --- CAMERA PERMISSION POPUP (Appears when clicking Camera Translate) ---
interface CameraPermissionPopupProps {
  isOpen: boolean;
  onAllowed: () => void;
  onUploadPhoto: () => void;
  onCancel: () => void;
}

export const CameraPermissionPopup: React.FC<CameraPermissionPopupProps> = ({
  isOpen,
  onAllowed,
  onUploadPhoto,
  onCancel,
}) => {
  const [loading, setLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [isSuccess, setIsSuccess] = useState<boolean | null>(null);

  if (!isOpen) return null;

  const handleAllow = async () => {
    setLoading(true);
    setStatusMessage(null);
    try {
      const res = await requestCameraAccess();
      if (res.granted) {
        setIsSuccess(true);
        setStatusMessage('Camera access granted!');
        setTimeout(() => {
          onAllowed();
        }, 600);
      } else {
        setIsSuccess(false);
        setStatusMessage(res.error || 'Camera access was denied.');
      }
    } catch (err: any) {
      setIsSuccess(false);
      setStatusMessage('Could not request camera access.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-fade-in">
      <div className="w-full max-w-sm bg-slate-900 border border-teal-500/30 rounded-3xl shadow-2xl overflow-hidden p-6 text-center relative animate-scale-up">
        {/* Close Button */}
        <button
          onClick={onCancel}
          className="absolute top-4 right-4 p-1 text-slate-400 hover:text-white rounded-full hover:bg-slate-800 transition-colors"
          title="Cancel"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Glow indicator */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-1 bg-gradient-to-r from-transparent via-teal-500 to-transparent" />

        {/* Icon */}
        <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-tr from-teal-600 to-emerald-500 p-0.5 shadow-lg shadow-teal-600/30 flex items-center justify-center">
          <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center text-teal-400">
            <Camera className="w-8 h-8" />
          </div>
        </div>

        {/* Badge */}
        <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-teal-500/15 border border-teal-500/30 text-teal-300 text-[11px] font-bold mb-2">
          <span>Camera Translate</span>
          <span>•</span>
          <span>Visual OCR</span>
        </div>

        {/* Title */}
        <h3 className="text-lg font-black text-white tracking-tight mb-2">
          Allow Camera Access
        </h3>

        {/* Description */}
        <p className="text-xs text-slate-300 leading-relaxed mb-5">
          Omni Translate needs camera access to scan foreign signs, street menus, notices, and documents in real-time.
        </p>

        {/* Key Points */}
        <div className="bg-slate-950/60 border border-slate-800/80 rounded-2xl p-3 text-left space-y-2 mb-5">
          <div className="flex items-center gap-2 text-xs text-slate-300">
            <div className="w-5 h-5 rounded-full bg-teal-500/15 text-teal-400 flex items-center justify-center shrink-0">
              ✓
            </div>
            <span>Instant optical text detection & AR translation overlay</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-slate-300">
            <div className="w-5 h-5 rounded-full bg-teal-500/15 text-teal-400 flex items-center justify-center shrink-0">
              ✓
            </div>
            <span>Translates menus, labels, subway & traffic boards</span>
          </div>
        </div>

        {/* Status Message */}
        {statusMessage && (
          <div className={`p-2.5 rounded-xl text-xs font-semibold mb-4 flex items-center justify-center gap-2 ${
            isSuccess 
              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' 
              : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
          }`}>
            {isSuccess ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <XCircle className="w-4 h-4 text-rose-400" />}
            <span>{statusMessage}</span>
          </div>
        )}

        {/* Actions */}
        <div className="space-y-2">
          <button
            id="allow-camera-popup-btn"
            onClick={handleAllow}
            disabled={loading}
            className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white font-bold text-sm shadow-lg shadow-teal-600/30 flex items-center justify-center gap-2 transition-all active:scale-[0.98] disabled:opacity-50"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Requesting Camera...</span>
              </>
            ) : (
              <>
                <Camera className="w-4 h-4" />
                <span>Allow Camera Access</span>
              </>
            )}
          </button>

          <button
            id="upload-photo-instead-btn"
            onClick={onUploadPhoto}
            disabled={loading}
            className="w-full py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-all flex items-center justify-center gap-1.5"
          >
            <Upload className="w-3.5 h-3.5 text-teal-400" />
            <span>Upload Photo Instead</span>
          </button>

          <button
            id="cancel-camera-popup-btn"
            onClick={onCancel}
            disabled={loading}
            className="w-full py-1.5 px-3 text-xs text-slate-400 hover:text-slate-200 transition-colors font-medium"
          >
            Back to Dashboard
          </button>
        </div>
      </div>
    </div>
  );
};
