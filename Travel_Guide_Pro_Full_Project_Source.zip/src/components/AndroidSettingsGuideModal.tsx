import React, { useState } from 'react';
import { Settings, CheckCircle2, X, RefreshCw, Smartphone, ShieldCheck, MapPin, Mic, Camera, Globe, Lock } from 'lucide-react';

interface AndroidSettingsGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  onVerify?: () => void;
  targetFeature?: 'Location' | 'Microphone' | 'Camera' | 'All';
}

export const AndroidSettingsGuideModal: React.FC<AndroidSettingsGuideModalProps> = ({
  isOpen,
  onClose,
  onVerify,
  targetFeature = 'All',
}) => {
  const [guideMode, setGuideMode] = useState<'browser' | 'app'>('browser');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/85 backdrop-blur-md p-3 sm:p-4 select-none animate-fade-in">
      <div className="w-full max-w-md bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center shrink-0">
              <Settings className="w-5 h-5 animate-spin-slow" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-white">
                How to Unblock Permissions
              </h3>
              <p className="text-[11px] text-amber-300 font-medium">
                Enable {targetFeature === 'All' ? 'Location, Mic & Camera' : targetFeature}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors cursor-pointer"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Browser vs Installed App Toggle Pills */}
        <div className="p-3 bg-slate-950/60 border-b border-slate-800 flex items-center gap-2">
          <button
            onClick={() => setGuideMode('browser')}
            className={`flex-1 py-1.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              guideMode === 'browser'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>Samsung Browser / Chrome</span>
          </button>

          <button
            onClick={() => setGuideMode('app')}
            className={`flex-1 py-1.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              guideMode === 'app'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Phone Settings (Installed App)</span>
          </button>
        </div>

        {/* Body Steps */}
        <div className="p-4 sm:p-5 space-y-3.5 overflow-y-auto text-xs text-slate-200">
          {guideMode === 'browser' ? (
            <div className="space-y-2.5">
              <p className="text-slate-300 leading-relaxed">
                In Samsung Internet or Chrome, Android blocks access once dismissed. Unblock in <strong>2 taps</strong>:
              </p>

              {/* Step 1 */}
              <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-2xl flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-indigo-600/30 text-indigo-300 font-bold flex items-center justify-center text-xs shrink-0 mt-0.5 border border-indigo-500/30">
                  1
                </span>
                <div>
                  <div className="font-bold text-slate-100 flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-teal-400" />
                    <span>Tap the Lock 🔒 icon in the URL bar</span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Look at the top or bottom URL bar. Tap the <strong>lock icon 🔒</strong> (or <em>view site info</em>) right next to the web address.
                  </div>
                </div>
              </div>

              {/* Step 2 */}
              <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-2xl flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-indigo-600/30 text-indigo-300 font-bold flex items-center justify-center text-xs shrink-0 mt-0.5 border border-indigo-500/30">
                  2
                </span>
                <div>
                  <div className="font-bold text-slate-100">Tap "Permissions" or "Site Settings"</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Tap on <strong>Permissions</strong> in the popup window.
                  </div>
                </div>
              </div>

              {/* Step 3 */}
              <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-2xl flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-indigo-600/30 text-indigo-300 font-bold flex items-center justify-center text-xs shrink-0 mt-0.5 border border-indigo-500/30">
                  3
                </span>
                <div>
                  <div className="font-bold text-slate-100">Toggle Location, Microphone & Camera to ON</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Switch <strong>Location</strong>, <strong>Microphone</strong>, and <strong>Camera</strong> from <em>Blocked</em> to <span className="text-emerald-400 font-bold">Allowed</span>.
                  </div>
                </div>
              </div>

              {/* Step 4 */}
              <div className="p-3 bg-slate-950/80 border border-emerald-500/30 rounded-2xl flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-emerald-600/30 text-emerald-300 font-bold flex items-center justify-center text-xs shrink-0 mt-0.5 border border-emerald-500/30">
                  4
                </span>
                <div>
                  <div className="font-bold text-emerald-300">Reload &amp; Verify</div>
                  <div className="text-[11px] text-slate-300 mt-0.5">
                    Refresh the page or tap <strong>Verify Permissions</strong> below.
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-2.5">
              <p className="text-slate-300 leading-relaxed">
                If running as an installed Android app or PWA:
              </p>

              <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-2xl flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-indigo-600/30 text-indigo-300 font-bold flex items-center justify-center text-xs shrink-0 mt-0.5 border border-indigo-500/30">
                  1
                </span>
                <div>
                  <div className="font-bold text-slate-100">Open your Phone Settings</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Swipe down on your screen and tap the gear ⚙️ icon.
                  </div>
                </div>
              </div>

              <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-2xl flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-indigo-600/30 text-indigo-300 font-bold flex items-center justify-center text-xs shrink-0 mt-0.5 border border-indigo-500/30">
                  2
                </span>
                <div>
                  <div className="font-bold text-slate-100">Go to Apps ➔ Travel Guide Pro</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Tap <strong>Apps</strong>, then tap <strong>Travel Guide Pro</strong> (or <em>Samsung Internet</em> if viewing in browser).
                  </div>
                </div>
              </div>

              <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-2xl flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-indigo-600/30 text-indigo-300 font-bold flex items-center justify-center text-xs shrink-0 mt-0.5 border border-indigo-500/30">
                  3
                </span>
                <div>
                  <div className="font-bold text-slate-100">Tap Permissions</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Set <strong>Location, Microphone, and Camera</strong> to <span className="text-emerald-400 font-semibold">"Allow only while using the app"</span>.
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className="p-2.5 bg-indigo-950/30 border border-indigo-500/20 rounded-xl text-[11px] text-slate-400 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Hardware sensors are active only while actively translating. Zero background tracking.</span>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-3.5 sm:p-4 border-t border-slate-800 bg-slate-950 flex items-center gap-2">
          <button
            onClick={onClose}
            className="flex-1 py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-colors cursor-pointer"
          >
            Close
          </button>
          {onVerify && (
            <button
              onClick={() => {
                onVerify();
                onClose();
              }}
              className="flex-1 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-emerald-600/30 transition-all active:scale-95 cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Verify Permissions</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
