import React, { useState } from 'react';
import { 
  Globe, 
  ShieldCheck, 
  User, 
  Sparkles, 
  CheckCircle2, 
  X, 
  FileText, 
  Lock, 
  AlertCircle,
  Loader2,
  Compass
} from 'lucide-react';
import { AuthUser } from '../types';
import { signInWithGoogleReal } from '../utils/firebaseAuth';

interface AuthScreenProps {
  onLogin: (user: AuthUser) => void;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({ onLogin }) => {
  const [showLegalModal, setShowLegalModal] = useState<'terms' | 'privacy' | null>(null);
  const [isSigningIn, setIsSigningIn] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const getSavedPrefs = () => {
    try {
      const saved = localStorage.getItem('omnitranslate_user_lang_prefs');
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      defaultUserLanguageCode: 'hi',
      preferredTranslationLanguageCode: 'en',
    };
  };

  const handleContinueWithGoogleClick = async () => {
    setErrorMessage(null);
    setIsSigningIn(true);
    try {
      const result = await signInWithGoogleReal(getSavedPrefs());
      if (result?.user) {
        onLogin(result.user);
      }
    } catch (error: any) {
      console.error('Real Google Sign-In error:', error);
      const code = error?.code || '';
      if (code === 'auth/popup-closed-by-user') {
        setErrorMessage('Sign-in cancelled: The Google account window was closed before completing.');
      } else if (code === 'auth/popup-blocked') {
        setErrorMessage('The Google Sign-In popup was blocked by your browser. Please allow popups for this site and try again.');
      } else if (code === 'auth/cancelled-popup-request') {
        setErrorMessage('A Google sign-in request is already in progress.');
      } else if (code === 'auth/network-request-failed') {
        setErrorMessage('Network error communicating with Google authentication servers.');
      } else {
        setErrorMessage(error?.message || 'Google Sign-In failed. Please try again.');
      }
    } finally {
      setIsSigningIn(false);
    }
  };

  const handleContinueAsGuest = () => {
    setIsSigningIn(true);
    setTimeout(() => {
      const guestUser: AuthUser = {
        id: `guest_${Date.now()}`,
        name: 'Guest Traveler',
        isGuest: true,
        provider: 'guest',
        loginTime: Date.now(),
        preferences: getSavedPrefs(),
      };
      setIsSigningIn(false);
      onLogin(guestUser);
    }, 200);
  };

  return (
    <div className="min-h-screen w-full bg-slate-950 text-slate-100 flex flex-col justify-between relative overflow-hidden select-none font-sans">
      {/* Ambient background glow accents */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-indigo-600/15 rounded-full blur-3xl pointer-events-none -translate-y-1/2" />
      <div className="absolute bottom-10 right-10 w-72 h-72 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top bar minimal branding */}
      <header className="w-full px-6 py-5 flex items-center justify-between z-10">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-slate-900 border border-teal-500/40 p-0.5 shadow-md shadow-teal-500/10 flex items-center justify-center shrink-0 overflow-hidden">
            <img src="/icon-192.png" alt="Travel Guide Pro" className="w-full h-full object-cover rounded-lg" />
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-bold tracking-tight text-white leading-tight">
              Travel Guide Pro
            </span>
            <span className="text-[10px] text-teal-300/90 font-medium tracking-normal">
              Translate. Explore. Navigate. Travel with confidence.
            </span>
          </div>
        </div>
        <div className="flex items-center gap-1.5 text-xs text-slate-400 bg-slate-900/80 px-2.5 py-1 rounded-full border border-slate-800">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span className="text-[11px] font-medium text-slate-300">Secure & Private</span>
        </div>
      </header>

      {/* Main hero & auth options container */}
      <main className="w-full max-w-md mx-auto px-5 py-4 flex flex-col items-center justify-center flex-1 z-10">
        {/* App Emblem & Visual Badge matching user branding screenshot */}
        <div className="relative mb-6">
          <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-3xl bg-[#0c2238] border-2 border-teal-400/40 p-1.5 shadow-2xl shadow-teal-500/20 flex items-center justify-center relative overflow-hidden group">
            {/* Ambient inner soft glow */}
            <div className="absolute inset-0 bg-gradient-to-tr from-teal-500/15 via-cyan-500/10 to-indigo-500/20 pointer-events-none" />
            <img src="/icon-512.png" alt="Travel Guide Pro" className="w-full h-full object-cover rounded-2xl relative z-10 shadow-lg group-hover:scale-105 transition-transform duration-300" />
          </div>
          <div className="absolute -bottom-2.5 -right-2 bg-gradient-to-r from-teal-400 to-emerald-400 text-slate-950 font-black text-[10px] px-2.5 py-0.5 rounded-full uppercase tracking-wider shadow-md flex items-center gap-1 border border-slate-900">
            <Sparkles className="w-2.5 h-2.5 text-slate-950 fill-current" />
            AI Guide
          </div>
        </div>

        {/* Title and Tagline exactly matching image */}
        <div className="text-center mb-7 sm:mb-8">
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight leading-tight">
            Travel Guide Pro
          </h1>
          <p className="text-base sm:text-lg text-sky-400 font-bold mt-1.5 tracking-tight">
            Travel Beyond Limits.
          </p>
          <p className="text-xs sm:text-sm text-teal-300 font-medium mt-1">
            Translate. Explore. Navigate. Travel with confidence.
          </p>
          <p className="text-xs text-slate-400 mt-3 max-w-xs mx-auto leading-relaxed">
            Where language stops being a barrier. Instant voice & camera translations, live currency radar, offline phrasebook, and 24/7 AI travel support.
          </p>
        </div>

        {/* Error notification banner if sign-in fails */}
        {errorMessage && (
          <div className="w-full mb-4 p-3.5 bg-rose-950/70 border border-rose-500/40 rounded-2xl flex items-start gap-3 text-rose-200 text-xs shadow-lg animate-fade-in">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-rose-100">Google Sign-In Alert</p>
              <p className="text-rose-200/90 mt-0.5 leading-relaxed">{errorMessage}</p>
            </div>
            <button 
              type="button"
              onClick={() => setErrorMessage(null)} 
              className="text-rose-400 hover:text-rose-100 p-1 cursor-pointer transition-colors"
              title="Dismiss"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Action Buttons Section */}
        <div className="w-full flex flex-col gap-3.5">
          {/* Button 1: [ Continue with Google ] */}
          <button
            id="auth-google-signin-btn"
            onClick={handleContinueWithGoogleClick}
            disabled={isSigningIn}
            className="w-full h-13 px-4 rounded-2xl bg-white hover:bg-slate-100 text-slate-900 font-semibold text-sm sm:text-base shadow-xl shadow-white/5 border border-slate-200 transition-all duration-200 flex items-center justify-center gap-3 active:scale-[0.98] disabled:opacity-60 cursor-pointer"
          >
            {isSigningIn ? (
              <div className="flex items-center gap-2.5 text-slate-800">
                <Loader2 className="w-5 h-5 animate-spin text-indigo-600" />
                <span className="tracking-tight font-bold">Connecting to Google...</span>
              </div>
            ) : (
              <>
                {/* Authentic Google 'G' multicolored icon */}
                <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24" aria-hidden="true">
                  <path
                    fill="#4285F4"
                    d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.17z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.34 24 12 24z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.16 0 9.94 0 12s.45 3.84 1.25 5.42l4.03-3.15z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.34 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                  />
                </svg>
                <span className="tracking-tight text-slate-800 font-bold">Continue with Google</span>
              </>
            )}
          </button>

          {/* Button 2: [ Continue as Guest ] */}
          <button
            id="auth-guest-signin-btn"
            onClick={handleContinueAsGuest}
            disabled={isSigningIn}
            className="w-full h-12 px-4 rounded-2xl bg-slate-900/90 hover:bg-slate-800/90 text-slate-200 hover:text-white font-medium text-sm sm:text-base border border-slate-800 transition-all duration-200 flex items-center justify-center gap-2.5 active:scale-[0.98] disabled:opacity-60 cursor-pointer"
          >
            <User className="w-4 h-4 text-slate-400" />
            <span>Continue as Guest</span>
          </button>
        </div>

        {/* Feature Highlights Pills */}
        <div className="grid grid-cols-2 gap-2 mt-6 w-full text-[11px] text-slate-400">
          <div className="flex items-center gap-2 bg-slate-900/50 border border-slate-800/60 px-3 py-2 rounded-xl">
            <CheckCircle2 className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
            <span className="truncate">100+ Live Languages</span>
          </div>
          <div className="flex items-center gap-2 bg-slate-900/50 border border-slate-800/60 px-3 py-2 rounded-xl">
            <CheckCircle2 className="w-3.5 h-3.5 text-teal-400 shrink-0" />
            <span className="truncate">Instant Voice & F2F</span>
          </div>
        </div>
      </main>

      {/* Footer Legal Section */}
      <footer className="w-full max-w-md mx-auto px-6 py-6 text-center z-10">
        <p className="text-xs text-slate-400 leading-relaxed">
          By continuing, you agree to our{' '}
          <button
            type="button"
            onClick={() => setShowLegalModal('terms')}
            className="text-indigo-400 hover:text-indigo-300 underline font-medium cursor-pointer transition-colors"
          >
            Terms
          </button>
          {' & '}
          <button
            type="button"
            onClick={() => setShowLegalModal('privacy')}
            className="text-indigo-400 hover:text-indigo-300 underline font-medium cursor-pointer transition-colors"
          >
            Privacy Policy
          </button>
          .
        </p>
      </footer>

      {/* =========================================================
          Legal Modals (Terms & Privacy Policy)
         ========================================================= */}
      {showLegalModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fade-in">
          <div 
            className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh] text-slate-200"
            role="dialog"
            aria-modal="true"
          >
            {/* Modal Header */}
            <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/95">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center">
                  {showLegalModal === 'terms' ? <FileText className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
                </div>
                <h3 className="text-base font-bold text-white">
                  {showLegalModal === 'terms' ? 'Terms of Service' : 'Privacy Policy'}
                </h3>
              </div>
              <button
                onClick={() => setShowLegalModal(null)}
                className="p-1.5 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
                title="Close"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 overflow-y-auto space-y-4 text-xs sm:text-sm text-slate-300 leading-relaxed">
              {showLegalModal === 'terms' ? (
                <>
                  <div className="p-3 rounded-2xl bg-indigo-950/40 border border-indigo-500/20 text-indigo-200 text-xs">
                    Last updated: September 2026. Welcome to Omni Translate. By using our application, you agree to these Terms.
                  </div>
                  <section className="space-y-1.5">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-100">1. Translation & AI Services</h4>
                    <p className="text-slate-400">
                      Travel Guide Pro provides AI-powered audio, camera OCR, and text translations for informational, travel, and conversational convenience. While our multimodal AI aims for maximum accuracy, translations may occasionally vary depending on ambient noise, accents, or idioms.
                    </p>
                  </section>
                  <section className="space-y-1.5">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-100">2. Medical & Emergency SOS Disclaimer</h4>
                    <p className="text-slate-400">
                      The emergency phrasebook and SOS features are designed to assist during travel. They do not replace certified emergency first responders, medical professionals, or official consular advice.
                    </p>
                  </section>
                  <section className="space-y-1.5">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-100">3. Acceptable Use</h4>
                    <p className="text-slate-400">
                      You agree not to use the service for unlawful surveillance, harassment, or violating wiretapping/recording privacy laws in jurisdictions requiring two-party consent.
                    </p>
                  </section>
                </>
              ) : (
                <>
                  <div className="p-3 rounded-2xl bg-emerald-950/40 border border-emerald-500/20 text-emerald-200 text-xs">
                    Your Privacy is Paramount. We prioritize on-device and ephemeral translation processing.
                  </div>
                  <section className="space-y-1.5">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-100">1. Audio & Microphone Data</h4>
                    <p className="text-slate-400">
                      Audio is recorded strictly while you tap or hold the microphone button. Spoken audio is converted into speech text or translated via secure multimodal Gemini endpoints. Spoken audio recordings are never sold, rented, or used for advertising.
                    </p>
                  </section>
                  <section className="space-y-1.5">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-100">2. Camera & OCR Processing</h4>
                    <p className="text-slate-400">
                      Camera translation inspects image frames for visible foreign text (such as street signs, menus, or receipts). Image data is processed ephemerally and is not saved to any external photo album without your consent.
                    </p>
                  </section>
                  <section className="space-y-1.5">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-100">3. Account & Local Storage</h4>
                    <p className="text-slate-400">
                      Your translation history and saved phrases are stored locally on your device in your browser's private storage. Guest mode stores no personal identity. Google Sign-In only uses your name and email to synchronize your session.
                    </p>
                  </section>
                </>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-slate-800 bg-slate-900/95 flex justify-end">
              <button
                onClick={() => setShowLegalModal(null)}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-sm transition-colors cursor-pointer"
              >
                I Understand
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
