import React, { useState, useMemo } from 'react';
import { Search, Check, X, Globe, ArrowLeft } from 'lucide-react';
import { Language, LanguageRegion } from '../types';
import { SUPPORTED_LANGUAGES, AUTO_DETECT_LANGUAGE, REGIONS } from '../data/languages';

interface LanguageSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedLanguage: Language;
  onSelectLanguage: (language: Language) => void;
  allowAutoDetect?: boolean;
  title?: string;
}

export const LanguageSelectorModal: React.FC<LanguageSelectorModalProps> = ({
  isOpen,
  onClose,
  selectedLanguage,
  onSelectLanguage,
  allowAutoDetect = true,
  title = 'Select Language',
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRegion, setSelectedRegion] = useState<LanguageRegion | 'all'>('all');

  const filteredLanguages = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    return SUPPORTED_LANGUAGES.filter(l => {
      // Region filter
      if (selectedRegion !== 'all' && l.region !== selectedRegion) {
        return false;
      }
      // Search filter
      if (!q) return true;
      return (
        l.name.toLowerCase().includes(q) ||
        l.nativeName.toLowerCase().includes(q) ||
        l.code.toLowerCase().includes(q) ||
        (l.region && l.region.toLowerCase().includes(q)) ||
        (l.script && l.script.toLowerCase().includes(q)) ||
        (l.description && l.description.toLowerCase().includes(q))
      );
    });
  }, [searchQuery, selectedRegion]);

  const indianLanguages = useMemo(() => {
    return SUPPORTED_LANGUAGES.filter(l => l.region === 'India');
  }, []);

  const popularLanguages = useMemo(() => {
    return SUPPORTED_LANGUAGES.filter(l => l.isPopular);
  }, []);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/75 backdrop-blur-md animate-fade-in p-0 sm:p-4">
      <div className="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col max-h-[88vh] overflow-hidden">
        {/* Modal Header */}
        <div className="p-3.5 sm:p-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/90 gap-2">
          <div className="flex items-center gap-2 sm:gap-2.5 min-w-0">
            <button
              onClick={onClose}
              className="sm:hidden p-1.5 -ml-1 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors shrink-0"
              title="Back"
              aria-label="Back"
            >
              <ArrowLeft className="w-5 h-5 text-indigo-400" />
            </button>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-bold text-slate-100 truncate">{title}</h3>
                <span className="text-[11px] px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 font-medium border border-indigo-500/30 shrink-0">
                  {SUPPORTED_LANGUAGES.length} Languages
                </span>
              </div>
              <p className="text-[11px] sm:text-xs text-slate-400 mt-0.5 truncate">
                All 22 Official Indian Languages & Global World Dialects
              </p>
            </div>
          </div>
          <button
            id="lang-modal-close-btn"
            onClick={onClose}
            className="flex items-center gap-1.5 px-2.5 py-1 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors text-xs font-semibold shrink-0"
            title="Close (Esc)"
          >
            <span className="hidden sm:inline">Close</span>
            <kbd className="hidden sm:inline-block text-[10px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded border border-slate-700 font-mono">Esc</kbd>
            <X className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>
        </div>

        {/* Search input */}
        <div className="p-3 border-b border-slate-800/80 bg-slate-900/50">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              id="lang-search-input"
              type="text"
              placeholder="Search language, script, or region (e.g. Kannada, Tamil, Español, বাংলা)..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-slate-800/90 border border-slate-700 rounded-xl pl-9 pr-4 py-2.5 text-sm text-slate-100 placeholder-slate-400 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-200 px-1.5 py-0.5 rounded bg-slate-700"
              >
                Clear
              </button>
            )}
          </div>
        </div>

        {/* Region Filter Chips (India, Europe, Asia, Middle East, Americas, Africa) */}
        <div className="px-3 py-2 border-b border-slate-800/80 bg-slate-950/40 overflow-x-auto no-scrollbar flex items-center gap-1.5">
          {REGIONS.map(reg => {
            const isActive = selectedRegion === reg.id;
            return (
              <button
                key={reg.id}
                id={`region-tab-${reg.id}`}
                onClick={() => setSelectedRegion(reg.id)}
                className={`whitespace-nowrap flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                    : 'bg-slate-800/70 text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-700/50'
                }`}
              >
                <span>{reg.icon}</span>
                <span>{reg.label}</span>
                {reg.id === 'India' && (
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${isActive ? 'bg-white/25 text-white' : 'bg-amber-500/20 text-amber-300'}`}>
                    22
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Scrollable Language List */}
        <div className="overflow-y-auto flex-1 p-2 divide-y divide-slate-800/50 space-y-1">
          {/* Auto Detect Option */}
          {allowAutoDetect && !searchQuery && selectedRegion === 'all' && (
            <div className="pb-2">
              <div className="px-3 py-1 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                Smart Detection
              </div>
              <button
                id="lang-option-auto"
                onClick={() => {
                  onSelectLanguage(AUTO_DETECT_LANGUAGE);
                  onClose();
                }}
                className={`w-full flex items-center justify-between p-3 rounded-xl transition-colors ${
                  selectedLanguage.code === 'auto'
                    ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/30 font-medium'
                    : 'hover:bg-slate-800 text-slate-200'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500/20 to-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-lg">
                    ✨
                  </div>
                  <div className="text-left">
                    <div className="font-semibold text-sm flex items-center gap-1.5 text-slate-100">
                      Auto Detect Language
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-semibold">AI</span>
                    </div>
                    <div className="text-xs text-slate-400">Listens and identifies speech automatically</div>
                  </div>
                </div>
                {selectedLanguage.code === 'auto' && <Check className="w-5 h-5 text-indigo-400" />}
              </button>
            </div>
          )}

          {/* Quick Highlight for All 22 Indian Languages when India tab is selected */}
          {selectedRegion === 'India' && !searchQuery && (
            <div className="py-2">
              <div className="px-3 py-1 text-[11px] font-semibold uppercase tracking-wider text-amber-400/90 flex items-center gap-1.5">
                <span>🇮🇳</span>
                <span>Constitution of India — 8th Schedule (All 22 Languages)</span>
              </div>
              <p className="px-3 text-xs text-slate-400 mb-2">
                Official languages of India with native scripts and regional speech recognition support.
              </p>
            </div>
          )}

          {/* Languages list */}
          <div className="pt-2">
            <div className="px-3 py-1 text-[11px] font-semibold uppercase tracking-wider text-slate-400 flex items-center justify-between">
              <span>
                {searchQuery
                  ? `Matching Languages (${filteredLanguages.length})`
                  : selectedRegion === 'all'
                  ? `All Languages (${filteredLanguages.length})`
                  : `${selectedRegion} (${filteredLanguages.length})`}
              </span>
            </div>
            <div className="space-y-1 mt-1">
              {filteredLanguages.map(lang => {
                const isSelected = selectedLanguage.code === lang.code;
                return (
                  <button
                    key={lang.code}
                    id={`lang-option-${lang.code}`}
                    onClick={() => {
                      onSelectLanguage(lang);
                      onClose();
                    }}
                    className={`w-full flex items-center justify-between p-3 rounded-xl transition-all ${
                      isSelected
                        ? 'bg-indigo-600/20 text-indigo-200 border border-indigo-500/40 shadow-sm'
                        : 'hover:bg-slate-800 text-slate-200 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-2xl shrink-0 drop-shadow-sm">{lang.flag}</span>
                      <div className="text-left">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-sm text-slate-100">{lang.name}</span>
                          {lang.region === 'India' && (
                            <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/15 text-amber-300 border border-amber-500/20">
                              IN
                            </span>
                          )}
                          {lang.isPopular && (
                            <span className="text-[10px] px-1.5 py-0.2 rounded bg-indigo-500/15 text-indigo-300">
                              Popular
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                          <span className="font-medium text-slate-300">{lang.nativeName}</span>
                          {lang.description && (
                            <>
                              <span>•</span>
                              <span className="text-slate-400 text-[11px] truncate max-w-[200px] sm:max-w-xs">
                                {lang.description}
                              </span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                    {isSelected && <Check className="w-5 h-5 text-indigo-400 shrink-0" />}
                  </button>
                );
              })}

              {filteredLanguages.length === 0 && (
                <div className="text-center py-10 px-4 text-slate-400 text-sm">
                  <Globe className="w-8 h-8 mx-auto text-slate-600 mb-2" />
                  <p className="font-medium text-slate-300">No languages found matching "{searchQuery}"</p>
                  <p className="text-xs text-slate-400 mt-1">Try searching by language name, native script, or region</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
