import React, { useState, useRef, useEffect } from 'react';
import { Settings, Wifi, WifiOff, ArrowLeft, User, LogOut, LogIn, ChevronDown, Languages, Sparkles, Shield, Compass } from 'lucide-react';
import { Language, AuthUser } from '../types';
import { PWAInstallButton } from './PWAInstallButton';

interface HeaderProps {
  sourceLang?: Language;
  targetLang?: Language;
  onOpenSourceSelector?: () => void;
  onOpenTargetSelector?: () => void;
  onSwapLanguages?: () => void;
  onOpenSettings: () => void;
  isOffline: boolean;
  onToggleOfflineMode?: () => void;
  currentScreenTitle?: string;
  onBack?: () => void;
  authUser?: AuthUser | null;
  onSignOut?: () => void;
  onOpenAuth?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenSettings,
  isOffline,
  onToggleOfflineMode,
  currentScreenTitle,
  onBack,
  authUser,
  onSignOut,
  onOpenAuth,
}) => {
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const userMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (userMenuRef.current && !userMenuRef.current.contains(e.target as Node)) {
        setIsUserMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className="fixed top-0 inset-x-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 text-white px-3 sm:px-4 py-2 sm:py-2.5 transition-all shadow-md">
      <div className="flex items-center justify-between gap-2 sm:gap-3 max-w-4xl mx-auto">
        {/* Left: App Brand or Back navigation */}
        <div className="flex items-center gap-2 sm:gap-3 min-w-0">
          {onBack ? (
            <div className="flex items-center gap-2 sm:gap-3 min-w-0">
              <button
                id="header-back-btn"
                onClick={onBack}
                className="flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-3 py-1.5 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700/80 hover:border-indigo-500/50 shadow-sm transition-all text-xs font-semibold group shrink-0 active:scale-[0.98] cursor-pointer"
                title="Go Back (Esc)"
                aria-label="Go Back"
              >
                <ArrowLeft className="w-4 h-4 text-indigo-400 group-hover:-translate-x-0.5 transition-transform" />
                <span className="hidden sm:inline">Back</span>
                <span className="sm:hidden">Back</span>
                <kbd className="hidden lg:inline-flex items-center justify-center text-[10px] bg-slate-900 text-slate-400 px-1.5 py-0.2 rounded border border-slate-700/80 font-mono ml-0.5">
                  Esc
                </kbd>
              </button>

              <div className="flex items-center gap-1.5 min-w-0">
                <span className="text-slate-600 hidden sm:inline">•</span>
                <span className="text-xs sm:text-sm font-bold text-white tracking-tight truncate max-w-[170px] sm:max-w-[320px]">
                  {currentScreenTitle || 'Travel Guide Pro'}
                </span>
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-2 sm:gap-2.5">
              <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-xl bg-slate-900 border border-teal-500/40 p-0.5 shadow-sm flex items-center justify-center shrink-0 overflow-hidden">
                <img src="/icon-192.png" alt="Travel Guide Pro" className="w-full h-full object-cover rounded-lg" />
              </div>
              <span className="text-base sm:text-lg font-black tracking-tight text-white whitespace-nowrap leading-none">
                Travel Guide Pro
              </span>
            </div>
          )}
        </div>

        {/* Right: Offline status, User Profile & Settings */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {/* PWA Install Action */}
          <PWAInstallButton compact={true} />

          {/* Offline Mode Indicator / Toggle */}
          {onToggleOfflineMode && (
            <button
              id="header-offline-toggle-btn"
              onClick={onToggleOfflineMode}
              className={`p-1.5 px-2.5 rounded-xl text-xs transition-colors flex items-center gap-1.5 ${
                isOffline
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800 border border-transparent'
              }`}
              title={isOffline ? 'Offline mode active (Tap to toggle)' : 'Online mode active (Tap to toggle)'}
            >
              {isOffline ? (
                <>
                  <WifiOff className="w-3.5 h-3.5 text-amber-400" />
                  <span className="text-[11px] font-semibold text-amber-300 hidden sm:inline">Offline</span>
                </>
              ) : (
                <>
                  <Wifi className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-[11px] font-medium text-slate-300 hidden sm:inline">Online</span>
                </>
              )}
            </button>
          )}

          {/* User Account Pill & Dropdown */}
          {authUser && (
            <div className="relative" ref={userMenuRef}>
              <button
                id="header-user-profile-btn"
                onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                className="flex items-center gap-1.5 p-1 pr-2 rounded-xl bg-slate-800 hover:bg-slate-700/90 border border-slate-700/80 transition-all text-xs active:scale-95 cursor-pointer"
                title={authUser.isGuest ? 'Guest User (Tap to manage)' : `${authUser.name} (${authUser.email})`}
              >
                {authUser.avatar ? (
                  <img
                    src={authUser.avatar}
                    alt={authUser.name}
                    className="w-6 h-6 rounded-lg object-cover ring-1 ring-indigo-400/30 shrink-0"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-6 h-6 rounded-lg bg-indigo-600/30 text-indigo-400 flex items-center justify-center shrink-0">
                    <User className="w-3.5 h-3.5" />
                  </div>
                )}
                <span className="hidden md:inline font-medium text-[11px] max-w-[90px] truncate text-slate-200">
                  {authUser.isGuest ? 'Guest' : authUser.name.split(' ')[0]}
                </span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </button>

              {/* User Dropdown Menu */}
              {isUserMenuOpen && (
                <div className="absolute right-0 mt-2 w-64 bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden py-1.5 z-50 animate-fade-in text-xs">
                  <div className="px-3.5 py-2.5 border-b border-slate-800 flex items-center gap-2.5">
                    {authUser.avatar ? (
                      <img
                        src={authUser.avatar}
                        alt={authUser.name}
                        className="w-9 h-9 rounded-full object-cover shrink-0 ring-1 ring-slate-700"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-9 h-9 rounded-full bg-slate-800 text-slate-300 flex items-center justify-center shrink-0">
                        <User className="w-5 h-5" />
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-slate-100 truncate">{authUser.name}</p>
                      <p className="text-[11px] text-slate-400 truncate">
                        {authUser.isGuest ? 'Guest Session' : authUser.email}
                      </p>
                    </div>
                  </div>

                  {authUser.isGuest && onOpenAuth && (
                    <button
                      onClick={() => {
                        setIsUserMenuOpen(false);
                        onOpenAuth();
                      }}
                      className="w-full px-3.5 py-2 text-left hover:bg-slate-800/80 text-indigo-300 hover:text-indigo-200 flex items-center gap-2 transition-colors font-medium cursor-pointer"
                    >
                      <LogIn className="w-4 h-4 text-indigo-400" />
                      <span>Sign in with Google</span>
                    </button>
                  )}

                  <button
                    onClick={() => {
                      setIsUserMenuOpen(false);
                      onOpenSettings();
                    }}
                    className="w-full px-3.5 py-2 text-left hover:bg-slate-800/80 text-slate-300 hover:text-white flex items-center gap-2 transition-colors font-medium text-xs cursor-pointer"
                  >
                    <Languages className="w-4 h-4 text-indigo-400" />
                    <span>Default Languages & Account</span>
                  </button>

                  {onSignOut && (
                    <button
                      id="header-signout-btn"
                      onClick={() => {
                        setIsUserMenuOpen(false);
                        onSignOut();
                      }}
                      className="w-full px-3.5 py-2 text-left hover:bg-rose-950/40 text-rose-400 hover:text-rose-300 flex items-center gap-2 transition-colors font-medium cursor-pointer"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>Sign Out / Switch Account</span>
                    </button>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Settings Button */}
          <button
            id="header-settings-btn"
            onClick={onOpenSettings}
            className="p-1.5 sm:p-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-xl transition-colors border border-transparent hover:border-slate-700 cursor-pointer"
            aria-label="Settings"
            title="Settings & Preferences"
          >
            <Settings className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
          </button>
        </div>
      </div>

      {/* Dedicated Tagline Row (Pulled to next line so it is never hidden or cut off) */}
      {!onBack && (
        <div className="max-w-4xl mx-auto pt-1 mt-1 border-t border-slate-800/80 flex items-center justify-between text-[11px] sm:text-xs text-teal-300 font-medium tracking-wide">
          <span className="truncate">
            Translate. Explore. Navigate. Travel with confidence.
          </span>
          <span className="text-[10px] text-slate-400 font-mono hidden sm:inline pl-2">
            AI Multimodal Companion
          </span>
        </div>
      )}
    </header>
  );
};


