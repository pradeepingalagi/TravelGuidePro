import React, { useState, useEffect, useRef } from 'react';
import { 
  Mic, 
  Volume2, 
  VolumeX, 
  RotateCcw, 
  ArrowLeftRight, 
  Sparkles, 
  AlertCircle, 
  Copy, 
  Check, 
  Volume1, 
  Send, 
  ShieldAlert, 
  RefreshCw, 
  Loader2, 
  Square,
  Repeat,
  Headphones,
  UserCheck,
  Smartphone,
  Users
} from 'lucide-react';
import { Language, TranslationRecord, VoiceSettings } from '../types';
import { 
  translateTwoWayApi, 
  translateTwoWayAudioApi,
  translateTextApi,
  translateAudioApi,
  getInstantLanguageDetection
} from '../services/translationService';
import { speakText, stopSpeaking } from '../utils/speech';
import { UnifiedVoiceRecorder } from '../utils/audioRecorder';
import { findLanguageByName } from '../data/languages';
import { requestMicrophoneAccess } from '../utils/permissions';

interface LiveVoiceScreenProps {
  sourceLang: Language; // User 1's preferred language
  targetLang: Language; // User 2's preferred language
  onOpenSourceSelector: () => void;
  onOpenTargetSelector: () => void;
  onSwapLanguages: () => void;
  voiceSettings: VoiceSettings;
  onAddTranslation: (record: TranslationRecord) => void;
  isOffline: boolean;
  onSwitchToTabletop?: () => void;
}

export const LiveVoiceScreen: React.FC<LiveVoiceScreenProps> = ({
  sourceLang,
  targetLang,
  onOpenSourceSelector,
  onOpenTargetSelector,
  onSwapLanguages,
  voiceSettings,
  onAddTranslation,
  isOffline,
  onSwitchToTabletop,
}) => {
  const [isRecording, setIsRecording] = useState(false);
  const isRecordingRef = useRef(false);
  const [activeSpeakerTarget, setActiveSpeakerTarget] = useState<'auto' | 'user1' | 'user2'>('auto');
  const activeSpeakerTargetRef = useRef<'auto' | 'user1' | 'user2'>('auto');

  const [liveVolume, setLiveVolume] = useState<number>(0);
  const [transcript, setTranscript] = useState('');
  const [textInput, setTextInput] = useState('');
  const [isTranslating, setIsTranslating] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [conversation, setConversation] = useState<TranslationRecord[]>([]);
  const [currentResult, setCurrentResult] = useState<TranslationRecord | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [speechSpeed, setSpeechSpeed] = useState<number>(voiceSettings.speechRate || 1.0);
  const [autoPlayAudio, setAutoPlayAudio] = useState(true);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [audioVolume, setAudioVolume] = useState(voiceSettings.volume || 1.0);
  const [showVolumeSlider, setShowVolumeSlider] = useState(false);
  const [permissionBlocked, setPermissionBlocked] = useState(false);
  const [liveDetectedLang, setLiveDetectedLang] = useState<{ name: string; code: string } | null>(null);

  // 2-Way Hands-Free Auto Continuous Loop Mode
  const [autoLoopMode, setAutoLoopMode] = useState(false);
  const autoLoopModeRef = useRef(false);
  const [loopWaitingCountdown, setLoopWaitingCountdown] = useState<string | null>(null);
  const loopTimeoutRef = useRef<any>(null);

  const recorderRef = useRef<UnifiedVoiceRecorder | null>(null);
  const conversationEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    autoLoopModeRef.current = autoLoopMode;
    if (!autoLoopMode && loopTimeoutRef.current) {
      clearTimeout(loopTimeoutRef.current);
      setLoopWaitingCountdown(null);
    }
  }, [autoLoopMode]);

  // Initialize Recorder on mount
  useEffect(() => {
    recorderRef.current = new UnifiedVoiceRecorder();
    return () => {
      stopSpeaking();
      if (loopTimeoutRef.current) clearTimeout(loopTimeoutRef.current);
      recorderRef.current?.cancel();
    };
  }, []);

  // Auto-dismiss error message after 4 seconds
  useEffect(() => {
    if (errorMessage) {
      const timer = setTimeout(() => setErrorMessage(null), 4000);
      return () => clearTimeout(timer);
    }
  }, [errorMessage]);

  // Safety watchdog: ensure isTranslating resets even on unexpected network stall
  useEffect(() => {
    if (isTranslating) {
      const timer = setTimeout(() => {
        setIsTranslating(false);
      }, 7000);
      return () => clearTimeout(timer);
    }
  }, [isTranslating]);

  // Scroll to bottom on new item
  useEffect(() => {
    conversationEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [conversation, currentResult, isTranslating]);

  // Speak audio using Web Speech API with completion callback
  const playAudio = (text: string, speechCode: string, onDone?: () => void) => {
    setIsPlayingAudio(true);
    speakText(
      text,
      speechCode || 'en-US',
      {
        speechRate: speechSpeed,
        volume: audioVolume,
        voiceGender: voiceSettings.voiceGender,
      },
      () => setIsPlayingAudio(true),
      () => {
        setIsPlayingAudio(false);
        onDone?.();
      },
      () => {
        setIsPlayingAudio(false);
        onDone?.();
      }
    );
  };

  // Schedule next speaker for hands-free 2-way continuous conversation
  const scheduleNextSpeakerLoop = (nextSpeaker: 'user1' | 'user2') => {
    if (!autoLoopModeRef.current) return;

    const nextLang = nextSpeaker === 'user1' ? sourceLang : targetLang;
    setLoopWaitingCountdown(`Listening for ${nextSpeaker === 'user1' ? 'User 1' : 'User 2'} (${nextLang.name})...`);

    if (loopTimeoutRef.current) clearTimeout(loopTimeoutRef.current);
    loopTimeoutRef.current = setTimeout(() => {
      setLoopWaitingCountdown(null);
      if (autoLoopModeRef.current && !isRecordingRef.current) {
        startRecording('auto');
      }
    }, 900);
  };

  // Execute 2-Way Text Translation with Auto Language Detection
  const handleTwoWayTranslateText = async (spokenText: string, specificSpeaker?: 'user1' | 'user2') => {
    if (!spokenText || !spokenText.trim()) return;

    setIsTranslating(true);
    setErrorMessage(null);

    const userAName = sourceLang.code === 'auto' ? 'Auto Detect' : sourceLang.name;
    const userBName = targetLang.name;
    const speakerHint = specificSpeaker || (activeSpeakerTargetRef.current !== 'auto' ? activeSpeakerTargetRef.current : 'auto');

    try {
      const res = await translateTwoWayApi({
        text: spokenText.trim(),
        userALang: userAName,
        userBLang: userBName,
        speakerHint,
        context: 'realtime-2way-conversation',
      });

      if (res.success) {
        // If caller explicitly tapped User 1 or User 2 button, honor that, otherwise use detected speaker
        const isUserA = specificSpeaker 
          ? specificSpeaker === 'user1' 
          : (speakerHint !== 'auto' ? speakerHint === 'user1' : res.speaker === 'userA');
        const speakerType: 'user1' | 'user2' = isUserA ? 'user1' : 'user2';

        const speakerLangObj = isUserA ? sourceLang : targetLang;
        const recipientLangObj = isUserA ? targetLang : sourceLang;

        const newRecord: TranslationRecord = {
          id: `conv_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
          originalText: spokenText.trim(),
          translatedText: res.translatedText,
          sourceLang: res.detectedLanguage || speakerLangObj.name,
          sourceLangCode: res.detectedLanguageCode || speakerLangObj.code,
          targetLang: res.targetLanguage || recipientLangObj.name,
          targetLangCode: res.targetLanguageCode || recipientLangObj.code,
          detectedLang: res.detectedLanguage,
          confidence: res.confidence || 'high',
          pronunciation: res.pronunciation,
          culturalNote: res.culturalNote,
          timestamp: Date.now(),
          category: 'voice',
          speaker: speakerType,
        };

        setCurrentResult(newRecord);
        setConversation(prev => [...prev, newRecord]);
        onAddTranslation(newRecord);
        setTextInput('');
        setTranscript('');
        setLiveDetectedLang(null);

        // Play translation aloud in recipient's language instantly
        if (autoPlayAudio) {
          const targetSpeechCode = recipientLangObj.speechCode === 'auto' ? 'en-US' : recipientLangObj.speechCode;
          playAudio(newRecord.translatedText, targetSpeechCode, () => {
            if (autoLoopModeRef.current) {
              scheduleNextSpeakerLoop(isUserA ? 'user2' : 'user1');
            }
          });
        } else if (autoLoopModeRef.current) {
          scheduleNextSpeakerLoop(isUserA ? 'user2' : 'user1');
        }
      } else {
        setErrorMessage(res.error || 'Live translation failed.');
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Error occurred during translation.');
    } finally {
      setIsTranslating(false);
    }
  };

  // Track recording elapsed time
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const pressStartTimeRef = useRef<number>(0);
  const holdTriggeredRef = useRef<boolean>(false);

  useEffect(() => {
    let timer: any = null;
    if (isRecording) {
      setRecordingSeconds(0);
      timer = setInterval(() => {
        setRecordingSeconds(prev => prev + 1);
      }, 1000);
    } else {
      setRecordingSeconds(0);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isRecording]);

  // Start Mic Recording
  const startRecording = async (target: 'auto' | 'user1' | 'user2' = 'auto') => {
    stopSpeaking();
    setIsTranslating(false);
    if (loopTimeoutRef.current) clearTimeout(loopTimeoutRef.current);
    setLoopWaitingCountdown(null);
    setTranscript('');
    setLiveDetectedLang(null);
    setErrorMessage(null);
    setPermissionBlocked(false);

    if (!recorderRef.current) {
      recorderRef.current = new UnifiedVoiceRecorder();
    }

    activeSpeakerTargetRef.current = target;
    setActiveSpeakerTarget(target);
    isRecordingRef.current = true;
    setIsRecording(true);

    // If a specific speaker mic was pressed, hint recognition with their speech code
    let speechCode = 'en-US';
    if (target === 'user1' && sourceLang.code !== 'auto') {
      speechCode = sourceLang.speechCode;
    } else if (target === 'user2') {
      speechCode = targetLang.speechCode;
    } else if (sourceLang.code !== 'auto') {
      speechCode = sourceLang.speechCode;
    }

    const started = await recorderRef.current.start(speechCode, {
      onStart: () => {
        isRecordingRef.current = true;
        setIsRecording(true);
      },
      onInterimTranscript: (text: string) => {
        setTranscript(text);
        if (text) {
          const detected = getInstantLanguageDetection(text);
          setLiveDetectedLang({ name: detected.languageName, code: detected.languageCode });
        }
      },
      onFinalTranscript: (text: string) => {
        setTranscript(text);
        if (text) {
          const detected = getInstantLanguageDetection(text);
          setLiveDetectedLang({ name: detected.languageName, code: detected.languageCode });
        }
      },
      onVolumeChange: (vol: number) => {
        setLiveVolume(vol);
      },
      onError: (err: string) => {
        isRecordingRef.current = false;
        setIsRecording(false);
        setErrorMessage(err);
        if (err.toLowerCase().includes('blocked') || err.toLowerCase().includes('permission') || err.toLowerCase().includes('denied')) {
          setPermissionBlocked(true);
        }
      },
      onEnd: () => {
        isRecordingRef.current = false;
        setIsRecording(false);
        setLiveVolume(0);
      },
    });

    if (!started) {
      isRecordingRef.current = false;
      setIsRecording(false);
    }
  };

  // Stop Recording and Process 2-Way Audio / Transcript
  const stopRecording = async () => {
    const chosenTarget = activeSpeakerTargetRef.current;
    isRecordingRef.current = false;
    setIsRecording(false);
    setLiveVolume(0);
    setIsTranslating(true);

    if (!recorderRef.current) {
      setIsTranslating(false);
      return;
    }

    try {
      // 1. Stop hardware recorder
      const recordingResult = await recorderRef.current.stop();
      const spokenText = (recordingResult.transcript || transcript).trim();

      // Check if any transcript OR audio was captured
      const hasAudio = Boolean(recordingResult.audioBase64 && recordingResult.audioBase64.length > 30);
      const hasTranscript = Boolean(spokenText.length > 0);

      if (!hasAudio && !hasTranscript) {
        setErrorMessage('No speech heard. Please tap the mic, speak clearly, and tap again when finished.');
        setIsTranslating(false);
        return;
      }

      // 2. FAST REAL-TIME PATH: If text was recognized live via WebSpeech, translate instantly without waiting!
      if (hasTranscript) {
        await handleTwoWayTranslateText(spokenText, chosenTarget === 'auto' ? undefined : chosenTarget);
        return;
      }

      // 3. MULTIMODAL AUDIO AI: If no WebSpeech transcript was available, process via Gemini
      if (hasAudio && recordingResult.audioBase64) {
        const userAName = sourceLang.code === 'auto' ? 'Auto Detect' : sourceLang.name;
        const userBName = targetLang.name;

        const audioRes = await translateTwoWayAudioApi({
          audioBase64: recordingResult.audioBase64,
          mimeType: recordingResult.mimeType,
          userALang: userAName,
          userBLang: userBName,
          speakerHint: chosenTarget,
        });

        if (audioRes.success) {
          if (!audioRes.hasSpeech || !audioRes.transcription?.trim() || !audioRes.translatedText?.trim()) {
            setErrorMessage('No speech heard. Please tap the microphone and speak clearly.');
            setIsTranslating(false);
            return;
          }

          const isUserA = chosenTarget !== 'auto' ? chosenTarget === 'user1' : audioRes.speaker === 'userA';
          const speakerType: 'user1' | 'user2' = isUserA ? 'user1' : 'user2';

          const speakerLangObj = isUserA ? sourceLang : targetLang;
          const recipientLangObj = isUserA ? targetLang : sourceLang;

          const newRecord: TranslationRecord = {
            id: `conv_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
            originalText: audioRes.transcription || 'Spoken message',
            translatedText: audioRes.translatedText,
            sourceLang: audioRes.detectedLanguage || speakerLangObj.name,
            sourceLangCode: audioRes.detectedLanguageCode || speakerLangObj.code,
            targetLang: audioRes.targetLanguage || recipientLangObj.name,
            targetLangCode: audioRes.targetLanguageCode || recipientLangObj.code,
            detectedLang: audioRes.detectedLanguage,
            confidence: audioRes.confidence || 'high',
            pronunciation: audioRes.pronunciation,
            culturalNote: audioRes.culturalNote,
            timestamp: Date.now(),
            category: 'voice',
            speaker: speakerType,
          };

          setCurrentResult(newRecord);
          setConversation(prev => [...prev, newRecord]);
          onAddTranslation(newRecord);
          setTranscript('');
          setLiveDetectedLang(null);

          // Play translation aloud in recipient's language
          if (autoPlayAudio) {
            const targetSpeechCode = recipientLangObj.speechCode === 'auto' ? 'en-US' : recipientLangObj.speechCode;
            playAudio(newRecord.translatedText, targetSpeechCode, () => {
              if (autoLoopModeRef.current) {
                scheduleNextSpeakerLoop(isUserA ? 'user2' : 'user1');
              }
            });
          } else if (autoLoopModeRef.current) {
            scheduleNextSpeakerLoop(isUserA ? 'user2' : 'user1');
          }
          return;
        } else if (audioRes.error) {
          console.warn('Audio AI translation note:', audioRes.error);
        }
      }

      // 4. Fallback if both speech recognition and audio returned empty
      setErrorMessage('No speech detected. Please hold the phone closer and speak clearly.');
    } catch (err: any) {
      console.error('Stop recording error:', err);
      setErrorMessage('Could not process speech. Please try again.');
    } finally {
      setIsTranslating(false);
    }
  };

  const toggleRecording = (target: 'auto' | 'user1' | 'user2' = 'auto') => {
    if (isRecordingRef.current || isRecording || recorderRef.current?.getIsRecording()) {
      stopRecording();
    } else {
      setIsTranslating(false);
      startRecording(target);
    }
  };

  // Dual mode: Tap to toggle OR Hold to speak & release to translate
  const handlePointerDownMic = (target: 'auto' | 'user1' | 'user2') => {
    pressStartTimeRef.current = Date.now();
    holdTriggeredRef.current = false;
  };

  const handlePointerUpMic = (target: 'auto' | 'user1' | 'user2') => {
    const elapsed = Date.now() - pressStartTimeRef.current;
    if (elapsed > 450 && isRecordingRef.current) {
      // User held the button to speak! Releasing stops and translates.
      holdTriggeredRef.current = true;
      stopRecording();
    }
  };

  const handleMicClick = (target: 'auto' | 'user1' | 'user2') => {
    if (holdTriggeredRef.current) {
      holdTriggeredRef.current = false;
      return;
    }
    toggleRecording(target);
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1800);
  };

  // Sample quick test dialogue turns
  const sampleDialogue = [
    {
      speaker: 'user1' as const,
      label: `User 1 (${sourceLang.name}): Hello, do you speak my language?`,
      text: sourceLang.code === 'hi' ? 'नमस्ते, क्या आप मेरी भाषा समझते हैं?' : 
            sourceLang.code === 'es' ? 'Hola, ¿puedes entenderme?' : 
            sourceLang.code === 'fr' ? 'Bonjour, comprenez-vous ma langue ?' : 
            'Hello, can you understand me?',
    },
    {
      speaker: 'user2' as const,
      label: `User 2 (${targetLang.name}): Yes, I understand you perfectly!`,
      text: targetLang.code === 'en' ? 'Yes, I understand you perfectly!' : 
            targetLang.code === 'es' ? '¡Sí, te entiendo perfectamente!' : 
            targetLang.code === 'fr' ? 'Oui, je vous comprends parfaitement !' : 
            'Yes, I can hear and understand you clearly.',
    }
  ];

  return (
    <div className="flex flex-col h-[calc(100vh-120px)] max-h-[850px] animate-fade-in">
      {/* Mode Switcher Bar: Handheld vs Tabletop Face-to-Face */}
      <div className="flex items-center justify-between gap-2 mb-2 px-0.5">
        <div className="flex items-center gap-1 bg-slate-900/90 border border-slate-800 p-1 rounded-xl shadow-sm">
          <button
            id="view-handheld-btn"
            className="flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-bold bg-indigo-600 text-white shadow-sm"
            title="Handheld chat stream mode"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Handheld</span>
          </button>

          {onSwitchToTabletop && (
            <button
              id="view-tabletop-btn"
              onClick={onSwitchToTabletop}
              className="flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-medium text-slate-400 hover:text-slate-200 hover:bg-slate-800/80 transition-all"
              title="Switch to tabletop split-screen mode for two people sitting across a table"
            >
              <Users className="w-3.5 h-3.5 text-slate-400" />
              <span>Tabletop (Face-to-Face)</span>
            </button>
          )}
        </div>

        <span className="text-[11px] text-slate-400 font-medium hidden sm:inline">
          📱 Handheld mode • Live Speech
        </span>
      </div>

      {/* 1. Top 2-Way Language Channel Card */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-2.5 shadow-md mb-2">
        <div className="flex items-center justify-between gap-2">
          {/* User 1 Lang Button */}
          <button
            id="voice-source-lang-btn"
            onClick={onOpenSourceSelector}
            className="flex-1 flex items-center gap-2 p-2 rounded-xl bg-slate-800/90 hover:bg-slate-700/80 border border-indigo-500/30 text-left transition-all"
          >
            <span className="text-xl">{sourceLang.flag}</span>
            <div className="truncate">
              <div className="flex items-center gap-1">
                <span className="text-[10px] text-indigo-300 font-bold uppercase tracking-wider">User 1</span>
                <span className="text-[9px] bg-indigo-500/20 text-indigo-300 px-1 rounded">Speaks</span>
              </div>
              <span className="text-xs font-bold text-slate-100 truncate block">
                {sourceLang.code === 'auto' ? 'Auto Detect' : sourceLang.name}
              </span>
            </div>
          </button>

          {/* Swap Button */}
          <button
            id="voice-swap-lang-btn"
            onClick={onSwapLanguages}
            disabled={sourceLang.code === 'auto'}
            className={`w-9 h-9 rounded-full flex items-center justify-center border transition-all ${
              sourceLang.code === 'auto'
                ? 'opacity-40 cursor-not-allowed bg-slate-800 text-slate-600 border-slate-700'
                : 'bg-indigo-600/20 border-indigo-500/40 text-indigo-400 hover:bg-indigo-600 hover:text-white active:rotate-180'
            }`}
            title="Swap user languages"
          >
            <ArrowLeftRight className="w-4 h-4" />
          </button>

          {/* User 2 Lang Button */}
          <button
            id="voice-target-lang-btn"
            onClick={onOpenTargetSelector}
            className="flex-1 flex items-center justify-end gap-2 p-2 rounded-xl bg-slate-800/90 hover:bg-slate-700/80 border border-purple-500/30 text-right transition-all"
          >
            <div className="truncate">
              <div className="flex items-center justify-end gap-1">
                <span className="text-[9px] bg-purple-500/20 text-purple-300 px-1 rounded">Speaks</span>
                <span className="text-[10px] text-purple-300 font-bold uppercase tracking-wider">User 2</span>
              </div>
              <span className="text-xs font-bold text-slate-100 truncate block">{targetLang.name}</span>
            </div>
            <span className="text-xl">{targetLang.flag}</span>
          </button>
        </div>

        {/* 2-Way Real-Time Controls & Hands-Free Mode Bar */}
        <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-800/80 px-1 text-xs">
          <div className="flex items-center gap-1.5 flex-wrap">
            {/* Auto Mode Badge */}
            <span className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold">
              <Sparkles className="w-3 h-3 text-emerald-400" />
              <span>Auto-Detect Active</span>
            </span>

            {/* Hands-free Auto Loop Toggle */}
            <button
              onClick={() => setAutoLoopMode(!autoLoopMode)}
              className={`flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold transition-colors border ${
                autoLoopMode 
                  ? 'bg-indigo-600 text-white border-indigo-400 shadow-sm shadow-indigo-500/30 animate-pulse' 
                  : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-slate-200'
              }`}
              title="When active, app alternates and automatically listens for each speaker in turn"
            >
              <Repeat className="w-3 h-3" />
              <span>Hands-Free Loop: {autoLoopMode ? 'ON' : 'OFF'}</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setAutoPlayAudio(!autoPlayAudio)}
              className={`p-1 rounded-lg ${autoPlayAudio ? 'text-indigo-300' : 'text-slate-500'}`}
              title={`Auto-Speak: ${autoPlayAudio ? 'Enabled' : 'Muted'}`}
            >
              {autoPlayAudio ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
            </button>

            <button
              onClick={() => {
                const next = speechSpeed === 1.0 ? 0.8 : speechSpeed === 0.8 ? 1.2 : 1.0;
                setSpeechSpeed(next);
              }}
              className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 text-[10px] font-medium border border-slate-700"
            >
              {speechSpeed}x
            </button>

            {conversation.length > 0 && (
              <button
                onClick={() => {
                  setConversation([]);
                  setCurrentResult(null);
                }}
                className="text-[10px] text-slate-500 hover:text-slate-300 font-medium"
              >
                Clear
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Loop Countdown Banner */}
      {loopWaitingCountdown && (
        <div className="bg-indigo-950/70 border border-indigo-500/40 rounded-xl px-3 py-1.5 text-xs text-indigo-200 flex items-center justify-between mb-2 animate-pulse">
          <div className="flex items-center gap-2 font-medium">
            <Headphones className="w-3.5 h-3.5 text-indigo-400 animate-bounce" />
            <span>{loopWaitingCountdown}</span>
          </div>
          <button 
            onClick={() => setAutoLoopMode(false)}
            className="text-[10px] text-slate-400 hover:text-white underline"
          >
            Stop Loop
          </button>
        </div>
      )}

      {/* Main Conversation Stream Display */}
      <div className="flex-1 overflow-y-auto space-y-3 p-2 bg-slate-950/40 rounded-2xl border border-slate-800/80 mb-2">
        {conversation.length === 0 && !isRecording && !isTranslating && (
          <div className="h-full flex flex-col items-center justify-center text-center p-4 text-slate-400 space-y-3">
            <div className="w-14 h-14 rounded-3xl bg-gradient-to-tr from-indigo-600/20 to-purple-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 shadow-inner">
              <Sparkles className="w-7 h-7 text-indigo-400 animate-pulse" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-100 mb-1">Live Multilingual Voice</h3>
              <p className="text-xs text-slate-400 max-w-xs leading-relaxed">
                Speak in your preferred language. The AI automatically detects your language, translates it for the second user, and speaks it out loud!
              </p>
            </div>

            {/* Quick test phrases for 2-way demonstration */}
            <div className="w-full pt-1">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                Quick Test Dialogue (Instant Click)
              </span>
              <div className="flex flex-col gap-1.5 max-w-sm mx-auto">
                {sampleDialogue.map((item, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleTwoWayTranslateText(item.text, item.speaker)}
                    className="text-xs bg-slate-900 hover:bg-indigo-950/40 border border-slate-800 hover:border-indigo-500/40 px-3 py-2 rounded-xl text-slate-200 transition-all text-left flex items-center justify-between group"
                  >
                    <span className="truncate">{item.label}</span>
                    <span className="text-[10px] text-indigo-400 group-hover:translate-x-0.5 transition-transform shrink-0 font-bold ml-2">
                      Send ➔
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Conversation Message Bubbles */}
        {conversation.map(item => {
          const isUser1 = item.speaker === 'user1';
          return (
            <div
              key={item.id}
              className={`rounded-2xl p-3.5 shadow-md space-y-2 border transition-all ${
                isUser1
                  ? 'bg-gradient-to-br from-indigo-950/40 via-slate-900 to-slate-900 border-indigo-500/30 mr-4'
                  : 'bg-gradient-to-br from-purple-950/40 via-slate-900 to-slate-900 border-purple-500/30 ml-4'
              }`}
            >
              {/* Speaker Indicator & Spoken Original Text */}
              <div className="flex items-start justify-between gap-2 border-b border-slate-800/80 pb-2">
                <div className="space-y-1 flex-1">
                  <div className="flex items-center gap-1.5 text-xs font-semibold">
                    <span className={`w-2 h-2 rounded-full ${isUser1 ? 'bg-indigo-400' : 'bg-purple-400'}`} />
                    <span className={isUser1 ? 'text-indigo-300' : 'text-purple-300'}>
                      {isUser1 ? `User 1 (${item.sourceLang})` : `User 2 (${item.sourceLang})`}
                    </span>
                    <span className="text-[10px] text-slate-500">spoke:</span>
                    {item.detectedLang && (
                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 border border-slate-700">
                        ✨ Detected: {item.detectedLang}
                      </span>
                    )}
                  </div>
                  <div className="text-sm text-slate-200 font-medium">"{item.originalText}"</div>
                </div>
                <button
                  onClick={() => playAudio(item.originalText, item.sourceLangCode)}
                  className="p-1.5 text-slate-400 hover:text-slate-200 rounded-lg hover:bg-slate-800"
                  title="Listen original"
                >
                  <Volume1 className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Translation Output for Recipient */}
              <div className="flex items-start justify-between gap-3 pt-1">
                <div className="space-y-1.5 flex-1">
                  <div className="flex items-center gap-1.5 text-[11px] font-bold text-slate-400">
                    <span className="text-emerald-400">➔ Translated for {isUser1 ? `User 2 (${item.targetLang})` : `User 1 (${item.targetLang})`}</span>
                  </div>
                  <div className="text-base font-bold text-white tracking-wide">
                    {item.translatedText}
                  </div>

                  {item.pronunciation && (
                    <div className="text-xs text-indigo-300 italic">
                      🗣 {item.pronunciation}
                    </div>
                  )}
                  {item.culturalNote && (
                    <div className="text-[11px] text-amber-300/90 bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded">
                      💡 {item.culturalNote}
                    </div>
                  )}
                </div>

                {/* Audio and Copy actions */}
                <div className="flex flex-col gap-1 shrink-0">
                  <button
                    onClick={() => playAudio(item.translatedText, item.targetLangCode)}
                    className="p-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl shadow-md transition-all active:scale-95"
                    title="Play translation"
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleCopy(item.id, item.translatedText)}
                    className="p-2 text-slate-400 hover:text-slate-200 rounded-xl hover:bg-slate-800"
                    title="Copy translation"
                  >
                    {copiedId === item.id ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </div>
          );
        })}

        {/* Live Interim Transcript Bubble */}
        {(isRecording || isTranslating) && (
          <div className="bg-indigo-950/60 border border-indigo-500/50 rounded-2xl p-3.5 animate-pulse space-y-2">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-xs font-bold text-indigo-300">
                <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
                <span>
                  {isRecording 
                    ? `Listening ${activeSpeakerTarget === 'user1' ? 'User 1' : activeSpeakerTarget === 'user2' ? 'User 2' : 'Live'}...` 
                    : 'Gemini AI detecting language & translating...'}
                </span>
              </div>
              {liveDetectedLang && (
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  ✨ Detected: {liveDetectedLang.name}
                </span>
              )}
            </div>
            <div className="text-base text-indigo-100 font-medium italic">
              {transcript || (isTranslating ? 'Processing 2-way translation...' : 'Speak now in any language...')}
            </div>
          </div>
        )}

        {/* Permission Blocked Alert */}
        {permissionBlocked && (
          <div className="bg-amber-950/40 border border-amber-500/50 rounded-2xl p-3.5 space-y-2.5 text-xs text-amber-200">
            <div className="flex items-center gap-2 font-bold text-amber-300">
              <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
              <span>Microphone Access Needed</span>
            </div>
            <p className="text-slate-300 text-[11px] leading-relaxed">
              To speak live, grant microphone permission in your browser (tap the lock 🔒 or site settings icon in the address bar). You can also test translation right now with the demo button below.
            </p>
            <div className="flex items-center gap-2 flex-wrap pt-0.5">
              <button
                onClick={async () => {
                  const res = await requestMicrophoneAccess();
                  if (res.granted) {
                    setPermissionBlocked(false);
                    startRecording('auto');
                  } else {
                    setErrorMessage(res.error || 'Microphone still blocked');
                  }
                }}
                className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl flex items-center gap-1.5 shadow-sm text-xs cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Allow Microphone</span>
              </button>
              <button
                onClick={() => {
                  setPermissionBlocked(false);
                  const sampleText = sourceLang.code === 'hi' ? 'नमस्ते, क्या आप मेरी मदद कर सकते हैं?' : 'Hello, can you help me find the train station?';
                  handleTwoWayTranslateText(sampleText, 'user1');
                }}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-indigo-300 font-bold rounded-xl text-xs border border-slate-700 flex items-center gap-1 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                <span>Test Voice Simulation</span>
              </button>
            </div>
          </div>
        )}

        {errorMessage && !permissionBlocked && (
          <div className="bg-red-500/15 border border-red-500/40 rounded-2xl p-3 text-xs text-red-300 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
              <span>{errorMessage}</span>
            </div>
            <button onClick={() => setErrorMessage(null)} className="text-red-300 hover:text-white font-bold ml-2">
              ✕
            </button>
          </div>
        )}

        <div ref={conversationEndRef} />
      </div>

      {/* Text Input Fallback Bar with Auto Detection */}
      <div className="mb-2 flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-2xl p-1.5 shadow-sm">
        <input
          type="text"
          value={textInput}
          onChange={e => setTextInput(e.target.value)}
          onKeyDown={e => {
            if (e.key === 'Enter' && textInput.trim()) {
              handleTwoWayTranslateText(textInput);
            }
          }}
          placeholder="Type in any language (auto-detects speaker & translates)..."
          className="flex-1 bg-transparent px-3 py-1.5 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none"
        />
        {textInput.trim() && (
          <button
            onClick={() => handleTwoWayTranslateText(textInput)}
            disabled={isTranslating}
            className="p-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition-all shrink-0"
          >
            <Send className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* 3. 2-Way Interactive Mic Controls Console */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-3.5 shadow-xl flex flex-col items-center gap-2.5">
        {/* Live Audio Visualizer */}
        {isRecording && (
          <div className="flex items-center justify-center gap-1 h-6 w-full max-w-xs">
            {[40, 75, 100, 60, 90, 45, 80, 100, 70, 50, 85, 30].map((h, i) => (
              <span
                key={i}
                className="w-1.5 bg-gradient-to-t from-indigo-500 to-teal-400 rounded-full animate-bounce"
                style={{
                  height: `${h}%`,
                  animationDelay: `${(i * 0.1).toFixed(1)}s`,
                  animationDuration: '0.6s',
                }}
              />
            ))}
          </div>
        )}

        {/* 3-Button Controller: User 1 Mic | Central Auto 2-Way Mic | User 2 Mic */}
        <div className="flex items-center justify-center gap-3 w-full">
          {/* User 1 Dedicated Mic */}
          <button
            onPointerDown={() => handlePointerDownMic('user1')}
            onPointerUp={() => handlePointerUpMic('user1')}
            onClick={() => handleMicClick('user1')}
            className={`flex flex-col items-center justify-center px-3.5 py-2.5 rounded-2xl border transition-all active:scale-95 ${
              isRecording && activeSpeakerTarget === 'user1'
                ? 'bg-rose-600 text-white border-rose-400 ring-4 ring-rose-500/30 shadow-lg shadow-rose-600/30'
                : 'bg-slate-800 hover:bg-slate-700/80 border-indigo-500/30 text-slate-200'
            }`}
            title={`Speak as User 1 (${sourceLang.name})`}
          >
            <div className="flex items-center gap-1.5">
              <span className="text-base">{sourceLang.flag}</span>
              <Mic className={`w-3.5 h-3.5 ${isRecording && activeSpeakerTarget === 'user1' ? 'text-white animate-pulse' : 'text-indigo-400'}`} />
            </div>
            <span className="text-[10px] font-bold text-slate-300 mt-0.5">User 1</span>
          </button>

          {/* Central Big 2-Way Auto Mic Button */}
          <button
            id="live-voice-mic-btn"
            onPointerDown={() => handlePointerDownMic('auto')}
            onPointerUp={() => handlePointerUpMic('auto')}
            onClick={() => handleMicClick('auto')}
            className={`relative flex items-center justify-center rounded-full transition-all duration-300 active:scale-90 shadow-2xl cursor-pointer ${
              isRecording
                ? 'w-16 h-16 bg-gradient-to-tr from-rose-600 to-red-500 text-white ring-8 ring-red-500/30 animate-pulse scale-105'
                : 'w-16 h-16 bg-gradient-to-tr from-indigo-600 via-blue-600 to-teal-500 text-white hover:shadow-indigo-500/40 hover:scale-105'
            }`}
            aria-label={isRecording ? 'Stop recording' : 'Start 2-way speaking'}
          >
            {isRecording ? <Square className="w-6 h-6 fill-white" /> : <Mic className="w-7 h-7" />}
            {isRecording && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-white rounded-full flex items-center justify-center shadow">
                <span className="w-2.5 h-2.5 bg-red-600 rounded-full animate-ping" />
              </span>
            )}
          </button>

          {/* User 2 Dedicated Mic */}
          <button
            onPointerDown={() => handlePointerDownMic('user2')}
            onPointerUp={() => handlePointerUpMic('user2')}
            onClick={() => handleMicClick('user2')}
            className={`flex flex-col items-center justify-center px-3.5 py-2.5 rounded-2xl border transition-all active:scale-95 ${
              isRecording && activeSpeakerTarget === 'user2'
                ? 'bg-rose-600 text-white border-rose-400 ring-4 ring-rose-500/30 shadow-lg shadow-rose-600/30'
                : 'bg-slate-800 hover:bg-slate-700/80 border-purple-500/30 text-slate-200'
            }`}
            title={`Speak as User 2 (${targetLang.name})`}
          >
            <div className="flex items-center gap-1.5">
              <span className="text-base">{targetLang.flag}</span>
              <Mic className={`w-3.5 h-3.5 ${isRecording && activeSpeakerTarget === 'user2' ? 'text-white animate-pulse' : 'text-purple-400'}`} />
            </div>
            <span className="text-[10px] font-bold text-slate-300 mt-0.5">User 2</span>
          </button>
        </div>

        {/* Dynamic Status & Guidance */}
        <div className="text-center text-xs">
          {isRecording ? (
            <div className="flex items-center justify-center gap-2">
              <span className="inline-flex items-center gap-1.5 text-red-400 font-bold">
                <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
                <span>Listening ({recordingSeconds < 10 ? `00:0${recordingSeconds}` : `00:${recordingSeconds}`})...</span>
              </span>
              <span className="text-slate-400 text-[11px]">Tap center button or release to translate</span>
            </div>
          ) : isTranslating ? (
            <span className="text-indigo-400 font-bold flex items-center justify-center gap-1.5">
              <Loader2 className="w-4 h-4 animate-spin text-indigo-400" />
              Detecting language & translating...
            </span>
          ) : isPlayingAudio ? (
            <div className="flex items-center justify-center gap-2">
              <span className="text-emerald-400 font-medium">🔊 Playing translation aloud...</span>
              <button 
                onClick={stopSpeaking} 
                className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-amber-400 rounded-lg text-[10px] font-bold"
              >
                Stop
              </button>
            </div>
          ) : (
            <div className="flex items-center justify-center gap-1.5 text-slate-300">
              <span className="font-semibold text-indigo-300">👉 Tap Center Mic</span>
              <span className="text-slate-400">— Auto-detects speaker & translates! (Hold to talk or tap once)</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
