import React, { useState, useRef, useEffect } from 'react';
import { 
  ArrowLeftRight, 
  Copy, 
  Share2, 
  Volume2, 
  Bookmark, 
  Trash2, 
  Sparkles, 
  ClipboardPaste, 
  Check, 
  Mic, 
  RotateCcw,
  Square,
  ShieldAlert,
  Loader2
} from 'lucide-react';
import { Language, TranslationRecord, VoiceSettings } from '../types';
import { translateTextApi, translateAudioApi } from '../services/translationService';
import { speakText, stopSpeaking } from '../utils/speech';
import { UnifiedVoiceRecorder } from '../utils/audioRecorder';

interface TextTranslateScreenProps {
  sourceLang: Language;
  targetLang: Language;
  onOpenSourceSelector: () => void;
  onOpenTargetSelector: () => void;
  onSwapLanguages: () => void;
  voiceSettings: VoiceSettings;
  onAddTranslation: (record: TranslationRecord) => void;
  onClose?: () => void;
}

export const TextTranslateScreen: React.FC<TextTranslateScreenProps> = ({
  sourceLang,
  targetLang,
  onOpenSourceSelector,
  onOpenTargetSelector,
  onSwapLanguages,
  voiceSettings,
  onAddTranslation,
  onClose,
}) => {
  const [inputText, setInputText] = useState('');
  const [isTranslating, setIsTranslating] = useState(false);
  const [isVoiceRecording, setIsVoiceRecording] = useState(false);
  const isVoiceRecordingRef = useRef(false);
  const [voiceVolume, setVoiceVolume] = useState(0);
  const [result, setResult] = useState<TranslationRecord | null>(null);
  const [copiedType, setCopiedType] = useState<'input' | 'output' | null>(null);
  const [speechSpeed, setSpeechSpeed] = useState<number>(voiceSettings.speechRate || 1.0);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const recorderRef = useRef<UnifiedVoiceRecorder | null>(null);

  useEffect(() => {
    recorderRef.current = new UnifiedVoiceRecorder();
    return () => {
      stopSpeaking();
      recorderRef.current?.cancel();
    };
  }, []);

  // ⚡ Debounced auto-translation for snappy instant typing experience
  useEffect(() => {
    const text = inputText.trim();
    if (!text || text.length < 2) return;
    const timer = setTimeout(() => {
      handleTranslate(text);
    }, 350);
    return () => clearTimeout(timer);
  }, [inputText, sourceLang.code, targetLang.code]);

  const handleTranslate = async (customText?: string) => {
    const textToTranslate = (customText !== undefined ? customText : inputText).trim();
    if (!textToTranslate) return;
    setIsTranslating(true);
    setErrorMessage(null);

    try {
      const res = await translateTextApi({
        text: textToTranslate,
        sourceLang: sourceLang.code === 'auto' ? 'auto' : sourceLang.name,
        targetLang: targetLang.name,
        context: 'text-translation',
      });

      if (res.success) {
        const item: TranslationRecord = {
          id: `txt_${Date.now()}`,
          originalText: textToTranslate,
          translatedText: res.translatedText,
          sourceLang: res.detectedLanguage || sourceLang.name,
          sourceLangCode: res.detectedLanguageCode || sourceLang.code,
          targetLang: targetLang.name,
          targetLangCode: targetLang.code,
          detectedLang: res.detectedLanguage,
          confidence: res.confidence || 'high',
          didYouMeanSuggestion: res.didYouMeanSuggestion,
          pronunciation: res.pronunciation,
          culturalNote: res.culturalNote,
          timestamp: Date.now(),
          category: 'text',
        };

        setResult(item);
        onAddTranslation(item);
      } else {
        setErrorMessage(res.error || 'Translation failed.');
      }
    } catch (err: any) {
      console.error('Text translate error:', err);
      setErrorMessage(err?.message || 'Error occurred during translation.');
    } finally {
      setIsTranslating(false);
    }
  };

  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const voicePressStartTimeRef = useRef<number>(0);
  const voiceHoldTriggeredRef = useRef<boolean>(false);

  useEffect(() => {
    let timer: any = null;
    if (isVoiceRecording) {
      setRecordingSeconds(0);
      timer = setInterval(() => {
        setRecordingSeconds(prev => prev + 1);
      }, 1000);
    } else {
      setRecordingSeconds(0);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isVoiceRecording]);

  const startVoiceInput = async () => {
    stopSpeaking();
    setErrorMessage(null);

    if (!recorderRef.current) {
      recorderRef.current = new UnifiedVoiceRecorder();
    }

    isVoiceRecordingRef.current = true;
    setIsVoiceRecording(true);

    const speechCode = sourceLang.code === 'auto' ? 'en-US' : sourceLang.speechCode;

    const started = await recorderRef.current.start(speechCode, {
      onStart: () => {
        isVoiceRecordingRef.current = true;
        setIsVoiceRecording(true);
      },
      onInterimTranscript: (text: string) => {
        setInputText(text);
      },
      onFinalTranscript: (text: string) => {
        setInputText(text);
      },
      onVolumeChange: (vol: number) => {
        setVoiceVolume(vol);
      },
      onError: (err: string) => {
        isVoiceRecordingRef.current = false;
        setIsVoiceRecording(false);
        setErrorMessage(err);
      },
      onEnd: () => {
        isVoiceRecordingRef.current = false;
        setIsVoiceRecording(false);
        setVoiceVolume(0);
      },
    });

    if (!started) {
      isVoiceRecordingRef.current = false;
      setIsVoiceRecording(false);
    }
  };

  const stopVoiceInput = async () => {
    isVoiceRecordingRef.current = false;
    setIsVoiceRecording(false);
    setVoiceVolume(0);

    if (!recorderRef.current) return;

    try {
      const recResult = await recorderRef.current.stop();
      const spokenText = (recResult.transcript || recorderRef.current.getTranscript() || inputText).trim();

      if (spokenText.length > 0) {
        setInputText(spokenText);
        await handleTranslate(spokenText);
      } else if (recResult.audioBase64) {
        setIsTranslating(true);
        const audioRes = await translateAudioApi({
          audioBase64: recResult.audioBase64,
          mimeType: recResult.mimeType,
          sourceLang: sourceLang.code === 'auto' ? 'auto' : sourceLang.name,
          targetLang: targetLang.name,
        });

        if (audioRes.success && (audioRes.hasSpeech || audioRes.transcription)) {
          const trans = audioRes.transcription || 'Spoken speech';
          setInputText(trans);
          const item: TranslationRecord = {
            id: `txt_${Date.now()}`,
            originalText: trans,
            translatedText: audioRes.translatedText,
            sourceLang: audioRes.detectedLanguage || sourceLang.name,
            sourceLangCode: audioRes.detectedLanguageCode || sourceLang.code,
            targetLang: targetLang.name,
            targetLangCode: targetLang.code,
            detectedLang: audioRes.detectedLanguage,
            confidence: audioRes.confidence || 'high',
            didYouMeanSuggestion: audioRes.didYouMeanSuggestion,
            pronunciation: audioRes.pronunciation,
            culturalNote: audioRes.culturalNote,
            timestamp: Date.now(),
            category: 'text',
          };
          setResult(item);
          onAddTranslation(item);
        } else {
          setErrorMessage('No speech heard. Please tap the mic, speak clearly, and tap stop.');
        }
      } else {
        setErrorMessage('No voice detected. Please hold phone closer and speak clearly.');
      }
    } catch (e: any) {
      setErrorMessage('Could not process speech input. Please try again.');
    } finally {
      setIsTranslating(false);
    }
  };

  const handlePointerDownVoice = () => {
    voicePressStartTimeRef.current = Date.now();
    voiceHoldTriggeredRef.current = false;
  };

  const handlePointerUpVoice = () => {
    const elapsed = Date.now() - voicePressStartTimeRef.current;
    if (elapsed > 450 && isVoiceRecordingRef.current) {
      voiceHoldTriggeredRef.current = true;
      stopVoiceInput();
    }
  };

  const handleVoiceButtonClick = () => {
    if (voiceHoldTriggeredRef.current) {
      voiceHoldTriggeredRef.current = false;
      return;
    }
    if (isVoiceRecordingRef.current) {
      stopVoiceInput();
    } else {
      startVoiceInput();
    }
  };

  const handlePasteClipboard = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        setInputText(text);
      }
    } catch (err) {
      console.warn('Clipboard read failed:', err);
    }
  };

  const handleCopy = (text: string, type: 'input' | 'output') => {
    navigator.clipboard.writeText(text);
    setCopiedType(type);
    setTimeout(() => setCopiedType(null), 1800);
  };

  const handleShare = async (text: string) => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Omni Translate Translation',
          text: text,
        });
      } catch (err) {
        // cancelled
      }
    } else {
      handleCopy(text, 'output');
    }
  };

  const playAudio = async (text: string, speechCode: string) => {
    setIsPlayingAudio(true);
    await speakText(
      text,
      speechCode,
      {
        speechRate: speechSpeed,
        volume: voiceSettings.volume,
      },
      () => setIsPlayingAudio(true),
      () => setIsPlayingAudio(false),
      () => setIsPlayingAudio(false)
    );
  };

  return (
    <div className="space-y-4 pb-8 animate-fade-in select-none">
      {/* Language Selector Bar with Smart Swap */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-2.5 shadow-md flex items-center justify-between gap-2">
        <button
          id="text-source-lang-btn"
          onClick={onOpenSourceSelector}
          className="flex-1 flex items-center gap-2 p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 text-left transition-all"
        >
          <span className="text-xl">{sourceLang.flag}</span>
          <span className="text-xs font-bold text-slate-100 truncate">
            {sourceLang.code === 'auto' ? 'Auto Detect' : sourceLang.name}
          </span>
        </button>

        <button
          id="text-swap-lang-btn"
          onClick={onSwapLanguages}
          disabled={sourceLang.code === 'auto'}
          className={`w-9 h-9 rounded-full flex items-center justify-center border transition-all ${
            sourceLang.code === 'auto'
              ? 'opacity-40 cursor-not-allowed bg-slate-800 text-slate-600 border-slate-700'
              : 'bg-blue-600/20 border-blue-500/40 text-blue-400 hover:bg-blue-600 hover:text-white active:rotate-180'
          }`}
          title="Swap languages"
        >
          <ArrowLeftRight className="w-4 h-4" />
        </button>

        <button
          id="text-target-lang-btn"
          onClick={onOpenTargetSelector}
          className="flex-1 flex items-center justify-end gap-2 p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 text-right transition-all"
        >
          <span className="text-xs font-bold text-slate-100 truncate">{targetLang.name}</span>
          <span className="text-xl">{targetLang.flag}</span>
        </button>
      </div>

      {/* Input Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 shadow-xl space-y-3 relative">
        <div className="flex items-center justify-between text-xs text-slate-400">
          <span className="font-semibold uppercase tracking-wider text-slate-300">Source Text</span>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePasteClipboard}
              className="flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-300 transition-colors"
            >
              <ClipboardPaste className="w-3.5 h-3.5" />
              <span>Paste</span>
            </button>
            {inputText && (
              <button
                onClick={() => {
                  setInputText('');
                  setResult(null);
                }}
                className="p-1 text-slate-400 hover:text-red-400 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Text Area */}
        <textarea
          id="text-translate-input"
          value={inputText}
          onChange={e => setInputText(e.target.value)}
          placeholder={`Type, paste text, or tap 🎤 Mic to speak in ${sourceLang.name}...`}
          rows={4}
          className="w-full bg-slate-950/60 border border-slate-800 rounded-2xl p-3 text-slate-100 placeholder-slate-500 text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 resize-none transition-all"
        />

        {/* Error message banner */}
        {errorMessage && (
          <div className="text-xs text-red-300 bg-red-500/15 border border-red-500/30 p-2 rounded-xl flex items-center justify-between">
            <span>{errorMessage}</span>
            <button onClick={() => setErrorMessage(null)} className="text-red-300 hover:text-white ml-2">✕</button>
          </div>
        )}

        <div className="flex items-center justify-between pt-1">
          <span className="text-[11px] text-slate-500 font-mono">
            {inputText.length} characters
          </span>

          <div className="flex items-center gap-2">
            {/* Quick Mic Speech button */}
            <button
              id="text-voice-input-btn"
              onPointerDown={handlePointerDownVoice}
              onPointerUp={handlePointerUpVoice}
              onClick={handleVoiceButtonClick}
              className={`p-2.5 rounded-2xl flex items-center gap-1.5 font-bold text-xs transition-all active:scale-95 cursor-pointer ${
                isVoiceRecording
                  ? 'bg-rose-600 text-white animate-pulse ring-4 ring-rose-500/30 shadow-lg shadow-rose-600/30'
                  : 'bg-slate-800 hover:bg-slate-700 text-indigo-300 border border-slate-700'
              }`}
              title={isVoiceRecording ? 'Tap or release to finish speech' : 'Speak to input (Hold or tap)'}
            >
              {isVoiceRecording ? <Square className="w-4 h-4 fill-white" /> : <Mic className="w-4 h-4" />}
              <span className="text-[11px]">
                {isVoiceRecording ? `Listening (${recordingSeconds}s)` : 'Voice'}
              </span>
            </button>

            {inputText && (
              <button
                onClick={() => playAudio(inputText, sourceLang.speechCode)}
                className="p-2 text-slate-400 hover:text-slate-200 rounded-xl hover:bg-slate-800"
                title="Listen to original"
              >
                <Volume2 className="w-4 h-4" />
              </button>
            )}

            <button
              id="text-translate-submit-btn"
              onClick={() => handleTranslate()}
              disabled={!inputText.trim() || isTranslating}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-2xl font-bold text-xs text-white shadow-lg transition-all active:scale-95 ${
                !inputText.trim() || isTranslating
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 shadow-blue-600/30'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              <span>{isTranslating ? 'Translating...' : 'Translate'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Translated Result Output Card */}
      {result && (
        <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-blue-950/30 border border-blue-500/40 rounded-3xl p-4 shadow-2xl space-y-3 animate-fade-in">
          <div className="flex items-center justify-between text-xs pb-1 border-b border-slate-800">
            <div className="flex items-center gap-1.5 font-bold text-blue-400">
              <span>{result.targetLang} Translation</span>
              {result.confidence && (
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-normal px-2 py-0.5 rounded-full">
                  {result.confidence} confidence
                </span>
              )}
            </div>

            {/* Speed selection */}
            <div className="flex items-center gap-1">
              <span className="text-[10px] text-slate-400">Speed:</span>
              {[0.8, 1.0, 1.2].map(speed => (
                <button
                  key={speed}
                  onClick={() => setSpeechSpeed(speed)}
                  className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                    speechSpeed === speed ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {speed}x
                </button>
              ))}
            </div>
          </div>

          {/* Translated Text Large Output */}
          <div className="text-lg font-bold text-slate-100 leading-relaxed">
            {result.translatedText}
          </div>

          {/* Pronunciation & Cultural Nuance */}
          {result.pronunciation && (
            <div className="text-xs text-blue-300 bg-blue-950/50 border border-blue-800/40 px-3 py-1.5 rounded-xl font-mono">
              🗣 Pronunciation: {result.pronunciation}
            </div>
          )}

          {result.culturalNote && (
            <div className="text-xs text-amber-300 bg-amber-500/10 border border-amber-500/20 px-3 py-1.5 rounded-xl">
              💡 {result.culturalNote}
            </div>
          )}

          {/* Action Bar */}
          <div className="flex items-center justify-between pt-2 border-t border-slate-800">
            <div className="flex items-center gap-2">
              <button
                id="text-listen-btn"
                onClick={() => playAudio(result.translatedText, targetLang.speechCode)}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold text-xs shadow-md transition-all active:scale-95"
              >
                {isPlayingAudio ? <Square className="w-4 h-4 fill-white" /> : <Volume2 className="w-4 h-4" />}
                <span>{isPlayingAudio ? 'Stop' : 'Listen'}</span>
              </button>
            </div>

            <div className="flex items-center gap-1">
              <button
                id="text-copy-btn"
                onClick={() => handleCopy(result.translatedText, 'output')}
                className="p-2 text-slate-300 hover:text-white rounded-xl bg-slate-800 hover:bg-slate-700 transition-colors"
                title="Copy translation"
              >
                {copiedType === 'output' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>

              <button
                onClick={() => handleShare(result.translatedText)}
                className="p-2 text-slate-300 hover:text-white rounded-xl bg-slate-800 hover:bg-slate-700 transition-colors"
                title="Share text"
              >
                <Share2 className="w-4 h-4" />
              </button>

              <button
                onClick={() => {
                  onAddTranslation({ ...result, starred: true });
                  handleCopy(result.translatedText, 'output');
                }}
                className="p-2 text-amber-300 hover:text-amber-200 rounded-xl bg-amber-500/10 border border-amber-500/30 transition-colors"
                title="Save translation"
              >
                <Bookmark className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
