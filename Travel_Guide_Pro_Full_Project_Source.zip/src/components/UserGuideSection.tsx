import React, { useState } from 'react';
import { 
  Mic, 
  Users, 
  MessagesSquare,
  Camera, 
  FileText, 
  AlertTriangle, 
  BookOpen, 
  WifiOff, 
  Volume2, 
  Settings, 
  HelpCircle,
  Sparkles,
  Layers,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Mail
} from 'lucide-react';

interface FeatureGuideItem {
  id: string;
  title: string;
  subtitle: string;
  icon: React.ComponentType<{ className?: string }>;
  iconColor: string;
  badge: string;
  badgeColor: string;
  howToUse: string[];
  proTips: string[];
  offlineCapable: boolean;
}

const FEATURE_GUIDES: FeatureGuideItem[] = [
  {
    id: 'live-conversation',
    title: 'Live Conversation (Handheld & Tabletop)',
    subtitle: 'Unified two-way voice translation with instant switching between Handheld chat and Tabletop Face-to-Face split-screen',
    icon: MessagesSquare,
    iconColor: 'text-indigo-400 bg-indigo-500/10 border-indigo-500/30',
    badge: 'Live Conversation',
    badgeColor: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40',
    howToUse: [
      'In the "Conversation" tab, toggle smoothly between Handheld Mode (walking & talking) and Tabletop Mode (table or counter chats).',
      'In Handheld Mode, tap User 1, User 2, or the Auto-Detect microphone to converse with live chat bubbles.',
      'In Tabletop Mode, place the phone on a table between two people; the top half is inverted 180° so both read right-side up.',
      'Enable "Hands-Free" auto loop to have Gemini alternate and listen to both speakers automatically without pressing buttons.'
    ],
    proTips: [
      'Use Tabletop mode at restaurants, hotel check-ins, or train stations by placing the phone flat on the counter.',
      'Switch between Handheld and Tabletop layouts anytime using the mode switch buttons in the header or toolbar.'
    ],
    offlineCapable: true
  },
  {
    id: 'camera-ocr',
    title: 'Camera & Live Sign AR OCR',
    subtitle: 'Point-and-translate with AI visual recognition for street signs, menus, and documents',
    icon: Camera,
    iconColor: 'text-amber-400 bg-amber-500/10 border-amber-500/30',
    badge: 'Gemini Vision',
    badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
    howToUse: [
      'Allow camera permissions when prompted to launch the live viewfinder.',
      'Frame the foreign text (e.g. food menu, warning sign, or packaging label) inside the targeting grid.',
      'Tap "Capture & Translate" or upload an existing image from your photo gallery.',
      'Gemini Vision extracts text blocks, translates them, and overlays localized text directly onto the image.'
    ],
    proTips: [
      'Toggle the "Live Overlay" switch to see translated text positioned exactly over original words.',
      'Tap any translated block to hear its spoken pronunciation.'
    ],
    offlineCapable: false
  },
  {
    id: 'text-translate',
    title: 'Text & Smart Dictionary',
    subtitle: 'Deep contextual translations with cultural etiquette tips and phonetic Romanization',
    icon: FileText,
    iconColor: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/30',
    badge: 'Cultural AI',
    badgeColor: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40',
    howToUse: [
      'Type or paste text into the input area. The app auto-detects the source language if enabled.',
      'Tap "Translate" to receive accurate meaning, cultural context notes, and formal vs. informal advice.',
      'Tap "Copy" to clipboard or "Star" to save the phrase to your personal travel notebook.'
    ],
    proTips: [
      'Cultural Tips warn you about honorifics, bowing etiquette, and polite phrasing in countries like Japan or Germany.',
      'Phonetic guides display Pinyin, Romaji, or Romanized Hindi for easy reading.'
    ],
    offlineCapable: true
  },
  {
    id: 'emergency-sos',
    title: 'Emergency SOS & Medical Cards',
    subtitle: 'Zero-internet life-saving phrases, medical alerts, and high-contrast audio beacon',
    icon: AlertTriangle,
    iconColor: 'text-red-400 bg-red-500/10 border-red-500/30',
    badge: '100% Offline',
    badgeColor: 'bg-red-500/20 text-red-300 border-red-500/40',
    howToUse: [
      'Quickly switch categories: Medical & Hospital, Police & Safety, Severe Allergies, Directions & Lost.',
      'Tap any emergency card to trigger loud automatic speech playback in the local country language.',
      'Open "Fullscreen Flashcard Mode" to display massive high-contrast text to paramedics or bystanders.',
      'Activate the "Audio Siren / Repeat Broadcast" if you need urgent attention in a noisy area.'
    ],
    proTips: [
      'Works 100% offline with zero cellular data or Wi-Fi required.',
      'Shows local emergency dispatch numbers (Police, Ambulance, Fire) for over 15 popular tourist countries.'
    ],
    offlineCapable: true
  },
  {
    id: 'travel-phrasebook',
    title: 'Travel Phrasebook & Categories',
    subtitle: 'Curated situational survival guides for dining, transit, shopping, lodging, and greetings',
    icon: BookOpen,
    iconColor: 'text-violet-400 bg-violet-500/10 border-violet-500/30',
    badge: 'Essential Guide',
    badgeColor: 'bg-violet-500/20 text-violet-300 border-violet-500/40',
    howToUse: [
      'Browse categories: Essentials, Ordering Food, Asking for Check, Metro & Taxis, Hotel Wi-Fi & Check-in.',
      'Tap any phrase to instantly copy, translate into your selected target language, or play aloud.',
      'Star frequently used phrases to keep them pinned to your quick-access favorites list.'
    ],
    proTips: [
      'Use the filter search bar to quickly find niche phrases like "vegetarian", "tax refund", or "pharmacy".'
    ],
    offlineCapable: true
  },
  {
    id: 'offline-mode',
    title: 'Offline Language Packs',
    subtitle: 'Download dictionary packages and phrases to stay translated when roaming without internet',
    icon: WifiOff,
    iconColor: 'text-amber-400 bg-amber-500/10 border-amber-500/30',
    badge: 'Roaming Ready',
    badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
    howToUse: [
      'Open the Offline Packs manager from the main header or quick actions.',
      'Download language packs (Spanish, French, Japanese, Mandarin, German, etc.) before boarding your flight.',
      'Toggle "Offline Simulation Mode" in the header to test your setup with zero internet connectivity.'
    ],
    proTips: [
      'Pre-download your destination pack to save expensive international cellular roaming costs.'
    ],
    offlineCapable: true
  },
  {
    id: 'mobile-install',
    title: 'Install on Android & iOS',
    subtitle: 'Add Omni Translate to your phone home screen for instant fullscreen native access',
    icon: Sparkles,
    iconColor: 'text-teal-400 bg-teal-500/10 border-teal-500/30',
    badge: 'Android & iOS',
    badgeColor: 'bg-teal-500/20 text-teal-300 border-teal-500/40',
    howToUse: [
      '🤖 On Android (Chrome / Edge): Tap the 3-dots menu (⋮) in the top right ➔ Tap "Install app" or "Add to Home screen".',
      '🍏 On iOS (Safari on iPhone / iPad): Tap the Share button (square with arrow ↑) ➔ Scroll down and tap "Add to Home Screen".',
      'The app will install as a standalone native-feeling icon on your home screen with offline cache and full screen support.'
    ],
    proTips: [
      'Installed home screen mode gives you instant one-tap translation without browser address bars.'
    ],
    offlineCapable: true
  }
];

export const UserGuideSection: React.FC = () => {
  const [expandedId, setExpandedId] = useState<string | null>('live-voice');

  const toggleExpand = (id: string) => {
    setExpandedId(prev => (prev === id ? null : id));
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between pb-2 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <HelpCircle className="w-4 h-4 text-indigo-400" />
          <h3 className="text-sm font-bold text-slate-100 uppercase tracking-wide">
            Comprehensive Feature & User Guide
          </h3>
        </div>
        <span className="text-[11px] font-semibold text-slate-400">
          {FEATURE_GUIDES.length} Guides & Modules
        </span>
      </div>

      <p className="text-xs text-slate-400 leading-relaxed">
        Learn how to get the most out of Omni Translate in real-world scenarios — from bustling train stations to airport counters and offline remote areas.
      </p>

      {/* Feature Guide Accordions */}
      <div className="space-y-2.5">
        {FEATURE_GUIDES.map(feature => {
          const Icon = feature.icon;
          const isExpanded = expandedId === feature.id;

          return (
            <div
              key={feature.id}
              className={`rounded-2xl border transition-all overflow-hidden ${
                isExpanded
                  ? 'bg-slate-800/80 border-slate-700 shadow-md'
                  : 'bg-slate-800/40 border-slate-800/80 hover:bg-slate-800/60'
              }`}
            >
              {/* Accordion Header */}
              <button
                type="button"
                onClick={() => toggleExpand(feature.id)}
                className="w-full p-3.5 flex items-center justify-between text-left gap-3 select-none"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`w-9 h-9 rounded-xl border flex items-center justify-center shrink-0 ${feature.iconColor}`}
                  >
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-bold text-slate-100 truncate">
                        {feature.title}
                      </span>
                      <span
                        className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${feature.badgeColor}`}
                      >
                        {feature.badge}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 truncate mt-0.5">
                      {feature.subtitle}
                    </p>
                  </div>
                </div>

                <div className="text-slate-400 shrink-0 ml-2">
                  {isExpanded ? (
                    <ChevronUp className="w-4 h-4 text-indigo-400" />
                  ) : (
                    <ChevronDown className="w-4 h-4" />
                  )}
                </div>
              </button>

              {/* Accordion Body */}
              {isExpanded && (
                <div className="px-4 pb-4 pt-1 border-t border-slate-700/50 space-y-3.5 text-xs text-slate-300 animate-fade-in">
                  {/* How to use */}
                  <div>
                    <h4 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-indigo-400" />
                      How to Use Step-by-Step
                    </h4>
                    <ul className="space-y-1.5 pl-1">
                      {feature.howToUse.map((step, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-slate-300">
                          <span className="w-4 h-4 rounded-full bg-indigo-500/20 text-indigo-300 text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">
                            {idx + 1}
                          </span>
                          <span className="leading-relaxed">{step}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Pro Tips */}
                  {feature.proTips.length > 0 && (
                    <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-700/60">
                      <h4 className="text-[11px] font-bold text-amber-300 uppercase tracking-wider mb-1 flex items-center gap-1.5">
                        <Sparkles className="w-3 h-3 text-amber-400" />
                        Travel Pro-Tip
                      </h4>
                      <ul className="space-y-1 text-[11px] text-slate-300">
                        {feature.proTips.map((tip, idx) => (
                          <li key={idx} className="flex items-start gap-1.5">
                            <span className="text-amber-400 font-bold">•</span>
                            <span className="leading-relaxed">{tip}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Developer Support & Feedback Card */}
      <div className="p-3.5 bg-slate-800/80 border border-slate-700/80 rounded-2xl flex items-center justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-9 h-9 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center shrink-0">
            <Mail className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <p className="text-xs font-bold text-slate-100">App Support & Inquiries</p>
            <p className="text-[11px] text-slate-400 truncate">piappsupport@gmail.com</p>
          </div>
        </div>
        <a
          href="mailto:piappsupport@gmail.com?subject=Travel%20Guide%20Pro%20App%20Support"
          className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition-colors shrink-0 shadow-sm"
        >
          Contact
        </a>
      </div>
    </div>
  );
};
