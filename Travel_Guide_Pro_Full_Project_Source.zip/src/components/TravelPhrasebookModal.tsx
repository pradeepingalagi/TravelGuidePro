import React, { useState } from 'react';
import { 
  Compass, 
  Search, 
  Volume2, 
  Maximize2, 
  X, 
  Sparkles, 
  Check, 
  Hospital, 
  Utensils, 
  Car, 
  Building, 
  ShoppingBag, 
  Copy,
  ArrowLeft
} from 'lucide-react';
import { Language, TravelPhraseCategory, VoiceSettings } from '../types';
import { TRAVEL_CATEGORIES } from '../data/travelPhrases';
import { translateTextApi } from '../services/translationService';
import { speakText, stopSpeaking } from '../utils/speech';

interface TravelPhrasebookModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetLang: Language;
  onOpenTargetSelector: () => void;
  voiceSettings: VoiceSettings;
}

export const TravelPhrasebookModal: React.FC<TravelPhrasebookModalProps> = ({
  isOpen,
  onClose,
  targetLang,
  onOpenTargetSelector,
  voiceSettings,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('hospital');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTranslations, setActiveTranslations] = useState<Record<string, { translated: string; pronunciation?: string }>>({});
  const [loadingId, setLoadingId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [fullscreenPhrase, setFullscreenPhrase] = useState<{ original: string; translated: string } | null>(null);

  if (!isOpen) return null;

  const currentCategory = TRAVEL_CATEGORIES.find(c => c.id === selectedCategory) || TRAVEL_CATEGORIES[0];

  const handleTranslatePhrase = async (phraseId: string, englishText: string) => {
    if (activeTranslations[phraseId]) {
      speakText(activeTranslations[phraseId].translated, targetLang.speechCode, {
        speechRate: voiceSettings.speechRate,
      });
      return;
    }

    setLoadingId(phraseId);
    try {
      const res = await translateTextApi({
        text: englishText,
        sourceLang: 'English',
        targetLang: targetLang.name,
        context: 'travel-phrasebook',
      });

      if (res.success) {
        setActiveTranslations(prev => ({
          ...prev,
          [phraseId]: {
            translated: res.translatedText,
            pronunciation: res.pronunciation || undefined,
          },
        }));
        speakText(res.translatedText, targetLang.speechCode, {
          speechRate: voiceSettings.speechRate,
        });
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingId(null);
    }
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-2 sm:p-4 select-none animate-fade-in">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="p-3.5 sm:p-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/95 gap-2">
          <div className="flex items-center gap-2 sm:gap-2.5 min-w-0">
            <button
              onClick={onClose}
              className="sm:hidden p-1.5 -ml-1 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors shrink-0"
              title="Back"
              aria-label="Back"
            >
              <ArrowLeft className="w-5 h-5 text-amber-400" />
            </button>
            <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center shrink-0">
              <Compass className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <div className="min-w-0">
              <h2 className="text-sm sm:text-base font-bold text-slate-100 truncate">Travel Phrasebook</h2>
              <p className="text-[11px] sm:text-xs text-slate-400 hidden sm:block truncate">Essential spoken phrases for international travel</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="flex items-center gap-1.5 px-2.5 py-1 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors text-xs font-semibold shrink-0"
            title="Close (Esc)"
          >
            <span className="hidden sm:inline">Close</span>
            <kbd className="hidden sm:inline-block text-[10px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded border border-slate-700 font-mono">Esc</kbd>
            <X className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>
        </div>

        {/* Target language selector bar */}
        <div className="px-4 py-2 bg-slate-950/50 border-b border-slate-800/80 flex items-center justify-between text-xs">
          <span className="text-slate-400">Translate to:</span>
          <button
            onClick={onOpenTargetSelector}
            className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1 rounded-full font-bold border border-slate-700"
          >
            <span>{targetLang.flag}</span>
            <span>{targetLang.name}</span>
          </button>
        </div>

        {/* Category horizontal scroll list */}
        <div className="p-2 border-b border-slate-800/80 flex items-center gap-1.5 overflow-x-auto scrollbar-none">
          {TRAVEL_CATEGORIES.map(cat => {
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                  isSelected
                    ? 'bg-indigo-600 text-white shadow-md'
                    : 'bg-slate-800/80 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
              >
                <span>{cat.title}</span>
              </button>
            );
          })}
        </div>

        {/* Phrases List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {currentCategory.phrases.map(item => {
            const trans = activeTranslations[item.id];
            const isLoading = loadingId === item.id;

            return (
              <div
                key={item.id}
                className="bg-slate-800/60 border border-slate-700/60 rounded-2xl p-3.5 hover:border-slate-600 transition-all space-y-2"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-semibold block">
                      {item.context}
                    </span>
                    <div className="text-sm font-medium text-slate-100 mt-0.5">
                      "{item.english}"
                    </div>
                  </div>

                  <button
                    onClick={() => handleTranslatePhrase(item.id, item.english)}
                    className="flex items-center gap-1 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold shadow-sm active:scale-95 transition-all"
                  >
                    {isLoading ? (
                      <span className="animate-spin text-xs">⏳</span>
                    ) : (
                      <Volume2 className="w-3.5 h-3.5" />
                    )}
                    <span>{trans ? 'Speak' : 'Translate'}</span>
                  </button>
                </div>

                {trans && (
                  <div className="pt-2 border-t border-slate-700/50 space-y-1">
                    <div className="text-sm font-bold text-indigo-300">
                      "{trans.translated}"
                    </div>
                    {trans.pronunciation && (
                      <div className="text-xs text-slate-400 font-mono italic">
                        🗣 {trans.pronunciation}
                      </div>
                    )}

                    <div className="flex items-center justify-end gap-1 pt-1">
                      <button
                        onClick={() => handleCopy(item.id, trans.translated)}
                        className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-700"
                        title="Copy"
                      >
                        {copiedId === item.id ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                      <button
                        onClick={() =>
                          setFullscreenPhrase({
                            original: item.english,
                            translated: trans.translated,
                          })
                        }
                        className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-700"
                        title="Show full screen"
                      >
                        <Maximize2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Fullscreen view for showing to taxi driver/hotel desk */}
      {fullscreenPhrase && (
        <div className="fixed inset-0 z-50 bg-slate-950 flex flex-col justify-between p-6 text-center select-none animate-fade-in">
          <div className="flex justify-end">
            <button
              onClick={() => setFullscreenPhrase(null)}
              className="p-2 text-slate-300 hover:text-white bg-slate-800 rounded-full"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          <div className="my-auto space-y-4">
            <div className="text-3xl sm:text-4xl font-extrabold text-white leading-tight">
              "{fullscreenPhrase.translated}"
            </div>
            <div className="text-sm text-slate-400">
              English: "{fullscreenPhrase.original}"
            </div>
          </div>

          <button
            onClick={() => speakText(fullscreenPhrase.translated, targetLang.speechCode)}
            className="w-full py-3.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl font-bold text-sm shadow-xl flex items-center justify-center gap-2"
          >
            <Volume2 className="w-5 h-5" />
            <span>Speak Again</span>
          </button>
        </div>
      )}
    </div>
  );
};
