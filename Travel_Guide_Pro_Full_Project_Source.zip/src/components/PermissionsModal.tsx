import React, { useState, useEffect } from 'react';
import { 
  Mic, 
  Camera, 
  MapPin, 
  ShieldCheck, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  Sparkles, 
  X, 
  Lock, 
  ArrowRight,
  Loader2,
  RefreshCw,
  Settings,
  ExternalLink,
  Info
} from 'lucide-react';
import { 
  checkAllPermissions, 
  requestMicrophoneAccess, 
  requestCameraAccess, 
  requestLocationAccess, 
  PermissionStateValue, 
  AppPermissionsStatus,
  isStandaloneApp
} from '../utils/permissions';

import { AndroidSettingsGuideModal } from './AndroidSettingsGuideModal';

interface PermissionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPermissionsUpdated?: (status: AppPermissionsStatus) => void;
  isInitialOnboarding?: boolean;
}

export const PermissionsModal: React.FC<PermissionsModalProps> = ({
  isOpen,
  onClose,
  onPermissionsUpdated,
  isInitialOnboarding = false,
}) => {
  const [statuses, setStatuses] = useState<{
    mic: PermissionStateValue;
    cam: PermissionStateValue;
    loc: PermissionStateValue;
  }>({
    mic: 'prompt',
    cam: 'prompt',
    loc: 'prompt',
  });

  const [loadingAction, setLoadingAction] = useState<'all' | 'mic' | 'cam' | 'loc' | null>(null);
  const [errorMessages, setErrorMessages] = useState<{ [key: string]: string }>({});
  const [showTroubleshooting, setShowTroubleshooting] = useState(false);
  const [selectedDeniedFeature, setSelectedDeniedFeature] = useState<'Location' | 'Microphone' | 'Camera' | 'All'>('All');
  const [isGuideOpen, setIsGuideOpen] = useState(false);

  const refreshStatuses = async () => {
    try {
      const perms = await checkAllPermissions();
      let locState = perms.location;
      // If location is denied or prompt, attempt quick test with getCurrentPosition
      if (locState !== 'granted' && typeof navigator !== 'undefined' && navigator.geolocation) {
        try {
          const res = await requestLocationAccess();
          if (res.granted) {
            locState = 'granted';
          }
        } catch {}
      }
      setStatuses({
        mic: perms.microphone,
        cam: perms.camera,
        loc: locState,
      });
      if (onPermissionsUpdated) {
        onPermissionsUpdated({
          microphone: perms.microphone,
          camera: perms.camera,
          location: locState,
          lastChecked: Date.now(),
        });
      }
    } catch (e) {
      console.warn('Error refreshing permissions:', e);
    }
  };

  useEffect(() => {
    if (isOpen) {
      refreshStatuses();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  // Trigger Android/Browser Microphone permission pop-up
  const handleRequestMic = async () => {
    setLoadingAction('mic');
    setErrorMessages(prev => ({ ...prev, mic: '' }));
    try {
      const res = await requestMicrophoneAccess();
      if (res.granted) {
        setStatuses(prev => ({ ...prev, mic: 'granted' }));
      } else {
        setStatuses(prev => ({ ...prev, mic: 'denied' }));
        if (res.error) setErrorMessages(prev => ({ ...prev, mic: res.error! }));
      }
    } finally {
      setLoadingAction(null);
      await refreshStatuses();
    }
  };

  // Trigger Android/Browser Camera permission pop-up
  const handleRequestCam = async () => {
    setLoadingAction('cam');
    setErrorMessages(prev => ({ ...prev, cam: '' }));
    try {
      const res = await requestCameraAccess();
      if (res.granted) {
        setStatuses(prev => ({ ...prev, cam: 'granted' }));
      } else {
        setStatuses(prev => ({ ...prev, cam: 'denied' }));
        if (res.error) setErrorMessages(prev => ({ ...prev, cam: res.error! }));
      }
    } finally {
      setLoadingAction(null);
      await refreshStatuses();
    }
  };

  // Trigger Android/Browser Location permission pop-up
  const handleRequestLoc = async () => {
    setLoadingAction('loc');
    setErrorMessages(prev => ({ ...prev, loc: '' }));
    try {
      const res = await requestLocationAccess();
      if (res.granted) {
        setStatuses(prev => ({ ...prev, loc: 'granted' }));
      } else {
        setStatuses(prev => ({ ...prev, loc: 'denied' }));
        if (res.error) setErrorMessages(prev => ({ ...prev, loc: res.error! }));
      }
    } finally {
      setLoadingAction(null);
      await refreshStatuses();
    }
  };

  // Show in-app settings instructions (NEVER navigate to Google Play Store intent!)
  const handleOpenAppSettings = (featureName: 'Location' | 'Microphone' | 'Camera' | 'All') => {
    setSelectedDeniedFeature(featureName);
    setIsGuideOpen(true);
  };

  const allGranted = statuses.mic === 'granted' && statuses.cam === 'granted' && statuses.loc === 'granted';
  const anyDenied = statuses.mic === 'denied' || statuses.cam === 'denied' || statuses.loc === 'denied';

  const handleComplete = () => {
    try {
      localStorage.setItem('omnitranslate_permissions_intro_shown', 'true');
      localStorage.setItem('live_ai_permissions_checked', 'true');
      localStorage.setItem('omnitranslate_permissions_checked', 'true');
    } catch (e) {}
    onClose();
  };

  // Update status badge: Enabled (granted) vs Denied/Prompt
  const renderStatusBadge = (status: PermissionStateValue, loading: boolean) => {
    if (loading) {
      return (
        <span className="flex items-center gap-1.5 text-[11px] font-bold text-indigo-400 bg-indigo-500/10 border border-indigo-500/30 px-2.5 py-1 rounded-full">
          <Loader2 className="w-3 h-3 animate-spin" />
          <span>Prompting...</span>
        </span>
      );
    }
    if (status === 'granted') {
      return (
        <span className="flex items-center gap-1.5 text-[11px] font-bold text-emerald-300 bg-emerald-500/20 border border-emerald-500/40 px-3 py-1 rounded-full shadow-sm shadow-emerald-500/10">
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
          <span>Enabled</span>
        </span>
      );
    }
    if (status === 'denied') {
      return (
        <span className="flex items-center gap-1.5 text-[11px] font-bold text-rose-300 bg-rose-500/15 border border-rose-500/30 px-2.5 py-1 rounded-full">
          <XCircle className="w-3.5 h-3.5 text-rose-400" />
          <span>Blocked in Settings</span>
        </span>
      );
    }
    return (
      <span className="flex items-center gap-1.5 text-[11px] font-medium text-slate-400 bg-slate-800/80 border border-slate-700/80 px-2.5 py-1 rounded-full">
        <AlertCircle className="w-3 h-3 text-slate-400" />
        <span>Not Enabled</span>
      </span>
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-3 sm:p-4 select-none animate-fade-in">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
        
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center shadow-lg shadow-indigo-600/20 shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h2 className="text-sm sm:text-base font-bold text-slate-100 flex items-center gap-2">
                Permissions & Privacy
                {isInitialOnboarding && (
                  <span className="text-[10px] bg-indigo-600 text-white font-bold px-2 py-0.5 rounded-full shrink-0">
                    Welcome
                  </span>
                )}
              </h2>
              <p className="text-[11px] sm:text-xs text-slate-400 truncate">
                Configure features as you need them. No background tracking.
              </p>
            </div>
          </div>

          <button
            onClick={handleComplete}
            className="flex items-center gap-1.5 px-2.5 py-1 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors text-xs font-semibold shrink-0"
            title="Close"
          >
            <span className="hidden sm:inline">Skip</span>
            <X className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>
        </div>

        {/* Content list */}
        <div className="p-4 sm:p-5 space-y-3.5 overflow-y-auto flex-1 text-slate-200">
          
          {/* Friendly Introduction */}
          <div className="bg-indigo-950/30 border border-indigo-500/20 rounded-2xl p-3 text-xs text-slate-300 leading-relaxed flex items-start gap-2.5">
            <Info className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-slate-100">You're in full control:</span> Text translation, offline phrasebook, currency rates, and travel guides work 100% without permissions. Enable sensors only when you want hands-free voice or camera translation.
            </div>
          </div>

          {/* 1. Location Permission Item */}
          <div className="p-3.5 bg-slate-950/70 border border-slate-800 rounded-2xl space-y-2 hover:border-slate-700/80 transition-colors">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-3">
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 mt-0.5 ${
                  statuses.loc === 'granted' 
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' 
                    : 'bg-amber-600/20 text-amber-400 border border-amber-500/30'
                }`}>
                  <MapPin className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-100 flex items-center gap-2">
                    Location Access
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5 leading-snug">
                    Auto-detects country, suggests local spoken languages, and pre-loads local SOS police/medical contacts.
                  </p>
                </div>
              </div>

              <div className="shrink-0 flex items-center gap-2">
                {renderStatusBadge(statuses.loc, loadingAction === 'loc')}
                {statuses.loc !== 'granted' && (
                  <button
                    id="permissions-modal-enable-loc-btn"
                    onClick={handleRequestLoc}
                    disabled={loadingAction !== null}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-bold shadow-sm transition-all active:scale-95 disabled:opacity-50 cursor-pointer"
                  >
                    <MapPin className="w-3.5 h-3.5" />
                    <span>{statuses.loc === 'denied' ? 'Allow / Verify' : 'Enable Location'}</span>
                  </button>
                )}
                {statuses.loc === 'denied' && (
                  <button
                    onClick={() => handleOpenAppSettings('Location')}
                    className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 rounded-xl text-xs font-bold transition-all active:scale-95 cursor-pointer"
                    title="How to enable in Android Phone Settings"
                  >
                    <Settings className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Settings Guide</span>
                  </button>
                )}
              </div>
            </div>
            {errorMessages.loc && (
              <div className="text-[11px] text-amber-300 bg-amber-950/40 border border-amber-800/40 p-2 rounded-xl">
                {errorMessages.loc}
              </div>
            )}
          </div>

          {/* 2. Camera Permission Item */}
          <div className="p-3.5 bg-slate-950/70 border border-slate-800 rounded-2xl space-y-2 hover:border-slate-700/80 transition-colors">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-3">
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 mt-0.5 ${
                  statuses.cam === 'granted' 
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' 
                    : 'bg-teal-600/20 text-teal-400 border border-teal-500/30'
                }`}>
                  <Camera className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-100 flex items-center gap-2">
                    Camera & Sign OCR
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5 leading-snug">
                    Instant optical text translation for restaurant menus, road signs, subways, and notices.
                  </p>
                </div>
              </div>

              <div className="shrink-0 flex items-center gap-2">
                {renderStatusBadge(statuses.cam, loadingAction === 'cam')}
                {statuses.cam !== 'granted' && (
                  <button
                    id="permissions-modal-enable-cam-btn"
                    onClick={handleRequestCam}
                    disabled={loadingAction !== null}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-teal-600 hover:bg-teal-500 text-white rounded-xl text-xs font-bold shadow-sm transition-all active:scale-95 disabled:opacity-50 cursor-pointer"
                  >
                    <Camera className="w-3.5 h-3.5" />
                    <span>{statuses.cam === 'denied' ? 'Allow / Verify' : 'Enable Camera'}</span>
                  </button>
                )}
                {statuses.cam === 'denied' && (
                  <button
                    onClick={() => handleOpenAppSettings('Camera')}
                    className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-teal-300 border border-slate-700 rounded-xl text-xs font-bold transition-all active:scale-95 cursor-pointer"
                    title="How to enable in Android Phone Settings"
                  >
                    <Settings className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Settings Guide</span>
                  </button>
                )}
              </div>
            </div>
            {errorMessages.cam && (
              <div className="text-[11px] text-amber-300 bg-amber-950/40 border border-amber-800/40 p-2 rounded-xl">
                {errorMessages.cam}
              </div>
            )}
          </div>

          {/* 3. Microphone Permission Item */}
          <div className="p-3.5 bg-slate-950/70 border border-slate-800 rounded-2xl space-y-2 hover:border-slate-700/80 transition-colors">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-3">
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 mt-0.5 ${
                  statuses.mic === 'granted' 
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' 
                    : 'bg-indigo-600/20 text-indigo-400 border border-indigo-500/30'
                }`}>
                  <Mic className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-100 flex items-center gap-2">
                    Microphone Access
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5 leading-snug">
                    Real-time 2-way voice conversation, tabletop face-to-face translation, and speech dictation.
                  </p>
                </div>
              </div>

              <div className="shrink-0 flex items-center gap-2">
                {renderStatusBadge(statuses.mic, loadingAction === 'mic')}
                {statuses.mic !== 'granted' && (
                  <button
                    id="permissions-modal-enable-mic-btn"
                    onClick={handleRequestMic}
                    disabled={loadingAction !== null}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold shadow-sm transition-all active:scale-95 disabled:opacity-50 cursor-pointer"
                  >
                    <Mic className="w-3.5 h-3.5" />
                    <span>{statuses.mic === 'denied' ? 'Allow / Verify' : 'Enable Mic'}</span>
                  </button>
                )}
                {statuses.mic === 'denied' && (
                  <button
                    onClick={() => handleOpenAppSettings('Microphone')}
                    className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-indigo-300 border border-slate-700 rounded-xl text-xs font-bold transition-all active:scale-95 cursor-pointer"
                    title="How to enable in Android Phone Settings"
                  >
                    <Settings className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Settings Guide</span>
                  </button>
                )}
              </div>
            </div>
            {errorMessages.mic && (
              <div className="text-[11px] text-amber-300 bg-amber-950/40 border border-amber-800/40 p-2 rounded-xl">
                {errorMessages.mic}
              </div>
            )}
          </div>

          {/* Android App Settings Guidance if Denied / Blocked */}
          {(anyDenied || showTroubleshooting) && (
            <div className="bg-slate-950 border border-amber-500/30 rounded-2xl p-3.5 space-y-2.5 animate-fade-in">
              <div className="flex items-center justify-between text-xs font-bold text-amber-300">
                <span className="flex items-center gap-1.5">
                  <Lock className="w-4 h-4 text-amber-400" />
                  <span>How to enable in Android Phone Settings</span>
                </span>
                <button
                  onClick={() => handleOpenAppSettings('All')}
                  className="text-[11px] text-indigo-400 hover:text-indigo-300 font-semibold underline cursor-pointer"
                >
                  View Step-by-Step
                </button>
              </div>

              <div className="text-[11px] text-slate-300 space-y-1.5 pt-1 border-t border-slate-800/80 leading-relaxed">
                <p className="text-slate-400">
                  If already allowed in Android Settings, tap <strong>"Allow / Verify"</strong> above or <strong>"Re-check Status"</strong> below to update immediately.
                </p>
              </div>
            </div>
          )}

          {/* Privacy & No Background Sensors Guarantee */}
          <div className="flex items-start gap-2.5 text-[11px] text-slate-400 bg-slate-950/60 p-3 rounded-2xl border border-slate-800/80">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-slate-300 font-semibold">Zero Background Usage:</strong> We do not keep camera or microphone active in the background. Hardware streams are only accessed when you explicitly start voice conversation or scan a sign.
            </div>
          </div>
        </div>

        {/* Footer Action Bar */}
        <div className="p-3.5 sm:p-4 border-t border-slate-800 bg-slate-950/80 flex flex-col sm:flex-row items-center justify-between gap-3">
          <button
            onClick={refreshStatuses}
            className="flex items-center gap-1.5 text-xs text-slate-300 hover:text-white transition-colors order-2 sm:order-1 font-semibold cursor-pointer"
            title="Refresh current permission states from device"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Re-check Status</span>
          </button>

          <div className="flex items-center gap-2 w-full sm:w-auto order-1 sm:order-2">
            <button
              id="continue-to-app-btn"
              onClick={handleComplete}
              className={`flex-1 sm:flex-initial flex items-center justify-center gap-2 py-2.5 px-6 rounded-xl text-xs font-bold transition-all active:scale-95 cursor-pointer ${
                allGranted
                  ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-600/30'
                  : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/30'
              }`}
            >
              <span>{allGranted ? 'Enter App' : 'Continue to App'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Settings Guide Modal */}
      <AndroidSettingsGuideModal
        isOpen={isGuideOpen}
        onClose={() => setIsGuideOpen(false)}
        onVerify={refreshStatuses}
        targetFeature={selectedDeniedFeature}
      />
    </div>
  );
};
