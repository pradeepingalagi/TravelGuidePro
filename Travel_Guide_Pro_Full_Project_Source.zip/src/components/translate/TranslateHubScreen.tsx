import React, { useState } from 'react';
import { 
  MessagesSquare, 
  Camera, 
  FileText, 
  AlertTriangle, 
  Compass, 
  History, 
  Download, 
  Smartphone, 
  Users, 
  Settings,
  Sparkles
} from 'lucide-react';
import { Language, TranslationRecord, VoiceSettings } from '../../types';
import { ConversationScreen, ConversationMode } from '../ConversationScreen';
import { CameraTranslateScreen } from '../CameraTranslateScreen';
import { TextTranslateScreen } from '../TextTranslateScreen';
import { EmergencyScreen } from '../EmergencyScreen';

export type TranslateSubMode = 'conversation' | 'camera' | 'text' | 'emergency';

interface TranslateHubScreenProps {
  sourceLang: Language;
  targetLang: Language;
  onOpenSourceSelector: () => void;
  onOpenTargetSelector: () => void;
  onSwapLanguages: () => void;
  voiceSettings: VoiceSettings;
  onAddTranslation: (record: TranslationRecord) => void;
  isOffline: boolean;
  onOpenPhrasebook: () => void;
  onOpenOfflinePacks: () => void;
  onOpenHistory: () => void;
  onOpenSettings: () => void;
  initialSubMode?: TranslateSubMode;
}

export const TranslateHubScreen: React.FC<TranslateHubScreenProps> = ({
  sourceLang,
  targetLang,
  onOpenSourceSelector,
  onOpenTargetSelector,
  onSwapLanguages,
  voiceSettings,
  onAddTranslation,
  isOffline,
  onOpenPhrasebook,
  onOpenOfflinePacks,
  onOpenHistory,
  onOpenSettings,
  initialSubMode = 'conversation',
}) => {
  const [activeSubMode, setActiveSubMode] = useState<TranslateSubMode>(initialSubMode);
  const [conversationMode, setConversationMode] = useState<ConversationMode>('handheld');

  return (
    <div className="space-y-4 pb-12 animate-fade-in max-w-4xl mx-auto">
      {/* 1. Sub-Navigation Ribbon covering ALL Translation Features in the same tab */}
      <div className="bg-slate-900/90 border border-slate-800 p-2 rounded-2xl flex items-center justify-between gap-2 overflow-x-auto no-scrollbar shadow-md">
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            id="translate-subtab-conversation"
            onClick={() => setActiveSubMode('conversation')}
            className={`px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 ${
              activeSubMode === 'conversation'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            <MessagesSquare className="w-4 h-4 text-indigo-300" />
            <span>Live Voice</span>
            <span className="hidden sm:inline text-[10px] text-indigo-200/80 bg-indigo-700/50 px-1.5 py-0.5 rounded">
              {conversationMode === 'tabletop' ? 'Tabletop' : 'Handheld'}
            </span>
          </button>

          <button
            id="translate-subtab-camera"
            onClick={() => setActiveSubMode('camera')}
            className={`px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 ${
              activeSubMode === 'camera'
                ? 'bg-teal-600 text-white shadow-md shadow-teal-600/30'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Camera className="w-4 h-4 text-teal-300" />
            <span>Camera & OCR</span>
          </button>

          <button
            id="translate-subtab-text"
            onClick={() => setActiveSubMode('text')}
            className={`px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 ${
              activeSubMode === 'text'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            <FileText className="w-4 h-4 text-blue-300" />
            <span>Text & Paste</span>
          </button>

          <button
            id="translate-subtab-emergency"
            onClick={() => setActiveSubMode('emergency')}
            className={`px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 ${
              activeSubMode === 'emergency'
                ? 'bg-red-600 text-white shadow-md shadow-red-600/30'
                : 'text-red-400 hover:text-red-300 hover:bg-red-950/40'
            }`}
          >
            <AlertTriangle className="w-4 h-4" />
            <span>SOS</span>
          </button>
        </div>

        {/* Quick Auxiliary Translation Tools */}
        <div className="flex items-center gap-1 shrink-0 pl-2 border-l border-slate-800">
          <button
            onClick={onOpenPhrasebook}
            className="p-2 rounded-xl text-slate-400 hover:text-amber-400 hover:bg-slate-800 text-xs font-medium flex items-center gap-1 transition-colors"
            title="Travel Phrasebook (Offline)"
          >
            <Compass className="w-4 h-4 text-amber-400" />
            <span className="hidden sm:inline">Phrasebook</span>
          </button>

          <button
            onClick={onOpenOfflinePacks}
            className="p-2 rounded-xl text-slate-400 hover:text-emerald-400 hover:bg-slate-800 text-xs font-medium flex items-center gap-1 transition-colors"
            title="Download Offline Language Packs"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span className="hidden sm:inline">Offline</span>
          </button>

          <button
            onClick={onOpenHistory}
            className="p-2 rounded-xl text-slate-400 hover:text-indigo-400 hover:bg-slate-800 text-xs font-medium flex items-center gap-1 transition-colors"
            title="Translation History"
          >
            <History className="w-4 h-4 text-indigo-400" />
            <span className="hidden sm:inline">History</span>
          </button>
        </div>
      </div>

      {/* 2. Active Translation Feature Screen Content */}
      <div className="animate-fade-in">
        {activeSubMode === 'conversation' && (
          <ConversationScreen
            sourceLang={sourceLang}
            targetLang={targetLang}
            onOpenSourceSelector={onOpenSourceSelector}
            onOpenTargetSelector={onOpenTargetSelector}
            onSwapLanguages={onSwapLanguages}
            voiceSettings={voiceSettings}
            onAddTranslation={onAddTranslation}
            isOffline={isOffline}
            initialMode={conversationMode}
            onModeChange={(mode) => setConversationMode(mode)}
          />
        )}

        {activeSubMode === 'camera' && (
          <CameraTranslateScreen
            sourceLang={sourceLang}
            targetLang={targetLang}
            onOpenTargetSelector={onOpenTargetSelector}
            onSwapLanguages={onSwapLanguages}
            voiceSettings={voiceSettings}
            onAddTranslation={onAddTranslation}
          />
        )}

        {activeSubMode === 'text' && (
          <TextTranslateScreen
            sourceLang={sourceLang}
            targetLang={targetLang}
            onOpenSourceSelector={onOpenSourceSelector}
            onOpenTargetSelector={onOpenTargetSelector}
            onSwapLanguages={onSwapLanguages}
            voiceSettings={voiceSettings}
            onAddTranslation={onAddTranslation}
          />
        )}

        {activeSubMode === 'emergency' && (
          <EmergencyScreen
            currentLanguage={targetLang}
            onOpenLanguageSelector={onOpenTargetSelector}
            voiceSettings={voiceSettings}
          />
        )}
      </div>
    </div>
  );
};
