import React from 'react';
import { 
  Smartphone, 
  Users, 
  ArrowRight, 
  ArrowLeftRight, 
  Sparkles, 
  Mic, 
  Volume2, 
  RotateCcw,
  Info
} from 'lucide-react';
import { Language } from '../types';

interface LiveConversationHubScreenProps {
  sourceLang: Language;
  targetLang: Language;
  onOpenSourceSelector: () => void;
  onOpenTargetSelector: () => void;
  onSwapLanguages: () => void;
  onSelectMode: (mode: 'handheld' | 'tabletop') => void;
  onBack?: () => void;
}

export const LiveConversationHubScreen: React.FC<LiveConversationHubScreenProps> = ({
  sourceLang,
  targetLang,
  onOpenSourceSelector,
  onOpenTargetSelector,
  onSwapLanguages,
  onSelectMode,
}) => {
  return (
    <div className="max-w-2xl mx-auto space-y-4 pb-10 animate-fade-in select-none">
      {/* Screen Title & Subtitle Banner */}
      <div className="bg-gradient-to-r from-indigo-950/60 via-slate-900 to-purple-950/40 border border-slate-800 rounded-3xl p-4 sm:p-5 shadow-xl">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-bold text-slate-100 tracking-tight">
                Live Conversation
              </h1>
              <span className="text-[11px] bg-indigo-500/20 text-indigo-300 font-bold border border-indigo-500/30 px-2.5 py-0.5 rounded-full">
                Real-Time Voice
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              Select your conversation setup. You can easily switch modes anytime.
            </p>
          </div>
        </div>

        {/* Language Selection Quick Bar */}
        <div className="mt-4 pt-3.5 border-t border-slate-800/80">
          <div className="flex items-center justify-between text-[11px] text-slate-400 font-medium mb-1.5 px-1">
            <span>Conversation Languages</span>
            <span className="text-slate-500">Tap language to change</span>
          </div>

          <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-2 flex items-center justify-between gap-2">
            {/* User 1 / Source */}
            <button
              id="hub-source-lang-btn"
              onClick={onOpenSourceSelector}
              className="flex-1 flex items-center gap-2 p-2 rounded-xl bg-slate-900/90 hover:bg-slate-800/90 border border-indigo-500/30 text-left transition-all group"
            >
              <span className="text-xl shrink-0 group-hover:scale-110 transition-transform">{sourceLang.flag}</span>
              <div className="truncate">
                <span className="text-[10px] text-indigo-400 font-bold uppercase tracking-wider block">Speaker 1</span>
                <span className="text-xs font-bold text-slate-100 truncate block">
                  {sourceLang.code === 'auto' ? 'Auto Detect' : sourceLang.name}
                </span>
              </div>
            </button>

            {/* Swap Languages Button */}
            <button
              id="hub-swap-lang-btn"
              onClick={onSwapLanguages}
              disabled={sourceLang.code === 'auto'}
              className={`w-9 h-9 rounded-full flex items-center justify-center border transition-all shrink-0 ${
                sourceLang.code === 'auto'
                  ? 'opacity-40 cursor-not-allowed bg-slate-800 text-slate-600 border-slate-700'
                  : 'bg-indigo-600/20 border-indigo-500/40 text-indigo-400 hover:bg-indigo-600 hover:text-white active:rotate-180'
              }`}
              title="Swap languages"
            >
              <ArrowLeftRight className="w-4 h-4" />
            </button>

            {/* User 2 / Target */}
            <button
              id="hub-target-lang-btn"
              onClick={onOpenTargetSelector}
              className="flex-1 flex items-center justify-end gap-2 p-2 rounded-xl bg-slate-900/90 hover:bg-slate-800/90 border border-purple-500/30 text-right transition-all group"
            >
              <div className="truncate">
                <span className="text-[10px] text-purple-400 font-bold uppercase tracking-wider block">Speaker 2</span>
                <span className="text-xs font-bold text-slate-100 truncate block">
                  {targetLang.name}
                </span>
              </div>
              <span className="text-xl shrink-0 group-hover:scale-110 transition-transform">{targetLang.flag}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Feature Options Grid: Handheld & Tabletop */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
        {/* 1. Handheld Mode Card */}
        <div
          id="select-handheld-mode-btn"
          onClick={() => onSelectMode('handheld')}
          className="group relative bg-gradient-to-br from-slate-900 via-slate-900 to-indigo-950/40 border border-indigo-500/30 hover:border-indigo-500/80 rounded-3xl p-5 text-left transition-all hover:shadow-xl hover:shadow-indigo-500/10 cursor-pointer active:scale-[0.98] flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between mb-3.5">
              <div className="w-12 h-12 rounded-2xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/40 flex items-center justify-center shadow-lg shadow-indigo-600/20 group-hover:scale-110 transition-transform">
                <Smartphone className="w-6 h-6" />
              </div>
              <span className="text-[11px] font-bold text-indigo-300 bg-indigo-500/20 border border-indigo-500/30 px-2.5 py-0.5 rounded-full">
                Handheld
              </span>
            </div>

            <h2 className="text-lg font-bold text-slate-100 group-hover:text-indigo-300 transition-colors flex items-center gap-1.5">
              Handheld Mode
            </h2>
            <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
              Hold the device in your hand between both speakers. Features dedicated microphones for each person, auto language detection, and audio replay.
            </p>

            <div className="mt-4 space-y-2">
              <div className="flex items-center gap-2 text-xs text-slate-300">
                <div className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
                <span>Individual speaker mics & auto-detect mic</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-300">
                <div className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
                <span>Live scrolling speech transcript bubbles</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-300">
                <div className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
                <span>Audio pronunciation playback & speed control</span>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center justify-between">
            <span className="text-xs font-bold text-indigo-400 group-hover:text-indigo-300">
              Open Handheld
            </span>
            <div className="w-8 h-8 rounded-xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white group-hover:translate-x-1 transition-all">
              <ArrowRight className="w-4 h-4" />
            </div>
          </div>
        </div>

        {/* 2. Tabletop Mode Card */}
        <div
          id="select-tabletop-mode-btn"
          onClick={() => onSelectMode('tabletop')}
          className="group relative bg-gradient-to-br from-slate-900 via-slate-900 to-purple-950/40 border border-purple-500/30 hover:border-purple-500/80 rounded-3xl p-5 text-left transition-all hover:shadow-xl hover:shadow-purple-500/10 cursor-pointer active:scale-[0.98] flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between mb-3.5">
              <div className="w-12 h-12 rounded-2xl bg-purple-600/20 text-purple-400 border border-purple-500/40 flex items-center justify-center shadow-lg shadow-purple-600/20 group-hover:scale-110 transition-transform">
                <Users className="w-6 h-6" />
              </div>
              <span className="text-[11px] font-bold text-purple-300 bg-purple-500/20 border border-purple-500/30 px-2.5 py-0.5 rounded-full">
                Face-to-Face
              </span>
            </div>

            <h2 className="text-lg font-bold text-slate-100 group-hover:text-purple-300 transition-colors flex items-center gap-1.5">
              Tabletop Mode
            </h2>
            <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
              Place the device flat on a table between two people. The top half is inverted 180° so your conversation partner can read translated text right-side up.
            </p>

            <div className="mt-4 space-y-2">
              <div className="flex items-center gap-2 text-xs text-slate-300">
                <div className="w-1.5 h-1.5 rounded-full bg-purple-400" />
                <span>180° inverted split-screen for partner</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-300">
                <div className="w-1.5 h-1.5 rounded-full bg-purple-400" />
                <span>Face-to-face table, counter & desk ready</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-300">
                <div className="w-1.5 h-1.5 rounded-full bg-purple-400" />
                <span>Hands-free continuous listening loop option</span>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center justify-between">
            <span className="text-xs font-bold text-purple-400 group-hover:text-purple-300">
              Open Tabletop
            </span>
            <div className="w-8 h-8 rounded-xl bg-purple-600/20 text-purple-400 flex items-center justify-center group-hover:bg-purple-600 group-hover:text-white group-hover:translate-x-1 transition-all">
              <ArrowRight className="w-4 h-4" />
            </div>
          </div>
        </div>
      </div>

      {/* Helpful Mode Switching Note */}
      <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-3.5 flex items-start gap-2.5 text-xs text-slate-400">
        <Info className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
        <p>
          <strong className="text-slate-200">Switch anytime:</strong> You can switch back and forth between Handheld and Tabletop mode while speaking by tapping the mode toggle at the top of the conversation screen.
        </p>
      </div>
    </div>
  );
};
