import React, { useState, useRef, useEffect, useMemo } from 'react';
import { 
  Camera, 
  RefreshCw, 
  Upload, 
  Volume2, 
  Copy, 
  Bookmark, 
  Sparkles, 
  AlertTriangle, 
  Check, 
  Zap, 
  ShieldAlert,
  X,
  Search,
  ZoomIn,
  ZoomOut,
  Maximize2,
  FileText,
  Layers,
  List,
  Globe,
  BookOpen,
  ArrowRight,
  Info
} from 'lucide-react';
import { Language, CameraDetectedBlock, TranslationRecord, VoiceSettings } from '../types';
import { SUPPORTED_LANGUAGES } from '../data/languages';
import { cameraTranslateApi } from '../services/translationService';
import { speakText, stopSpeaking } from '../utils/speech';

interface CameraTranslateScreenProps {
  sourceLang: Language;
  targetLang: Language;
  onSelectTargetLang?: (lang: Language) => void;
  onOpenTargetSelector: () => void;
  onSwapLanguages: () => void;
  voiceSettings: VoiceSettings;
  onAddTranslation: (record: TranslationRecord) => void;
  onClose: () => void;
}

// Helper to ensure uploaded or captured high-res images are scaled optimally for fast, sharp Gemini OCR
async function resizeImageIfNeeded(dataUrl: string, maxDim = 1200): Promise<string> {
  return new Promise((resolve) => {
    if (!dataUrl.startsWith('data:image')) {
      resolve(dataUrl);
      return;
    }
    const img = new Image();
    img.onload = () => {
      let { width, height } = img;
      if (width <= maxDim && height <= maxDim) {
        resolve(dataUrl);
        return;
      }
      if (width > height) {
        height = Math.round((height * maxDim) / width);
        width = maxDim;
      } else {
        width = Math.round((width * maxDim) / height);
        height = maxDim;
      }
      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', 0.82));
      } else {
        resolve(dataUrl);
      }
    };
    img.onerror = () => resolve(dataUrl);
    img.src = dataUrl;
  });
}

// Popular target language shortcuts for rapid 1-tap switching in Camera OCR
const QUICK_TARGET_LANGUAGES = [
  { code: 'en', name: 'English', flag: '🇺🇸' },
  { code: 'hi', name: 'Hindi', flag: '🇮🇳' },
  { code: 'es', name: 'Spanish', flag: '🇪🇸' },
  { code: 'fr', name: 'French', flag: '🇫🇷' },
  { code: 'de', name: 'German', flag: '🇩🇪' },
  { code: 'ja', name: 'Japanese', flag: '🇯🇵' },
  { code: 'zh', name: 'Chinese', flag: '🇨🇳' },
  { code: 'ar', name: 'Arabic', flag: '🇸🇦' },
  { code: 'ru', name: 'Russian', flag: '🇷🇺' },
  { code: 'pt', name: 'Portuguese', flag: '🇧🇷' },
  { code: 'it', name: 'Italian', flag: '🇮🇹' },
  { code: 'ko', name: 'Korean', flag: '🇰🇷' },
  { code: 'kn', name: 'Kannada', flag: '🇮🇳' },
  { code: 'ta', name: 'Tamil', flag: '🇮🇳' },
  { code: 'te', name: 'Telugu', flag: '🇮🇳' },
  { code: 'mr', name: 'Marathi', flag: '🇮🇳' },
  { code: 'bn', name: 'Bengali', flag: '🇮🇳' },
];

// Built-in test samples covering ALL major text types and scripts across the world
const SAMPLE_SIGNS: Array<{
  id: string;
  title: string;
  category: string;
  textType: string;
  image: string;
  overallLang: string;
  summary: string;
  fullDoc: string;
  mockBlocks: CameraDetectedBlock[];
}> = [
  {
    id: 'mumbai_station',
    title: '🚆 Transit Board (Hindi + English)',
    category: 'Railway & Transit',
    textType: 'sign',
    image: 'https://images.unsplash.com/photo-1570168007204-dfb528c6958f?w=800&auto=format&fit=crop&q=80',
    overallLang: 'Hindi & English',
    summary: 'Railway station main line entrance guidance with platform directions and safety warning against track crossing.',
    fullDoc: "Entrance Gate - Only for valid ticket holders.\nPlatform No. 1 - Main Line Express Trains.\nCaution: Crossing railway tracks is strictly prohibited and punishable by law.",
    mockBlocks: [
      { 
        originalText: 'प्रवेश द्वार - केवल वैध टिकट धारकों के लिए', 
        translatedText: 'Entrance Gate - Only for valid ticket holders', 
        romanization: 'Pravesh Dwaar - Keval Vaidh Ticket Dhaarakon Ke Liye',
        category: 'Notice', 
        detectedLanguage: 'Hindi',
        confidence: 'high',
        box: { top: 16, left: 12, width: 76, height: 19 } 
      },
      { 
        originalText: 'प्लेटफ़ॉर्म क्रमांक 1 - मुख्य लाइन', 
        translatedText: 'Platform No. 1 - Main Line Express', 
        romanization: 'Platform Kramank 1 - Mukhya Line',
        category: 'Wayfinding', 
        detectedLanguage: 'Hindi',
        confidence: 'high',
        box: { top: 42, left: 15, width: 70, height: 18 } 
      },
      { 
        originalText: 'सावधान: पटरी पार करना मना है', 
        translatedText: 'Caution: Crossing tracks is strictly prohibited', 
        romanization: 'Saavdhan: Patri Paar Karna Manaa Hai',
        category: 'Safety / Warning', 
        detectedLanguage: 'Hindi',
        confidence: 'high',
        box: { top: 68, left: 10, width: 80, height: 18 } 
      },
    ],
  },
  {
    id: 'delhi_hospital',
    title: '🏥 Hospital Emergency (Hindi)',
    category: 'Medical Sign',
    textType: 'sign',
    image: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=800&auto=format&fit=crop&q=80',
    overallLang: 'Hindi',
    summary: 'Hospital medical sign with 24/7 Emergency Room directions, pharmacy dispensary, and patient hygiene instructions.',
    fullDoc: "Emergency Medical Department - Open 24/7.\nPharmacy & Doctor Consultation Chamber.\nPlease maintain silence and wear a face mask inside premises.",
    mockBlocks: [
      { 
        originalText: 'आपातकालीन चिकित्सा विभाग (Emergency Room)', 
        translatedText: 'Emergency Medical Department - 24/7 Service', 
        romanization: 'Aapatkaleen Chikitsa Vibhaag',
        category: 'Sign', 
        detectedLanguage: 'Hindi',
        confidence: 'high',
        box: { top: 15, left: 10, width: 80, height: 22 } 
      },
      { 
        originalText: 'दवा वितरण केंद्र एवं परामर्श कक्ष', 
        translatedText: 'Pharmacy Dispensary & Doctor Consultation Chamber', 
        romanization: 'Dawa Vitaran Kendra Evam Paramarsh Kaksh',
        category: 'Wayfinding', 
        detectedLanguage: 'Hindi',
        confidence: 'high',
        box: { top: 45, left: 15, width: 70, height: 18 } 
      },
      { 
        originalText: 'कृपया शांति बनाए रखें और मास्क पहनें', 
        translatedText: 'Please maintain silence and wear a face mask.', 
        romanization: 'Kripya Shanti Banaye Rakhein Aur Mask Pehnen',
        category: 'Safety / Warning', 
        detectedLanguage: 'Hindi',
        confidence: 'high',
        box: { top: 70, left: 10, width: 80, height: 18 } 
      },
    ],
  },
  {
    id: 'tokyo_subway',
    title: '🚇 Tokyo Metro Wayfinding (Japanese)',
    category: 'Subway Sign',
    textType: 'sign',
    image: 'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?w=800&auto=format&fit=crop&q=80',
    overallLang: 'Japanese & English',
    summary: 'Subway station exit guide to Roppongi Hills with ticket office directions and train boarding safety warnings.',
    fullDoc: "Exit A4 - Towards Roppongi Hills\nTicket Office & Fare Adjustment Counter\nPlease do not rush onto the train doors.",
    mockBlocks: [
      { 
        originalText: '出口 Exit A4 - 六本木ヒルズ方面', 
        translatedText: 'Exit A4 - Towards Roppongi Hills', 
        romanization: 'Deguchi Exit A4 - Roppongi Hiruzu Hōmen',
        category: 'Wayfinding', 
        detectedLanguage: 'Japanese',
        confidence: 'high',
        box: { top: 20, left: 15, width: 70, height: 18 } 
      },
      { 
        originalText: '切符売り場・精算所', 
        translatedText: 'Ticket Office & Fare Adjustment', 
        romanization: 'Kippu Uriba / Seisansho',
        category: 'Sign', 
        detectedLanguage: 'Japanese',
        confidence: 'high',
        box: { top: 48, left: 20, width: 60, height: 16 } 
      },
      { 
        originalText: '駆け込み乗車はおやめください', 
        translatedText: 'Please do not rush onto the train.', 
        romanization: 'Kakekomi jōsha wa oyame kudasai',
        category: 'Safety / Warning', 
        detectedLanguage: 'Japanese',
        confidence: 'high',
        box: { top: 72, left: 15, width: 70, height: 15 } 
      },
    ],
  },
  {
    id: 'paris_bistro',
    title: '🍽️ Paris Bistro Menu (French)',
    category: 'Restaurant Menu',
    textType: 'menu',
    image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&auto=format&fit=crop&q=80',
    overallLang: 'French',
    summary: 'Classic French bistro daily menu featuring French onion soup, beef tenderloin in peppercorn sauce, and homemade caramel apple tart.',
    fullDoc: "DAILY SPECIALS (Menu du Jour)\n• Today's Special: French Onion Soup with melted Gruyère cheese (€12)\n• Main Course: Prime Beef Tenderloin in Green Peppercorn Sauce with roasted potatoes (€28)\n• Dessert: Homemade Tarte Tatin with double cream (€9.50)",
    mockBlocks: [
      { 
        originalText: 'Plat du Jour: Soupe à l’oignon gratinée (€12)', 
        translatedText: "Today's Special: French Onion Soup with melted cheese (€12)", 
        category: 'Menu Item', 
        detectedLanguage: 'French',
        confidence: 'high',
        box: { top: 18, left: 12, width: 75, height: 20 } 
      },
      { 
        originalText: 'Filet de bœuf sauce au poivre vert (€28)', 
        translatedText: 'Prime beef tenderloin with green peppercorn sauce (€28)', 
        category: 'Menu Item', 
        detectedLanguage: 'French',
        confidence: 'high',
        box: { top: 44, left: 12, width: 75, height: 18 } 
      },
      { 
        originalText: 'Tarte Tatin maison avec crème fraîche (€9.50)', 
        translatedText: 'Homemade caramel apple tart with fresh cream (€9.50)', 
        category: 'Menu Item', 
        detectedLanguage: 'French',
        confidence: 'high',
        box: { top: 68, left: 12, width: 75, height: 18 } 
      },
    ],
  },
  {
    id: 'berlin_pharmacy',
    title: '💊 Medicine Label & Dosage (German)',
    category: 'Medicine / Prescription',
    textType: 'label',
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=800&auto=format&fit=crop&q=80',
    overallLang: 'German',
    summary: 'Pharmaceutical prescription packaging detailing dosage instructions, storage under 25°C, and child safety warning.',
    fullDoc: "PRESCRIPTION INSTRUCTIONS:\n• Take 1 film-coated tablet twice daily with water after meals.\n• Caution: Keep out of the reach and sight of children.\n• Storage: Do not store above 25°C. Protect from moisture and direct sunlight.",
    mockBlocks: [
      { 
        originalText: 'Dosierung: 2x täglich 1 Filmtablette nach den Mahlzeiten', 
        translatedText: 'Dosage: 1 film-coated tablet twice daily after meals with water', 
        category: 'Label / Medicine', 
        detectedLanguage: 'German',
        confidence: 'high',
        box: { top: 20, left: 12, width: 76, height: 22 } 
      },
      { 
        originalText: 'Achtung: Für Kinder unzugänglich aufbewahren!', 
        translatedText: 'Warning: Keep strictly out of reach of children!', 
        category: 'Safety / Warning', 
        detectedLanguage: 'German',
        confidence: 'high',
        box: { top: 48, left: 14, width: 72, height: 18 } 
      },
      { 
        originalText: 'Nicht über 25°C lagern. Vor Feuchtigkeit schützen.', 
        translatedText: 'Do not store above 25°C. Protect from moisture.', 
        category: 'Label / Medicine', 
        detectedLanguage: 'German',
        confidence: 'high',
        box: { top: 72, left: 15, width: 70, height: 16 } 
      },
    ],
  },
  {
    id: 'madrid_receipt',
    title: '🧾 Supermarket Receipt (Spanish)',
    category: 'Receipt / Bill',
    textType: 'receipt',
    image: 'https://images.unsplash.com/photo-1554415707-9e44667ff61a?w=800&auto=format&fit=crop&q=80',
    overallLang: 'Spanish',
    summary: 'Itemized supermarket receipt including fresh bakery, olive oil, organic milk, VAT tax breakdown, and total €24.50.',
    fullDoc: "SUPERMERCADO CENTRAL MADRID\n• Pan de pueblo artesano (Artisan bread) - €1.80\n• Aceite de oliva virgen extra 1L (Extra virgin olive oil) - €9.20\n• Leche entera orgánica 2L (Organic whole milk) - €2.50\n• Queso manchego curado (Aged manchego cheese) - €11.00\nTOTAL PAGADO: €24.50 (IVA incluido)",
    mockBlocks: [
      { 
        originalText: 'Supermercado Central - Factura Simplificada', 
        translatedText: 'Central Supermarket - Simplified Invoice Receipt', 
        category: 'Receipt', 
        detectedLanguage: 'Spanish',
        confidence: 'high',
        box: { top: 15, left: 15, width: 70, height: 16 } 
      },
      { 
        originalText: 'Aceite de oliva virgen extra 1L - 9,20 €', 
        translatedText: 'Extra virgin olive oil 1L - €9.20', 
        category: 'Receipt', 
        detectedLanguage: 'Spanish',
        confidence: 'high',
        box: { top: 38, left: 12, width: 76, height: 16 } 
      },
      { 
        originalText: 'TOTAL A PAGAR: 24,50 € (IVA incluido)', 
        translatedText: 'TOTAL AMOUNT DUE: €24.50 (VAT included)', 
        category: 'Receipt', 
        detectedLanguage: 'Spanish',
        confidence: 'high',
        box: { top: 65, left: 10, width: 80, height: 20 } 
      },
    ],
  },
  {
    id: 'dubai_airport',
    title: '✈️ Airport Flight Gate (Arabic + English)',
    category: 'Flight Board',
    textType: 'screen',
    image: 'https://images.unsplash.com/photo-1542296332-2e4473faf563?w=800&auto=format&fit=crop&q=80',
    overallLang: 'Arabic & English',
    summary: 'International airport flight board displaying flight EK201 to New York, gate B14 boarding status, and passenger advisory.',
    fullDoc: "FLIGHT BOARDING NOTICE:\n• Flight EK201 to New York (JFK) - Gate B14\n• Status: Final Call - Immediate Boarding\n• All passengers must show passport and boarding pass.",
    mockBlocks: [
      { 
        originalText: 'رحلة طيران الإمارات EK201 إلى نيويورك', 
        translatedText: 'Emirates Flight EK201 to New York (JFK)', 
        romanization: 'Rihlat Tayaran Al-Imarat EK201 ila Niwyurk',
        category: 'Screen', 
        detectedLanguage: 'Arabic',
        confidence: 'high',
        box: { top: 18, left: 10, width: 80, height: 20 } 
      },
      { 
        originalText: 'البوابة ب 14 - النداء الأخير للصعود', 
        translatedText: 'Gate B14 - Final Call for Boarding', 
        romanization: 'Al-Bawwaba B 14 - An-Nida Al-Akheer',
        category: 'Wayfinding', 
        detectedLanguage: 'Arabic',
        confidence: 'high',
        box: { top: 45, left: 12, width: 76, height: 19 } 
      },
      { 
        originalText: 'يرجى إبراز جواز السفر وبطاقة الصعود', 
        translatedText: 'Please have passport and boarding pass ready.', 
        romanization: 'Yurja ibraz jawaz as-safar',
        category: 'Notice', 
        detectedLanguage: 'Arabic',
        confidence: 'high',
        box: { top: 72, left: 10, width: 80, height: 18 } 
      },
    ],
  },
  {
    id: 'rome_recipe',
    title: '✍️ Handwritten Kitchen Recipe (Italian)',
    category: 'Handwriting / Note',
    textType: 'handwriting',
    image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&auto=format&fit=crop&q=80',
    overallLang: 'Italian',
    summary: 'Handwritten culinary recipe for authentic Roman Carbonara with guanciale, pecorino cheese, and egg yolks.',
    fullDoc: "NONNA'S CARBONARA RECIPE:\n• Brown the diced guanciale slowly until crispy without adding extra oil.\n• Whisk fresh egg yolks with plenty of freshly grated Pecorino Romano and cracked black pepper.\n• Toss al dente spaghetti with guanciale fat off the heat, then quickly stir in egg-cheese mixture for a velvety cream.",
    mockBlocks: [
      { 
        originalText: 'Rosolare il guanciale a fuoco dolce finché croccante', 
        translatedText: 'Brown the diced cured pork jowl gently until crisp', 
        category: 'Handwriting', 
        detectedLanguage: 'Italian',
        confidence: 'high',
        box: { top: 20, left: 12, width: 76, height: 22 } 
      },
      { 
        originalText: 'Sbattere i tuorli con abbondante Pecorino Romano e pepe nero', 
        translatedText: 'Whisk egg yolks with generous Pecorino Romano and black pepper', 
        category: 'Handwriting', 
        detectedLanguage: 'Italian',
        confidence: 'high',
        box: { top: 48, left: 10, width: 80, height: 22 } 
      },
      { 
        originalText: 'Mantecare la pasta a fuoco spento per una crema vellutata', 
        translatedText: 'Mix pasta off the heat for a perfectly creamy, silky sauce', 
        category: 'Handwriting', 
        detectedLanguage: 'Italian',
        confidence: 'high',
        box: { top: 74, left: 12, width: 76, height: 18 } 
      },
    ],
  },
];

export const CameraTranslateScreen: React.FC<CameraTranslateScreenProps> = ({
  sourceLang,
  targetLang,
  onSelectTargetLang,
  onOpenTargetSelector,
  onSwapLanguages,
  voiceSettings,
  onAddTranslation,
  onClose,
}) => {
  const [mode, setMode] = useState<'instant' | 'capture'>('instant');
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraPermissionError, setCameraPermissionError] = useState<string | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  
  // OCR Output states
  const [detectedBlocks, setDetectedBlocks] = useState<CameraDetectedBlock[]>([]);
  const [summaryTranslation, setSummaryTranslation] = useState<string | null>(null);
  const [fullDocumentText, setFullDocumentText] = useState<string | null>(null);
  const [detectedLanguage, setDetectedLanguage] = useState<string | null>(null);
  const [detectedTextType, setDetectedTextType] = useState<string>('sign');
  const [advisoryMessage, setAdvisoryMessage] = useState<string | null>(null);
  const [selectedBlock, setSelectedBlock] = useState<CameraDetectedBlock | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Viewing & Filtering States
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'overlay' | 'document' | 'cards'>('overlay');
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [isLangPickerOpen, setIsLangPickerOpen] = useState(false);
  const [langSearch, setLangSearch] = useState('');

  // Camera Hardware State
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [activeFacing, setActiveFacing] = useState<'environment' | 'user'>('environment');
  const [activeLensLabel, setActiveLensLabel] = useState<string>('Back Camera');

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const nativeCameraInputRef = useRef<HTMLInputElement | null>(null);

  // Filtered blocks based on activeCategoryFilter
  const filteredBlocks = useMemo(() => {
    if (activeCategoryFilter === 'all') return detectedBlocks;
    return detectedBlocks.filter((b) => {
      const cat = (b.category || '').toLowerCase();
      if (activeCategoryFilter === 'sign') return cat.includes('sign') || cat.includes('wayfinding') || cat.includes('direction') || cat.includes('notice');
      if (activeCategoryFilter === 'menu') return cat.includes('menu') || cat.includes('food') || cat.includes('dish') || cat.includes('beverage');
      if (activeCategoryFilter === 'document') return cat.includes('document') || cat.includes('receipt') || cat.includes('bill') || cat.includes('invoice');
      if (activeCategoryFilter === 'safety') return cat.includes('safety') || cat.includes('warning') || cat.includes('caution') || cat.includes('emergency');
      if (activeCategoryFilter === 'label') return cat.includes('label') || cat.includes('medicine') || cat.includes('packaging') || cat.includes('dosage');
      if (activeCategoryFilter === 'handwriting') return cat.includes('handwriting') || cat.includes('note') || cat.includes('chalk');
      if (activeCategoryFilter === 'screen') return cat.includes('screen') || cat.includes('digital') || cat.includes('display');
      return true;
    });
  }, [detectedBlocks, activeCategoryFilter]);

  // Sync stream to video element whenever camera is active
  useEffect(() => {
    if (videoRef.current && streamRef.current && cameraActive && !capturedImage) {
      if (videoRef.current.srcObject !== streamRef.current) {
        videoRef.current.srcObject = streamRef.current;
      }
      videoRef.current.play().catch((e) => console.warn('Video auto-play handled:', e));
    }
  }, [cameraActive, capturedImage]);

  // Start Real Camera Stream
  const startCamera = async () => {
    setCameraPermissionError(null);
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }

    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setCameraActive(false);
        setCameraPermissionError('Camera is not supported on this browser or device. Please upload a photo or use a modern browser.');
        return;
      }

      let stream: MediaStream | null = null;
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: { ideal: facingMode },
            width: { ideal: 1920, min: 640 },
            height: { ideal: 1080, min: 480 },
          },
          audio: false,
        });
      } catch (err) {
        console.warn('Ideal facingMode constraint failed, trying generic...', err);
        stream = await navigator.mediaDevices.getUserMedia({
          video: true,
          audio: false,
        });
      }

      const activeTrack = stream.getVideoTracks()[0];
      if (activeTrack) {
        const trackLabel = activeTrack.label || '';
        const isBack = /back|rear|environment|camera\s*0/i.test(trackLabel) || facingMode === 'environment';
        setActiveFacing(isBack ? 'environment' : 'user');
        setActiveLensLabel(trackLabel || (isBack ? 'Back Camera' : 'Front Camera'));
      }

      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.onloadedmetadata = () => {
          videoRef.current?.play().catch((e) => console.warn('Video play error:', e));
        };
        videoRef.current.play().catch(() => {});
      }
      setCameraActive(true);
      setCapturedImage(null);
      setDetectedBlocks([]);
      setSelectedBlock(null);
      setSummaryTranslation(null);
      setFullDocumentText(null);
      setZoomLevel(1);
    } catch (err: any) {
      console.warn('Camera access denied or unavailable:', err);
      setCameraActive(false);
      const isDenied = err?.name === 'NotAllowedError' || err?.name === 'PermissionDeniedError';
      const msg = isDenied
        ? 'Camera permission is blocked. On Android: open Phone Settings ➔ Apps ➔ Travel Guide Pro (and Chrome) ➔ Permissions ➔ Allow Camera, or in Chrome: Settings ➔ Site Settings ➔ Camera ➔ Allow.'
        : 'Unable to start camera. Please check camera permissions or upload a photo.';
      setCameraPermissionError(msg);
    }
  };

  const toggleCameraLens = () => {
    setFacingMode((prev) => (prev === 'environment' ? 'user' : 'environment'));
    setCapturedImage(null);
  };

  useEffect(() => {
    startCamera();
    return () => {
      stopSpeaking();
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
        streamRef.current = null;
      }
    };
  }, [facingMode]);

  // Capture frame from video and send to Gemini AI
  const captureAndTranslate = () => {
    if (!videoRef.current || !cameraActive || isProcessing) return;

    try {
      const video = videoRef.current;
      if (video.readyState < 2 || !video.videoWidth || !video.videoHeight) {
        setAdvisoryMessage('Camera is initializing. Please wait a moment and tap scan again.');
        return;
      }

      const width = video.videoWidth || 640;
      const height = video.videoHeight || 480;

      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, width, height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
        setCapturedImage(dataUrl);
        processImageTranslation(dataUrl, targetLang.name);
      }
    } catch (err) {
      console.error('Error capturing video frame:', err);
    }
  };

  // Upload custom photo from device
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        const dataUrl = reader.result as string;
        setCapturedImage(dataUrl);
        setCameraActive(false);
        setZoomLevel(1);
        processImageTranslation(dataUrl, targetLang.name);
      };
      reader.readAsDataURL(file);
    }
  };

  // Load Built-in Test Sample
  const handleLoadSample = (sample: typeof SAMPLE_SIGNS[0]) => {
    setCapturedImage(sample.image);
    setCameraActive(false);
    setCameraPermissionError(null);
    setDetectedBlocks(sample.mockBlocks);
    setDetectedLanguage(sample.overallLang);
    setDetectedTextType(sample.textType);
    setSummaryTranslation(sample.summary);
    setFullDocumentText(sample.fullDoc);
    setAdvisoryMessage(null);
    setSelectedBlock(sample.mockBlocks[0]);
    setZoomLevel(1);
  };

  // Return to live camera feed
  const handleResumeLiveCamera = () => {
    setCapturedImage(null);
    setDetectedBlocks([]);
    setSelectedBlock(null);
    setSummaryTranslation(null);
    setFullDocumentText(null);
    setZoomLevel(1);
    startCamera();
  };

  // Execute Gemini OCR + Translation
  const processImageTranslation = async (base64Img: string, targetLanguageName = targetLang.name) => {
    setIsProcessing(true);
    setAdvisoryMessage(null);
    setSelectedBlock(null);

    try {
      const optimizedImg = await resizeImageIfNeeded(base64Img, 1600);
      const res = await cameraTranslateApi({
        imageBase64: optimizedImg,
        targetLang: targetLanguageName,
        mode,
      });

      const hasValidText = res.success && (
        res.isReadable ||
        (res.textBlocks && res.textBlocks.length > 0) ||
        (Boolean(res.summaryTranslation) && res.summaryTranslation.trim().length > 0 && !res.summaryTranslation.toLowerCase().includes('no text'))
      );

      if (hasValidText) {
        const blocks = (res.textBlocks && res.textBlocks.length > 0)
          ? res.textBlocks
          : (res.summaryTranslation ? [{
              originalText: res.overallDetectedLanguage || 'Detected Visual Text',
              translatedText: res.summaryTranslation,
              category: 'Sign / Notice',
              detectedLanguage: res.overallDetectedLanguage || 'Auto',
              box: { top: 25, left: 12, width: 76, height: 35 },
            }] : []);

        setDetectedBlocks(blocks);
        setDetectedLanguage(res.overallDetectedLanguage || 'Detected Language');
        setDetectedTextType(res.detectedTextType || 'sign');
        setSummaryTranslation(res.summaryTranslation || null);
        setFullDocumentText(res.fullDocumentText || res.summaryTranslation || null);

        if (blocks.length > 0) {
          setSelectedBlock(blocks[0]);
        }
        setAdvisoryMessage(null);
      } else {
        setAdvisoryMessage(res.advisoryMessage || 'No readable text recognized in this image. Ensure clear focus, good lighting, and tap Scan again.');
        setDetectedBlocks([]);
      }
    } catch (err: any) {
      setAdvisoryMessage(err?.message || 'Could not process image. Please hold camera steady and tap scan again.');
    } finally {
      setIsProcessing(false);
    }
  };

  // Switch preferred target language and re-translate active image if one is loaded
  const handleSelectPreferredLanguage = (lang: Language) => {
    if (onSelectTargetLang) {
      onSelectTargetLang(lang);
    }
    setIsLangPickerOpen(false);

    // If an image is already captured or loaded, automatically re-translate into this preferred language
    if (capturedImage && !isProcessing) {
      processImageTranslation(capturedImage, lang.name);
    }
  };

  const playSpeech = (text: string) => {
    speakText(text, targetLang.speechCode, {
      speechRate: voiceSettings.speechRate,
      volume: voiceSettings.volume,
    });
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId('active');
    setTimeout(() => setCopiedId(null), 1800);
  };

  const handleSaveTranslation = (block: CameraDetectedBlock) => {
    const rec: TranslationRecord = {
      id: `cam_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      originalText: block.originalText,
      translatedText: block.translatedText,
      sourceLang: block.detectedLanguage || detectedLanguage || 'Camera OCR',
      sourceLangCode: 'auto',
      targetLang: targetLang.name,
      targetLangCode: targetLang.code,
      timestamp: Date.now(),
      category: 'camera',
      starred: true,
    };
    onAddTranslation(rec);
    handleCopy(block.translatedText);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-120px)] max-h-[860px] animate-fade-in relative select-none">
      {/* Top Header Bar: Mode Switcher + Lens + Preferred Language Selector */}
      <div className="bg-slate-900/95 border border-slate-800 rounded-2xl p-2 sm:p-2.5 shadow-md mb-2 flex flex-col gap-2 z-20">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* Instant vs Capture Mode */}
            <div className="flex items-center bg-slate-800 p-0.5 rounded-xl border border-slate-700">
              <button
                onClick={() => setMode('instant')}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                  mode === 'instant'
                    ? 'bg-teal-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                title="Instant OCR translation overlay"
              >
                <Zap className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Instant</span>
              </button>
              <button
                onClick={() => setMode('capture')}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                  mode === 'capture'
                    ? 'bg-teal-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                title="Detailed capture breakdown"
              >
                <Camera className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Capture</span>
              </button>
            </div>

            {/* Camera Lens Flip Button */}
            <button
              id="camera-lens-toggle-btn"
              onClick={toggleCameraLens}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-bold border transition-all ${
                activeFacing === 'environment'
                  ? 'bg-emerald-950/80 border-emerald-500/50 text-emerald-300 hover:bg-emerald-900/60'
                  : 'bg-indigo-950/80 border-indigo-500/50 text-indigo-300 hover:bg-indigo-900/60'
              }`}
              title="Flip between mobile back and front camera"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>{activeFacing === 'environment' ? '📷 Back' : '🤳 Front'}</span>
            </button>
          </div>

          {/* Preferred Target Language Button */}
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] text-slate-400 font-medium hidden md:inline">Preferred Lang:</span>
            <button
              id="camera-target-lang-btn"
              onClick={() => setIsLangPickerOpen(true)}
              className="flex items-center gap-1.5 bg-teal-950/70 hover:bg-teal-900 border border-teal-500/50 text-teal-200 px-3 py-1 rounded-xl text-xs font-extrabold shadow-sm transition-all"
              title="Select preferred translation language for all signs and texts"
            >
              <Globe className="w-3.5 h-3.5 text-teal-400" />
              <span>{targetLang.flag}</span>
              <span>{targetLang.name}</span>
            </button>
          </div>
        </div>

        {/* Quick Popular Language Chips Bar for 1-Tap Switching */}
        <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none pt-0.5 border-t border-slate-800/80">
          <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider shrink-0 mr-0.5">
            Translate to:
          </span>
          {QUICK_TARGET_LANGUAGES.map((lang) => {
            const isSelected = targetLang.code === lang.code;
            return (
              <button
                key={lang.code}
                onClick={() => {
                  const fullLang = SUPPORTED_LANGUAGES.find((l) => l.code === lang.code);
                  if (fullLang) handleSelectPreferredLanguage(fullLang);
                }}
                className={`flex items-center gap-1 px-2 py-0.5 rounded-lg text-[11px] font-semibold transition-all shrink-0 ${
                  isSelected
                    ? 'bg-teal-600 text-white shadow-xs font-bold ring-1 ring-teal-400'
                    : 'bg-slate-800/90 text-slate-300 hover:bg-slate-700 hover:text-white border border-slate-700/70'
                }`}
              >
                <span>{lang.flag}</span>
                <span>{lang.name}</span>
              </button>
            );
          })}
          <button
            onClick={() => setIsLangPickerOpen(true)}
            className="text-[11px] font-bold text-teal-300 bg-teal-950/80 hover:bg-teal-900 border border-teal-700/60 px-2 py-0.5 rounded-lg shrink-0"
          >
            + More...
          </button>
        </div>
      </div>

      {/* Main Viewfinder Canvas / Video Preview Area */}
      <div 
        onClick={() => {
          if (cameraActive && !capturedImage && !isProcessing && videoRef.current && videoRef.current.readyState >= 2) {
            captureAndTranslate();
          }
        }}
        className={`relative flex-1 bg-black rounded-3xl overflow-hidden border border-slate-800 shadow-2xl flex items-center justify-center transition-all ${
          cameraActive && !capturedImage && !isProcessing ? 'cursor-pointer' : ''
        }`}
        title={cameraActive && !capturedImage ? 'Tap to snap & translate' : ''}
      >
        {/* Real Live Video Feed */}
        <video
          ref={videoRef}
          playsInline
          muted
          autoPlay
          className={`w-full h-full object-cover transition-opacity duration-300 ${
            cameraActive && !capturedImage ? 'opacity-100 block' : 'opacity-0 hidden'
          }`}
        />

        {capturedImage ? (
          <div 
            className="w-full h-full relative overflow-hidden flex items-center justify-center bg-slate-950"
            style={{
              transform: `scale(${zoomLevel})`,
              transition: 'transform 0.2s ease-out',
            }}
          >
            <img
              src={capturedImage}
              alt="Sign capture preview"
              className="max-w-full max-h-full object-contain"
            />
          </div>
        ) : cameraPermissionError ? (
          /* Camera Permission Denied / Blocked Fallback Screen */
          <div className="flex flex-col items-center justify-center p-6 text-center max-w-sm mx-auto space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
              <ShieldAlert className="w-8 h-8" />
            </div>
            <div className="space-y-1">
              <h3 className="text-base font-bold text-white">Camera Access Required</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                {cameraPermissionError}
              </p>
            </div>

            {/* Quick Android & Browser unblock guide card */}
            <div className="w-full bg-slate-950/80 border border-slate-800 rounded-2xl p-3 text-left text-[11px] space-y-1.5">
              <div className="font-bold text-amber-300 flex items-center gap-1.5 text-xs">
                <span>📱 Quick Unblock Steps:</span>
              </div>
              <div className="text-slate-300 space-y-1">
                <p>• <strong>Installed App:</strong> Phone Settings ➔ Apps ➔ <strong>Travel Guide Pro</strong> ➔ Permissions ➔ Turn on <strong>Camera</strong>.</p>
                <p>• <strong>Chrome Browser:</strong> Phone Settings ➔ Apps ➔ <strong>Chrome</strong> ➔ Permissions ➔ Turn on <strong>Camera</strong>.</p>
                <p>• <strong>Chrome Site Settings:</strong> Open Chrome ➔ 3 dots menu ➔ Settings ➔ Site settings ➔ Camera ➔ Set to <strong>Allow</strong>.</p>
              </div>
            </div>

            <div className="flex flex-col w-full gap-2 pt-1">
              <input
                type="file"
                ref={nativeCameraInputRef}
                accept="image/*"
                capture="environment"
                onChange={handleFileUpload}
                className="hidden"
              />
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  nativeCameraInputRef.current?.click();
                }}
                className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2 transition-transform active:scale-95"
              >
                <Camera className="w-4 h-4" />
                <span>Snap with Phone Camera (Bypass Browser Block)</span>
              </button>
              <div className="flex items-center gap-2">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    startCamera();
                  }}
                  className="flex-1 py-2 px-3 bg-teal-700/80 hover:bg-teal-600 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-transform active:scale-95"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Retry Live Stream</span>
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    fileInputRef.current?.click();
                  }}
                  className="flex-1 py-2 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold border border-slate-700 flex items-center justify-center gap-1.5"
                >
                  <Upload className="w-3.5 h-3.5 text-teal-400" />
                  <span>Gallery</span>
                </button>
              </div>
            </div>
          </div>
        ) : !cameraActive ? (
          <div className="flex flex-col items-center justify-center text-slate-400 gap-2">
            <RefreshCw className="w-6 h-6 animate-spin text-teal-400" />
            <span className="text-xs font-medium">Starting camera...</span>
          </div>
        ) : null}

        {/* Zoom Controls for Captured Image */}
        {capturedImage && (
          <div className="absolute top-3 right-3 flex items-center bg-slate-900/80 backdrop-blur-md rounded-xl p-1 border border-slate-700 gap-1 z-30">
            <button
              onClick={(e) => {
                e.stopPropagation();
                setZoomLevel((prev) => Math.min(prev + 0.3, 2.5));
              }}
              className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg"
              title="Zoom in on fine print"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                setZoomLevel((prev) => Math.max(prev - 0.3, 1));
              }}
              className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg"
              title="Zoom out"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            {zoomLevel > 1 && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setZoomLevel(1);
                }}
                className="p-1.5 text-teal-300 hover:text-white hover:bg-slate-800 rounded-lg text-[10px] font-bold"
                title="Reset zoom"
              >
                1x
              </button>
            )}
          </div>
        )}

        {/* Live Camera Scanner Target HUD */}
        {cameraActive && !capturedImage && (
          <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-3 sm:p-4">
            <div className="flex items-center justify-between text-xs">
              <span className="bg-slate-900/85 backdrop-blur-md px-3 py-1 rounded-full text-teal-300 border border-teal-500/30 flex items-center gap-1.5 font-medium shadow-md">
                <Sparkles className="w-3.5 h-3.5 text-teal-400" />
                <span>Point at signs, menus, receipts, medicine or handwriting</span>
              </span>
              <span className="text-[10px] bg-black/60 text-slate-300 px-2 py-0.5 rounded-full border border-slate-700">
                {activeFacing === 'environment' ? '📷 Back Lens' : '🤳 Front Lens'}
              </span>
            </div>

            {/* Expansive Frame Target */}
            <div className="w-[94%] max-w-xl h-[78%] border-2 border-teal-400/80 rounded-3xl self-center relative flex flex-col items-center justify-between p-4 bg-teal-500/[0.04] shadow-[0_0_35px_rgba(45,212,191,0.25)] transition-all">
              <div className="absolute -top-1 -left-1 w-8 h-8 border-t-4 border-l-4 border-teal-400 rounded-tl-2xl shadow-[0_0_8px_#2dd4bf]" />
              <div className="absolute -top-1 -right-1 w-8 h-8 border-t-4 border-r-4 border-teal-400 rounded-tr-2xl shadow-[0_0_8px_#2dd4bf]" />
              <div className="absolute -bottom-1 -left-1 w-8 h-8 border-b-4 border-l-4 border-teal-400 rounded-bl-2xl shadow-[0_0_8px_#2dd4bf]" />
              <div className="absolute -bottom-1 -right-1 w-8 h-8 border-b-4 border-r-4 border-teal-400 rounded-br-2xl shadow-[0_0_8px_#2dd4bf]" />

              <div className="w-full h-0.5 bg-gradient-to-r from-transparent via-teal-300 to-transparent animate-pulse absolute top-1/2 -translate-y-1/2 shadow-[0_0_15px_#2dd4bf]" />

              <div className="flex items-center gap-1.5 bg-slate-950/85 backdrop-blur-md px-3 py-1 rounded-full border border-teal-500/30 text-teal-300 text-[11px] font-bold shadow">
                <span>Multi-Script Universal OCR Active</span>
              </div>

              <div className="text-center py-2">
                <span className="text-xs text-teal-200 bg-slate-950/80 backdrop-blur-md px-3.5 py-1.5 rounded-full border border-teal-500/30 shadow-md">
                  Translates all languages into {targetLang.name}
                </span>
              </div>

              <div className="text-center">
                <span className="text-[10px] text-slate-300 bg-black/75 backdrop-blur-md px-3 py-1 rounded-full border border-slate-700">
                  Align words within this frame or tap shutter below
                </span>
              </div>
            </div>

            <div className="text-center">
              <span className="bg-black/85 backdrop-blur-md text-[11px] text-slate-200 px-4 py-1.5 rounded-full border border-slate-700 font-semibold shadow-md">
                📸 Tap the shutter button below to scan
              </span>
            </div>
          </div>
        )}

        {/* Laser scan animation when processing */}
        {isProcessing && (
          <div className="absolute inset-0 pointer-events-none bg-teal-950/50 backdrop-blur-xs flex flex-col items-center justify-center gap-3 z-30">
            <div className="w-full h-1.5 bg-gradient-to-r from-transparent via-teal-300 to-transparent absolute top-1/2 -translate-y-1/2 animate-pulse shadow-[0_0_20px_#2dd4bf]" />
            <div className="bg-slate-900/95 text-white px-5 py-3.5 rounded-2xl text-xs font-bold flex items-center gap-3 border border-teal-400 shadow-2xl animate-bounce">
              <Sparkles className="w-5 h-5 text-teal-400 animate-spin" />
              <div>
                <div className="text-white font-extrabold">Reading All Texts & Signs...</div>
                <div className="text-[11px] text-teal-300 font-medium">
                  Translating into {targetLang.name} ({targetLang.flag})
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Bounding Box Overlays for Detected Signs & Texts (AR Mode) */}
        {viewMode === 'overlay' && filteredBlocks.map((block, idx) => {
          const isSelected = selectedBlock === block;
          return (
            <div
              key={idx}
              onClick={(e) => {
                e.stopPropagation();
                setSelectedBlock(block);
              }}
              className={`absolute cursor-pointer transition-all duration-200 rounded-xl p-1.5 shadow-lg backdrop-blur-md ${
                isSelected
                  ? 'bg-teal-900/95 border-2 border-teal-300 text-white ring-4 ring-teal-400/40 scale-105 z-30 shadow-teal-500/30'
                  : 'bg-slate-900/90 border border-teal-500/70 text-teal-100 hover:border-teal-300 z-20'
              }`}
              style={{
                top: `${block.box.top}%`,
                left: `${block.box.left}%`,
                width: `${block.box.width}%`,
                minHeight: `${block.box.height}%`,
              }}
            >
              <div className="text-[10px] uppercase font-bold text-teal-400 flex items-center justify-between gap-1">
                <span className="truncate">{block.category}</span>
                <Volume2
                  onClick={(e) => {
                    e.stopPropagation();
                    playSpeech(block.translatedText);
                  }}
                  className="w-3.5 h-3.5 text-teal-300 hover:text-white shrink-0"
                />
              </div>
              <div className="text-xs font-extrabold text-white leading-tight mt-0.5 drop-shadow-sm">
                "{block.translatedText}"
              </div>
              <div className="text-[10px] text-slate-300/80 truncate mt-0.5">
                {block.originalText}
              </div>
              {block.romanization && (
                <div className="text-[9px] text-teal-300/90 italic truncate">
                  🗣️ {block.romanization}
                </div>
              )}
            </div>
          );
        })}

        {/* Advisory Warning Message */}
        {advisoryMessage && (
          <div className="absolute top-4 inset-x-4 bg-amber-500/95 text-slate-950 px-4 py-2.5 rounded-2xl shadow-xl flex items-center justify-between gap-2.5 text-xs font-bold z-40">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{advisoryMessage}</span>
            </div>
            <button
              onClick={() => setAdvisoryMessage(null)}
              className="p-1 text-slate-950 hover:bg-amber-600/30 rounded"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>

      {/* View Mode Switcher + Category Filters (Visible when texts are detected) */}
      {detectedBlocks.length > 0 && (
        <div className="mt-2 bg-slate-900/95 border border-slate-800 rounded-2xl p-2 flex flex-col gap-1.5 z-20">
          <div className="flex items-center justify-between gap-2">
            {/* View Mode Toggle */}
            <div className="flex items-center bg-slate-800 p-0.5 rounded-xl border border-slate-700">
              <button
                onClick={() => setViewMode('overlay')}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold ${
                  viewMode === 'overlay' ? 'bg-teal-600 text-white shadow-xs' : 'text-slate-400 hover:text-slate-200'
                }`}
                title="Augmented Reality bounding box overlay"
              >
                <Layers className="w-3.5 h-3.5" />
                <span>AR Overlay</span>
              </button>
              <button
                onClick={() => setViewMode('document')}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold ${
                  viewMode === 'document' ? 'bg-teal-600 text-white shadow-xs' : 'text-slate-400 hover:text-slate-200'
                }`}
                title="Full document continuous reading view"
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>Full Document</span>
              </button>
              <button
                onClick={() => setViewMode('cards')}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold ${
                  viewMode === 'cards' ? 'bg-teal-600 text-white shadow-xs' : 'text-slate-400 hover:text-slate-200'
                }`}
                title="Extracted text cards list"
              >
                <List className="w-3.5 h-3.5" />
                <span>Cards ({filteredBlocks.length})</span>
              </button>
            </div>

            {/* Language Detected Tag */}
            <div className="flex items-center gap-1 text-[11px] text-teal-300 font-bold bg-teal-950/60 px-2.5 py-1 rounded-lg border border-teal-800/60">
              <Sparkles className="w-3 h-3 text-teal-400" />
              <span>{detectedLanguage || 'Detected'}</span>
              <ArrowRight className="w-3 h-3 text-slate-400" />
              <span>{targetLang.name}</span>
            </div>
          </div>

          {/* Text Category Filter Chips */}
          <div className="flex items-center gap-1 overflow-x-auto scrollbar-none pt-1">
            <span className="text-[10px] uppercase font-bold text-slate-500 shrink-0 mr-1">Filter:</span>
            {[
              { id: 'all', label: `All (${detectedBlocks.length})` },
              { id: 'sign', label: '🚏 Signs' },
              { id: 'menu', label: '🍽️ Menus' },
              { id: 'document', label: '📄 Documents' },
              { id: 'safety', label: '⚠️ Safety' },
              { id: 'label', label: '💊 Labels' },
              { id: 'handwriting', label: '✍️ Handwriting' },
              { id: 'screen', label: '💻 Screens' },
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCategoryFilter(cat.id)}
                className={`px-2 py-0.5 rounded-lg text-[11px] font-semibold whitespace-nowrap transition-all ${
                  activeCategoryFilter === cat.id
                    ? 'bg-teal-600 text-white shadow-xs'
                    : 'bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-700/60'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* DOCUMENT / READING VIEW MODE */}
      {viewMode === 'document' && (summaryTranslation || fullDocumentText) && (
        <div className="mt-2 bg-slate-900 border border-teal-500/40 rounded-2xl p-3.5 shadow-xl space-y-2 z-20 max-h-48 overflow-y-auto">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div className="flex items-center gap-1.5 text-teal-300 text-xs font-bold">
              <FileText className="w-4 h-4 text-teal-400" />
              <span>Continuous Document Reading ({targetLang.name})</span>
            </div>
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => playSpeech(fullDocumentText || summaryTranslation || '')}
                className="p-1.5 bg-teal-600 hover:bg-teal-500 text-white rounded-lg flex items-center gap-1 text-xs font-semibold"
                title="Listen to full translated document"
              >
                <Volume2 className="w-3.5 h-3.5" />
                <span>Listen Aloud</span>
              </button>
              <button
                onClick={() => handleCopy(fullDocumentText || summaryTranslation || '')}
                className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg border border-slate-700 flex items-center gap-1 text-xs"
                title="Copy full translation"
              >
                <Copy className="w-3.5 h-3.5 text-teal-400" />
                <span>{copiedId === 'active' ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
          </div>
          <div className="text-xs text-slate-200 font-normal leading-relaxed whitespace-pre-line select-text">
            {fullDocumentText || summaryTranslation}
          </div>
        </div>
      )}

      {/* CARDS LIST VIEW MODE */}
      {viewMode === 'cards' && (
        <div className="mt-2 bg-slate-900 border border-slate-800 rounded-2xl p-2 shadow-xl space-y-2 z-20 max-h-48 overflow-y-auto">
          {filteredBlocks.length === 0 ? (
            <div className="text-center py-4 text-xs text-slate-400">
              No blocks found in this category.
            </div>
          ) : (
            filteredBlocks.map((block, idx) => (
              <div 
                key={idx}
                className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-2.5 flex items-start justify-between gap-2"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-bold uppercase text-teal-400 bg-teal-950/80 px-1.5 py-0.5 rounded border border-teal-800/60">
                      {block.category}
                    </span>
                    {block.detectedLanguage && (
                      <span className="text-[10px] text-slate-400">
                        {block.detectedLanguage}
                      </span>
                    )}
                  </div>
                  <div className="text-sm font-bold text-white">
                    "{block.translatedText}"
                  </div>
                  <div className="text-xs text-slate-400">
                    Original: {block.originalText}
                  </div>
                  {block.romanization && (
                    <div className="text-xs text-teal-300/90 italic">
                      Pronunciation: {block.romanization}
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  <button
                    onClick={() => playSpeech(block.translatedText)}
                    className="p-2 bg-teal-600/90 hover:bg-teal-500 text-white rounded-lg shadow-sm"
                    title="Listen"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleCopy(block.translatedText)}
                    className="p-2 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-lg"
                    title="Copy"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleSaveTranslation(block)}
                    className="p-2 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 rounded-lg border border-amber-500/30"
                    title="Save to history"
                  >
                    <Bookmark className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Selected Block Quick Action Box in AR Overlay Mode */}
      {viewMode === 'overlay' && (selectedBlock || summaryTranslation) && (
        <div className="mt-2 bg-gradient-to-br from-slate-900 to-slate-800 border border-teal-500/40 rounded-2xl p-3 shadow-xl space-y-2 z-20">
          {selectedBlock ? (
            <div className="flex items-start justify-between gap-2">
              <div className="space-y-0.5 max-w-[80%]">
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] uppercase font-extrabold text-teal-300 bg-teal-950/80 px-2 py-0.5 rounded border border-teal-700/60">
                    {selectedBlock.category}
                  </span>
                  {selectedBlock.detectedLanguage && (
                    <span className="text-[10px] text-slate-400 font-medium">
                      ({selectedBlock.detectedLanguage})
                    </span>
                  )}
                </div>
                <div className="text-sm font-bold text-white leading-snug">
                  "{selectedBlock.translatedText}"
                </div>
                <div className="text-xs text-slate-400 truncate">
                  Original: "{selectedBlock.originalText}"
                </div>
                {selectedBlock.romanization && (
                  <div className="text-xs text-teal-300/90 italic">
                    Pronunciation: {selectedBlock.romanization}
                  </div>
                )}
              </div>

              <div className="flex flex-col gap-1.5 shrink-0">
                <button
                  id="camera-speak-btn"
                  onClick={() => playSpeech(selectedBlock.translatedText)}
                  className="p-2 bg-teal-600 hover:bg-teal-500 text-white rounded-xl shadow-md flex items-center justify-center gap-1 text-xs font-semibold"
                  title="Listen aloud in preferred language"
                >
                  <Volume2 className="w-4 h-4" />
                  <span className="hidden sm:inline">Listen</span>
                </button>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleCopy(selectedBlock.translatedText)}
                    className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg border border-slate-700"
                    title="Copy translation"
                  >
                    <Copy className="w-3.5 h-3.5 text-teal-400" />
                  </button>
                  <button
                    onClick={() => handleSaveTranslation(selectedBlock)}
                    className="p-1.5 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 rounded-lg border border-amber-500/30"
                    title="Save to bookmarks"
                  >
                    <Bookmark className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ) : summaryTranslation ? (
            <div className="flex items-start justify-between gap-2">
              <div>
                <div className="text-[10px] uppercase font-bold text-teal-300 flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-teal-400" />
                  <span>Translation Summary ({detectedLanguage || 'Detected'})</span>
                </div>
                <div className="text-xs font-semibold text-white mt-0.5 leading-snug">
                  {summaryTranslation}
                </div>
              </div>
              <button
                onClick={() => playSpeech(summaryTranslation)}
                className="p-2 bg-teal-600 hover:bg-teal-500 text-white rounded-xl shadow-md shrink-0 flex items-center gap-1 text-xs font-semibold"
                title="Listen to summary translation"
              >
                <Volume2 className="w-4 h-4" />
                <span className="hidden sm:inline">Listen</span>
              </button>
            </div>
          ) : null}
        </div>
      )}

      {/* Bottom Camera Controls & Demo Sign Test Selector */}
      <div className="mt-2 bg-slate-900 border border-slate-800 rounded-2xl p-2.5 flex items-center justify-between gap-2 z-20">
        {/* Sample Demo Sign test buttons */}
        <div className="flex items-center gap-1 overflow-x-auto max-w-[150px] sm:max-w-xs scrollbar-none">
          <span className="text-[10px] text-slate-400 font-bold uppercase shrink-0 hidden sm:inline">Samples:</span>
          {SAMPLE_SIGNS.map((sample) => (
            <button
              key={sample.id}
              onClick={() => handleLoadSample(sample)}
              className="text-[11px] font-medium whitespace-nowrap bg-slate-800 hover:bg-slate-700 px-2 py-1 rounded-lg text-slate-200 border border-slate-700 shrink-0"
              title={`Test OCR with ${sample.title}`}
            >
              {sample.title.split(' ')[0]} {sample.title.split(' ')[1]}
            </button>
          ))}
        </div>

        {/* Central Capture Controls with Extra Large High-Visibility Shutter */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* File Upload from Gallery */}
          <input
            type="file"
            ref={fileInputRef}
            accept="image/*"
            onChange={handleFileUpload}
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl border border-slate-700 shadow-sm"
            title="Upload photo from device gallery"
          >
            <Upload className="w-4 h-4" />
          </button>

          {/* Re-analyze image button if an image is currently loaded */}
          {capturedImage && (
            <button
              onClick={() => processImageTranslation(capturedImage, targetLang.name)}
              disabled={isProcessing}
              className="p-2.5 bg-teal-600/90 hover:bg-teal-500 text-white rounded-xl border border-teal-500/40 shadow-sm flex items-center gap-1.5 text-xs font-bold"
              title={`Re-translate this image into ${targetLang.name}`}
            >
              <Sparkles className="w-4 h-4 text-teal-200" />
              <span className="hidden sm:inline">Re-Scan</span>
            </button>
          )}

          {/* Main Camera Shutter button */}
          <button
            id="camera-capture-shutter-btn"
            onClick={capturedImage ? handleResumeLiveCamera : captureAndTranslate}
            disabled={isProcessing}
            className={`px-4 sm:px-6 h-12 rounded-full text-white flex items-center justify-center gap-2 shadow-xl transition-transform active:scale-90 ${
              capturedImage
                ? 'bg-indigo-600 hover:bg-indigo-500 shadow-indigo-600/40 ring-4 ring-indigo-500/20'
                : 'bg-gradient-to-r from-teal-500 via-teal-600 to-emerald-500 shadow-teal-500/40 ring-4 ring-teal-400/30 hover:scale-105'
            }`}
            title={capturedImage ? 'Retake / Live View' : 'Snap & Translate Sign'}
          >
            {capturedImage ? (
              <>
                <RefreshCw className="w-4 h-4" />
                <span className="text-xs font-bold">Retake</span>
              </>
            ) : (
              <>
                <Camera className="w-5 h-5" />
                <span className="text-xs font-black tracking-wide">Scan View</span>
              </>
            )}
          </button>

          {/* Flip Camera Lens */}
          <button
            id="camera-flip-lens-bottom-btn"
            onClick={toggleCameraLens}
            className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl border border-slate-700 shadow-sm flex items-center gap-1"
            title={`Currently active: ${activeFacing === 'environment' ? 'Back' : 'Front'} camera. Click to flip.`}
          >
            <RefreshCw className="w-4 h-4 text-teal-400" />
            <span className="text-[11px] hidden sm:inline">{activeFacing === 'environment' ? 'Back' : 'Front'}</span>
          </button>
        </div>
      </div>

      {/* Preferred Target Language Search & Selection Modal */}
      {isLangPickerOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-md max-h-[85vh] flex flex-col overflow-hidden shadow-2xl animate-scale-up">
            {/* Modal Header */}
            <div className="p-4 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Globe className="w-5 h-5 text-teal-400" />
                <h3 className="text-base font-bold text-white">Choose Preferred Language</h3>
              </div>
              <button
                onClick={() => setIsLangPickerOpen(false)}
                className="p-1 text-slate-400 hover:text-white rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Search Input */}
            <div className="p-3 border-b border-slate-800">
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={langSearch}
                  onChange={(e) => setLangSearch(e.target.value)}
                  placeholder="Search 30+ languages (e.g. Hindi, French, Japanese)..."
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-teal-500"
                  autoFocus
                />
              </div>
            </div>

            {/* Language List */}
            <div className="flex-1 overflow-y-auto p-3 space-y-1.5 divide-y divide-slate-800/40">
              {SUPPORTED_LANGUAGES.filter(
                (l) =>
                  l.code !== 'auto' &&
                  (l.name.toLowerCase().includes(langSearch.toLowerCase()) ||
                    l.nativeName.toLowerCase().includes(langSearch.toLowerCase()))
              ).map((lang) => {
                const isSelected = targetLang.code === lang.code;
                return (
                  <button
                    key={lang.code}
                    onClick={() => handleSelectPreferredLanguage(lang)}
                    className={`w-full flex items-center justify-between p-2.5 rounded-xl transition-all ${
                      isSelected
                        ? 'bg-teal-600/20 border border-teal-500/50 text-white font-bold'
                        : 'hover:bg-slate-800 text-slate-200'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="text-lg">{lang.flag}</span>
                      <div className="text-left">
                        <div className="text-xs font-semibold">{lang.name}</div>
                        <div className="text-[10px] text-slate-400">{lang.nativeName} {lang.region ? `• ${lang.region}` : ''}</div>
                      </div>
                    </div>
                    {isSelected && (
                      <Check className="w-4 h-4 text-teal-400" />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Modal Footer Note */}
            <div className="p-3 bg-slate-950/80 border-t border-slate-800 text-[11px] text-slate-400 flex items-center gap-1.5">
              <Info className="w-4 h-4 text-teal-400 shrink-0" />
              <span>Selecting a language will immediately translate any current sign or photo into it.</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
