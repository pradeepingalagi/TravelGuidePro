export type LanguageRegion = 'India' | 'Europe' | 'Asia' | 'Middle East' | 'Americas' | 'Africa';

export interface Language {
  code: string;
  name: string;
  nativeName: string;
  flag: string;
  speechCode: string;
  region?: LanguageRegion;
  isPopular?: boolean;
  isRtl?: boolean;
  script?: string;
  description?: string;
}

export type ConfidenceLevel = 'high' | 'medium' | 'low';

export interface TranslationRecord {
  id: string;
  originalText: string;
  translatedText: string;
  sourceLang: string;
  sourceLangCode: string;
  targetLang: string;
  targetLangCode: string;
  detectedLang?: string;
  confidence?: ConfidenceLevel;
  didYouMeanSuggestion?: string | null;
  pronunciation?: string | null;
  culturalNote?: string | null;
  timestamp: number;
  starred?: boolean;
  speaker?: 'user1' | 'user2' | 'personA' | 'personB';
  category?: 'voice' | 'face-to-face' | 'camera' | 'text' | 'emergency';
}

export interface CameraDetectedBlock {
  originalText: string;
  translatedText: string;
  category: string;
  detectedLanguage?: string;
  romanization?: string;
  confidence?: 'high' | 'medium' | 'low';
  box: {
    top: number;
    left: number;
    width: number;
    height: number;
  };
}

export interface EmergencyPhrase {
  id: string;
  englishText: string;
  category: 'medical' | 'accident' | 'police' | 'general';
  translations: Record<string, { text: string; phonetic?: string }>;
  urgentPriority?: boolean;
}

export interface TravelPhraseCategory {
  id: string;
  title: string;
  icon: string;
  phrases: {
    id: string;
    english: string;
    context: string;
  }[];
}

export interface VoiceSettings {
  speechRate: number; // 0.75, 1.0, 1.25, etc.
  pitch: number;
  voiceGender: 'auto' | 'female' | 'male';
  volume: number; // 0 to 1
  autoPlayVoice: boolean;
  selectedVoiceURI?: string;
}

export interface OfflineLanguagePack {
  code: string;
  name: string;
  flag: string;
  sizeMB: number;
  isDownloaded: boolean;
  downloadDate?: string;
}

export interface UserLanguagePreferences {
  defaultUserLanguageCode: string;
  preferredTranslationLanguageCode: string;
}

export interface AuthUser {
  id: string;
  name: string;
  email?: string;
  avatar?: string;
  isGuest: boolean;
  provider: 'google' | 'guest';
  loginTime: number;
  preferences?: UserLanguagePreferences;
}
