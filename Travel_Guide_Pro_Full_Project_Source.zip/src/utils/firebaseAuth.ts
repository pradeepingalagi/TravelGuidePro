import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getAuth, 
  signInWithPopup, 
  GoogleAuthProvider, 
  signOut as firebaseSignOut, 
  deleteUser,
  onAuthStateChanged, 
  User as FirebaseUser 
} from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';
import { AuthUser, UserLanguagePreferences } from '../types';

// Initialize Firebase App instance safely
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
export const auth = getAuth(app);

export const googleProvider = new GoogleAuthProvider();
googleProvider.addScope('openid');
googleProvider.addScope('https://www.googleapis.com/auth/userinfo.email');
googleProvider.addScope('https://www.googleapis.com/auth/userinfo.profile');
googleProvider.setCustomParameters({
  prompt: 'select_account',
});

// Cache the OAuth access token in memory as mandated by security rules
let cachedAccessToken: string | null = null;

export const getCachedAccessToken = (): string | null => cachedAccessToken;

export const formatFirebaseUserToAuthUser = (
  firebaseUser: FirebaseUser, 
  savedPrefs?: UserLanguagePreferences
): AuthUser => {
  return {
    id: firebaseUser.uid,
    name: firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'Google User',
    email: firebaseUser.email || undefined,
    avatar: firebaseUser.photoURL || undefined,
    isGuest: false,
    provider: 'google',
    loginTime: Date.now(),
    preferences: savedPrefs,
  };
};

/**
 * Initiates the authentic real Google Sign-In flow using Firebase Auth & Google Identity popup.
 * Opens Google's official account picker/consent screen and returns genuine authenticated user profile.
 */
export const signInWithGoogleReal = async (
  savedPrefs?: UserLanguagePreferences
): Promise<{ user: AuthUser; rawUser: FirebaseUser }> => {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (credential?.accessToken) {
      cachedAccessToken = credential.accessToken;
    }
    const authUser = formatFirebaseUserToAuthUser(result.user, savedPrefs);
    return { user: authUser, rawUser: result.user };
  } catch (error: any) {
    console.error('Real Google Sign-In error:', error);
    throw error;
  }
};

export const signOutGoogleReal = async (): Promise<void> => {
  try {
    await firebaseSignOut(auth);
    cachedAccessToken = null;
  } catch (error) {
    console.error('Firebase Sign-Out error:', error);
  }
};

export const deleteUserAccountReal = async (): Promise<void> => {
  try {
    const user = auth.currentUser;
    if (user) {
      await deleteUser(user);
    }
  } catch (error: any) {
    console.warn('Firebase user delete note (e.g. requires recent login or guest):', error);
  } finally {
    await signOutGoogleReal();
  }
};

export const subscribeToAuthState = (
  callback: (user: FirebaseUser | null) => void
) => {
  return onAuthStateChanged(auth, callback);
};
