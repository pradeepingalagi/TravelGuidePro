import { VoiceSettings } from '../types';

let currentUtterance: SpeechSynthesisUtterance | null = null;

export function getAvailableVoices(): SpeechSynthesisVoice[] {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    return [];
  }
  const voices = window.speechSynthesis.getVoices();
  return Array.isArray(voices) ? voices : [];
}

export function findBestVoiceForLang(langCode: string, preferredGender: 'auto' | 'female' | 'male' = 'auto'): SpeechSynthesisVoice | null {
  const voices = getAvailableVoices();
  if (!voices || !voices.length) return null;

  const cleanLang = langCode.toLowerCase().replace('_', '-');
  const codePrefix = cleanLang.split('-')[0];

  // 1. Exact speech code match (e.g. 'kn-IN', 'hi-IN', 'te-IN', 'ta-IN')
  let matchingVoices = voices.filter(v => v.lang.toLowerCase().replace('_', '-') === cleanLang);

  // 2. If no exact match, match by primary language code prefix (e.g. 'kn', 'hi', 'ta', 'mr')
  if (matchingVoices.length === 0) {
    matchingVoices = voices.filter(v => 
      v.lang.toLowerCase().startsWith(codePrefix) || 
      v.lang.toLowerCase().replace('_', '-').includes(codePrefix)
    );
  }

  if (matchingVoices.length === 0) return null;

  if (preferredGender === 'female') {
    const female = matchingVoices.find(v => 
      v.name.toLowerCase().includes('female') || 
      v.name.toLowerCase().includes('zira') || 
      v.name.toLowerCase().includes('natural')
    );
    if (female) return female;
  } else if (preferredGender === 'male') {
    const male = matchingVoices.find(v => 
      v.name.toLowerCase().includes('male') || 
      v.name.toLowerCase().includes('david') || 
      v.name.toLowerCase().includes('george')
    );
    if (male) return male;
  }

  // Prioritize natural Google / Apple / Microsoft neural voices
  const natural = matchingVoices.find(v => 
    v.name.toLowerCase().includes('natural') || 
    v.name.toLowerCase().includes('google') || 
    v.name.toLowerCase().includes('siri') || 
    v.name.toLowerCase().includes('enhanced')
  );

  return natural || matchingVoices[0];
}

export function stopSpeaking() {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
    currentUtterance = null;
  }
}

export function pauseSpeaking() {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.pause();
  }
}

export function resumeSpeaking() {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.resume();
  }
}

export function isSpeaking(): boolean {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    return window.speechSynthesis.speaking;
  }
  return false;
}

export function speakText(
  text: string,
  langSpeechCode: string = 'en-US',
  settings?: Partial<VoiceSettings>,
  onStart?: () => void,
  onEnd?: () => void,
  onError?: (err: any) => void
): Promise<void> {
  return new Promise((resolve) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      console.warn('Speech synthesis is not supported on this browser.');
      resolve();
      return;
    }

    // Cancel ongoing speech
    window.speechSynthesis.cancel();

    if (!text || !text.trim()) {
      resolve();
      return;
    }

    const utterance = new SpeechSynthesisUtterance(text.trim());
    currentUtterance = utterance;

    // Set language and settings
    utterance.lang = langSpeechCode;
    utterance.rate = settings?.speechRate ?? 1.0;
    utterance.pitch = settings?.pitch ?? 1.0;
    utterance.volume = settings?.volume ?? 1.0;

    const matchedVoice = findBestVoiceForLang(langSpeechCode, settings?.voiceGender ?? 'auto');
    if (matchedVoice) {
      utterance.voice = matchedVoice;
    }

    let finished = false;
    const finish = () => {
      if (!finished) {
        finished = true;
        clearTimeout(watchdogTimer);
        currentUtterance = null;
        onEnd?.();
        resolve();
      }
    };

    // Watchdog timer to ensure UI never hangs if browser drops onend
    const estimatedWords = text.trim().split(/\s+/).length;
    const maxDurationMs = Math.max(2000, Math.min(12000, estimatedWords * 600 + 1500));
    const watchdogTimer = setTimeout(finish, maxDurationMs);

    utterance.onstart = () => {
      onStart?.();
    };

    utterance.onend = () => {
      finish();
    };

    utterance.onerror = (event) => {
      console.warn('Speech synthesis utterance error:', event);
      onError?.(event);
      finish();
    };

    // Speak immediately without delay
    try {
      if (window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
      }
      window.speechSynthesis.speak(utterance);
    } catch (err) {
      console.error('speak error:', err);
      resolve();
    }
  });
}

export async function requestMicrophonePermission(): Promise<{ granted: boolean; error?: string }> {
  if (typeof navigator === 'undefined' || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    return { granted: false, error: 'MediaDevices API is not available on this browser.' };
  }

  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    // Stop tracks immediately after permission check
    stream.getTracks().forEach(track => track.stop());
    return { granted: true };
  } catch (err: any) {
    console.warn('Microphone permission request error:', err);
    if (err?.name === 'NotAllowedError' || err?.name === 'PermissionDeniedError' || err?.message?.includes('denied')) {
      return { 
        granted: false, 
        error: 'Microphone permission was blocked. Please tap the lock/camera icon in your browser address bar and choose "Allow" for Microphone.' 
      };
    }
    return { granted: false, error: err?.message || 'Could not access microphone.' };
  }
}

// Helper for Speech Recognition (Web Speech API)
export interface SpeechRecognizerHandlers {
  onResult: (transcript: string, isFinal: boolean) => void;
  onError: (error: string) => void;
  onStart: () => void;
  onEnd: () => void;
}

export class AppSpeechRecognizer {
  private recognition: any = null;
  private isListening = false;
  private langCode = 'en-US';

  constructor(langCode: string = 'en-US') {
    this.langCode = langCode;
    const SpeechRecognitionClass = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognitionClass) {
      try {
        this.recognition = new SpeechRecognitionClass();
        this.recognition.continuous = false;
        this.recognition.interimResults = true;
        this.recognition.maxAlternatives = 1;
        this.recognition.lang = langCode;
      } catch (e) {
        console.warn('Failed to construct SpeechRecognition:', e);
      }
    }
  }

  public setLanguage(langCode: string) {
    this.langCode = langCode;
    if (this.recognition) {
      this.recognition.lang = langCode === 'auto' ? 'en-US' : langCode;
    }
  }

  public isSupported(): boolean {
    return !!((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition);
  }

  public async start(handlers: SpeechRecognizerHandlers) {
    const SpeechRecognitionClass = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    
    if (!SpeechRecognitionClass) {
      handlers.onError('Speech recognition is not natively supported by this browser. You can type or use the test phrases below.');
      return;
    }

    // Re-instantiate recognition to avoid stale native recognition states
    try {
      this.recognition = new SpeechRecognitionClass();
      this.recognition.continuous = false;
      this.recognition.interimResults = true;
      this.recognition.maxAlternatives = 1;
      this.recognition.lang = this.langCode === 'auto' ? 'en-US' : this.langCode;
    } catch (err: any) {
      handlers.onError('Could not initialize speech recognizer: ' + err?.message);
      return;
    }

    if (this.isListening) {
      this.stop();
    }

    this.recognition.onstart = () => {
      this.isListening = true;
      handlers.onStart();
    };

    this.recognition.onresult = (event: any) => {
      let interim = '';
      let final = '';

      for (let i = event.resultIndex; i < event.results.length; ++i) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          final += transcript;
        } else {
          interim += transcript;
        }
      }

      if (final) {
        handlers.onResult(final.trim(), true);
      } else if (interim) {
        handlers.onResult(interim.trim(), false);
      }
    };

    this.recognition.onerror = (event: any) => {
      this.isListening = false;
      const err = event.error;
      console.warn('Speech recognition error event:', err, event);

      if (err === 'no-speech') {
        handlers.onError('No speech detected. Please speak closer to the microphone.');
      } else if (err === 'not-allowed' || err === 'service-not-allowed') {
        handlers.onError('Microphone permission blocked. Please click the lock icon in your browser URL bar, enable Microphone, and refresh or tap Retry.');
      } else if (err === 'audio-capture') {
        handlers.onError('No microphone was detected on this device. Please check your audio input settings.');
      } else if (err === 'network') {
        handlers.onError('Speech recognition network error. Check internet connection or type below.');
      } else if (err !== 'aborted') {
        handlers.onError(`Microphone error (${err}). Please tap to try again.`);
      }
      handlers.onEnd();
    };

    this.recognition.onend = () => {
      this.isListening = false;
      handlers.onEnd();
    };

    try {
      this.recognition.start();
    } catch (err: any) {
      console.warn('Recognition start caught error:', err);
      if (err?.name === 'NotAllowedError' || err?.message?.includes('not-allowed')) {
        handlers.onError('Microphone access denied. Please allow microphone permissions in your browser.');
      } else {
        handlers.onError(err?.message || 'Could not start microphone');
      }
      handlers.onEnd();
    }
  }

  public stop() {
    if (this.recognition) {
      try {
        this.recognition.stop();
      } catch (err) {
        // ignore
      }
      this.isListening = false;
    }
  }
}
