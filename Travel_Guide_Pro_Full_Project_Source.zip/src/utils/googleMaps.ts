/**
 * Google Maps Universal URL helper utilities.
 * 
 * Works 100% free with NO API key or billing required.
 * On mobile devices (Android / iOS), these official Universal Links launch
 * directly inside the native Google Maps app if installed, or prompt the user.
 * On desktop, it opens in a new tab with full satellite, reviews, and navigation.
 */

export function getGoogleMapsSearchUrl(query: string): string {
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query.trim())}`;
}

export function getGoogleMapsDirectionsUrl(
  origin: string,
  destination: string,
  travelMode: 'transit' | 'driving' | 'walking' | 'bicycling' = 'transit'
): string {
  const params = new URLSearchParams({
    api: '1',
    origin: origin.trim(),
    destination: destination.trim(),
    travelmode: travelMode,
  });
  return `https://www.google.com/maps/dir/?${params.toString()}`;
}

export function openInGoogleMaps(query: string) {
  const url = getGoogleMapsSearchUrl(query);
  window.open(url, '_blank', 'noopener,noreferrer');
}

export function openGoogleMapsDirections(
  origin: string,
  destination: string,
  travelMode: 'transit' | 'driving' | 'walking' | 'bicycling' = 'transit'
) {
  const url = getGoogleMapsDirectionsUrl(origin, destination, travelMode);
  window.open(url, '_blank', 'noopener,noreferrer');
}
