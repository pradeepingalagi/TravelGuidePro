// Permissions management utility for Microphone, Camera, and Geolocation

export type PermissionStateValue = 'granted' | 'denied' | 'prompt' | 'unsupported';

export interface AppPermissionsStatus {
  microphone: PermissionStateValue;
  camera: PermissionStateValue;
  location: PermissionStateValue;
  lastChecked: number;
}

export async function checkMicrophonePermission(): Promise<PermissionStateValue> {
  if (typeof navigator === 'undefined') return 'unsupported';
  try {
    if (navigator.permissions && navigator.permissions.query) {
      const status = await navigator.permissions.query({ name: 'microphone' as any });
      return status.state;
    }
  } catch (e) {
    // Some browsers don't support querying microphone directly
  }
  return 'prompt';
}

export async function checkCameraPermission(): Promise<PermissionStateValue> {
  if (typeof navigator === 'undefined') return 'unsupported';
  try {
    if (navigator.permissions && navigator.permissions.query) {
      const status = await navigator.permissions.query({ name: 'camera' as any });
      return status.state;
    }
  } catch (e) {
    // Query not supported
  }
  return 'prompt';
}

export async function checkLocationPermission(): Promise<PermissionStateValue> {
  if (typeof navigator === 'undefined' || !navigator.geolocation) return 'unsupported';
  try {
    if (navigator.permissions && navigator.permissions.query) {
      const status = await navigator.permissions.query({ name: 'geolocation' as any });
      return status.state;
    }
  } catch (e) {
    // Query not supported
  }
  return 'prompt';
}

export async function checkAllPermissions(): Promise<AppPermissionsStatus> {
  const [mic, cam, loc] = await Promise.all([
    checkMicrophonePermission(),
    checkCameraPermission(),
    checkLocationPermission(),
  ]);

  return {
    microphone: mic,
    camera: cam,
    location: loc,
    lastChecked: Date.now(),
  };
}

export function isStandaloneApp(): boolean {
  if (typeof window === 'undefined') return false;
  return (
    window.matchMedia('(display-mode: standalone)').matches ||
    Boolean((window.navigator as any)?.standalone) ||
    (typeof document !== 'undefined' && document.referrer.includes('android-app://'))
  );
}

// Dispatches an in-app guide event instead of launching a broken intent that redirects to Google Play
export function openAndroidAppSettings(): void {
  if (typeof window === 'undefined') return;
  window.dispatchEvent(new CustomEvent('open-android-settings-guide'));
}

export function savePermissionState(perm: 'location' | 'microphone' | 'camera', status: PermissionStateValue): void {
  try {
    // Only cache if explicitly granted; never permanently cache denied so user can re-prompt
    if (status === 'granted') {
      localStorage.setItem(`travelguidepro_perm_${perm}`, 'granted');
    } else {
      localStorage.removeItem(`travelguidepro_perm_${perm}`);
      localStorage.removeItem(`travelpro_perm_${perm}`);
      localStorage.removeItem(`travelsarathi_perm_${perm}`);
    }
  } catch {}
}

export function getSavedPermissionState(perm: 'location' | 'microphone' | 'camera'): PermissionStateValue | null {
  try {
    const saved = localStorage.getItem(`travelguidepro_perm_${perm}`) || 
                  localStorage.getItem(`travelpro_perm_${perm}`) || 
                  localStorage.getItem(`travelsarathi_perm_${perm}`);
    if (saved === 'granted') return 'granted';
    return null;
  } catch {
    return null;
  }
}

export async function requestMicrophoneAccess(): Promise<{ granted: boolean; error?: string }> {
  if (typeof navigator === 'undefined' || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    savePermissionState('microphone', 'unsupported');
    return { granted: false, error: 'Microphone is not supported on this browser or device.' };
  }
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    // Immediately stop tracks to release hardware light
    stream.getTracks().forEach(t => t.stop());
    savePermissionState('microphone', 'granted');
    return { granted: true };
  } catch (err: any) {
    const isDenied = err?.name === 'NotAllowedError' || err?.name === 'PermissionDeniedError';
    const isApp = isStandaloneApp();
    savePermissionState('microphone', 'denied');
    return {
      granted: false,
      error: isDenied
        ? (isApp
            ? 'Microphone blocked by device settings. Open your Phone Settings ➔ Apps ➔ Travel Guide Pro ➔ Permissions ➔ Set Microphone to "Allow".'
            : 'Microphone access was blocked. Tap the 🔒 lock icon in the address bar (or Phone Settings ➔ Apps) to allow.')
        : err?.message || 'Failed to access microphone.',
    };
  }
}

export async function requestCameraAccess(): Promise<{ granted: boolean; error?: string }> {
  if (typeof navigator === 'undefined' || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    savePermissionState('camera', 'unsupported');
    return { granted: false, error: 'Camera is not supported on this browser or device.' };
  }
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
    // Stop tracks immediately to release hardware camera
    stream.getTracks().forEach(t => t.stop());
    savePermissionState('camera', 'granted');
    return { granted: true };
  } catch (err: any) {
    const isDenied = err?.name === 'NotAllowedError' || err?.name === 'PermissionDeniedError';
    const isApp = isStandaloneApp();
    savePermissionState('camera', 'denied');
    return {
      granted: false,
      error: isDenied
        ? (isApp
            ? 'Camera blocked by device settings. Open your Phone Settings ➔ Apps ➔ Travel Guide Pro ➔ Permissions ➔ Set Camera to "Allow".'
            : 'Camera access was blocked. Tap the 🔒 lock icon in the address bar (or Phone Settings ➔ Apps) to allow.')
        : err?.message || 'Failed to access camera.',
    };
  }
}

export async function requestLocationAccess(): Promise<{
  granted: boolean;
  coords?: { latitude: number; longitude: number };
  error?: string;
}> {
  if (typeof navigator === 'undefined' || !navigator.geolocation) {
    savePermissionState('location', 'unsupported');
    return { granted: false, error: 'Location is not supported on this browser or device.' };
  }
  return new Promise(resolve => {
    navigator.geolocation.getCurrentPosition(
      pos => {
        savePermissionState('location', 'granted');
        resolve({
          granted: true,
          coords: {
            latitude: pos.coords.latitude,
            longitude: pos.coords.longitude,
          },
        });
      },
      err => {
        const isDenied = err.code === err.PERMISSION_DENIED;
        const isApp = isStandaloneApp();
        savePermissionState('location', 'denied');
        resolve({
          granted: false,
          error: isDenied
            ? (isApp
                ? 'Location blocked by device settings. Open your Phone Settings ➔ Apps ➔ Travel Guide Pro ➔ Permissions ➔ Set Location to "Allow".'
                : 'Location access was blocked. Tap the 🔒 lock icon in the address bar (or Phone Settings ➔ Apps) to allow.')
            : err.message || 'Unable to retrieve location.',
        });
      },
      { timeout: 10000, enableHighAccuracy: false }
    );
  });
}

