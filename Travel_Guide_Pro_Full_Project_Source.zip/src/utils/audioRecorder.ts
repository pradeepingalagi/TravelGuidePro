// Unified Voice & Microphone Recorder Engine
// Combines Web Speech API (for real-time interim display) and MediaRecorder + Multimodal Audio AI (for 100% reliable transcription & translation)

export interface AudioRecordingResult {
  transcript: string;
  audioBase64: string | null;
  mimeType: string;
  durationMs: number;
  maxVolume: number;
}

export interface VoiceRecorderCallbacks {
  onStart?: () => void;
  onInterimTranscript?: (text: string) => void;
  onFinalTranscript?: (text: string) => void;
  onVolumeChange?: (volume: number) => void; // 0 to 100
  onError?: (errorMessage: string) => void;
  onEnd?: () => void;
}

export class UnifiedVoiceRecorder {
  private mediaStream: MediaStream | null = null;
  private mediaRecorder: MediaRecorder | null = null;
  private audioChunks: Blob[] = [];
  private audioContext: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private animFrameId: number | null = null;
  private recognition: any = null;
  private isRecording = false;
  private isStarting = false;
  private isStopping = false;
  private startTime = 0;
  private maxVolumeObserved = 0;
  private collectedTranscript = '';
  private chosenMimeType = 'audio/webm';
  private callbacks: VoiceRecorderCallbacks = {};

  constructor() {}

  public getIsRecording(): boolean {
    return this.isRecording || this.isStarting;
  }

  public getTranscript(): string {
    return this.collectedTranscript.trim();
  }

  // Detect supported audio mimeType across mobile Safari, Android Chrome, and desktop
  private getSupportedMimeType(): string {
    if (typeof window === 'undefined' || typeof MediaRecorder === 'undefined') return '';
    const types = [
      'audio/webm;codecs=opus',
      'audio/webm',
      'audio/mp4',
      'audio/aac',
      'audio/ogg;codecs=opus',
      'audio/ogg',
      'audio/wav',
    ];
    for (const t of types) {
      if (typeof MediaRecorder.isTypeSupported === 'function' && MediaRecorder.isTypeSupported(t)) {
        return t;
      }
    }
    return '';
  }

  public async start(speechCode: string = 'en-US', callbacks: VoiceRecorderCallbacks): Promise<boolean> {
    // If stop() is currently completing, wait briefly for clean resource release
    if (this.isStopping) {
      const waitStart = Date.now();
      while (this.isStopping && Date.now() - waitStart < 350) {
        await new Promise((r) => setTimeout(r, 20));
      }
    }

    // Clean up any lingering active sessions
    this.cancelInternal();

    this.isStarting = true;
    this.callbacks = callbacks;
    this.audioChunks = [];
    this.collectedTranscript = '';
    this.maxVolumeObserved = 0;
    this.startTime = Date.now();

    // 1. Request hardware microphone stream with mobile-safe constraints
    let hasMediaStream = false;
    try {
      if (typeof navigator !== 'undefined' && navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        try {
          this.mediaStream = await navigator.mediaDevices.getUserMedia({
            audio: {
              echoCancellation: true,
              noiseSuppression: true,
              autoGainControl: true,
            },
          });
          hasMediaStream = true;
        } catch (advancedErr) {
          console.warn('Advanced audio constraints failed, retrying basic audio: true', advancedErr);
          try {
            this.mediaStream = await navigator.mediaDevices.getUserMedia({ audio: true });
            hasMediaStream = true;
          } catch (basicErr) {
            console.warn('Basic getUserMedia also failed:', basicErr);
          }
        }
      }
    } catch (err: any) {
      console.warn('getUserMedia check error:', err);
    }

    const SpeechClass = typeof window !== 'undefined'
      ? (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
      : null;

    // If getUserMedia completely failed or was blocked, but Web Speech API is present, gracefully run in Web Speech mode!
    if (!hasMediaStream && !SpeechClass) {
      this.isStarting = false;
      this.isRecording = false;
      const msg = 'Microphone access is blocked or unavailable. Please enable microphone permissions in your browser settings (tap the lock 🔒 or site settings icon in the address bar).';
      this.callbacks.onError?.(msg);
      return false;
    }

    // Check if user stopped while resolving
    if (!this.isStarting) {
      if (this.mediaStream) {
        this.mediaStream.getTracks().forEach((track) => track.stop());
        this.mediaStream = null;
      }
      return false;
    }

    this.isStarting = false;
    this.isRecording = true;
    this.callbacks.onStart?.();

    // 2. Setup AudioContext Volume Analyser if mediaStream is active
    if (this.mediaStream) {
      try {
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioCtx) {
          this.audioContext = new AudioCtx();
          if (this.audioContext.state === 'suspended') {
            this.audioContext.resume().catch(() => {});
          }
          const source = this.audioContext.createMediaStreamSource(this.mediaStream);
          this.analyser = this.audioContext.createAnalyser();
          this.analyser.fftSize = 256;
          source.connect(this.analyser);

          const bufferLength = this.analyser.frequencyBinCount;
          const dataArray = new Uint8Array(bufferLength);

          const checkVolume = () => {
            if (!this.isRecording || !this.analyser) return;
            this.analyser.getByteFrequencyData(dataArray);
            let sum = 0;
            for (let i = 0; i < bufferLength; i++) {
              sum += dataArray[i];
            }
            const avg = sum / bufferLength;
            const normalized = Math.min(100, Math.round((avg / 128) * 100));
            if (normalized > this.maxVolumeObserved) {
              this.maxVolumeObserved = normalized;
            }
            this.callbacks.onVolumeChange?.(normalized);
            this.animFrameId = requestAnimationFrame(checkVolume);
          };
          checkVolume();
        }
      } catch (e) {
        console.warn('AudioContext volume analyzer error:', e);
      }

      // 3. Setup MediaRecorder with robust fallback for Mobile Safari / Android Chrome
      try {
        const supportedMime = this.getSupportedMimeType();
        const options: MediaRecorderOptions = supportedMime ? { mimeType: supportedMime } : {};

        try {
          this.mediaRecorder = new MediaRecorder(this.mediaStream, options);
        } catch (errMime) {
          console.warn('MediaRecorder with specified options failed, falling back to browser default', errMime);
          this.mediaRecorder = new MediaRecorder(this.mediaStream);
        }

        this.chosenMimeType = (this.mediaRecorder && this.mediaRecorder.mimeType) || supportedMime || 'audio/webm';

        this.mediaRecorder.ondataavailable = (event: BlobEvent) => {
          if (event.data && event.data.size > 0) {
            this.audioChunks.push(event.data);
          }
        };

        // 250ms chunks ensure smooth mobile buffering
        this.mediaRecorder.start(250);
      } catch (mrErr) {
        console.warn('MediaRecorder init error:', mrErr);
      }
    }

    // 4. Try Web Speech API in parallel for instant client-side interim text
    if (SpeechClass) {
      try {
        if (this.recognition) {
          try {
            this.recognition.onstart = null;
            this.recognition.onresult = null;
            this.recognition.onerror = null;
            this.recognition.onend = null;
            this.recognition.abort();
          } catch (e) {}
          this.recognition = null;
        }

        const rec = new SpeechClass();
        rec.continuous = true;
        rec.interimResults = true;
        rec.lang = speechCode === 'auto' ? (navigator.language || 'en-US') : speechCode;

        let hasFatalSpeechError = false;

        rec.onresult = (event: any) => {
          let interim = '';
          let final = '';
          for (let i = event.resultIndex; i < event.results.length; ++i) {
            const t = event.results[i][0]?.transcript || '';
            if (event.results[i].isFinal) {
              final += t;
            } else {
              interim += t;
            }
          }

          if (final) {
            this.collectedTranscript = (this.collectedTranscript + ' ' + final).trim();
            this.callbacks.onFinalTranscript?.(this.collectedTranscript);
          } else if (interim) {
            const currentTotal = (this.collectedTranscript + ' ' + interim).trim();
            this.callbacks.onInterimTranscript?.(currentTotal);
          }
        };

        rec.onerror = (e: any) => {
          console.warn('WebSpeech event error:', e?.error);
          if (e?.error === 'not-allowed' || e?.error === 'service-not-allowed') {
            hasFatalSpeechError = true;
            if (!hasMediaStream) {
              this.callbacks.onError?.('Microphone access was denied in browser settings.');
            }
          }
        };

        rec.onend = () => {
          if (this.isRecording && this.recognition === rec && !hasFatalSpeechError) {
            try {
              rec.start();
            } catch (reErr) {}
          }
        };

        this.recognition = rec;
        try {
          rec.start();
        } catch (startErr: any) {
          if (startErr?.name === 'InvalidStateError') {
            setTimeout(() => {
              try {
                if (this.isRecording && this.recognition === rec && !hasFatalSpeechError) rec.start();
              } catch (e) {}
            }, 80);
          }
        }
      } catch (speechErr) {
        console.warn('WebSpeech start error (will use Gemini Audio AI):', speechErr);
      }
    }

    return true;
  }

  // Stop recording cleanly and return transcript and/or base64 audio
  public async stop(): Promise<AudioRecordingResult> {
    this.isStopping = true;
    this.isStarting = false;
    this.isRecording = false;
    const durationMs = Date.now() - this.startTime;

    try {
      // 1. Immediately cancel volume animation frame & trigger onEnd callback
      if (this.animFrameId) {
        cancelAnimationFrame(this.animFrameId);
        this.animFrameId = null;
      }
      this.callbacks.onEnd?.();

      // 2. Stop Web Speech Recognition immediately with abort to prevent hanging
      if (this.recognition) {
        try {
          this.recognition.onstart = null;
          this.recognition.onresult = null;
          this.recognition.onerror = null;
          this.recognition.onend = null;
          if (typeof this.recognition.abort === 'function') {
            this.recognition.abort();
          } else if (typeof this.recognition.stop === 'function') {
            this.recognition.stop();
          }
        } catch (e) {}
        this.recognition = null;
      }

      // 3. Request final data chunk and stop MediaRecorder, waiting for onstop to guarantee all audio chunks
      let audioBase64: string | null = null;
      if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') {
        await new Promise<void>((resolve) => {
          let isResolved = false;
          const done = () => {
            if (!isResolved) {
              isResolved = true;
              resolve();
            }
          };

          // Reliable timeout (350ms) ensures audio chunks flush completely on mobile without delay
          const timeoutId = setTimeout(done, 350);

          this.mediaRecorder!.onstop = () => {
            clearTimeout(timeoutId);
            done();
          };

          try {
            if (typeof (this.mediaRecorder as any).requestData === 'function' && this.mediaRecorder!.state === 'recording') {
              (this.mediaRecorder as any).requestData();
            }
            this.mediaRecorder!.stop();
          } catch (e) {
            clearTimeout(timeoutId);
            done();
          }
        });
      }

      // 4. Immediately stop all media tracks to release the hardware microphone & light
      if (this.mediaStream) {
        this.mediaStream.getTracks().forEach((track) => track.stop());
        this.mediaStream = null;
      }

      // 5. Close AudioContext
      if (this.audioContext && this.audioContext.state !== 'closed') {
        try {
          await this.audioContext.close();
        } catch (e) {}
        this.audioContext = null;
      }

      // 6. Convert recorded audio chunks to base64
      if (this.audioChunks.length > 0) {
        try {
          const finalMime = (this.mediaRecorder && this.mediaRecorder.mimeType) || this.chosenMimeType || 'audio/webm';
          const audioBlob = new Blob(this.audioChunks, { type: finalMime });
          if (audioBlob.size > 20) {
            audioBase64 = await this.blobToBase64(audioBlob);
            this.chosenMimeType = finalMime;
          }
        } catch (blobErr) {
          console.warn('Error converting audio blob to base64:', blobErr);
        }
      }

      return {
        transcript: this.collectedTranscript.trim(),
        audioBase64,
        mimeType: this.chosenMimeType || 'audio/webm',
        durationMs,
        maxVolume: this.maxVolumeObserved,
      };
    } finally {
      this.isStopping = false;
    }
  }

  // Force stop / cancel
  public cancel() {
    this.cancelInternal();
    this.callbacks.onEnd?.();
  }

  private cancelInternal() {
    this.isStarting = false;
    this.isRecording = false;
    this.isStopping = false;
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
      this.animFrameId = null;
    }
    if (this.recognition) {
      try {
        this.recognition.onstart = null;
        this.recognition.onresult = null;
        this.recognition.onerror = null;
        this.recognition.onend = null;
        if (typeof this.recognition.abort === 'function') {
          this.recognition.abort();
        } else {
          this.recognition.stop();
        }
      } catch (e) {}
      this.recognition = null;
    }
    if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') {
      try {
        this.mediaRecorder.stop();
      } catch (e) {}
    }
    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach((track) => track.stop());
      this.mediaStream = null;
    }
    if (this.audioContext && this.audioContext.state !== 'closed') {
      this.audioContext.close().catch(() => {});
      this.audioContext = null;
    }
  }

  private blobToBase64(blob: Blob): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const res = reader.result as string;
        // Clean prefix
        const base64 = res.split(',')[1] || res;
        resolve(base64);
      };
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  }
}
