import { WeatherCondition } from '../types/travel';

interface WeatherCacheEntry {
  data: WeatherCondition;
  timestamp: number;
}

const memoryWeatherCache: Record<string, WeatherCacheEntry> = {};
const CACHE_TTL_MS = 15 * 60 * 1000; // 15 minutes

/**
 * Fetches live weather for a destination using Open-Meteo free API
 */
export async function fetchLiveWeather(
  destination: string,
  coords?: { latitude: number; longitude: number }
): Promise<WeatherCondition | null> {
  const cacheKey = destination.toLowerCase().trim();
  const now = Date.now();

  if (memoryWeatherCache[cacheKey] && now - memoryWeatherCache[cacheKey].timestamp < CACHE_TTL_MS) {
    return memoryWeatherCache[cacheKey].data;
  }

  try {
    let url = `/api/weather?city=${encodeURIComponent(destination)}`;
    if (coords && coords.latitude && coords.longitude) {
      url += `&lat=${coords.latitude}&lng=${coords.longitude}`;
    }

    const res = await fetch(url);
    if (res.ok) {
      const json = await res.json();
      if (json.success && json.weather) {
        memoryWeatherCache[cacheKey] = {
          data: json.weather,
          timestamp: now,
        };
        return json.weather;
      }
    }
  } catch (err: any) {
    console.info('Live weather service note (using local profile):', err?.message || 'offline');
  }

  return null;
}
