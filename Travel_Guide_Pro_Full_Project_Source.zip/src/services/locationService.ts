import { DestinationCity } from '../types/travel';
import { CITIES_DATA } from '../data/travelData';

export interface CityCoordinate {
  city: DestinationCity;
  lat: number;
  lng: number;
  country: string;
}

export const CITY_COORDINATES: Record<DestinationCity, { lat: number; lng: number; country: string }> = {
  'Delhi, India': { lat: 28.6139, lng: 77.2090, country: 'India' },
  'Tokyo, Japan': { lat: 35.6762, lng: 139.6503, country: 'Japan' },
  'Paris, France': { lat: 48.8566, lng: 2.3522, country: 'France' },
  'Rome, Italy': { lat: 41.9028, lng: 12.4964, country: 'Italy' },
  'Bangkok, Thailand': { lat: 13.7563, lng: 100.5018, country: 'Thailand' },
  'London, UK': { lat: 51.5074, lng: -0.1278, country: 'UK' },
  'New York, USA': { lat: 40.7128, lng: -74.0060, country: 'USA' },
  'Dubai, UAE': { lat: 25.2048, lng: 55.2708, country: 'UAE' },
  'Singapore': { lat: 1.3521, lng: 103.8198, country: 'Singapore' },
  'Barcelona, Spain': { lat: 41.3879, lng: 2.1699, country: 'Spain' },
};

export interface LocationDetectionResult {
  status: 'detected' | 'denied' | 'unavailable' | 'error';
  isLocationBased: boolean;
  isIpBased?: boolean;
  coords?: {
    latitude: number;
    longitude: number;
  };
  accuracy?: number;
  city?: string;
  state?: string;
  country?: string;
  countryCode?: string;
  flag?: string;
  detectedPlaceName?: string;
  matchedDestination: DestinationCity;
  closestPresetHub?: DestinationCity;
  distanceKm?: number;
  primaryLanguage?: string;
  primaryLanguageCode?: string;
  currency?: {
    code: string;
    symbol: string;
    rate: number;
  };
  emergency?: {
    emergency: string;
    police: string;
    ambulance: string;
  };
  weather?: {
    tempC: number;
    tempF: number;
    condition: string;
    icon: string;
  };
  timestamp: number;
  message?: string;
}

const LOCATION_STORAGE_KEY = 'omnitranslate_location_state';

// Haversine formula to compute great-circle distance between two points in km
export function calculateDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Radius of the Earth in km
  const dLat = (lat2 - lat1) * (Math.PI / 180);
  const dLon = (lon2 - lon1) * (Math.PI / 180);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * (Math.PI / 180)) *
      Math.cos(lat2 * (Math.PI / 180)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

// Find closest supported travel hub/destination based on coordinates
export function findClosestDestination(lat: number, lng: number): { city: DestinationCity; distanceKm: number } {
  let closestCity: DestinationCity = 'Delhi, India';
  let minDistance = Infinity;

  for (const [cityName, coords] of Object.entries(CITY_COORDINATES)) {
    const dist = calculateDistanceKm(lat, lng, coords.lat, coords.lng);
    if (dist < minDistance) {
      minDistance = dist;
      closestCity = cityName as DestinationCity;
    }
  }

  return { city: closestCity, distanceKm: Math.round(minDistance) };
}

// Load previously detected location from localStorage
export function loadStoredLocationState(): LocationDetectionResult | null {
  try {
    const saved = localStorage.getItem(LOCATION_STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (parsed && (parsed.matchedDestination || parsed.city)) {
        return parsed as LocationDetectionResult;
      }
    }
  } catch (err) {
    console.warn('Failed to load stored location state:', err);
  }
  return null;
}

// Save location state to localStorage
export function saveStoredLocationState(state: LocationDetectionResult): void {
  try {
    localStorage.setItem(LOCATION_STORAGE_KEY, JSON.stringify(state));
  } catch (err) {
    console.warn('Failed to save location state:', err);
  }
}

// Perform device geolocation detection with server-side high-fidelity reverse geocoding & IP fallback
export async function detectDeviceLocation(): Promise<LocationDetectionResult> {
  // Helper for IP-based network fallback
  const fallbackToIp = async (reason = 'GPS Unavailable'): Promise<LocationDetectionResult> => {
    try {
      const res = await fetch('/api/location/detect');
      if (res.ok) {
        const ipData = await res.json();
        if (ipData.status === 'detected') {
          const result: LocationDetectionResult = {
            status: 'detected',
            isLocationBased: true,
            isIpBased: true,
            coords: ipData.coords,
            accuracy: 5000,
            city: ipData.city,
            state: ipData.state,
            country: ipData.country,
            countryCode: ipData.countryCode,
            flag: ipData.flag || '📍',
            detectedPlaceName: ipData.displayName || ipData.matchedDestination,
            matchedDestination: ipData.matchedDestination,
            primaryLanguage: ipData.primaryLanguage,
            primaryLanguageCode: ipData.primaryLanguageCode,
            currency: ipData.currency,
            emergency: ipData.emergency,
            weather: ipData.weather,
            timestamp: Date.now(),
            message: `Network Location Detected: ${ipData.matchedDestination} (${reason})`,
          };
          saveStoredLocationState(result);
          return result;
        }
      }
    } catch {}

    const fallbackStored = loadStoredLocationState();
    return {
      status: 'unavailable',
      isLocationBased: false,
      matchedDestination: fallbackStored?.matchedDestination || 'Delhi, India',
      timestamp: Date.now(),
      message: reason,
    };
  };

  if (typeof window === 'undefined' || !navigator.geolocation) {
    return fallbackToIp('Geolocation API not supported');
  }

  return new Promise((resolve) => {
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const { latitude, longitude, accuracy } = pos.coords;
        const closest = findClosestDestination(latitude, longitude);

        try {
          // Call our server reverse-geocode endpoint with real weather and region details
          const res = await fetch(`/api/location/reverse-geocode?lat=${latitude}&lng=${longitude}`);
          if (res.ok) {
            const data = await res.json();
            const result: LocationDetectionResult = {
              status: 'detected',
              isLocationBased: true,
              isIpBased: false,
              coords: { latitude, longitude },
              accuracy: Math.round(accuracy),
              city: data.city,
              state: data.state,
              country: data.country,
              countryCode: data.countryCode,
              flag: data.flag,
              detectedPlaceName: data.displayName || data.matchedDestination,
              matchedDestination: data.matchedDestination || closest.city,
              closestPresetHub: closest.city,
              distanceKm: closest.distanceKm,
              primaryLanguage: data.primaryLanguage,
              primaryLanguageCode: data.primaryLanguageCode,
              currency: data.currency,
              emergency: data.emergency,
              weather: data.weather,
              timestamp: Date.now(),
              message: `Live GPS Active: ${data.matchedDestination} (±${Math.round(accuracy)}m)`,
            };

            saveStoredLocationState(result);
            resolve(result);
            return;
          }
        } catch (err) {
          console.warn('Reverse geocode error, using coordinates fallback:', err);
        }

        // Fallback with coordinates
        const result: LocationDetectionResult = {
          status: 'detected',
          isLocationBased: true,
          coords: { latitude, longitude },
          accuracy: Math.round(accuracy),
          detectedPlaceName: `${latitude.toFixed(4)}°, ${longitude.toFixed(4)}°`,
          matchedDestination: closest.city,
          closestPresetHub: closest.city,
          distanceKm: closest.distanceKm,
          timestamp: Date.now(),
          message: `Live GPS Active: ${closest.city} Hub (~${closest.distanceKm} km)`,
        };

        saveStoredLocationState(result);
        resolve(result);
      },
      async (error) => {
        let msg = 'Could not access GPS';
        if (error.code === error.PERMISSION_DENIED) {
          msg = 'Location permission denied';
        } else if (error.code === error.POSITION_UNAVAILABLE) {
          msg = 'Location position unavailable';
        } else if (error.code === error.TIMEOUT) {
          msg = 'Location request timed out';
        }

        // Attempt IP fallback seamlessly so user still gets their real destination
        const ipResult = await fallbackToIp(msg);
        resolve(ipResult);
      },
      {
        enableHighAccuracy: true,
        timeout: 9000,
        maximumAge: 30000,
      }
    );
  });
}
