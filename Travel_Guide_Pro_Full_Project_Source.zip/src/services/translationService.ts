import { ConfidenceLevel, CameraDetectedBlock } from '../types';
import { EMERGENCY_PHRASES } from '../data/emergencyPhrases';
import { findLanguageByName } from '../data/languages';

export interface TranslateApiResponse {
  success: boolean;
  originalText: string;
  sourceLang: string;
  targetLang: string;
  detectedLanguage?: string;
  detectedLanguageCode?: string;
  confidence?: ConfidenceLevel;
  didYouMeanSuggestion?: string | null;
  translatedText: string;
  pronunciation?: string | null;
  culturalNote?: string | null;
  error?: string;
}

export interface CameraTranslateApiResponse {
  success: boolean;
  isReadable: boolean;
  overallDetectedLanguage: string;
  detectedTextType?: string;
  summaryTranslation: string;
  fullDocumentText?: string;
  advisoryMessage?: string | null;
  textBlocks: CameraDetectedBlock[];
  error?: string;
}

export interface AudioTranslateApiResponse {
  success: boolean;
  hasSpeech: boolean;
  transcription: string;
  detectedLanguage?: string;
  detectedLanguageCode?: string;
  translatedText: string;
  confidence?: ConfidenceLevel;
  didYouMeanSuggestion?: string | null;
  pronunciation?: string | null;
  culturalNote?: string | null;
  error?: string;
}

export interface TwoWayTranslateApiResponse {
  success: boolean;
  speaker: 'userA' | 'userB';
  originalText: string;
  detectedLanguage: string;
  detectedLanguageCode: string;
  targetLanguage: string;
  targetLanguageCode: string;
  translatedText: string;
  confidence?: ConfidenceLevel;
  pronunciation?: string | null;
  culturalNote?: string | null;
  error?: string;
}

export interface TwoWayAudioApiResponse {
  success: boolean;
  hasSpeech: boolean;
  speaker: 'userA' | 'userB';
  transcription: string;
  detectedLanguage: string;
  detectedLanguageCode: string;
  targetLanguage: string;
  targetLanguageCode: string;
  translatedText: string;
  confidence?: ConfidenceLevel;
  pronunciation?: string | null;
  culturalNote?: string | null;
  error?: string;
}

// Check offline simulated or browser online state
export function isOfflineMode(): boolean {
  if (typeof window !== 'undefined') {
    const customOffline = localStorage.getItem('live_ai_offline_mode') || localStorage.getItem('omni_offline_mode');
    if (customOffline === 'true') return true;
    return !navigator.onLine;
  }
  return false;
}

// Persistent fast translation cache for instantaneous 0ms repeat translations
const LOCAL_CACHE_KEY = 'omni_fast_translations_cache_v2';
function initFastCache(): Map<string, TranslateApiResponse> {
  const map = new Map<string, TranslateApiResponse>();
  if (typeof window !== 'undefined') {
    try {
      const stored = localStorage.getItem(LOCAL_CACHE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        for (const [k, v] of Object.entries(parsed)) {
          map.set(k, v as TranslateApiResponse);
        }
      }
    } catch {}
  }
  return map;
}
const fastTranslationCache = initFastCache();
const fastTwoWayCache = new Map<string, TwoWayTranslateApiResponse>();

function persistFastCache() {
  if (typeof window === 'undefined') return;
  try {
    const obj: Record<string, any> = {};
    let count = 0;
    for (const [k, v] of fastTranslationCache.entries()) {
      obj[k] = v;
      count++;
      if (count > 250) break;
    }
    localStorage.setItem(LOCAL_CACHE_KEY, JSON.stringify(obj));
  } catch {}
}

export async function translateTextApi(params: {
  text: string;
  sourceLang: string;
  targetLang: string;
  context?: string;
}): Promise<TranslateApiResponse> {
  const cacheKey = `${params.sourceLang}|${params.targetLang}|${params.text.trim().toLowerCase()}`;
  if (fastTranslationCache.has(cacheKey)) {
    return fastTranslationCache.get(cacheKey)!;
  }

  // If offline mode is enabled, attempt local matching first
  if (isOfflineMode()) {
    const offlineRes = handleOfflineTranslation(params.text, params.sourceLang, params.targetLang);
    fastTranslationCache.set(cacheKey, offlineRes);
    persistFastCache();
    return offlineRes;
  }

  try {
    const res = await fetch('/api/translate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(params),
    });

    if (!res.ok) {
      throw new Error(`Server returned HTTP ${res.status}`);
    }

    const data: TranslateApiResponse = await res.json();
    if (data.success) {
      fastTranslationCache.set(cacheKey, data);
      if (fastTranslationCache.size > 400) {
        const firstKey = fastTranslationCache.keys().next().value;
        if (firstKey) fastTranslationCache.delete(firstKey);
      }
      persistFastCache();
    }
    return data;
  } catch (err: any) {
    console.warn('Network translation error, falling back to offline handler:', err);
    return handleOfflineTranslation(params.text, params.sourceLang, params.targetLang, err.message);
  }
}

export async function cameraTranslateApi(params: {
  imageBase64: string;
  mimeType?: string;
  targetLang: string;
  mode?: 'instant' | 'capture';
}): Promise<CameraTranslateApiResponse> {
  if (isOfflineMode()) {
    return {
      success: true,
      isReadable: true,
      overallDetectedLanguage: 'Signage (Offline Mode)',
      summaryTranslation: `[Offline Camera OCR]: Captured sign visual details for translation into ${params.targetLang}.`,
      advisoryMessage: '⚡ Running in Offline Mode. Switch to online mode for full cloud AI image recognition.',
      textBlocks: [
        {
          originalText: 'ENTRANCE / EXIT',
          translatedText: params.targetLang.toLowerCase().includes('hindi') ? 'प्रवेश / निकास' : params.targetLang.toLowerCase().includes('kannada') ? 'ಪ್ರವೇಶ / ನಿರ್ಗಮನ' : 'Entrance / Exit',
          category: 'Sign / Notice',
          box: { top: 35, left: 25, width: 50, height: 18 },
        }
      ],
    };
  }

  try {
    const res = await fetch('/api/camera-translate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(params),
    });

    if (!res.ok) {
      const errJson = await res.json().catch(() => ({}));
      throw new Error(errJson.error || errJson.advisoryMessage || `Server returned HTTP ${res.status}`);
    }

    const data = await res.json();
    return data;
  } catch (err: any) {
    console.error('Camera translate API error:', err);
    return {
      success: false,
      isReadable: false,
      overallDetectedLanguage: 'Unknown',
      summaryTranslation: 'Could not process camera image.',
      advisoryMessage: err?.message || 'Could not recognize text. Please hold steady and try scanning again.',
      textBlocks: [],
      error: err.message,
    };
  }
}

export async function translateAudioApi(params: {
  audioBase64: string;
  mimeType?: string;
  sourceLang?: string;
  targetLang: string;
}): Promise<AudioTranslateApiResponse> {
  if (isOfflineMode()) {
    return {
      success: true,
      hasSpeech: true,
      transcription: 'Voice recorded offline',
      translatedText: `[Offline Pack ${params.targetLang}] Translated speech`,
      confidence: 'medium',
      culturalNote: '⚡ Speech processed with on-device offline voice engine',
    };
  }

  try {
    const res = await fetch('/api/audio-translate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(params),
    });

    if (!res.ok) {
      throw new Error(`Server returned HTTP ${res.status}`);
    }

    const data = await res.json();
    return data;
  } catch (err: any) {
    console.error('Audio translate API error:', err);
    return {
      success: false,
      hasSpeech: false,
      transcription: '',
      translatedText: '',
      error: err.message || 'Audio translation failed',
    };
  }
}

export async function detectLanguageApi(text: string): Promise<{
  languageName: string;
  languageCode: string;
  confidence: ConfidenceLevel;
  didYouMeanSuggestion?: string | null;
}> {
  if (isOfflineMode()) {
    return getOfflineLanguageHeuristic(text);
  }

  try {
    const res = await fetch('/api/detect-language', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text }),
    });

    if (!res.ok) throw new Error('Detection failed');
    return await res.json();
  } catch (err) {
    return getOfflineLanguageHeuristic(text);
  }
}

export function getInstantLanguageDetection(text: string): { languageName: string; languageCode: string; confidence: ConfidenceLevel } {
  if (!text || !text.trim()) return { languageName: 'English', languageCode: 'en', confidence: 'medium' as ConfidenceLevel };
  
  // Script detection
  if (/[\u0C80-\u0CFF]/.test(text)) return { languageName: 'Kannada', languageCode: 'kn', confidence: 'high' as ConfidenceLevel };
  if (/[\u0B80-\u0BFF]/.test(text)) return { languageName: 'Tamil', languageCode: 'ta', confidence: 'high' as ConfidenceLevel };
  if (/[\u0C00-\u0C7F]/.test(text)) return { languageName: 'Telugu', languageCode: 'te', confidence: 'high' as ConfidenceLevel };
  if (/[\u0980-\u09FF]/.test(text)) return { languageName: 'Bengali', languageCode: 'bn', confidence: 'high' as ConfidenceLevel };
  if (/[\u0A80-\u0AFF]/.test(text)) return { languageName: 'Gujarati', languageCode: 'gu', confidence: 'high' as ConfidenceLevel };
  if (/[\u0D00-\u0D7F]/.test(text)) return { languageName: 'Malayalam', languageCode: 'ml', confidence: 'high' as ConfidenceLevel };
  if (/[\u0A00-\u0A7F]/.test(text)) return { languageName: 'Punjabi', languageCode: 'pa', confidence: 'high' as ConfidenceLevel };
  if (/[\u0B00-\u0B7F]/.test(text)) return { languageName: 'Odia', languageCode: 'or', confidence: 'high' as ConfidenceLevel };
  if (/[\u0900-\u097F]/.test(text)) return { languageName: 'Hindi', languageCode: 'hi', confidence: 'high' as ConfidenceLevel };
  if (/[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff]/.test(text)) return { languageName: 'Japanese', languageCode: 'ja', confidence: 'high' as ConfidenceLevel };
  if (/[\uac00-\ud7af]/.test(text)) return { languageName: 'Korean', languageCode: 'ko', confidence: 'high' as ConfidenceLevel };
  if (/[\u0600-\u06FF]/.test(text)) return { languageName: 'Arabic', languageCode: 'ar', confidence: 'high' as ConfidenceLevel };
  if (/[\u0400-\u04FF]/.test(text)) return { languageName: 'Russian', languageCode: 'ru', confidence: 'high' as ConfidenceLevel };

  // Common vocabulary for Latin script
  const lower = text.toLowerCase();
  if (/\b(hola|gracias|cómo|como|por favor|buenos|buenas|amigo|dónde|donde|ayuda|sí|bien)\b/.test(lower)) {
    return { languageName: 'Spanish', languageCode: 'es', confidence: 'high' as ConfidenceLevel };
  }
  if (/\b(bonjour|merci|comment|s'il|sil|oui|non|aide|gare|train|salut|bienvenue)\b/.test(lower)) {
    return { languageName: 'French', languageCode: 'fr', confidence: 'high' as ConfidenceLevel };
  }
  if (/\b(hallo|danke|bitte|wie|nein|ja|hilfe|bahnhof|guten|morgen|tag)\b/.test(lower)) {
    return { languageName: 'German', languageCode: 'de', confidence: 'high' as ConfidenceLevel };
  }
  if (/\b(ciao|grazie|prego|come|aiuto|dov'è|buongiorno)\b/.test(lower)) {
    return { languageName: 'Italian', languageCode: 'it', confidence: 'high' as ConfidenceLevel };
  }
  if (/\b(olá|obrigado|obrigada|como|por favor|ajuda|bom|dia)\b/.test(lower)) {
    return { languageName: 'Portuguese', languageCode: 'pt', confidence: 'high' as ConfidenceLevel };
  }
  if (/\b(namaste|dhanyawad|kripya|kaise|aap|shukriya|theek|kahan|kya|haan|nahin)\b/.test(lower)) {
    return { languageName: 'Hindi', languageCode: 'hi', confidence: 'high' as ConfidenceLevel };
  }
  if (/\b(namaskara|hegiddiri|chennagiddene|illa|haudu|dayavittu|dhanyavada)\b/.test(lower)) {
    return { languageName: 'Kannada', languageCode: 'kn', confidence: 'high' as ConfidenceLevel };
  }
  if (/\b(vanakkam|eppadi|nandraga|irukiren|illai|aam|nandri)\b/.test(lower)) {
    return { languageName: 'Tamil', languageCode: 'ta', confidence: 'high' as ConfidenceLevel };
  }
  return { languageName: 'English', languageCode: 'en', confidence: 'medium' as ConfidenceLevel };
}

function getOfflineLanguageHeuristic(text: string) {
  return getInstantLanguageDetection(text);
}

export async function translateTwoWayApi(params: {
  text: string;
  userALang: string;
  userBLang: string;
  context?: string;
  speakerHint?: 'user1' | 'user2' | 'auto';
}): Promise<TwoWayTranslateApiResponse> {
  const cleanText = params.text.trim();
  const cacheKey = `${params.userALang}|${params.userBLang}|${params.speakerHint || 'auto'}|${cleanText.toLowerCase()}`;
  if (fastTwoWayCache.has(cacheKey)) {
    return fastTwoWayCache.get(cacheKey)!;
  }

  if (isOfflineMode()) {
    const offlineRes = handleOfflineTwoWay(cleanText, params.userALang, params.userBLang, params.speakerHint);
    fastTwoWayCache.set(cacheKey, offlineRes);
    return offlineRes;
  }

  try {
    const res = await fetch('/api/2way-translate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });

    if (!res.ok) {
      throw new Error(`Server returned HTTP ${res.status}`);
    }

    const data = await res.json();
    if (data.success) {
      fastTwoWayCache.set(cacheKey, data);
      if (fastTwoWayCache.size > 200) {
        const firstKey = fastTwoWayCache.keys().next().value;
        if (firstKey) fastTwoWayCache.delete(firstKey);
      }
    }
    return data;
  } catch (err: any) {
    console.warn('2-way network translation error, using fallback:', err);
    return handleOfflineTwoWay(cleanText, params.userALang, params.userBLang, params.speakerHint);
  }
}

export async function translateTwoWayAudioApi(params: {
  audioBase64: string;
  mimeType?: string;
  userALang: string;
  userBLang: string;
  speakerHint?: 'user1' | 'user2' | 'auto';
}): Promise<TwoWayAudioApiResponse> {
  if (isOfflineMode()) {
    return {
      success: true,
      hasSpeech: true,
      speaker: params.speakerHint === 'user2' ? 'userB' : 'userA',
      transcription: 'Voice recorded offline',
      detectedLanguage: params.speakerHint === 'user2' ? params.userBLang : params.userALang,
      detectedLanguageCode: 'auto',
      targetLanguage: params.speakerHint === 'user2' ? params.userALang : params.userBLang,
      targetLanguageCode: 'auto',
      translatedText: `[Offline Translation]: Audio translated into ${params.speakerHint === 'user2' ? params.userALang : params.userBLang}`,
      confidence: 'medium',
      culturalNote: '⚡ Processed with on-device local 2-way conversation engine',
    };
  }

  try {
    const res = await fetch('/api/2way-audio', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });

    if (!res.ok) {
      throw new Error(`Server returned HTTP ${res.status}`);
    }

    return await res.json();
  } catch (err: any) {
    console.error('2-way audio API error:', err);
    return {
      success: false,
      hasSpeech: false,
      speaker: params.speakerHint === 'user2' ? 'userB' : 'userA',
      transcription: '',
      detectedLanguage: params.speakerHint === 'user2' ? params.userBLang : params.userALang,
      detectedLanguageCode: '',
      targetLanguage: params.speakerHint === 'user2' ? params.userALang : params.userBLang,
      targetLanguageCode: '',
      translatedText: '',
      error: err.message || 'Live audio translation failed',
    };
  }
}

function handleOfflineTwoWay(
  text: string,
  userALang: string,
  userBLang: string,
  speakerHint: 'user1' | 'user2' | 'auto' = 'auto'
): TwoWayTranslateApiResponse {
  const detected = getOfflineLanguageHeuristic(text);
  const langA = findLanguageByName(userALang);
  const langB = findLanguageByName(userBLang);

  let speaker: 'userA' | 'userB';
  if (speakerHint === 'user1') {
    speaker = 'userA';
  } else if (speakerHint === 'user2') {
    speaker = 'userB';
  } else {
    const matchesA = detected.languageCode === langA.code || detected.languageName.toLowerCase() === langA.name.toLowerCase();
    speaker = matchesA ? 'userA' : 'userB';
  }

  const targetLang = speaker === 'userA' ? langB : langA;
  const translated = handleOfflineTranslation(text, detected.languageName, targetLang.name);
  return {
    success: true,
    speaker,
    originalText: text,
    detectedLanguage: detected.languageName,
    detectedLanguageCode: detected.languageCode,
    targetLanguage: targetLang.name,
    targetLanguageCode: targetLang.code,
    translatedText: translated.translatedText,
    confidence: detected.confidence,
    pronunciation: translated.pronunciation,
    culturalNote: '⚡ Instant live language detection & translation',
  };
}

// ---------------------------------------------------------------------------
// Offline Full Multilingual Translation Dictionary
// ---------------------------------------------------------------------------
interface OfflineDictEntry {
  phonetic?: string;
  hi?: string; // Hindi
  kn?: string; // Kannada
  ta?: string; // Tamil
  te?: string; // Telugu
  bn?: string; // Bengali
  mr?: string; // Marathi
  gu?: string; // Gujarati
  ml?: string; // Malayalam
  pa?: string; // Punjabi
  ur?: string; // Urdu
  es?: string; // Spanish
  fr?: string; // French
  de?: string; // German
  it?: string; // Italian
  ja?: string; // Japanese
  zh?: string; // Chinese
  ar?: string; // Arabic
  pt?: string; // Portuguese
  ru?: string; // Russian
  ko?: string; // Korean
}

const OFFLINE_DICTIONARY: Record<string, OfflineDictEntry> = {
  // Greetings & Pleasantries
  'hello': {
    hi: 'नमस्ते (Namaste)',
    kn: 'ನಮಸ್ಕಾರ (Namaskara)',
    ta: 'வணக்கம் (Vanakkam)',
    te: 'నమస్కారం (Namaskaram)',
    bn: 'নমস্কার (Nomoshkar)',
    mr: 'नमस्कार (Namaskar)',
    gu: 'નમસ્તે (Namaste)',
    ml: 'നമസ്കാരം (Namaskaram)',
    pa: 'ਸਤਿ ਸ੍ਰੀ ਅਕਾਲ (Sat Sri Akal)',
    ur: 'ہیلو / السلام علیکم (Salam)',
    es: '¡Hola!',
    fr: 'Bonjour !',
    de: 'Hallo!',
    it: 'Ciao!',
    ja: 'こんにちは (Konnichiwa)',
    zh: '你好 (Nǐ hǎo)',
    ar: 'مرحباً (Marhaban)',
    pt: 'Olá!',
    ru: 'Здравствуйте! (Zdravstvuyte)',
    ko: '안녕하세요 (Annyeonghaseyo)',
  },
  'hi': {
    hi: 'नमस्ते (Namaste)',
    kn: 'ನಮಸ್ಕಾರ (Namaskara)',
    ta: 'வணக்கம் (Vanakkam)',
    te: 'నమస్కారం (Namaskaram)',
    bn: 'নমস্কার (Nomoshkar)',
    mr: 'नमस्कार (Namaskar)',
    es: '¡Hola!',
    fr: 'Salut !',
    de: 'Hallo!',
    ja: 'やあ (Yā)',
    zh: '嗨 (Hāi)',
    ar: 'أهلاً (Ahlan)',
  },
  'good morning': {
    hi: 'शुभ प्रभात (Shubh Prabhat)',
    kn: 'ಶುಭೋದಯ (Shubhōdaya)',
    ta: 'காலை வணக்கம் (Kaalai Vanakkam)',
    te: 'శుభోదయం (Shubhodayam)',
    bn: 'সুপ্রভাত (Suprobhat)',
    mr: 'शुभ प्रभात (Shubh Prabhat)',
    es: '¡Buenos días!',
    fr: 'Bonjour !',
    de: 'Guten Morgen!',
    it: 'Buongiorno!',
    ja: 'おはようございます (Ohayou gozaimasu)',
    zh: '早上好 (Zǎoshang hǎo)',
    ar: 'صباح الخير (Sabah al-khayr)',
  },
  'good evening': {
    hi: 'शुभ संध्या (Shubh Sandhya)',
    kn: 'ಶುಭ ಸಂಜೆ (Shubha Sanje)',
    ta: 'மாலை வணக்கம் (Maalai Vanakkam)',
    te: 'శుభ సాయంత్రం (Shubha Sayanthram)',
    bn: 'শুভ সন্ধ্যা (Shuvo Shondha)',
    es: '¡Buenas tardes / noches!',
    fr: 'Bonsoir !',
    de: 'Guten Abend!',
    ja: 'こんばんは (Konbanwa)',
    zh: '晚上好 (Wǎnshang hǎo)',
    ar: 'مساء الخير (Masa\' al-khayr)',
  },
  'good night': {
    hi: 'शुभ रात्रि (Shubh Ratri)',
    kn: 'ಶುಭ ರಾತ್ರಿ (Shubha Rathri)',
    ta: 'இனிய இரவு (Iniya Iravu)',
    te: 'శుభరాత్రి (Shubharathri)',
    bn: 'শুভ রাত্রি (Shubho Raatri)',
    es: '¡Buenas noches!',
    fr: 'Bonne nuit !',
    de: 'Gute Nacht!',
    ja: 'おやすみなさい (Oyasuminasai)',
    zh: '晚安 (Wǎn\'ān)',
    ar: 'تصبح على خير (Tisbah ala khayr)',
  },
  'thank you': {
    hi: 'धन्यवाद (Dhanyawad)',
    kn: 'ಧನ್ಯವಾದಗಳು (Dhanyavadagalu)',
    ta: 'நன்றி (Nandri)',
    te: 'ధన్యవాదాలు (Dhanyavadalu)',
    bn: 'ধন্যবাদ (Dhonnobad)',
    mr: 'धन्यवाद (Dhanyavad)',
    gu: 'આભાર (Aabhar)',
    ml: 'നന്ദി (Nandi)',
    pa: 'ਧੰਨਵਾਦ (Dhanvaad)',
    ur: 'شکریہ (Shukriya)',
    es: 'Muchas gracias',
    fr: 'Merci beaucoup',
    de: 'Vielen Dank',
    it: 'Grazie mille',
    ja: 'ありがとうございます (Arigatou gozaimasu)',
    zh: '谢谢 (Xièxiè)',
    ar: 'شكراً جزيلاً (Shukran jazeelan)',
    pt: 'Muito obrigado',
    ru: 'Спасибо большое (Spasibo bolshoye)',
    ko: '감사합니다 (Gamsahamnida)',
  },
  'thanks': {
    hi: 'धन्यवाद (Dhanyawad)',
    kn: 'ಧನ್ಯವಾದ (Dhanyavada)',
    ta: 'நன்றி (Nandri)',
    te: 'ధన్యవాదాలు (Dhanyavadalu)',
    es: 'Gracias',
    fr: 'Merci',
    de: 'Danke',
    it: 'Grazie',
    ja: 'ありがとう (Arigatou)',
    zh: '多谢 (Duōxiè)',
    ar: 'شكراً (Shukran)',
  },
  'please': {
    hi: 'कृपया (Kripya)',
    kn: 'ದಯವಿಟ್ಟು (Dayavittu)',
    ta: 'தயவுசெய்து (Thayavu seithu)',
    te: 'దయచేసి (Dayachesi)',
    bn: 'দয়া করে (Doya kore)',
    mr: 'कृपया (Krupaya)',
    gu: 'કૃપા કરીને (Krupa karine)',
    es: 'Por favor',
    fr: "S'il vous plaît",
    de: 'Bitte',
    it: 'Per favore',
    ja: 'お願いします (Onegaishimasu)',
    zh: '请 (Qǐng)',
    ar: 'من فضلك (Min fadlak)',
  },
  'yes': {
    hi: 'हाँ (Haan)',
    kn: 'ಹೌದು (Haudu)',
    ta: 'ஆம் (Aam)',
    te: 'అవును (Avunu)',
    bn: 'হ্যাঁ (Hya)',
    mr: 'हो (Ho)',
    gu: 'હા (Haa)',
    es: 'Sí',
    fr: 'Oui',
    de: 'Ja',
    it: 'Sì',
    ja: 'はい (Hai)',
    zh: '是的 (Shì de)',
    ar: 'نعم (Na\'am)',
    ru: 'Да (Da)',
  },
  'no': {
    hi: 'नहीं (Nahin)',
    kn: 'ಇಲ್ಲ (Illa)',
    ta: 'இல்லை (Illai)',
    te: 'కాదు / లేదు (Kadu / Ledu)',
    bn: 'না (Na)',
    mr: 'नाही (Nahi)',
    gu: 'ના (Naa)',
    es: 'No',
    fr: 'Non',
    de: 'Nein',
    it: 'No',
    ja: 'いいえ (Iie)',
    zh: '不 / 不是 (Bù)',
    ar: 'لا (La)',
    ru: 'Нет (Net)',
  },
  'excuse me': {
    hi: 'माफ़ कीजिए (Maaf kijiye)',
    kn: 'ಕ್ಷಮಿಸಿ (Kshamisi)',
    ta: 'மன்னிக்கவும் (Mannikkavum)',
    te: 'క్షమించండి (Kshaminchandi)',
    bn: 'মাফ করবেন (Maaf korben)',
    mr: 'माफ करा (Maaf kara)',
    es: 'Disculpe / Perdón',
    fr: 'Excusez-moi / Pardon',
    de: 'Entschuldigung',
    it: 'Scusi',
    ja: 'すみません (Sumimasen)',
    zh: '不好意思 / 请问 (Bù hǎoyìsi)',
    ar: 'عفواً / معذرة (Afwan / Ma\'ziratan)',
  },
  'sorry': {
    hi: 'माफ़ करना (Maaf karna)',
    kn: 'ಕ್ಷಮಿಸಿ (Kshamisi)',
    ta: 'மன்னிக்கவும் (Mannikkavum)',
    te: 'నన్ను క్షమించండి (Nannu kshaminchandi)',
    bn: 'দুঃখিত (Dukkhito)',
    es: 'Lo siento',
    fr: 'Désolé',
    de: 'Es tut mir leid',
    ja: 'ごめんなさい (Gomennasai)',
    zh: '对不起 (Duìbùqǐ)',
    ar: 'آسف (Aasif)',
  },
  // Questions & Directions
  'how are you?': {
    hi: 'आप कैसे हैं? (Aap kaise hain?)',
    kn: 'ನೀವು ಹೇಗಿದ್ದೀರಿ? (Neevu hegiddiri?)',
    ta: 'நீங்கள் எப்படி இருக்கிறீர்கள்? (Neengal eppadi irukireerkal?)',
    te: 'మీరు ఎలా ఉన్నారు? (Meeru ela unnaru?)',
    bn: 'আপনি কেমন আছেন? (Apni kemon achhen?)',
    mr: 'तुम्ही कसे आहात? (Tumhi kase aahat?)',
    gu: 'તમે કેમ છો? (Tame kem chho?)',
    ml: 'സുഖമാണോ? (Sukhamano?)',
    pa: 'ਤੁਸੀਂ ਕਿਵੇਂ ਹੋ? (Tusi kivein ho?)',
    es: '¿Cómo estás? / ¿Cómo está usted?',
    fr: 'Comment allez-vous ?',
    de: 'Wie geht es Ihnen?',
    it: 'Come stai?',
    ja: 'お元気ですか？ (Ogenki desu ka?)',
    zh: '你好吗？ (Nǐ hǎo ma?)',
    ar: 'كيف حالك؟ (Kayfa haluk?)',
  },
  'i am fine': {
    hi: 'मैं ठीक हूँ (Main theek hoon)',
    kn: 'ನಾನು ಚೆನ್ನಾಗಿದ್ದೇನೆ (Naanu chennagiddene)',
    ta: 'நான் நன்றாக இருக்கிறேன் (Naan nandraga irukiren)',
    te: 'నేను బాగున్నాను (Nenu bagunnanu)',
    bn: 'আমি ভালো আছি (Ami bhalo achi)',
    es: 'Estoy bien, gracias',
    fr: 'Je vais bien, merci',
    de: 'Mir geht es gut, danke',
    ja: '元気です (Genki desu)',
    zh: '我很好 (Wǒ hěn hǎo)',
  },
  'what is your name?': {
    hi: 'आपका नाम क्या है? (Aapka naam kya hai?)',
    kn: 'ನಿಮ್ಮ ಹೆಸರೇನು? (Nimma hesarenu?)',
    ta: 'உங்கள் பெயர் என்ன? (Ungal peyar enna?)',
    te: 'మీ పేరు ఏమిటి? (Mee peru emiti?)',
    bn: 'আপনার নাম কি? (Apnar naam ki?)',
    mr: 'तुमचे नाव काय आहे? (Tumche naav kaay aahe?)',
    es: '¿Cómo te llamas? / ¿Cuál es su nombre?',
    fr: 'Comment vous appelez-vous ?',
    de: 'Wie heißen Sie?',
    it: 'Come ti chiami?',
    ja: 'お名前は何ですか？ (Onamae wa nan desu ka?)',
    zh: '你叫什么名字？ (Nǐ jiào shénme míngzì?)',
    ar: 'ما اسمك؟ (Ma ismuk?)',
  },
  'where is the restroom?': {
    hi: 'शौचालय कहाँ है? (Shauchalaya kahan hai?)',
    kn: 'ಶೌಚಾಲಯ ಎಲ್ಲಿದೆ? (Shauchalaya ellide?)',
    ta: 'கழிப்பறை எங்கே உள்ளது? (Kazhipparai enge ullathu?)',
    te: 'వాష్‌రూమ్ / టాయిలెట్ ఎక్కడ ఉంది? (Washroom ekkada undi?)',
    bn: 'টয়লেট / বাথরুম কোথায়? (Toilet kothay?)',
    mr: 'शौचालय कुठे आहे? (Shauchalay kuthe aahe?)',
    es: '¿Dónde está el baño?',
    fr: 'Où sont les toilettes ?',
    de: 'Wo ist die Toilette?',
    it: "Dov'è il bagno?",
    ja: 'お手洗いはどこですか？ (Otearai wa doko desu ka?)',
    zh: '洗手间在哪里？ (Xǐshǒujiān zài nǎlǐ?)',
    ar: 'أين الحمام / دورة المياه؟ (Ayna al-hammam?)',
  },
  'where is the toilet?': {
    hi: 'टॉयलेट कहाँ है? (Toilet kahan hai?)',
    kn: 'ಶೌಚಾಲಯ ಎಲ್ಲಿದೆ? (Shauchalaya ellide?)',
    ta: 'கழிப்பறை எங்கே? (Kazhipparai enge?)',
    te: 'టాయిలెట్ ఎక్కడ? (Toilet ekkada?)',
    es: '¿Dónde está el baño?',
    fr: 'Où sont les toilettes ?',
    de: 'Wo ist das WC / die Toilette?',
    ja: 'トイレはどこですか？ (Toire wa doko desu ka?)',
    zh: '厕所在哪里？ (Cèsuǒ zài nǎlǐ?)',
  },
  'how much does this cost?': {
    hi: 'इसकी कीमत क्या है? (Iski keemat kya hai?)',
    kn: 'ಇದರ ಬೆಲೆ ಎಷ್ಟು? (Idara bele eshtu?)',
    ta: 'இதன் விலை என்ன? (Ithan vilai enna?)',
    te: 'దీని ధర ఎంత? (Deeni dhara entha?)',
    bn: 'এটার দাম কত? (Etar daam koto?)',
    mr: 'याची किंमत काय आहे? (Yaachi kimmat kaay aahe?)',
    es: '¿Cuánto cuesta esto?',
    fr: 'Combien ça coûte ?',
    de: 'Wie viel kostet das?',
    it: 'Quanto costa questo?',
    ja: 'これはいくらですか？ (Kore wa ikura desu ka?)',
    zh: '这个多少钱？ (Zhège duōshǎo qián?)',
    ar: 'بكم هذا؟ / كم سعر هذا؟ (Bikam hatha?)',
  },
  'how much?': {
    hi: 'कितना? (Kitna?)',
    kn: 'ಎಷ್ಟು? (Eshtu?)',
    ta: 'எவ்வளவு? (Evvalavu?)',
    te: 'ఎంత? (Entha?)',
    bn: 'কত? (Koto?)',
    es: '¿Cuánto cuesta?',
    fr: 'Combien ?',
    de: 'Wie viel?',
    ja: 'いくら？ (Ikura?)',
    zh: '多少钱？ (Duōshǎo qián?)',
  },
  'where is the hospital?': {
    hi: 'अस्पताल कहाँ है? (Aspataal kahan hai?)',
    kn: 'ಆಸ್ಪತ್ರೆ ಎಲ್ಲಿದೆ? (Aaspathre ellide?)',
    ta: 'மருத்துவமனை எங்கே உள்ளது? (Maruthuvamanai enge ullathu?)',
    te: 'ఆసుపత్రి ఎక్కడ ఉంది? (Aasupatri ekkada undi?)',
    bn: 'হাসপাতাল কোথায়? (Hospital kothay?)',
    es: '¿Dónde está el hospital?',
    fr: "Où est l'hôpital ?",
    de: 'Wo ist das Krankenhaus?',
    ja: '病院はどこですか？ (Byouin wa doko desu ka?)',
    zh: '医院在哪里？ (Yīyuàn zài nǎlǐ?)',
    ar: 'أين المستشفى؟ (Ayna al-mustashfa?)',
  },
  'where is the metro station?': {
    hi: 'मेट्रो स्टेशन कहाँ है? (Metro station kahan hai?)',
    kn: 'ಮೆಟ್ರೋ ನಿಲ್ದಾಣ ಎಲ್ಲಿದೆ? (Metro nildana ellide?)',
    ta: 'மெட்ரோ நிலையம் எங்கே உள்ளது? (Metro nilaiyam enge ullathu?)',
    te: 'మెట్రో స్టేషన్ ఎక్కడ ఉంది? (Metro station ekkada undi?)',
    es: '¿Dónde está la estación de metro?',
    fr: 'Où est la station de métro ?',
    de: 'Wo ist die U-Bahn-Station?',
    ja: '地下鉄の駅はどこですか？ (Chikatetsu no eki wa doko desu ka?)',
    zh: '地铁站在哪里？ (Dìtiě zhàn zài nǎlǐ?)',
  },
  'i need help': {
    hi: 'मुझे मदद चाहिए (Mujhe madad chahiye)',
    kn: 'ನನಗೆ ಸಹಾಯ ಬೇಕು (Nanage sahaya beku)',
    ta: 'எனக்கு உதவி தேவை (Enakku uthavi thevai)',
    te: 'నాకు సహాయం కావాలి (Naaku sahayam kavali)',
    bn: 'আমার সাহায্য দরকার (Amar sahajjo dorkar)',
    es: 'Necesito ayuda',
    fr: "J'ai besoin d'aide",
    de: 'Ich brauche Hilfe',
    ja: '助けが必要です (Tasuke ga hitsuyou desu)',
    zh: '我需要帮助 (Wǒ xūyào bāngzhù)',
    ar: 'أحتاج إلى مساعدة (Ahtaju ila musa\'adah)',
  },
  'help me': {
    hi: 'मेरी मदद करो (Meri madad karo)',
    kn: 'ನನಗೆ ಸಹಾಯ ಮಾಡಿ (Nanage sahaya maadi)',
    ta: 'எனக்கு உதவி செய்யுங்கள் (Enakku uthavi seiyungal)',
    te: 'నాకు సహాయం చేయండి (Naaku sahayam cheyandi)',
    bn: 'আমাকে সাহায্য করুন (Amake sahajjo korun)',
    es: '¡Ayúdame!',
    fr: 'Aidez-moi !',
    de: 'Helfen Sie mir!',
    ja: '助けてください！ (Tasukete kudasai!)',
    zh: '请帮帮我！ (Qǐng bāng bāng wǒ!)',
    ar: 'ساعدني! (Sa\'idni!)',
  },
  'stop': {
    hi: 'रुको (Ruko)',
    kn: 'ನಿಲ್ಲಿಸಿ (Nillisi)',
    ta: 'நிறுத்துங்கள் (Niruthungal)',
    te: 'ఆగండి (Aagandi)',
    bn: 'থামুন (Thamun)',
    es: '¡Alto! / ¡Pare!',
    fr: 'Arrêtez ! / Stop !',
    de: 'Halt! / Stopp!',
    ja: '止まってください (Tomatte kudasai)',
    zh: '停 (Tíng)',
    ar: 'توقف! (Tawaqqaf!)',
  },
  'water': {
    hi: 'पानी (Paani)',
    kn: 'ನೀರು (Neeru)',
    ta: 'தண்ணீர் (Thanneer)',
    te: 'నీరు / మంచి నీళ్ళు (Neeru / Manchi neellu)',
    bn: 'জল / পানি (Jol / Paani)',
    mr: 'पाणी (Paani)',
    gu: 'પાણી (Paani)',
    es: 'Agua',
    fr: 'Eau',
    de: 'Wasser',
    it: 'Acqua',
    ja: '水 (Mizu)',
    zh: '水 (Shuǐ)',
    ar: 'ماء (Maa\')',
  },
  'food': {
    hi: 'खाना / भोजन (Khaana)',
    kn: 'ಊಟ / ಆಹಾರ (Oota / Aahara)',
    ta: 'உணவு / சாப்பாடு (Unavu / Saapaadu)',
    te: 'ఆహారం / భోజనం (Aaharam / Bhojanam)',
    bn: 'খাবার (Khabar)',
    es: 'Comida',
    fr: 'Nourriture',
    de: 'Essen',
    ja: '食べ物 (Tabemono)',
    zh: '食物 (Shíwù)',
    ar: 'طعام (Ta\'am)',
  },
};

// Fuzzy keyword & sentence matcher for offline translations
function handleOfflineTranslation(
  text: string,
  sourceLang: string,
  targetLang: string,
  errMsg?: string
): TranslateApiResponse {
  const cleanInput = text.trim().toLowerCase().replace(/[.,!?;:]/g, '');
  const targetLangObj = findLanguageByName(targetLang);
  const targetCode = (targetLangObj.code || 'en').split('-')[0].toLowerCase();

  // 1. Exact Emergency Phrases Match
  for (const phrase of EMERGENCY_PHRASES) {
    const eng = phrase.englishText.toLowerCase();
    if (cleanInput === eng || cleanInput.includes(eng) || eng.includes(cleanInput)) {
      const translation = phrase.translations[targetCode] || phrase.translations['hi'] || { text: phrase.englishText };
      return {
        success: true,
        originalText: text,
        sourceLang: 'English',
        targetLang,
        detectedLanguage: 'English',
        detectedLanguageCode: 'en',
        confidence: 'high',
        translatedText: translation.text,
        pronunciation: translation.phonetic || null,
        culturalNote: '⚡ Translated instantly via Built-in Offline Emergency Pack',
      };
    }
  }

  // 2. Exact or Substring Match from Offline Multilingual Dictionary
  if (OFFLINE_DICTIONARY[cleanInput]) {
    const entry = OFFLINE_DICTIONARY[cleanInput];
    const trans = (entry as any)[targetCode];
    if (trans) {
      return {
        success: true,
        originalText: text,
        sourceLang,
        targetLang,
        detectedLanguage: sourceLang === 'auto' ? 'English' : sourceLang,
        detectedLanguageCode: 'en',
        confidence: 'high',
        translatedText: trans,
        culturalNote: '⚡ Translated via Offline On-Device Pack',
      };
    }
  }

  // 3. Multi-word phrase keyword search (e.g. "where is the metro", "need help", "toilet")
  for (const [key, entry] of Object.entries(OFFLINE_DICTIONARY)) {
    if (cleanInput.includes(key) || key.includes(cleanInput)) {
      const trans = (entry as any)[targetCode];
      if (trans) {
        return {
          success: true,
          originalText: text,
          sourceLang,
          targetLang,
          detectedLanguage: sourceLang === 'auto' ? 'English' : sourceLang,
          detectedLanguageCode: 'en',
          confidence: 'high',
          translatedText: trans,
          culturalNote: '⚡ Smart offline phrase match',
        };
      }
    }
  }

  // 4. Token-by-token fallback translation
  const words = cleanInput.split(/\s+/);
  const translatedTokens: string[] = [];
  let foundAny = false;

  for (const word of words) {
    if (OFFLINE_DICTIONARY[word] && (OFFLINE_DICTIONARY[word] as any)[targetCode]) {
      translatedTokens.push((OFFLINE_DICTIONARY[word] as any)[targetCode]);
      foundAny = true;
    } else {
      translatedTokens.push(word);
    }
  }

  if (foundAny) {
    return {
      success: true,
      originalText: text,
      sourceLang,
      targetLang,
      detectedLanguage: sourceLang === 'auto' ? 'English' : sourceLang,
      detectedLanguageCode: 'en',
      confidence: 'medium',
      translatedText: translatedTokens.join(' '),
      culturalNote: '⚡ Offline word-level translation pack active',
    };
  }

  // 5. General Offline Pack Fallback Indicator
  return {
    success: true,
    originalText: text,
    sourceLang,
    targetLang,
    detectedLanguage: sourceLang === 'auto' ? 'English' : sourceLang,
    detectedLanguageCode: 'en',
    confidence: 'medium',
    translatedText: `[Offline ${targetLang}]: ${text}`,
    culturalNote: errMsg ? `Note: Offline Mode active (${errMsg})` : '⚡ Offline Mode Active (No internet required)',
  };
}
