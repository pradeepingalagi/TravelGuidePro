import { 
  DestinationCity, 
  TravelDocument, 
  ScamGuardResult, 
  AgentChatMessage, 
  AgentActionCard 
} from '../types/travel';
import { INITIAL_TRAVEL_DOCUMENTS, CITIES_DATA } from '../data/travelData';

const DOCUMENTS_STORAGE_KEY = 'omnitranslate_travel_documents';
const DESTINATION_STORAGE_KEY = 'omnitranslate_active_destination';

export function loadStoredTravelDocuments(): TravelDocument[] {
  try {
    const data = localStorage.getItem(DOCUMENTS_STORAGE_KEY);
    if (data) {
      const parsed = JSON.parse(data);
      if (Array.isArray(parsed)) {
        // Keep all user documents; only exclude legacy mock samples
        const realDocs = parsed.filter(doc => 
          doc && doc.id && 
          !doc.id.startsWith('dummy_') && 
          !doc.id.startsWith('sample_') && 
          !doc.id.startsWith('demo_')
        );
        return realDocs;
      }
    }
  } catch (e) {
    console.warn('Failed to load travel documents from storage', e);
  }
  return [];
}

export function saveStoredTravelDocuments(docs: TravelDocument[]): void {
  try {
    localStorage.setItem(DOCUMENTS_STORAGE_KEY, JSON.stringify(docs));
  } catch (e) {
    console.warn('Failed to save travel documents to storage', e);
  }
}

export function loadActiveDestination(): DestinationCity {
  try {
    const data = localStorage.getItem(DESTINATION_STORAGE_KEY);
    if (data && typeof data === 'string' && data.trim()) {
      return data.trim();
    }
  } catch {}
  return 'Delhi, India';
}

export function saveActiveDestination(city: DestinationCity): void {
  try {
    localStorage.setItem(DESTINATION_STORAGE_KEY, city);
  } catch {}
}

const agentLocalCache = new Map<string, { reply: string; actionCard?: AgentActionCard; followUps?: string[] }>();
const scamLocalCache = new Map<string, ScamGuardResult>();

export async function askAITravelAgent(
  prompt: string,
  destination: DestinationCity,
  language = 'English'
): Promise<{ reply: string; actionCard?: AgentActionCard; followUps?: string[] }> {
  const cacheKey = `${destination}|${language}|${prompt.trim().toLowerCase()}`;
  if (agentLocalCache.has(cacheKey)) {
    return agentLocalCache.get(cacheKey)!;
  }

  try {
    const res = await fetch('/api/travel-agent/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message: prompt,
        destination,
        language,
      }),
    });

    if (res.ok) {
      const data = await res.json();
      if (data.reply) {
        const result = {
          reply: data.reply,
          actionCard: data.actionCard,
          followUps: data.followUps,
        };
        agentLocalCache.set(cacheKey, result);
        if (agentLocalCache.size > 100) {
          const firstKey = agentLocalCache.keys().next().value;
          if (firstKey) agentLocalCache.delete(firstKey);
        }
        return result;
      }
    }
  } catch (e) {
    console.warn('Backend travel agent call failed, using intelligent fallback rules:', e);
  }

  // High-acuity heuristic fallback tailored directly to user queries
  const lower = prompt.toLowerCase();
  const cityProfile = CITIES_DATA[destination] || CITIES_DATA['Tokyo, Japan'];

  if (lower.includes('flight') && (lower.includes('delayed') || lower.includes('cancelled') || lower.includes('cancel'))) {
    return {
      reply: `✈️ Here is your immediate Flight Delay Action Plan for ${destination}:\n\n` +
        `1. **Keep Your Boarding Pass & Receipts:** Under international aviation regulations (EU261, US DOT, and local CAA rules), you are entitled to meals, refreshments, and free telephone/internet access for delays over 2-3 hours.\n` +
        `2. **Duty of Care:** If the delay stretches overnight, the operating airline MUST provide complimentary hotel accommodation and airport ground transit.\n` +
        `3. **Rebooking:** Head directly to the airline customer service desk or use their smartphone app to secure free re-routing on the next available flight or partner alliance carrier.\n` +
        `4. **Compensation Eligibility:** You may be entitled to between $250 - $700 (€250 - €600) cash compensation unless caused by extraordinary weather or air traffic control strikes.`,
      actionCard: {
        type: 'flight_rights',
        title: 'Flight Delay & Passenger Rights Guide',
        subtitle: 'Official Airline Rebooking Protocol',
        details: {
          'Entitlements': 'Meals, refreshments, hotel if overnight',
          'Cash Claim Range': '€250 - €600 / $250 - $700 depending on distance',
          'Key Step': 'Request official written Reason for Delay at the gate',
        },
        primaryActionLabel: 'Draft Claim Letter',
        secondaryActionLabel: 'Search Alternate Flights',
      },
      followUps: [
        'How do I claim meal vouchers from the gate agent?',
        'What are the alternative flights from here today?',
        'Draft an official compensation email to the airline',
      ],
    };
  }

  if (lower.includes('taxi') || lower.includes('hotel') || lower.includes('driver')) {
    const hotelDoc = loadStoredTravelDocuments().find(d => d.type === 'hotel');
    const hotelName = hotelDoc?.title.replace('Hotel Reservation: ', '') || 'Park Hyatt Tokyo';
    const hotelNotes = hotelDoc?.notes || '3-7-1-2 Nishi-Shinjuku, Shinjuku City';

    return {
      reply: `🚕 Here is a high-visibility Driver Destination Card to show your taxi driver in ${cityProfile.country}. It displays your destination in the native script, phonetic reading, and official taxi meter notice so you avoid getting overcharged!`,
      actionCard: {
        type: 'taxi_card',
        title: `Take Me To: ${hotelName}`,
        subtitle: `Destination Card for Taxi Driver in ${cityProfile.primaryLanguage}`,
        nativeScript: cityProfile.primaryLanguageCode === 'ja'
          ? `運転手さん、このホテルまでお願いします：\n【${hotelName}】\n東京都新宿区西新宿3-7-1-2\nメーターを使ってください。領収書をお願いします。`
          : cityProfile.primaryLanguageCode === 'th'
          ? `พี่คนขับครับ ไปส่งที่โรงแรมนี้ครับ:\n【${hotelName}】\nกรุณาเปิดมิเตอร์ด้วยครับ ขอบคุณครับ`
          : cityProfile.primaryLanguageCode === 'fr'
          ? `Bonjour monsieur, déposez-moi s'il vous plaît à cet hôtel :\n【${hotelName}】\nMerci d'enclencher le compteur.`
          : `Please take me to this hotel: ${hotelName}. Please turn on the official meter. Thank you!`,
        phonetic: cityProfile.primaryLanguageCode === 'ja'
          ? 'Unten-shu-san, kono hoteru made onegaishimasu: Park Hyatt Tokyo. Meetaa wo tsukatte kudasai.'
          : cityProfile.primaryLanguageCode === 'th'
          ? 'Pii kon-khab khrap, pai song thee rong-raem nee khrap. Karunaa perd mee-ter duay khrap.'
          : 'Bonjour, kon-dweet mwah ah seht oh-tehl.',
        details: {
          'Hotel': hotelName,
          'Address': hotelNotes,
          'Local Emergency No': cityProfile.emergencyNumber,
          'Rate Type': 'Official Regulated Meter',
        },
        primaryActionLabel: 'Show Fullscreen Driver Card',
        secondaryActionLabel: 'Play Native Speech for Driver',
      },
      followUps: [
        'What is the typical taxi fare to this hotel?',
        'How do I hail an official taxi in this city?',
        'Show airport pickup points',
      ],
    };
  }

  if (lower.includes('hospital') || lower.includes('doctor') || lower.includes('medical') || lower.includes('sick')) {
    const hospital = cityProfile.nearbyPlaces.find(p => p.category === 'hospital') || cityProfile.nearbyPlaces[0];
    return {
      reply: `🏥 The nearest accredited English-speaking emergency hospital in ${cityProfile.city} is **${hospital.name}** (${hospital.distance} away, ~${hospital.walkingTime}).\n\n` +
        `• **Phone:** ${hospital.phone}\n` +
        `• **Local Emergency Dispatch:** Call **${cityProfile.ambulanceNumber}** immediately if it is a life-threatening crisis.\n` +
        `• **Local Address to show driver:** ${hospital.localLanguageAddress}`,
      actionCard: {
        type: 'hospital_radar',
        title: hospital.name,
        subtitle: hospital.localName || 'Emergency Care',
        nativeScript: hospital.localLanguageAddress,
        phonetic: hospital.phoneticAddress,
        details: {
          'Distance': hospital.distance,
          'Status': hospital.openStatus,
          'Phone': hospital.phone,
          'Ambulance Hotline': cityProfile.ambulanceNumber,
        },
        primaryActionLabel: `Call Hospital (${hospital.phone})`,
        secondaryActionLabel: 'Open Navigation Directions',
      },
      followUps: [
        'How do I explain my medical symptoms in the local language?',
        'Where is the nearest 24-hour pharmacy?',
        'How does travel insurance claim for emergency hospital visits work?',
      ],
    };
  }

  if (lower.includes('menu') || lower.includes('food') || lower.includes('dish') || lower.includes('restaurant')) {
    return {
      reply: `🍜 To translate foreign menus with 100% accuracy:\n\n` +
        `1. **Launch Camera Translate:** Tap the Camera tab or the OCR button below to point your phone directly at the printed menu, chalkboard, or wine list.\n` +
        `2. **Dietary & Allergy Filter:** Gemini will identify whether dishes contain pork, beef, seafood, dairy, nuts, or gluten, plus display romanized pronunciation and price conversions!\n` +
        `3. **Order with confidence:** Tap on any dish block to hear native pronunciation for the server.`,
      actionCard: {
        type: 'custom',
        title: 'Instant Menu & Sign Scanner',
        subtitle: 'Powered by Multimodal Vision OCR',
        details: {
          'Features': 'Allergy alerts, price conversion, native phonetic ordering',
          'Target Language': cityProfile.primaryLanguage,
        },
        primaryActionLabel: 'Open Camera Translator',
        secondaryActionLabel: 'View Food Phrases',
      },
      followUps: [
        'How do I say "I am vegetarian / allergic to peanuts"?',
        'What are the must-try local specialties here?',
        'Is tipping expected at this restaurant?',
      ],
    };
  }

  if (
    lower.includes('currency') ||
    lower.includes('convert') ||
    lower.includes('exchange') ||
    lower.includes('rate') ||
    lower.includes('tipping') ||
    lower.includes('tip') ||
    lower.includes('money') ||
    lower.includes('usd') ||
    lower.includes('dollar') ||
    lower.includes('euro') ||
    lower.includes('yen') ||
    lower.includes('baht') ||
    lower.includes('inr') ||
    lower.includes('cost') ||
    lower.includes('price')
  ) {
    // Extract any number in the user query, default to 100
    const numberMatch = prompt.match(/\b\d+(\.\d+)?\b/);
    const amount = numberMatch ? parseFloat(numberMatch[0]) : 100;

    let liveRate = cityProfile.currency.rate;
    let rateSource = 'Benchmark Rate';

    try {
      const rateRes = await fetch(`/api/currency/rate?from=USD&to=${cityProfile.localCurrency}`);
      if (rateRes.ok) {
        const rJson = await rateRes.json();
        if (rJson.rate && typeof rJson.rate === 'number') {
          liveRate = rJson.rate;
          rateSource = rJson.source || 'European Central Bank (Frankfurter API)';
        }
      }
    } catch {}

    const converted = (amount * liveRate).toLocaleString('en-US', {
      maximumFractionDigits: liveRate > 10 ? 0 : 2,
    });

    return {
      reply: `💵 **Currency & Conversion Insights for ${destination}**:\n\n` +
        `• **Local Currency:** ${cityProfile.localCurrency} (${cityProfile.localCurrencySymbol})\n` +
        `• **Exchange Rate:** 1 USD = **${liveRate} ${cityProfile.localCurrency}** (${rateSource})\n` +
        `• **Live Conversion:** $${amount} USD ≈ **${cityProfile.localCurrencySymbol} ${converted} ${cityProfile.localCurrency}**\n` +
        `• **Tipping Custom:** ${cityProfile.currency.tipEtiquette}\n` +
        `• **Local Cost Averages:** Coffee ~${cityProfile.currency.pricingInsights.coffee}, Casual Meal ~${cityProfile.currency.pricingInsights.casualMeal}, Metered Taxi Base ~${cityProfile.currency.pricingInsights.taxiBase}.\n` +
        `• **Payment Advice:** Most hotels, department stores, and rail transit accept international cards (Visa/Mastercard), but keep small cash notes (${cityProfile.localCurrency}) for local markets, street stalls, and temple entries.`,
      actionCard: {
        type: 'currency_conversion',
        title: `${cityProfile.localCurrency} Currency & Conversion Guide`,
        subtitle: `1 USD = ${liveRate} ${cityProfile.localCurrency} • ${rateSource}`,
        details: {
          'Conversion Estimate': `$${amount} USD = ${cityProfile.localCurrencySymbol} ${converted}`,
          'Exchange Rate': `1 USD = ${liveRate} ${cityProfile.localCurrency}`,
          'Rate Source': rateSource,
          'Tipping Etiquette': cityProfile.currency.tipEtiquette,
          'Coffee / Casual Meal': `${cityProfile.currency.pricingInsights.coffee} / ${cityProfile.currency.pricingInsights.casualMeal}`,
          'Taxi Base Fare': cityProfile.currency.pricingInsights.taxiBase,
        },
        primaryActionLabel: `Convert $${amount * 2}`,
        secondaryActionLabel: 'Ask Another Currency Query',
      },
      followUps: [
        `How much is $250 USD in ${cityProfile.localCurrency}?`,
        `Where are the best zero-fee ATMs in ${cityProfile.city}?`,
        `Is tipping required at restaurants in ${cityProfile.country}?`,
      ],
    };
  }

  // General helpful response
  return {
    reply: `I am your AI Travel Agent for **${destination}**. Here is the live status for your trip:\n\n` +
      `• **Weather:** ${cityProfile.weather.condition}, ${cityProfile.weather.tempC}°C (${cityProfile.weather.tempF}°F). ${cityProfile.weather.advisory}\n` +
      `• **Primary Language:** ${cityProfile.primaryLanguage}\n` +
      `• **Transit Tip:** ${cityProfile.transport[0]?.keyAdvice || 'Public transit is safe and punctual.'}\n` +
      `• **Emergency Hotline:** ${cityProfile.emergencyNumber}`,
    followUps: [
      'My flight is delayed. What should I do?',
      'How do I tell the taxi driver where my hotel is?',
      'Find the nearest hospital or 24/7 pharmacy',
      'Check if this taxi quote or restaurant bill is a scam',
    ],
  };
}

export async function checkScamAndPriceGuard(
  query: string,
  destination: DestinationCity,
  type = 'taxi_fare'
): Promise<ScamGuardResult> {
  const cacheKey = `${destination}|${type}|${query.trim().toLowerCase()}`;
  if (scamLocalCache.has(cacheKey)) {
    return scamLocalCache.get(cacheKey)!;
  }

  try {
    const res = await fetch('/api/travel-agent/scam-guard', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query, destination, type }),
    });
    if (res.ok) {
      const data = await res.json();
      if (data.analysisSummary) {
        scamLocalCache.set(cacheKey, data);
        return data;
      }
    }
  } catch (e) {
    console.warn('Scam guard endpoint offline, evaluating locally:', e);
  }

  const city = CITIES_DATA[destination] || CITIES_DATA['Tokyo, Japan'];
  const lower = query.toLowerCase();

  // Heuristic analysis based on city benchmarks
  const isHighFare = /\b(\d{3,5})\b/.test(query) && (lower.includes('taxi') || lower.includes('cab') || lower.includes('fare'));
  const isSuspiciousMessage = lower.includes('link') || lower.includes('bank') || lower.includes('otp') || lower.includes('click') || lower.includes('urgent');

  if (isSuspiciousMessage) {
    return {
      riskLevel: 'high_risk',
      category: 'suspicious_message',
      analysisSummary: 'CRITICAL PHISHING RISK: Legitimate airlines, immigration authorities, and banks never ask for card PINs, CVV, or one-time codes over unverified SMS or WhatsApp links.',
      redFlags: [
        'Urgent pressure creating artificial panic about flight cancellation or passport penalty',
        'Shortened URL or mismatched domain (not official airline or government domain)',
        'Requesting immediate credit card verification or wire transfer',
      ],
      actionAdvice: [
        'DO NOT click any link or send reply messages.',
        'Check your official airline booking by opening their app directly or at the physical check-in counter.',
        'Block the sending number immediately.',
      ],
      localRefusalScript: {
        nativeText: 'No thanks. I will verify directly at the official counter.',
        phonetic: 'No thanks. I will verify at the counter.',
        englishTranslation: 'I will check with official personnel directly.',
      },
    };
  }

  if (lower.includes('meter') && (lower.includes('broken') || lower.includes('refuse') || lower.includes('fixed'))) {
    return {
      riskLevel: 'high_risk',
      category: 'taxi_fare',
      estimatedFairPrice: 'Standard Regulated Meter Rate',
      quotedPrice: 'Flat arbitrary quote',
      analysisSummary: 'CLASSIC TAXI OVERCHARGE SCAM: Claiming the taximeter is "broken", "off during rush hour", or quoting an arbitrary fixed price is an internationally recognized overcharge tactic.',
      redFlags: [
        'Driver refused to engage the mechanical or digital taximeter',
        'Offered an arbitrary high flat fare far exceeding standard metered rates',
        'Stated destination is "too far" or "closed" to charge a premium',
      ],
      actionAdvice: [
        'Firmly say: "Please turn on the meter, or I will step out and take another taxi."',
        'Point to the taximeter on the dashboard.',
        'If they refuse, calmly exit the vehicle and hail an official taxi or open an app like Uber/Grab/GO.',
      ],
      localRefusalScript: city.primaryLanguageCode === 'ja'
        ? {
            nativeText: 'メーターを入れてください。入れないなら降ります。',
            phonetic: 'Meetaa wo irete kudasai. Irenai nara orimasu.',
            englishTranslation: 'Please turn on the meter. If not, I will step out.',
          }
        : city.primaryLanguageCode === 'th'
        ? {
            nativeText: 'กรุณาเปิดมิเตอร์ครับ ถ้าไม่เปิดขอลงครับ',
            phonetic: 'Karunaa perd mee-ter khrap. Thaa mai perd khor long khrap.',
            englishTranslation: 'Please turn on the meter. If you will not, I will step out.',
          }
        : city.primaryLanguageCode === 'it'
        ? {
            nativeText: 'Per favore, accenda il tassametro o scendo dal taxi.',
            phonetic: 'Per fah-voreh, ah-chendah eel tahs-sah-meh-troh.',
            englishTranslation: 'Please turn on the meter or I will get out.',
          }
        : {
            nativeText: 'Please turn on the meter or I will exit.',
            phonetic: 'Please turn on the meter.',
            englishTranslation: 'Please use the official meter.',
          },
    };
  }

  return {
    riskLevel: 'caution',
    category: 'taxi_fare',
    estimatedFairPrice: 'Standard Regulated Meter Rate',
    quotedPrice: query,
    analysisSummary: `PRICE GUARD ADVISORY for ${destination}: Always confirm whether tax, service charge, or airport supplements are legally included before agreeing to any cash transaction.`,
    redFlags: [
      'Lack of itemized printed receipt with business tax registration number',
      'Verbal price differences before and after service completion',
    ],
    actionAdvice: [
      `Ask for a printed or digital receipt ("Receipt please / ${city.primaryLanguage === 'Japanese' ? 'Ryoshusho' : 'Facture/Ricevuta'}").`,
      'Pay with contactless credit card or digital wallet where possible for dispute protection and chargeback safety.',
    ],
    localRefusalScript: {
      nativeText: 'Can I have an itemized receipt with tax, please?',
      phonetic: 'Receipt please with itemized breakdown.',
      englishTranslation: 'Please provide an official itemized receipt.',
    },
  };
}
