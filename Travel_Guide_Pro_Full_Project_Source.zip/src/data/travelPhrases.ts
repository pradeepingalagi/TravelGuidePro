import { TravelPhraseCategory } from '../types';

export const TRAVEL_CATEGORIES: TravelPhraseCategory[] = [
  {
    id: 'hospital',
    title: 'Hospital & Health',
    icon: 'Hospital',
    phrases: [
      { id: 'h1', english: 'Where is the nearest hospital or clinic?', context: 'Asking for medical facility' },
      { id: 'h2', english: 'I need to see an English or Hindi speaking doctor.', context: 'Language preference' },
      { id: 'h3', english: 'I need a pharmacy to buy this medicine.', context: 'Pharmacy' },
      { id: 'h4', english: 'I feel dizzy, nauseous, and have a fever.', context: 'Symptoms' },
      { id: 'h5', english: 'Do you accept international travel insurance?', context: 'Payment & Insurance' },
    ],
  },
  {
    id: 'food',
    title: 'Restaurant & Dining',
    icon: 'Utensils',
    phrases: [
      { id: 'f1', english: 'A table for two, please.', context: 'Table reservation' },
      { id: 'f2', english: 'Do you have a vegetarian or vegan menu?', context: 'Dietary requirements' },
      { id: 'f3', english: 'Is this food spicy or halal?', context: 'Food preference' },
      { id: 'f4', english: 'Could we please have the bill / check?', context: 'Payment' },
      { id: 'f5', english: 'What is the chef’s special recommendation today?', context: 'Recommendations' },
      { id: 'f6', english: 'Can I pay with a credit card or digital wallet?', context: 'Payment' },
    ],
  },
  {
    id: 'transport',
    title: 'Taxi & Transport',
    icon: 'Car',
    phrases: [
      { id: 't1', english: 'Please take me to this address.', context: 'Taxi direction' },
      { id: 't2', english: 'How much does it cost to get to the airport?', context: 'Fare inquiry' },
      { id: 't3', english: 'Please turn on the taximeter.', context: 'Meter request' },
      { id: 't4', english: 'Which train / bus platform goes to the city center?', context: 'Public transit' },
      { id: 't5', english: 'Please stop here, thank you.', context: 'Drop off' },
    ],
  },
  {
    id: 'directions',
    title: 'Directions & City',
    icon: 'Compass',
    phrases: [
      { id: 'd1', english: 'Excuse me, how do I get to the metro station?', context: 'Metro directions' },
      { id: 'd2', english: 'Is this within walking distance or should I take a cab?', context: 'Distance' },
      { id: 'd3', english: 'Can you show me where we are on Google Maps?', context: 'Map assistance' },
      { id: 'd4', english: 'Where is the nearest public restroom / toilet?', context: 'Restroom' },
      { id: 'd5', english: 'Is this area safe to walk around at night?', context: 'Safety' },
    ],
  },
  {
    id: 'hotel',
    title: 'Hotel & Stay',
    icon: 'Building',
    phrases: [
      { id: 'ht1', english: 'I have a reservation under my name.', context: 'Check-in' },
      { id: 'ht2', english: 'What time is breakfast and check-out?', context: 'Hotel timings' },
      { id: 'ht3', english: 'What is the Wi-Fi password in the room?', context: 'Internet access' },
      { id: 'ht4', english: 'Can you keep my luggage stored until my evening flight?', context: 'Luggage storage' },
      { id: 'ht5', english: 'Could you arrange an airport taxi for tomorrow morning?', context: 'Concierge' },
    ],
  },
  {
    id: 'shopping',
    title: 'Shopping & Bargaining',
    icon: 'ShoppingBag',
    phrases: [
      { id: 's1', english: 'How much does this item cost?', context: 'Price inquiry' },
      { id: 's2', english: 'Can you give me a discount for paying cash?', context: 'Bargaining' },
      { id: 's3', english: 'Do you have this in a larger or smaller size?', context: 'Sizes' },
      { id: 's4', english: 'Can I try this on in the fitting room?', context: 'Trying clothes' },
      { id: 's5', english: 'Can I get a tax-free refund invoice for tourists?', context: 'Tax refund' },
    ],
  },
];
