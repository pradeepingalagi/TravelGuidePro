export type PresetDestinationCity = 
  | 'Tokyo, Japan'
  | 'Paris, France'
  | 'Rome, Italy'
  | 'Bangkok, Thailand'
  | 'Delhi, India'
  | 'London, UK'
  | 'New York, USA'
  | 'Dubai, UAE'
  | 'Singapore'
  | 'Barcelona, Spain';

export type DestinationCity = PresetDestinationCity | (string & {});

export interface WeatherCondition {
  tempC: number;
  tempF: number;
  condition: string;
  icon: string; // emoji or condition key
  humidity: number;
  uvIndex: number;
  rainChance: number;
  airQuality: string;
  advisory?: string;
  forecast: {
    day: string;
    tempC: number;
    condition: string;
    icon: string;
  }[];
}

export type AlertSeverity = 'critical' | 'warning' | 'info';
export type AlertCategory = 'weather' | 'traffic' | 'transit' | 'safety' | 'flight';

export interface TravelAlert {
  id: string;
  title: string;
  description: string;
  category: AlertCategory;
  severity: AlertSeverity;
  timestamp: number;
  actionRecommendation?: string;
  isDismissed?: boolean;
}

export type PlaceCategory = 'hospital' | 'police' | 'pharmacy' | 'atm' | 'fuel' | 'transit';

export interface NearbyPlace {
  id: string;
  name: string;
  localName?: string;
  category: PlaceCategory;
  distance: string; // e.g. "0.4 km"
  walkingTime: string; // e.g. "5 min walk"
  address: string;
  localLanguageAddress: string; // in native script for taxi/locals
  phoneticAddress?: string;
  phone: string;
  openStatus: 'Open 24/7' | 'Open now' | 'Closes soon' | 'Closed';
  isEmergency?: boolean;
  rating: number;
}

export interface CurrencyRate {
  baseCode: string;
  baseSymbol: string;
  targetCode: string;
  targetSymbol: string;
  rate: number; // 1 base = rate target
  tipEtiquette: string;
  pricingInsights: {
    coffee: string;
    casualMeal: string;
    taxiBase: string;
    metroTicket: string;
  };
}

export interface LocalTransportOption {
  type: 'metro' | 'bus' | 'taxi' | 'rideshare' | 'train';
  name: string;
  recommendedApps: string[];
  paymentMethods: string;
  typicalCost: string;
  keyAdvice: string;
}

export type DocumentType = 'passport' | 'visa' | 'ticket' | 'hotel' | 'insurance';

export interface TravelDocument {
  id: string;
  type: DocumentType;
  title: string;
  holderName: string;
  documentNumber: string;
  expiryDate?: string;
  bookingRef?: string;
  destination?: string;
  emergencyContact?: string;
  notes?: string;
  lastUpdated: number;
  fileData?: string; // Base64 data URL for document photo/scan
  fileName?: string;
}

export interface AgentActionCard {
  type: 'taxi_card' | 'flight_rights' | 'scam_report' | 'hospital_radar' | 'document_ref' | 'currency_conversion' | 'custom';
  title: string;
  subtitle?: string;
  details?: Record<string, string>;
  nativeScript?: string;
  phonetic?: string;
  primaryActionLabel?: string;
  secondaryActionLabel?: string;
}

export interface AgentChatMessage {
  id: string;
  sender: 'user' | 'agent';
  text: string;
  timestamp: number;
  actionCard?: AgentActionCard;
  suggestedFollowUps?: string[];
  isThinking?: boolean;
}

export interface ScamGuardResult {
  riskLevel: 'safe' | 'caution' | 'high_risk';
  category: 'taxi_fare' | 'restaurant_bill' | 'street_vendor' | 'suspicious_message' | 'currency_exchange' | 'general';
  estimatedFairPrice?: string;
  quotedPrice?: string;
  analysisSummary: string;
  redFlags: string[];
  actionAdvice: string[];
  localRefusalScript: {
    nativeText: string;
    phonetic: string;
    englishTranslation: string;
  };
}
